# JARVIS Android App (Part 7) — SOURCE PART 2 of 5

Is file mein neeche diye gaye project files ka poora, unchanged source hai. Har file `=== FILE: <path> ===` se shuru aur `=== END FILE ===` pe khatam hoti hai. Path exactly waise hi banana hai jaisa likha hai.

Files in this part:
- app/src/main/java/com/jarvis/assistant/background/JarvisConversationService.kt
- app/src/main/java/com/jarvis/assistant/data/memory/MemoryDao.kt
- app/src/main/java/com/jarvis/assistant/data/memory/MemoryDatabase.kt
- app/src/main/java/com/jarvis/assistant/data/memory/MemoryEntity.kt
- app/src/main/java/com/jarvis/assistant/data/memory/MemoryManager.kt
- app/src/main/java/com/jarvis/assistant/data/memory/MemoryRepository.kt
- app/src/main/java/com/jarvis/assistant/data/model/ChatTurn.kt
- app/src/main/java/com/jarvis/assistant/data/model/ConversationState.kt
- app/src/main/java/com/jarvis/assistant/data/model/GeminiLiveModels.kt
- app/src/main/java/com/jarvis/assistant/data/preferences/AppPreferences.kt
- app/src/main/java/com/jarvis/assistant/data/preferences/YouTubePreferences.kt
- app/src/main/java/com/jarvis/assistant/data/repository/ChatRepository.kt
- app/src/main/java/com/jarvis/assistant/network/GeminiLiveWebSocket.kt
- app/src/main/java/com/jarvis/assistant/security/AppIdentityVerifier.kt
- app/src/main/java/com/jarvis/assistant/security/DeveloperInfo.kt
- app/src/main/java/com/jarvis/assistant/security/SecurityManager.kt
- app/src/main/java/com/jarvis/assistant/ui/agent/TaskProgressOverlay.kt
- app/src/main/java/com/jarvis/assistant/ui/chat/ChatAdapter.kt
- app/src/main/java/com/jarvis/assistant/ui/chat/ChatFragment.kt
- app/src/main/java/com/jarvis/assistant/ui/chat/ChatHistoryBottomSheet.kt
- app/src/main/java/com/jarvis/assistant/ui/chat/JarvisChatAdapter.kt
- app/src/main/java/com/jarvis/assistant/ui/chat/NairaChatAdapter.kt
- app/src/main/java/com/jarvis/assistant/ui/home/HomeFragment.kt


=== FILE: app/src/main/java/com/jarvis/assistant/background/JarvisConversationService.kt ===
```kotlin
package com.jarvis.assistant.background

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.audio.VoskModelManager
import org.json.JSONObject
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener as VoskRecognitionListener
import org.vosk.android.SpeechService
import com.jarvis.assistant.audio.AudioPlayer
import com.jarvis.assistant.audio.AudioRecorder
import com.jarvis.assistant.data.model.ConversationState
import com.jarvis.assistant.network.GeminiLiveWebSocket
import com.jarvis.assistant.ui.home.MainActivity
import com.jarvis.assistant.util.PermissionHelper
import com.jarvis.assistant.util.PromptGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import java.util.concurrent.CopyOnWriteArrayList
import java.util.Locale

data class JarvisLiveError(
    val title: String,
    val message: String,
    val errorCode: String,
    val actionText: String = "FIX IN SETTINGS"
)

/**
 * Owns the *entire* Jarvis conversation lifecycle: the microphone, the audio
 * player, the Gemini Live WebSocket, the 120-second inactivity timer, and the
 * wake-word standby listener.
 *
 * This intentionally does NOT live inside the Activity/ViewModel. When the
 * user removes the app from Recents (or the screen turns off), Android
 * destroys the Activity and its ViewModel - if the live session lived there,
 * the conversation would die with it. Because everything here is owned by a
 * foreground service instead, the mic stays on and Jarvis keeps talking
 * normally even with the app closed. The Activity/ViewModel only *observes*
 * this service's state through the companion StateFlows below; they never
 * own the audio pipeline.
 */
class JarvisConversationService : Service() {

    companion object {
        const val ACTION_START_CONVERSATION = "com.jarvis.assistant.START_CONVERSATION"
        const val ACTION_STOP_ALL = "com.jarvis.assistant.STOP_ALL"
        const val ACTION_ENTER_STANDBY = "com.jarvis.assistant.ENTER_STANDBY"

        private const val CHANNEL_ID = "jarvis_conversation"
        private const val NOTIFICATION_ID = 41
        private const val INACTIVITY_TIMEOUT_MS = 30 * 60 * 1000L // 30 minutes before standby
        private const val STANDBY_COOLDOWN_MS = 2500L

        @Volatile private var activeInstance: JarvisConversationService? = null

        private val _isSessionOn = MutableStateFlow(false)
        val isSessionOn: StateFlow<Boolean> = _isSessionOn.asStateFlow()

        private val _isStandby = MutableStateFlow(false)
        val isStandby: StateFlow<Boolean> = _isStandby.asStateFlow()

        private val _liveError = MutableStateFlow<JarvisLiveError?>(null)
        val liveError: StateFlow<JarvisLiveError?> = _liveError.asStateFlow()

        fun clearLiveError() {
            _liveError.value = null
        }

        fun setLiveError(error: JarvisLiveError) {
            _liveError.value = error
        }

        private val _conversationState = MutableStateFlow(ConversationState.IDLE)
        val conversationState: StateFlow<ConversationState> = _conversationState.asStateFlow()

        private val _connectionStatus = MutableStateFlow("READY")
        val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

        private val _audioLevel = MutableStateFlow(0f)
        val audioLevel: StateFlow<Float> = _audioLevel.asStateFlow()

        private val _audioFrequency = MutableStateFlow(com.jarvis.assistant.audio.AudioFrequencyData())
        val audioFrequency: StateFlow<com.jarvis.assistant.audio.AudioFrequencyData> = _audioFrequency.asStateFlow()

        private val _liveUserTranscript = MutableStateFlow("")
        val liveUserTranscript: StateFlow<String> = _liveUserTranscript.asStateFlow()

        private val _liveAssistantResponse = MutableStateFlow("")
        val liveAssistantResponse: StateFlow<String> = _liveAssistantResponse.asStateFlow()

        private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
        val events: SharedFlow<String> = _events.asSharedFlow()

        /** True once a wake word has just brought the conversation back, for a one-off UI toast. */
        private val _wakeEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
        val wakeEvents: SharedFlow<Unit> = _wakeEvents.asSharedFlow()

        fun setMicMuted(muted: Boolean) {
            activeInstance?.audioRecorder?.setMuted(muted)
        }

        fun interruptPlayback() {
            activeInstance?.let { service ->
                if (_conversationState.value == ConversationState.SPEAKING) {
                    Log.i("JarvisService", "Manual interruption: stopping audio playback")
                    service.audioPlayer?.flush()
                    _conversationState.value = ConversationState.LISTENING
                }
            }
        }

        fun restartSession() {
            activeInstance?.let { service ->
                if (_isSessionOn.value) {
                    service.stopActiveConversation()
                    service.beginActiveConversation()
                }
            }
        }

        val isScreenSharing: StateFlow<Boolean> = com.jarvis.assistant.vision.ScreenCaptureManager.getInstance().isSharing

        fun elevateToMediaProjection(): Boolean {
            return activeInstance?.elevateToMediaProjection() == true
        }

        fun demoteFromMediaProjection() {
            activeInstance?.demoteFromMediaProjection()
        }

        fun startScreenCapture(projection: android.media.projection.MediaProjection, metrics: android.util.DisplayMetrics): Boolean {
            val instance = activeInstance ?: run {
                projection.stop()
                return false
            }
            if (liveWebSocketReady(instance).not()) {
                projection.stop()
                return false
            }
            val captureManager = com.jarvis.assistant.vision.ScreenCaptureManager.getInstance()
            captureManager.onStoppedListener = {
                activeInstance?.demoteFromMediaProjection()
            }
            return captureManager.startCapture(projection, metrics) { jpegBytes ->
                val frameInstance = activeInstance ?: return@startCapture
                if (frameInstance.canSendVideoFrame()) {
                    frameInstance.liveWebSocket?.sendMediaChunk(jpegBytes)
                }
            }
        }

        private fun liveWebSocketReady(instance: JarvisConversationService): Boolean =
            _isSessionOn.value && instance.liveWebSocket?.isSessionReady() == true

        fun sendImmediateVideoFrame(jpegBytes: ByteArray) {
            val instance = activeInstance ?: return
            val ws = instance.liveWebSocket ?: return
            // Screen imagery is opt-in. Gemini Live accepts concurrent real-time modalities,
            // including while a response or tool action is in progress.
            if (!com.jarvis.assistant.vision.ScreenCaptureManager.getInstance().isSharing.value ||
                !ws.isSessionReady() || jpegBytes.isEmpty()) return
            ws.sendMediaChunk(jpegBytes)
        }

        fun stopScreenCapture() {
            com.jarvis.assistant.vision.ScreenCaptureManager.getInstance().stopCapture()
            activeInstance?.demoteFromMediaProjection()
        }

        /** True while a foreground instance of this service exists in any mode. */
        fun isServiceRunning(): Boolean = activeInstance != null

        fun sendTextMessage(text: String) {
            val instance = activeInstance ?: return
            instance.liveWebSocket?.sendClientContent(text)
            JarvisApp.instance.chatRepository.addTurn(text, "")
        }

        fun cancelActiveTaskFromOverlay() {
            val service = activeInstance
            if (service != null) service.cancelAllActiveTools()
            else com.jarvis.assistant.automation.agent.AgentTaskEngine.requestCancellation()
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var taskProgressOverlay: com.jarvis.assistant.ui.agent.TaskProgressOverlay? = null
    private var taskProgressOverlayJob: Job? = null
    private var overlayPermissionWarningTaskId: String? = null
    private val preferences by lazy { (applicationContext as JarvisApp).preferences }

    // --- Active-conversation components ---
    private var audioRecorder: AudioRecorder? = null
    private var audioPlayer: AudioPlayer? = null
    private var liveWebSocket: GeminiLiveWebSocket? = null
    private var inactivityJob: Job? = null
    private val currentTurnAssistantText = StringBuilder()
    private val currentTurnUserText = StringBuilder()
    private var lastUserSpeechDetectedTime = 0L
    private var lastPlaybackEndTime = 0L
    private var hasSpeechInCurrentUtterance = false
    private var hasSignalledUtteranceEnd = false
    private var consecutiveVoicedFrames = 0
    private var totalVoicedFramesInCurrentUtterance = 0
    private var ambientNoiseFloor = 0.03f
    private var thinkingTimeoutJob: Job? = null
    private var isPendingBackgroundTransition = false
    @Volatile
    private var suppressAudioUntilTurnComplete = false
    @Volatile
    private var isExecutingTool = false
    private val currentUtteranceAudioStream = java.io.ByteArrayOutputStream()
    @Volatile
    private var isCurrentTurnOwnerVoiceVerified = false
    @Volatile
    private var lastOwnerVerifiedTimestamp = 0L
    private val preSpeechRingBuffer = java.util.ArrayDeque<ByteArray>(12)
    private val preConnectAudioQueue = java.util.concurrent.ConcurrentLinkedQueue<ByteArray>()
    @Volatile
    private var lastCompletedTaskSummary: String? = null
    @Volatile private var lastVerifiedCompletionAt = 0L
    @Volatile
    private var lastOpenedWebUrl: String? = null
    @Volatile
    private var lastOpenedWebTime: Long = 0L

    // Autonomous Multi-Step Chaining Engine
    @Volatile
    private var isAutonomousTaskRunning = false
    @Volatile
    private var autonomousTaskGoal = ""
    @Volatile
    private var bulkEndOfListVerified = false
    @Volatile
    private var bulkNoProgressScrollCount = 0
    private var lastBulkScreenSignature: com.jarvis.assistant.automation.agent.ScreenSignature? = null
    @Volatile
    private var autonomousStepCount = 0
    @Volatile
    private var autonomousContinuationAttempts = 0
    @Volatile
    private var autonomousWaitingForUser = false
    @Volatile
    private var autoResumeAwaitingResponse = false
    @Volatile
    private var isAutonomousContinuationTurn = false
    private val autonomousAudioLock = Any()
    private val autonomousAudioBuffer = mutableListOf<ByteArray>()
    private var autonomousAudioBufferBytes = 0
    private val autonomousSpokenFingerprints = mutableListOf<String>()
    private var autonomousSpokenUpdateCount = 0
    @Volatile
    private var lastResponseTimedOut = false
    @Volatile
    private var isGoogleFlowCreationTask = false
    @Volatile
    private var flowPromptVerified = false
    @Volatile
    private var flowGenerationVerified = false
    @Volatile
    private var lastVerifiedFlowPrompt = ""
    private var autonomousLoopJob: Job? = null
    private val MAX_AUTONOMOUS_STEPS = 25
    // Mic voice-activity tuning. Raised so room noise no longer flips LISTENING/THINKING when nobody speaks.
    private val VAD_MIN_THRESHOLD = 0.05f
    private val VAD_NOISE_MULTIPLIER = 2.0f
    private val VAD_START_FRAMES = 5
    private val VAD_MIN_UTTERANCE_FRAMES = 10
    // Loop guard: once tripped, ALL automation tools are refused until the user speaks again.
    @Volatile
    private var autonomousHardStop = false
    @Volatile
    private var consecutiveToolFailures = 0
    private val MAX_CONSECUTIVE_FAILURES = 4
    private var lastToolSignature = ""
    private var sameToolRepeatCount = 0
    private val toolExecutionMutex = Mutex()
    private val activeToolJobs = CopyOnWriteArrayList<Job>()
    private var activeToolJob: Job? = null

    private fun isInstagramBulkTask(): Boolean {
        val goal = autonomousTaskGoal.lowercase(Locale.ROOT)
        return com.jarvis.assistant.automation.agent.TaskGoal.fromUserUtterance(goal).isBulkAction &&
            goal.contains("instagram") &&
            (goal.contains("like") || goal.contains("liked") || goal.contains("reel"))
    }

    private fun automationToolTimeoutMs(): Long {
        val goal = autonomousTaskGoal.ifBlank { currentTurnUserText.toString() }.lowercase(Locale.ROOT)
        val bulk = com.jarvis.assistant.automation.agent.TaskGoal.fromUserUtterance(goal).isBulkAction
        return when {
            bulk && goal.contains("instagram") -> 480_000L
            goal.contains("spotify") && listOf("play", "bajao", "chalao").any(goal::contains) -> 120_000L
            else -> 25_000L
        }
    }

    private fun autonomousTaskStepLimit(): Int = if (isInstagramBulkTask()) 400 else MAX_AUTONOMOUS_STEPS

    private fun expectedPackageForTask(goal: String): String? {
        val text = goal.lowercase(Locale.ROOT)
        return when {
            "instagram" in text -> "instagram"
            "spotify" in text -> "spotify"
            "youtube" in text -> "youtube"
            "amazon" in text -> "amazon"
            "gmail" in text || "email" in text -> "com.google.android.gm"
            "whatsapp" in text -> "whatsapp"
            "where is my train" in text || ("train" in text && ("station" in text || "route" in text || "secunderabad" in text || "kagaznagar" in text)) -> "whereismytrain"
            "google photos" in text || "photos app" in text -> "photos"
            "chrome" in text || "browser" in text || "github" in text || "repository" in text || "google search" in text -> "chrome"
            else -> null
        }
    }

    private fun isExplicitContinuationUtterance(text: String): Boolean {
        val clean = text.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N} ]+"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (clean in setOf("yes", "yeah", "yep", "haan", "han", "ok", "okay", "theek hai", "continue", "resume", "go on")) {
            return true
        }
        val hasContinuation = listOf("continue", "resume", "go on", "keep going", "aage badho", "aage karo")
            .any { containsPhrase(clean, it) }
        val startsNewTask = listOf("open", "search", "send", "play", "unlike", "delete", "call", "message", "type")
            .any { containsPhrase(clean, it) }
        return hasContinuation && !startsNewTask
    }

    /** Do not block an authorized task merely because the model phrased an update as a question. */
    private fun assistantNeedsUserDecision(response: String): Boolean {
        val text = response.lowercase(Locale.ROOT)
        return listOf(
            "need your permission", "need permission", "please confirm", "please provide",
            "which account", "which one", "what should i", "enter the code",
            "enter otp", "verification code", "approve this"
        ).any(text::contains)
    }

    /** Keeps automatic task narration useful and prevents duplicate spoken blockers/statuses. */
    private fun rememberAutonomousSpokenUpdate(text: String) {
        val fingerprint = autonomousSpeechFingerprint(text)
        if (fingerprint.isBlank()) return
        synchronized(autonomousSpokenFingerprints) {
            if (autonomousSpokenFingerprints.none { areSimilarAutonomousUpdates(it, fingerprint) }) {
                autonomousSpokenFingerprints += fingerprint
                if (autonomousSpokenFingerprints.size > 8) autonomousSpokenFingerprints.removeAt(0)
                autonomousSpokenUpdateCount++
            }
        }
    }

    private fun shouldSpeakAutonomousUpdate(text: String, isFinalResult: Boolean): Boolean {
        val candidate = text.ifBlank { lastCompletedTaskSummary.orEmpty() }.trim()
        if (candidate.isBlank()) return false
        val fingerprint = autonomousSpeechFingerprint(candidate)
        if (fingerprint.isBlank()) return false
        val needsDecision = assistantNeedsUserDecision(candidate)
        synchronized(autonomousSpokenFingerprints) {
            val repeated = autonomousSpokenFingerprints.any { areSimilarAutonomousUpdates(it, fingerprint) }
            if (repeated && !isFinalResult) return false
            if (autonomousSpokenUpdateCount >= 3 && !isFinalResult && !needsDecision) return false
            if (!repeated) {
                autonomousSpokenFingerprints += fingerprint
                if (autonomousSpokenFingerprints.size > 8) autonomousSpokenFingerprints.removeAt(0)
                autonomousSpokenUpdateCount++
            }
        }
        return true
    }

    private fun autonomousSpeechFingerprint(text: String): String {
        val clean = text.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N} ]+"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (clean.isBlank()) return ""
        if (clean.contains("screen") && (clean.contains("share") || clean.contains("sharing"))) return "screen share status"
        if (clean.contains("accessibility") || clean.contains("permission")) return "permission status"
        if (clean.contains("not visible") || clean.contains("can't see") || clean.contains("cannot see") || clean.contains("nothing is showing")) return "screen visibility status"
        val ignored = setOf("the", "a", "an", "i", "am", "is", "are", "it", "to", "and", "now", "just", "please", "your", "this", "that", "on", "in", "for", "with")
        return clean.split(' ').filter { it.length > 2 && it !in ignored }.distinct().sorted().joinToString(" ")
    }

    private fun areSimilarAutonomousUpdates(first: String, second: String): Boolean {
        if (first == second) return true
        val a = first.split(' ').filter(String::isNotBlank).toSet()
        val b = second.split(' ').filter(String::isNotBlank).toSet()
        if (a.isEmpty() || b.isEmpty()) return false
        val overlap = a.intersect(b).size.toFloat() / a.union(b).size.toFloat()
        return overlap >= 0.62f
    }

    private fun setConversationState(state: ConversationState) {
        if (_conversationState.value != state) {
            _conversationState.value = state
            updateNotification()
        }
    }

    /**
     * Immediately aborts all running and pending tool executions, resetting the automation loop.
     */
    fun cancelAllActiveTools() {
        Log.i("JarvisService", "cancelAllActiveTools: Aborting all active and pending tool calls (${activeToolJobs.size} jobs)")
        com.jarvis.assistant.automation.agent.AgentTaskEngine.requestCancellation()
        isAutonomousContinuationTurn = false
        synchronized(autonomousAudioLock) {
            autonomousAudioBuffer.clear()
            autonomousAudioBufferBytes = 0
        }
        isAutonomousTaskRunning = false
        autonomousStepCount = 0
        isGoogleFlowCreationTask = false
        flowPromptVerified = false
        flowGenerationVerified = false
        lastVerifiedFlowPrompt = ""
        autonomousLoopJob?.cancel()
        autonomousLoopJob = null
        for (job in activeToolJobs) {
            job.cancel()
        }
        activeToolJobs.clear()
        activeToolJob = null
        isExecutingTool = false
        com.jarvis.assistant.automation.agent.SerializedActionExecutor.cancelAllPendingActions()
    }

    // Pending tool call queue: tool calls are queued when owner voice verification hasn't completed yet
    private data class PendingToolCall(val callId: String, val name: String, val args: JSONObject)
    private val pendingToolCalls = java.util.concurrent.ConcurrentLinkedQueue<PendingToolCall>()

    /** Real-time video and audio are concurrent input modalities in Gemini Live. */
    fun canSendVideoFrame(): Boolean {
        val ws = liveWebSocket ?: return false
        return com.jarvis.assistant.vision.ScreenCaptureManager.getInstance().isSharing.value && ws.isSessionReady()
    }

    // --- Standby / wake-word components (Pure Vosk) ---
    private var voskSpeechService: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: android.net.wifi.WifiManager.WifiLock? = null
    private var standbyActivatedTime = 0L
    @Volatile
    private var isPendingWakeGreeting = false
    private var headsetAudioRouter: com.jarvis.assistant.audio.HeadsetAudioRouter? = null

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        createChannel()
        initTts()
        headsetAudioRouter = com.jarvis.assistant.audio.HeadsetAudioRouter(applicationContext)
        taskProgressOverlay = com.jarvis.assistant.ui.agent.TaskProgressOverlay(this)
        taskProgressOverlayJob = serviceScope.launch(Dispatchers.Main.immediate) {
            combine(
                com.jarvis.assistant.automation.agent.AgentTaskEngine.taskState,
                JarvisApp.isAppForeground,
                _isSessionOn,
                _isStandby
            ) { snapshot, appForeground, sessionOn, standbyOn ->
                snapshot to (JarvisApp.instance.preferences.taskOverlayMode == "always" || (!appForeground && (sessionOn || standbyOn)))
            }.collect { (snapshot, showIdleAvatar) ->
                val shown = taskProgressOverlay?.update(snapshot, showIdleAvatar) == true
                if (snapshot != null && !shown && overlayPermissionWarningTaskId != snapshot.taskId) {
                    overlayPermissionWarningTaskId = snapshot.taskId
                    _events.emit("Task progress is shown inside JARVIS Home. Allow Display over other apps if you want the floating task panel over Instagram, Spotify, and Chrome.")
                }
            }
        }
        serviceScope.launch(Dispatchers.Main.immediate) {
            var previousAvailability: List<Any>? = null
            while (isActive) {
                delay(900L)
                if (_isSessionOn.value &&
                    (!PermissionHelper.hasRecordAudioPermission(this@JarvisConversationService) ||
                        !PermissionHelper.hasNotificationPermission(this@JarvisConversationService))) {
                    Log.w("JarvisService", "A required runtime permission was revoked during the live session; stopping the session")
                    stopActiveConversation()
                    serviceScope.launch { _events.emit("Jarvis paused because a required permission was turned off. Re-enable it in System Permissions to continue.") }
                }
                if (com.jarvis.assistant.automation.agent.AgentTaskEngine.current() != null &&
                    !PermissionHelper.isAccessibilityServiceEnabled(this@JarvisConversationService)) {
                    Log.w("JarvisService", "Accessibility was disabled during an active task; clearing task progress")
                    isAutonomousTaskRunning = false
                    com.jarvis.assistant.automation.agent.AgentTaskEngine.resetForSession()
                }
                val snapshot = com.jarvis.assistant.automation.agent.AgentTaskEngine.taskState.value
                val prefs = (application as JarvisApp).preferences
                val appForeground = JarvisApp.isAppForeground.value
                val showIdleAvatar = prefs.taskOverlayMode == "always" || (!appForeground && (_isSessionOn.value || _isStandby.value))
                val availability = listOf(
                    prefs.isTaskOverlayEnabled,
                    PermissionHelper.hasOverlayPermission(this@JarvisConversationService),
                    prefs.taskOverlayAvatar,
                    prefs.taskOverlayMode,
                    prefs.taskOverlayEdge,
                    appForeground,
                    _isSessionOn.value,
                    _isStandby.value
                )
                if (availability != previousAvailability) {
                    previousAvailability = availability
                    taskProgressOverlay?.update(snapshot, showIdleAvatar)
                }
            }
        }
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.US
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            Log.d("JarvisService", "TTS onStart: $utteranceId")
                        }

                        override fun onDone(utteranceId: String?) {
                            Log.d("JarvisService", "TTS onDone: $utteranceId")
                            handleTtsDone(utteranceId)
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            Log.e("JarvisService", "TTS onError: $utteranceId")
                            handleTtsDone(utteranceId)
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            Log.e("JarvisService", "TTS onError: $utteranceId code: $errorCode")
                            handleTtsDone(utteranceId)
                        }
                    })
                }
            }
        } catch (e: Exception) {
            Log.e("JarvisService", "Failed to init TTS: ${e.message}")
        }
    }

    private fun handleTtsDone(utteranceId: String?) {
        // Robotic system announcements disabled; all speech is handled via natural Gemini Live neural audio.
    }

    private fun ensureMicrophoneForegroundService() {
        val notification = buildNotification()
        var combinedTypes = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        } else {
            0
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q &&
            com.jarvis.assistant.vision.ScreenCaptureManager.getInstance().isSharing.value) {
            combinedTypes = combinedTypes or android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            try {
                startForeground(NOTIFICATION_ID, notification, combinedTypes)
                Log.d("JarvisService", "startForeground elevated to types=$combinedTypes")
            } catch (e: Exception) {
                Log.w("JarvisService", "startForeground with combined types failed: ${e.message}")
                try {
                    startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
                } catch (_: Exception) {
                    try {
                        startForeground(NOTIFICATION_ID, notification)
                    } catch (_: Exception) {}
                }
            }
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    fun elevateToMediaProjection(): Boolean {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val notification = buildNotification()
            val types = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK or
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            try {
                startForeground(NOTIFICATION_ID, notification, types)
                Log.i("JarvisService", "Foreground service elevated to include MEDIA_PROJECTION")
                return true
            } catch (e: Exception) {
                Log.w("JarvisService", "Failed to elevate to MEDIA_PROJECTION: ${e.message}")
                return false
            }
        }
        return true
    }

    fun demoteFromMediaProjection() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val notification = buildNotification()
            val types = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            try {
                startForeground(NOTIFICATION_ID, notification, types)
                Log.i("JarvisService", "Foreground service demoted from MEDIA_PROJECTION")
            } catch (e: Exception) {
                Log.w("JarvisService", "Failed to demote from MEDIA_PROJECTION: ${e.message}")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!com.jarvis.assistant.security.AppIdentityVerifier.isTrustedRelease(this)) {
            Log.e("JarvisService", "Blocked service start: release signing certificate did not match the configured pin")
            stopSelf(startId)
            return START_NOT_STICKY
        }
        ensureMicrophoneForegroundService()
        acquireWakeLock()

        when (intent?.action) {
            ACTION_START_CONVERSATION -> {
                com.jarvis.assistant.audio.JarvisSoundEffects.playWakeSound()
                beginActiveConversation()
            }
            ACTION_ENTER_STANDBY -> enterStandby(announce = false)
            ACTION_STOP_ALL -> {
                fullStop()
                return START_NOT_STICKY
            }
            else -> {
                // System restarted service or restarted after recents removal
                if (!_isSessionOn.value && !_isStandby.value) {
                    enterStandby(announce = false)
                }
            }
        }
        return START_STICKY
    }

    // ---------------------------------------------------------------------
    // Active conversation
    // ---------------------------------------------------------------------

    private suspend fun generateCurrentSystemPrompt(): String {
        val app = application as? JarvisApp ?: return ""
        return withContext(Dispatchers.IO) {
            val memoryContext = app.memoryManager.getSystemPromptContext()
            val favSong = app.memoryManager.resolveSongQuery("my favorite song")
            com.jarvis.assistant.util.PromptGenerator.generateSystemPrompt(
                personality = preferences.personality,
                userName = preferences.userName,
                memoryContext = memoryContext,
                favoriteSong = favSong,
                userBirthday = preferences.userBirthday,
                userLocation = preferences.userLocation,
                isTorchOn = app.phoneControlManager.isTorchOn,
                language = preferences.language,
                isSilentExecutionMode = preferences.isSilentExecutionMode
            )
        }
    }

    private fun beginActiveConversation(wakeTriggered: Boolean = false) {
        if (_isSessionOn.value) return
        com.jarvis.assistant.automation.agent.AgentTaskEngine.resetForSession()
        isAutonomousContinuationTurn = false
        synchronized(autonomousAudioLock) {
            autonomousAudioBuffer.clear()
            autonomousAudioBufferBytes = 0
        }
        synchronized(autonomousSpokenFingerprints) {
            autonomousSpokenFingerprints.clear()
            autonomousSpokenUpdateCount = 0
        }
        exitStandbyListening()
        isPendingWakeGreeting = wakeTriggered

        val app = application as JarvisApp
        val preferences = app.preferences
        val apiKey = preferences.apiKey.trim()
        if (apiKey.isBlank()) {
            _liveError.value = JarvisLiveError(
                title = "API KEY MISSING",
                message = "No Gemini API Key configured. Please enter your API Key in Settings to activate Jarvis.",
                errorCode = "API_KEY_MISSING",
                actionText = "OPEN SETTINGS"
            )
            serviceScope.launch { _events.emit("Please configure your Gemini API Key in Settings first.") }
            fullStop()
            return
        }

        if (!PermissionHelper.hasAllRequiredPermissions(this)) {
            _liveError.value = JarvisLiveError(
                title = "PERMISSIONS REQUIRED",
                message = "Jarvis requires Microphone and Notification permissions to run. Please grant them in Authorizations.",
                errorCode = "PERMISSIONS_MISSING",
                actionText = "GRANT PERMISSIONS"
            )
            serviceScope.launch { _events.emit("Please allow all required permissions in Settings to use Jarvis.") }
            fullStop()
            return
        }

        _liveError.value = null

        _isSessionOn.value = true
        _isStandby.value = false
        lastResponseTimedOut = false
        val now = System.currentTimeMillis()
        lastUserSpeechDetectedTime = now
        lastOwnerVerifiedTimestamp = now
        isCurrentTurnOwnerVoiceVerified = !preferences.isOwnerVoiceEnabled || !preferences.hasOwnerVoiceProfile()
        pendingToolCalls.clear()
        hasSpeechInCurrentUtterance = false
        hasSignalledUtteranceEnd = false
        currentTurnAssistantText.clear()
        currentTurnUserText.clear()
        startInactivityTimer()
        setConversationState(ConversationState.IDLE)
        updateNotification()
        headsetAudioRouter?.start()

        audioPlayer = AudioPlayer(
            onPlaybackStateChanged = { isPlaying ->
                if (isPlaying) {
                    setConversationState(ConversationState.SPEAKING)
                } else {
                    lastPlaybackEndTime = System.currentTimeMillis()
                    finalizeTurn()
                    if (_isSessionOn.value) {
                        setConversationState(ConversationState.IDLE)
                    }
                }
            },
            onPlaybackAmplitude = { amp ->
                if (_conversationState.value == ConversationState.SPEAKING) {
                    _audioLevel.value = amp
                    _audioFrequency.value = com.jarvis.assistant.audio.AudioFrequencyData(
                        amplitude = amp,
                        pitchHz = 180f,
                        bass = (amp * 0.7f).coerceIn(0f, 1f),
                        mid = (amp * 0.9f).coerceIn(0f, 1f),
                        high = (amp * 0.4f).coerceIn(0f, 1f)
                    )
                }
            }
        ).apply { start() }

        serviceScope.launch(Dispatchers.IO) {
            val systemPrompt = generateCurrentSystemPrompt()

            withContext(Dispatchers.Main) {
                if (!_isSessionOn.value) return@withContext
                liveWebSocket = GeminiLiveWebSocket(
                    apiKey = apiKey,
                    model = preferences.aiModel,
                    voiceName = preferences.voice,
                    systemPrompt = systemPrompt,
                    listener = object : GeminiLiveWebSocket.Listener {
                        override fun onConnectionStateChanged(status: String) {
                            _connectionStatus.value = status
                            updateNotification()
                            if (status == "LIVE") {
                                _liveError.value = null
                                // Flush any speech chunks captured during the connection handshake
                                serviceScope.launch(Dispatchers.Default) {
                                    while (!preConnectAudioQueue.isEmpty()) {
                                        val chunk = preConnectAudioQueue.poll() ?: break
                                        liveWebSocket?.sendAudioChunk(chunk)
                                    }
                                }
                                // Reset autonomous task state on fresh connection
                                isAutonomousTaskRunning = false
                                isAutonomousContinuationTurn = false
                                synchronized(autonomousAudioLock) {
                                    autonomousAudioBuffer.clear()
                                    autonomousAudioBufferBytes = 0
                                }
                                autonomousStepCount = 0
                                autonomousLoopJob?.cancel()
                                autonomousLoopJob = null
                                if (_conversationState.value != ConversationState.SPEAKING && _conversationState.value != ConversationState.THINKING) {
                                    setConversationState(ConversationState.IDLE)
                                }
                                if (isPendingWakeGreeting) {
                                    isPendingWakeGreeting = false
                                    if (!hasSpeechInCurrentUtterance) {
                                        liveWebSocket?.sendClientContent("Hey Jarvis")
                                    }
                                }
                            }
                        }

                        private var audioChunksReceivedInTurn = 0

                        override fun onAudioDataReceived(pcmData: ByteArray) {
                            thinkingTimeoutJob?.cancel()
                            thinkingTimeoutJob = null
                            lastResponseTimedOut = false
                            if (suppressAudioUntilTurnComplete) {
                                Log.w("JarvisService", "onAudioDataReceived: Audio suppressed (suppressAudioUntilTurnComplete=true)")
                                return
                            }
                            // Silent execution applies to task narration, while leaving ordinary
                            // conversation audible. Read the preference dynamically so toggling
                            // it during a session takes effect immediately.
                            if (preferences.isSilentExecutionMode &&
                                (isAutonomousTaskRunning || hasExecutedCommandInCurrentTurn || !lastCompletedTaskSummary.isNullOrBlank())
                            ) {
                                audioPlayer?.flush()
                                return
                            }
                            if (isAutonomousContinuationTurn) {
                                synchronized(autonomousAudioLock) {
                                    if (autonomousAudioBufferBytes + pcmData.size <= 2_000_000) {
                                        autonomousAudioBuffer += pcmData.copyOf()
                                        autonomousAudioBufferBytes += pcmData.size
                                    }
                                }
                                return
                            }
                            audioChunksReceivedInTurn++
                            if (audioChunksReceivedInTurn % 25 == 1) {
                                Log.d("JarvisService", "Streaming audio chunk #$audioChunksReceivedInTurn (${pcmData.size} bytes) to AudioPlayer")
                            }
                            setConversationState(ConversationState.SPEAKING)
                            audioPlayer?.enqueueAudio(pcmData)
                        }

                        override fun onAssistantTextReceived(textChunk: String) {
                            if (textChunk.isEmpty()) return
                            thinkingTimeoutJob?.cancel()
                            thinkingTimeoutJob = null
                            lastResponseTimedOut = false
                            synchronized(currentTurnAssistantText) {
                                val chunkToAppend = if (currentTurnAssistantText.isNotEmpty() && currentTurnAssistantText.last() == ' ') {
                                    textChunk.trimStart()
                                } else {
                                    textChunk
                                }
                                if (chunkToAppend.isNotEmpty()) {
                                    if (currentTurnAssistantText.isNotEmpty()) {
                                        val lastChar = currentTurnAssistantText.last()
                                        val firstChar = chunkToAppend.first()
                                        if (!Character.isWhitespace(lastChar) && !Character.isWhitespace(firstChar)) {
                                            if (Character.isLetterOrDigit(firstChar) || firstChar == '(' || firstChar == '[') {
                                                currentTurnAssistantText.append(' ')
                                            }
                                        }
                                    }
                                    currentTurnAssistantText.append(chunkToAppend)
                                }
                            }
                            _liveAssistantResponse.value = currentTurnAssistantText.toString().trim()
                            val assistantText = currentTurnAssistantText.toString().lowercase(Locale.ROOT)
                            Log.d("JarvisService", "Assistant text so far: '$assistantText'")
                        }

                        override fun onUserTextReceived(textChunk: String) {
                            lastUserSpeechDetectedTime = System.currentTimeMillis()
                            val trimmed = textChunk.trim()
                            if (trimmed.isNotEmpty()) {
                                val startsNewUserTurn = currentTurnUserText.isEmpty()
                                val answeringTaskBlocker = startsNewUserTurn && isAutonomousTaskRunning && autonomousWaitingForUser
                                if (answeringTaskBlocker) {
                                    autonomousWaitingForUser = false
                                    com.jarvis.assistant.automation.agent.AgentTaskEngine.resumeAfterUserInput()
                                }
                                if (startsNewUserTurn && isAutonomousTaskRunning && !isExplicitContinuationUtterance(trimmed) && !answeringTaskBlocker) {
                                    Log.i("JarvisService", "New user request superseded the previous automation task; cancelling stale actions.")
                                    cancelAllActiveTools()
                                    autonomousTaskGoal = ""
                                    autonomousContinuationAttempts = 0
                                    bulkEndOfListVerified = false
                                    bulkNoProgressScrollCount = 0
                                    lastBulkScreenSignature = null
                                    autoResumeAwaitingResponse = false
                                }
                                if (startsNewUserTurn && autonomousHardStop) {
                                    val resumeExistingTask = isExplicitContinuationUtterance(trimmed) && autonomousTaskGoal.isNotBlank() &&
                                        com.jarvis.assistant.automation.agent.AgentTaskEngine.current() != null
                                    Log.i("JarvisService", if (resumeExistingTask) "User requested continuation; preserving the original task and resuming from fresh UI." else "New user request received: clearing automation hard stop.")
                                    autonomousHardStop = false
                                    autonomousContinuationAttempts = 0
                                    consecutiveToolFailures = 0
                                    sameToolRepeatCount = 0
                                    lastToolSignature = ""
                                    if (resumeExistingTask) {
                                        isAutonomousTaskRunning = true
                                        autonomousStepCount = 0
                                        com.jarvis.assistant.automation.agent.AgentTaskEngine.resumeAfterUserInput()
                                    } else {
                                        isAutonomousTaskRunning = false
                                        autonomousStepCount = 0
                                        autonomousTaskGoal = ""
                                    }
                                }
                                if (currentTurnUserText.isNotEmpty() && !currentTurnUserText.endsWith(" ")) {
                                    currentTurnUserText.append(" ")
                                }
                                currentTurnUserText.append(trimmed)
                                _liveUserTranscript.value = currentTurnUserText.toString().trim()
                                if (_conversationState.value == ConversationState.IDLE) {
                                    setConversationState(ConversationState.LISTENING)
                                }
                            }
                            lastResponseTimedOut = false
                            updateNotification()
                            val userText = currentTurnUserText.toString().lowercase(Locale.ROOT)
                            if (isStopCommand(userText)) {
                                Log.i("JarvisService", "Detected explicit stop/cancel in user speech: '$userText'. Aborting all tasks.")
                                cancelAllActiveTools()
                            }
                            if (isExplicitStandbyCommand(userText)) {
                                Log.i("JarvisService", "Detected explicit background / standby command in user speech: '$userText'")
                                minimizeToHomeScreen()
                                enterStandby(announce = true)
                                return
                            }
                            app.memoryManager.learnPreferencesFromConversation(currentTurnUserText.toString())
                            // Do not run checkAndExecuteCommand on streaming chunks mid-speech!
                            // Gemini Live onToolCall is the authoritative neural intent engine.
                        }

                        override fun onInterrupted() {
                            val hasHeadset = headsetAudioRouter?.isHeadsetConnected() == true
                            Log.w("JarvisService", "onInterrupted received from server (hasHeadset=$hasHeadset, state=${_conversationState.value})")
                            val userTurnInProgress = hasSpeechInCurrentUtterance || currentTurnUserText.isNotBlank()
                            val isOwnAutoResumeInterrupt = autoResumeAwaitingResponse &&
                                !userTurnInProgress
                            if (isOwnAutoResumeInterrupt) {
                                Log.i("JarvisService", "Preserving task state for the assistant's automatic continuation")
                                autoResumeAwaitingResponse = false
                            } else {
                                isAutonomousContinuationTurn = false
                                synchronized(autonomousAudioLock) {
                                    autonomousAudioBuffer.clear()
                                    autonomousAudioBufferBytes = 0
                                }
                                cancelAllActiveTools()
                                if (userTurnInProgress && !isExplicitContinuationUtterance(currentTurnUserText.toString())) {
                                    autonomousTaskGoal = ""
                                    autonomousContinuationAttempts = 0
                                    autoResumeAwaitingResponse = false
                                }
                            }
                            thinkingTimeoutJob?.cancel()
                            thinkingTimeoutJob = null
                            suppressAudioUntilTurnComplete = false
                            if (hasHeadset || _conversationState.value != ConversationState.SPEAKING) {
                                audioPlayer?.flush()
                                currentTurnAssistantText.clear()
                                _liveAssistantResponse.value = ""
                            }
                            if (!userTurnInProgress) {
                                currentTurnUserText.clear()
                                _liveUserTranscript.value = ""
                            }
                            hasSpeechInCurrentUtterance = false
                            hasSignalledUtteranceEnd = false
                            consecutiveVoicedFrames = 0
                            totalVoicedFramesInCurrentUtterance = 0
                            synchronized(currentUtteranceAudioStream) { currentUtteranceAudioStream.reset() }
                            isCurrentTurnOwnerVoiceVerified = !preferences.isOwnerVoiceEnabled || !preferences.hasOwnerVoiceProfile()
                            if (_conversationState.value != ConversationState.SPEAKING) {
                                setConversationState(if (userTurnInProgress) ConversationState.LISTENING else ConversationState.IDLE)
                            }
                            updateNotification()
                        }

                        override fun onTurnCompleted() {
                            autoResumeAwaitingResponse = false
                            thinkingTimeoutJob?.cancel()
                            thinkingTimeoutJob = null
                            val assistantTurnText = synchronized(currentTurnAssistantText) { currentTurnAssistantText.toString().trim() }
                            if (isAutonomousContinuationTurn) {
                                isAutonomousContinuationTurn = false
                                val bufferedAudio = synchronized(autonomousAudioLock) {
                                    autonomousAudioBuffer.toList().also {
                                        autonomousAudioBuffer.clear()
                                        autonomousAudioBufferBytes = 0
                                    }
                                }
                                val finalResult = !isAutonomousTaskRunning || !lastCompletedTaskSummary.isNullOrBlank()
                                val speakUpdate = shouldSpeakAutonomousUpdate(assistantTurnText, finalResult)
                                if (speakUpdate && bufferedAudio.isNotEmpty()) {
                                    bufferedAudio.forEach { audioPlayer?.enqueueAudio(it) }
                                    Log.i("JarvisService", "Playing a new autonomous milestone; buffered repeated narration is discarded")
                                } else {
                                    Log.i("JarvisService", "Suppressing repeated or routine speech from automatic task continuation")
                                }
                            } else if (isAutonomousTaskRunning && assistantTurnText.isNotBlank()) {
                                rememberAutonomousSpokenUpdate(assistantTurnText)
                            }
                            audioPlayer?.notifyTurnComplete()
                            audioChunksReceivedInTurn = 0
                            suppressAudioUntilTurnComplete = false
                            hasSpeechInCurrentUtterance = false
                            hasSignalledUtteranceEnd = false
                            consecutiveVoicedFrames = 0
                            totalVoicedFramesInCurrentUtterance = 0
                            if (_conversationState.value == ConversationState.THINKING && (audioPlayer == null || !audioPlayer!!.isPlaying())) {
                                setConversationState(ConversationState.IDLE)
                            }
                            lastResponseTimedOut = false
                            updateNotification()

                            // Owner voice gating: if owner-only mode is active and speaker was not verified, ignore turn completely
                            val hasActualSpeechInThisTurn = hasSpeechInCurrentUtterance || currentTurnUserText.isNotEmpty()
                            val isLeaseActive = (System.currentTimeMillis() - lastOwnerVerifiedTimestamp) < 120_000L

                            if (preferences.isOwnerVoiceEnabled && preferences.hasOwnerVoiceProfile() && !isCurrentTurnOwnerVoiceVerified && !isLeaseActive && hasActualSpeechInThisTurn) {
                                val nonOwnerUtterance = currentTurnUserText.toString().trim()
                                Log.w("JarvisService", "Turn completed by NON-OWNER: Suppressing response and logging ignored.")
                                val app = application as? JarvisApp
                                val loggedQuery = if (nonOwnerUtterance.isNotEmpty()) nonOwnerUtterance else "(Unrecognized voice)"
                                app?.chatRepository?.addTurn(
                                    userText = "[Non-Owner Voice]: $loggedQuery",
                                    jarvisText = "[IGNORED] Voice not recognized as owner"
                                )
                                audioPlayer?.flush()
                                currentTurnAssistantText.clear()
                                currentTurnUserText.clear()
                                _liveAssistantResponse.value = ""
                                _liveUserTranscript.value = ""
                                processPendingToolCalls(verified = false)
                                return
                            }

                            val userUtterance = currentTurnUserText.toString().trim()
                            if (userUtterance.isNotEmpty()) {
                                app.memoryManager.learnPreferencesFromConversation(userUtterance)
                            }
                            val assistantText = currentTurnAssistantText.toString().lowercase(Locale.ROOT)
                            val isConfused = assistantText.contains("not understand") ||
                                    assistantText.contains("didn't understand") ||
                                    assistantText.contains("don't understand") ||
                                    assistantText.contains("couldn't understand") ||
                                    assistantText.contains("sorry, i can't") ||
                                    assistantText.contains("i'm not sure")

                            // Only run fallback if Gemini Live did NOT call a tool AND did not express confusion
                            if (!hasExecutedCommandInCurrentTurn && !isConfused) {
                                checkAndExecuteCommand(userUtterance)
                                checkAssistantTextForCommands(currentTurnAssistantText.toString())
                            }

                            // Reset verification flag for the next conversational turn
                            if (preferences.isOwnerVoiceEnabled && preferences.hasOwnerVoiceProfile()) {
                                // Keep verification active if within the owner session lease window.
                                // This prevents the owner from being re-challenged every single turn.
                                val leaseStillActive = (System.currentTimeMillis() - lastOwnerVerifiedTimestamp) < 120_000L
                                if (!leaseStillActive) {
                                    isCurrentTurnOwnerVoiceVerified = false
                                }
                            }
                            pendingToolCalls.clear()

                            if (!lastCompletedTaskSummary.isNullOrBlank()) {
                                val summaryToSpeak = lastCompletedTaskSummary
                                lastCompletedTaskSummary = null
                                val isLive = liveWebSocket?.isSessionReady() == true
                                if (!preferences.isSilentExecutionMode && !isLive) {
                                    Log.i("JarvisService", "Offline fallback: Speaking confirmation via TTS: '$summaryToSpeak'")
                                    tts?.speak(summaryToSpeak, TextToSpeech.QUEUE_FLUSH, null, "task_done")
                                }
                            }

                            val engineStatus = com.jarvis.assistant.automation.agent.AgentTaskEngine.current()?.status
                            if (isAutonomousTaskRunning && engineStatus == com.jarvis.assistant.automation.agent.AgentTaskEngine.State.COMPLETED) {
                                Log.i("JarvisService", "Task engine already verified completion; skipping another automatic continuation")
                                isAutonomousTaskRunning = false
                                autonomousStepCount = 0
                                autonomousLoopJob?.cancel()
                                autonomousLoopJob = null
                            }

                            // Do NOT reset autonomous task state on turn completion!
                            // Autonomous tasks span across multiple turns (e.g. download -> open -> onboarding -> phone entry -> OTP -> setup complete).
                            // The autonomous task ONLY completes when:
                            // 1. Gemini explicitly calls `task_completed(summary=...)`
                            // 2. The user explicitly gives a cancel/stop command ("stop", "ruko", "cancel")
                            // 3. Safety cap of MAX_AUTONOMOUS_STEPS (25) is reached.
                            if (isAutonomousTaskRunning && autonomousStepCount >= autonomousTaskStepLimit()) {
                                Log.w("JarvisService", "Autonomous task reached its step safety cap (${autonomousTaskStepLimit()}). Terminating loop safety.")
                                autonomousHardStop = true
                                isAutonomousTaskRunning = false
                                com.jarvis.assistant.automation.agent.AgentTaskEngine.recordCompletionEvidence(
                                    com.jarvis.assistant.automation.agent.AgentTaskEngine.CompletionEvidence.SAFETY_LIMIT,
                                    "Reached the current action batch limit; the original task is preserved and can resume from a fresh screen."
                                )
                                com.jarvis.assistant.automation.agent.AgentTaskEngine.failCurrentStep(
                                    "Reached the current action batch limit. Say continue to resume this same task from a fresh screen.",
                                    blocked = true
                                )
                                com.jarvis.assistant.automation.agent.AgentTaskEngine.setState(
                                    com.jarvis.assistant.automation.agent.AgentTaskEngine.State.BLOCKED
                                )
                                autonomousStepCount = 0
                                autonomousLoopJob?.cancel()
                                autonomousLoopJob = null
                            } else if (isAutonomousTaskRunning) {
                                val response = currentTurnAssistantText.toString().trim().ifBlank { "The Instagram bulk task is still in progress." }
                                val needsUserDecision = assistantNeedsUserDecision(response)
                                val continuationLimit = 25
                                if (!autonomousWaitingForUser && !needsUserDecision && autonomousContinuationAttempts < continuationLimit) {
                                    autonomousContinuationAttempts++
                                    val attempt = autonomousContinuationAttempts
                                    autonomousLoopJob?.cancel()
                                    val speechAtTurnEnd = lastUserSpeechDetectedTime
                                    autonomousLoopJob = serviceScope.launch {
                                        // The model can finish its turn before the device finishes playing the queued audio.
                                        // Sending a continuation during playback makes Gemini interrupt its own speech.
                                        var quietSince = 0L
                                        val waitStartedAt = System.currentTimeMillis()
                                        while (isActive && System.currentTimeMillis() - waitStartedAt < 90_000L) {
                                            if (!isAutonomousTaskRunning || lastUserSpeechDetectedTime > speechAtTurnEnd ||
                                                liveWebSocket?.isSessionReady() != true) {
                                                Log.i("JarvisService", "Auto-resume cancelled because the task/session changed or the user spoke")
                                                return@launch
                                            }
                                            val playbackActive = audioPlayer?.isPlaying() == true || tts?.isSpeaking == true ||
                                                _conversationState.value == ConversationState.SPEAKING
                                            if (playbackActive) {
                                                quietSince = 0L
                                            } else if (quietSince == 0L) {
                                                quietSince = System.currentTimeMillis()
                                            } else if (System.currentTimeMillis() - quietSince >= 350L) {
                                                break
                                            }
                                            kotlinx.coroutines.delay(100L)
                                        }
                                        if (!isActive || System.currentTimeMillis() - waitStartedAt >= 90_000L) {
                                            Log.w("JarvisService", "Auto-resume timed out waiting for speech playback to finish")
                                            return@launch
                                        }
                                        if (com.jarvis.assistant.automation.agent.AgentTaskEngine.current()?.status in setOf(
                                                com.jarvis.assistant.automation.agent.AgentTaskEngine.State.COMPLETED,
                                                com.jarvis.assistant.automation.agent.AgentTaskEngine.State.FAILED,
                                                com.jarvis.assistant.automation.agent.AgentTaskEngine.State.CANCELLED,
                                                com.jarvis.assistant.automation.agent.AgentTaskEngine.State.BLOCKED
                                            )) {
                                            isAutonomousTaskRunning = false
                                            return@launch
                                        }
                                        if (isAutonomousTaskRunning && !isExecutingTool && activeToolJobs.isEmpty() &&
                                            pendingToolCalls.isEmpty() && lastUserSpeechDetectedTime <= speechAtTurnEnd &&
                                            liveWebSocket?.isSessionReady() == true) {
                                            var uiWait: com.jarvis.assistant.vision.UiWaitResult? = null
                                            val uiWaitDeadline = System.currentTimeMillis() + 45_000L
                                            while (isActive && isAutonomousTaskRunning && System.currentTimeMillis() < uiWaitDeadline &&
                                                lastUserSpeechDetectedTime <= speechAtTurnEnd && uiWait?.ready != true) {
                                                if (!com.jarvis.assistant.automation.agent.AgentTaskEngine.awaitIfRunnable()) return@launch
                                                val expectedPackage = expectedPackageForTask(autonomousTaskGoal)
                                                uiWait = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                                                    .waitForUiState(expectedPackage = expectedPackage, timeoutMs = 8_000L)
                                                if (!uiWait.ready) {
                                                    com.jarvis.assistant.automation.agent.AgentTaskEngine.updateActivity(
                                                        "Waiting for a stable screen before continuing: ${uiWait.reason}",
                                                        com.jarvis.assistant.automation.agent.AgentTaskEngine.State.WAITING_FOR_UI
                                                    )
                                                }
                                            }
                                            if (!isActive || !isAutonomousTaskRunning || lastUserSpeechDetectedTime > speechAtTurnEnd) return@launch
                                            val observedScreen = uiWait?.let { wait ->
                                                com.jarvis.assistant.vision.UiGroundingEngine().formatElementsSummary(wait.elements, wait.root)
                                            }.orEmpty()
                                            if (uiWait?.ready != true) {
                                                com.jarvis.assistant.automation.agent.AgentTaskEngine.failCurrentStep(
                                                    "The UI did not become stable within 45 seconds; task needs a fresh strategy."
                                                )
                                            }
                                            Log.i("JarvisService", "Auto-resuming task after speech playback ended (attempt $attempt)")
                                            autoResumeAwaitingResponse = true
                                            isAutonomousContinuationTurn = true
                                            synchronized(autonomousAudioLock) {
                                                autonomousAudioBuffer.clear()
                                                autonomousAudioBufferBytes = 0
                                            }
                                            liveWebSocket?.sendClientContent(
                                                "Continue the existing task from the fresh phone state; this is an automatic continuation, not a new user command. " +
                                                    "Do not quote, paraphrase, repeat, or summarize previous assistant messages; use task state and this fresh screen only. " +
                                                    "UI readiness: ${uiWait?.reason ?: "not observed"}. " +
                                                    "Latest accessibility observation: ${observedScreen.take(5000)}. " +
                                                    "Use the current observation to select the next safe plan step or recover/replan if the screen changed. " +
                                                    "Do not repeat verified steps, do not ask the user to say continue, and never claim completion without local verification. " +
                                                "Keep the phone quiet while continuing: do not narrate each click, inspection, scroll, or repeated blocker. The task start was already acknowledged. Speak only for a new material milestone, a genuine user decision that is required, or one final verified result. Never repeat the same status wording. " +
                                                    "If a genuine clarification or permission is required, explain the blocker and wait for the user's answer."
                                            )
                                        }
                                    }
                                } else if (autonomousWaitingForUser || needsUserDecision) {
                                    com.jarvis.assistant.automation.agent.AgentTaskEngine.failCurrentStep(
                                        "The assistant requested user clarification or confirmation.", blocked = true
                                    )
                                    com.jarvis.assistant.automation.agent.AgentTaskEngine.setState(
                                        com.jarvis.assistant.automation.agent.AgentTaskEngine.State.BLOCKED
                                    )
                                } else {
                                    Log.w("JarvisService", "Auto-resume limit reached; stopping task to avoid an unattended loop")
                                    isAutonomousTaskRunning = false
                                    com.jarvis.assistant.automation.agent.AgentTaskEngine.failCurrentStep(
                                        "Automatic continuation limit reached without verified completion.", blocked = true
                                    )
                                    serviceScope.launch { _events.emit("The task is blocked because it did not reach a verified result within the automatic recovery limit.") }
                                }
                            }
                        }

                        override fun onError(message: String, isFatal: Boolean, errorCode: String?) {
                            Log.e("JarvisService", "GeminiLive onError: fatal=$isFatal, code=$errorCode, msg=$message")
                            updateNotification()
                            serviceScope.launch { _events.emit(message) }
                            when (errorCode) {
                                "API_KEY_INVALID" -> {
                                    _liveError.value = JarvisLiveError(
                                        title = "API KEY INVALID",
                                        message = "Google rejected your Gemini API key (400/403). Please verify and enter a valid API key in Settings.",
                                        errorCode = "API_KEY_INVALID",
                                        actionText = "OPEN SETTINGS"
                                    )
                                }
                                "API_KEY_MISSING" -> {
                                    _liveError.value = JarvisLiveError(
                                        title = "API KEY MISSING",
                                        message = "No Gemini API key found. Enter your BYOK key in Settings to activate Jarvis.",
                                        errorCode = "API_KEY_MISSING",
                                        actionText = "OPEN SETTINGS"
                                    )
                                }
                                "QUOTA_EXCEEDED" -> {
                                    _liveError.value = JarvisLiveError(
                                        title = "API QUOTA EXHAUSTED",
                                        message = "Gemini API quota or rate limit exceeded. Please check your Google AI Studio plan.",
                                        errorCode = "QUOTA_EXCEEDED",
                                        actionText = "CHECK PLAN"
                                    )
                                }
                                else -> {
                                    if (isFatal) {
                                        _liveError.value = JarvisLiveError(
                                            title = "CONNECTION FAILED",
                                            message = message,
                                            errorCode = errorCode ?: "FATAL_ERROR",
                                            actionText = "RETRY"
                                        )
                                    } else if (_liveError.value == null) {
                                        _liveError.value = JarvisLiveError(
                                            title = "CONNECTION DROP",
                                            message = message,
                                            errorCode = "CONNECTION_ERROR",
                                            actionText = "RECONNECT"
                                        )
                                    }
                                }
                            }
                        }

                        override fun onToolCall(callId: String, name: String, args: JSONObject) {
                            val isLeaseActive = (System.currentTimeMillis() - lastOwnerVerifiedTimestamp) < 120_000L
                            val hasNoIncomingSpeech = !hasSpeechInCurrentUtterance && currentTurnUserText.isEmpty()
                            val isOwnerVerifiedOrAutonomous = isCurrentTurnOwnerVoiceVerified || isLeaseActive || hasNoIncomingSpeech || isAutonomousTaskRunning

                            if (preferences.isOwnerVoiceEnabled && preferences.hasOwnerVoiceProfile() && !isOwnerVerifiedOrAutonomous) {
                                Log.w("JarvisService", "QUEUED tool call '$name' (callId=$callId): Owner verification pending, will execute after silence detection confirms speaker.")
                                pendingToolCalls.add(PendingToolCall(callId, name, args))
                                return
                            }
                            handleToolCallExecution(callId, name, args)
                        }
                    }
                ).apply {
                    // System prompt is already baked into the constructor; no need to regenerate on reconnect.
                    // promptProvider removed to eliminate double-generation latency.
                    connect(serviceScope)
                }
            }
        }

        audioRecorder = AudioRecorder { chunk, amplitude, frequencyData ->
            if (_isSessionOn.value) {
                val now = System.currentTimeMillis()

                // Acoustic Echo Decay Protection (AEDP):
                // For 150ms after speaker audio stops, discard mic chunks so room reverberation
                // does not bounce into Gemini Live and cause false self-interruption.
                if (now - lastPlaybackEndTime < 150L) {
                    consecutiveVoicedFrames = 0
                    return@AudioRecorder
                }

                // Assistant is speaking / AudioTrack or TTS is actively playing:
                val isSpeakerActive = (audioPlayer?.isPlaying() == true) || (tts?.isSpeaking == true) ||
                        (_conversationState.value == ConversationState.SPEAKING)

                if (isSpeakerActive) {
                    val hasHeadset = headsetAudioRouter?.isHeadsetConnected() == true
                    // Only allow voice barge-in if headphones/headset are connected AND assistant is already speaking!
                    // Over the phone loudspeaker, acoustic leakage from speaker into microphone
                    // hits amplitudes of 0.8-1.0, which causes false self-interruption ("talks in middle and cuts off").
                    // Over loudspeaker, users tap mic/orb to interrupt, as prompted on screen.
                    if (hasHeadset) {
                        if (amplitude > 0.25f) {
                            consecutiveVoicedFrames++
                            if (consecutiveVoicedFrames >= 4) {
                                Log.i("JarvisService", "Headset voice barge-in: user spoke over assistant (amp=$amplitude)")
                                audioPlayer?.flush()
                                try { tts?.stop() } catch (_: Exception) {}
                                setConversationState(ConversationState.LISTENING)
                                lastUserSpeechDetectedTime = now
                                hasSpeechInCurrentUtterance = true
                                hasSignalledUtteranceEnd = false
                                currentTurnUserText.clear()
                                currentTurnAssistantText.clear()
                                _liveUserTranscript.value = ""
                                _liveAssistantResponse.value = ""
                                hasExecutedCommandInCurrentTurn = false
                                totalVoicedFramesInCurrentUtterance = 4
                                synchronized(currentUtteranceAudioStream) {
                                    currentUtteranceAudioStream.reset()
                                    currentUtteranceAudioStream.write(chunk)
                                }
                                isCurrentTurnOwnerVoiceVerified = !preferences.isOwnerVoiceEnabled || !preferences.hasOwnerVoiceProfile()
                                return@AudioRecorder
                            }
                        } else {
                            consecutiveVoicedFrames = 0
                        }
                    } else {
                        consecutiveVoicedFrames = 0
                    }
                    // Suppress mic audio from streaming to Gemini ONLY while assistant is physically speaking over loudspeaker.
                    return@AudioRecorder
                }

                // Stream user speech to Gemini Live
                if (liveWebSocket?.isSessionReady() == true) {
                    while (!preConnectAudioQueue.isEmpty()) {
                        val queued = preConnectAudioQueue.poll() ?: break
                        liveWebSocket?.sendAudioChunk(queued)
                    }
                    liveWebSocket?.sendAudioChunk(chunk)
                } else {
                    // Connection still warming up: buffer up to 60 chunks (~1.2s of audio) so early speech is never lost
                    if (preConnectAudioQueue.size < 60) {
                        preConnectAudioQueue.offer(chunk.copyOf())
                    }
                }

                // Track ambient noise floor adaptively when quiet
                if (amplitude < 0.10f) {
                    ambientNoiseFloor = (ambientNoiseFloor * 0.97f + amplitude * 0.03f).coerceIn(0.015f, 0.10f)
                }

                // Maintain pre-speech buffer of recent chunks (for smooth onset capture)
                synchronized(preSpeechRingBuffer) {
                    if (preSpeechRingBuffer.size >= 10) {
                        preSpeechRingBuffer.pollFirst()
                    }
                    preSpeechRingBuffer.addLast(chunk.copyOf())
                }

                // Dynamic voice threshold: responsive to normal conversational volume (0.035f)
                val voiceThreshold = maxOf(VAD_MIN_THRESHOLD, ambientNoiseFloor * VAD_NOISE_MULTIPLIER)

                if (amplitude > voiceThreshold) {
                    consecutiveVoicedFrames++
                    lastUserSpeechDetectedTime = now
                    _audioLevel.value = amplitude
                    _audioFrequency.value = frequencyData

                    // Declare speech start only after several consecutive voiced frames (not a short noise blip)
                    if (consecutiveVoicedFrames >= VAD_START_FRAMES) {
                        if (!hasSpeechInCurrentUtterance) {
                            currentTurnUserText.clear()
                            currentTurnAssistantText.clear()
                            _liveUserTranscript.value = ""
                            _liveAssistantResponse.value = ""
                            hasExecutedCommandInCurrentTurn = false
                            totalVoicedFramesInCurrentUtterance = 0
                            synchronized(currentUtteranceAudioStream) {
                                currentUtteranceAudioStream.reset()
                                synchronized(preSpeechRingBuffer) {
                                    for (preChunk in preSpeechRingBuffer) {
                                        currentUtteranceAudioStream.write(preChunk)
                                    }
                                }
                            }
                            isCurrentTurnOwnerVoiceVerified = !preferences.isOwnerVoiceEnabled || !preferences.hasOwnerVoiceProfile()
                        }
                        hasSpeechInCurrentUtterance = true
                        hasSignalledUtteranceEnd = false
                        totalVoicedFramesInCurrentUtterance++
                        // EARLY VOICE VERIFICATION: Verify owner as soon as we have enough voiced audio (300ms)
                        // This ensures verification completes BEFORE Gemini starts sending response audio
                        if (!isCurrentTurnOwnerVoiceVerified && preferences.isOwnerVoiceEnabled && preferences.hasOwnerVoiceProfile() && totalVoicedFramesInCurrentUtterance == 15) {
                            val audioSnapshot = synchronized(currentUtteranceAudioStream) { currentUtteranceAudioStream.toByteArray() }
                            if (audioSnapshot.size >= 16000 * 2 * 0.25) {
                                serviceScope.launch(Dispatchers.Default) {
                                    val match = com.jarvis.assistant.audio.OwnerVoiceManager.verifySpeakerAudio(audioSnapshot, preferences)
                                    if (match.isMatch || match.distance < match.threshold * 1.35f) {
                                        lastOwnerVerifiedTimestamp = System.currentTimeMillis()
                                        isCurrentTurnOwnerVoiceVerified = true
                                        Log.i("JarvisService", "EARLY voice verification PASSED: Owner confirmed during speech (dist=${match.distance}, sim=${match.similarityPercent}%)")
                                        processPendingToolCalls(verified = true)
                                    } else if (match.hasExtractedVector) {
                                        Log.w("JarvisService", "EARLY voice verification FAILED: Non-owner detected (dist=${match.distance}, thr=${match.threshold})")
                                        // Don't reject yet - let silence handler do final check with more audio
                                    }
                                }
                            }
                        }
                        synchronized(currentUtteranceAudioStream) {
                            if (currentUtteranceAudioStream.size() < 480000) {
                                currentUtteranceAudioStream.write(chunk)
                            }
                        }
                        if (_conversationState.value != ConversationState.LISTENING) {
                            setConversationState(ConversationState.LISTENING)
                        }
                    }
                } else {
                    // Gradual decrement instead of instant reset: one quiet 20ms frame won't kill voiced speech tracking
                    if (consecutiveVoicedFrames > 0) consecutiveVoicedFrames--
                    val silentDuration = now - lastUserSpeechDetectedTime

                    if (hasSpeechInCurrentUtterance && silentDuration < 450) {
                        // Keep buffering inter-word pauses so Vosk receives natural continuous audio
                        synchronized(currentUtteranceAudioStream) {
                            if (currentUtteranceAudioStream.size() < 480000) {
                                currentUtteranceAudioStream.write(chunk)
                            }
                        }
                    }

                    if (_conversationState.value == ConversationState.LISTENING) {
                        _audioLevel.value = amplitude
                        _audioFrequency.value = frequencyData

                        // Conversational pause reached (~450ms — safe for natural Hinglish speech with inter-word pauses)
                        if (silentDuration > 450) {
                            if (preferences.isOwnerVoiceEnabled && preferences.hasOwnerVoiceProfile()) {
                                val isLeaseActive = (now - lastOwnerVerifiedTimestamp) < 120_000L
                                if (isLeaseActive) {
                                    // Ultra-low latency: Active owner lease immediately confirms turn with 0ms delay
                                    lastOwnerVerifiedTimestamp = now
                                    isCurrentTurnOwnerVoiceVerified = true
                                    processPendingToolCalls(verified = true)
                                } else if (!isCurrentTurnOwnerVoiceVerified) {
                                    val audioBytes = synchronized(currentUtteranceAudioStream) {
                                        currentUtteranceAudioStream.toByteArray()
                                    }
                                    if (audioBytes.size >= 16000 * 2 * 0.3) {
                                        val match = com.jarvis.assistant.audio.OwnerVoiceManager.verifySpeakerAudio(audioBytes, preferences)
                                        if (match.isMatch || match.distance < match.threshold * 1.35f) {
                                            lastOwnerVerifiedTimestamp = now
                                            isCurrentTurnOwnerVoiceVerified = true
                                            Log.i("JarvisService", "Speech verification passed: Owner confirmed (dist: ${match.distance}, sim: ${match.similarityPercent}%)")
                                            processPendingToolCalls(verified = true)
                                        } else {
                                            isCurrentTurnOwnerVoiceVerified = false
                                            audioPlayer?.flush()
                                            currentTurnAssistantText.clear()
                                            _liveAssistantResponse.value = ""
                                            Log.w("JarvisService", "Speech verification rejected: Non-owner (dist: ${match.distance}, thr: ${match.threshold})")
                                            processPendingToolCalls(verified = false)
                                        }
                                    } else {
                                        isCurrentTurnOwnerVoiceVerified = !preferences.isOwnerVoiceEnabled || !preferences.hasOwnerVoiceProfile()
                                        if (!isCurrentTurnOwnerVoiceVerified) {
                                            processPendingToolCalls(verified = false)
                                        }
                                    }
                                }
                            }

                            if (totalVoicedFramesInCurrentUtterance >= VAD_MIN_UTTERANCE_FRAMES || currentTurnUserText.trim().isNotEmpty()) {
                                if (preferences.isOwnerVoiceEnabled && preferences.hasOwnerVoiceProfile() && !isCurrentTurnOwnerVoiceVerified) {
                                    val nonOwnerQuery = currentTurnUserText.toString().trim()
                                    Log.w("JarvisService", "Non-owner speech ended: '$nonOwnerQuery'; IGNORING utterance, suppressing reply, and recording to history.")
                                    val app = application as? JarvisApp
                                    val loggedQuery = if (nonOwnerQuery.isNotEmpty()) nonOwnerQuery else "(Unrecognized voice)"
                                    app?.chatRepository?.addTurn(
                                        userText = "[Non-Owner Voice]: $loggedQuery",
                                        jarvisText = "[IGNORED] Voice not recognized as owner"
                                    )
                                    audioPlayer?.flush()
                                    currentTurnAssistantText.clear()
                                    currentTurnUserText.clear()
                                    _liveUserTranscript.value = ""
                                    _liveAssistantResponse.value = ""
                                    hasSpeechInCurrentUtterance = false
                                    hasSignalledUtteranceEnd = false
                                    consecutiveVoicedFrames = 0
                                    totalVoicedFramesInCurrentUtterance = 0
                                    synchronized(currentUtteranceAudioStream) { currentUtteranceAudioStream.reset() }
                                    setConversationState(ConversationState.IDLE)
                                    processPendingToolCalls(verified = false)
                                } else {
                                    if (!hasSignalledUtteranceEnd) {
                                        hasSignalledUtteranceEnd = true
                                        // If screen capture is active, send one fresh snapshot right with the question
                                        if (com.jarvis.assistant.vision.ScreenCaptureManager.getInstance().isSharing.value) {
                                            val snapshot = com.jarvis.assistant.vision.ScreenCaptureManager.getInstance().captureSnapshotJpeg(60)
                                            if (snapshot != null && snapshot.isNotEmpty()) {
                                                liveWebSocket?.sendMediaChunk(snapshot)
                                            }
                                        }
                                    }
                                    setConversationState(ConversationState.THINKING)
                                    thinkingTimeoutJob?.cancel()
                                    thinkingTimeoutJob = serviceScope.launch {
                                        delay(15000)
                                        if (_conversationState.value == ConversationState.THINKING && (audioPlayer == null || !audioPlayer!!.isPlaying())) {
                                            Log.i("JarvisService", "Thinking timeout safety; returning to IDLE")
                                            setConversationState(ConversationState.IDLE)
                                            lastResponseTimedOut = true
                                            updateNotification()
                                            serviceScope.launch { _events.emit("Jarvis did not receive a reply. Check the connection and repeat your request.") }
                                        }
                                    }
                                }
                            } else {
                                // Short acoustic pop / ambient noise - return cleanly to IDLE
                                hasSpeechInCurrentUtterance = false
                                hasSignalledUtteranceEnd = false
                                setConversationState(ConversationState.IDLE)
                            }
                        }
                    } else if (_conversationState.value == ConversationState.IDLE) {
                        _audioLevel.value = 0f
                    }
                }
            }
        }.apply {
            setMuted(preferences.isMicMuted)
            start(serviceScope)
        }
    }

    private var lastHandledCommandText = ""
    private var lastHandledAssistantCommand = ""
    @Volatile
    private var hasExecutedCommandInCurrentTurn = false
    @Volatile
    private var lastCommandExecutionTime = 0L

    // Holds a command that Jarvis heard but isn't confident enough about to run blindly
    // (e.g. a YouTube title that sounded too short/garbled). Cleared once the user
    // confirms or cancels it in a follow-up turn.
    @Volatile
    private var pendingGenericCommand: com.jarvis.assistant.automation.command.JarvisCommand? = null

    /**
     * Executes a tool call from Gemini. Called both from the direct onToolCall path
     * (when owner is already verified) and from processPendingToolCalls (after verification completes).
     */
    private fun handleToolCallExecution(callId: String, name: String, args: JSONObject) {
        val job = serviceScope.launch(Dispatchers.IO) {
            val thisJob = coroutineContext[Job]
            if (thisJob != null) activeToolJobs.add(thisJob)
            try {
                toolExecutionMutex.withLock {
                    if (!isActive) return@withLock
                    isExecutingTool = true
                    try {
                        withTimeout(automationToolTimeoutMs()) {
                            val app = application as? JarvisApp ?: return@withTimeout

                hasExecutedCommandInCurrentTurn = true
                lastCommandExecutionTime = System.currentTimeMillis()
                suppressAudioUntilTurnComplete = false

                val isAutomationTool = name in setOf(
                    "open_app", "open_website", "search_in_chrome",
                    "click_ui_element", "type_text", "scroll_screen", "press_key"
                )
                if (isAutomationTool && autonomousHardStop) {
                    Log.w("JarvisService", "Automation tool '$name' refused: hard stop is active.")
                    liveWebSocket?.sendToolResponse(callId, name, JSONObject().apply {
                        put("success", false)
                        put("autonomous_status", "STOPPED")
                        put("message", "STOPPED: automation was halted (repeated failures or too many steps). Do NOT call any more tools. Tell the user honestly, in one or two short sentences, what you actually completed and where you got stuck, then wait for their next instruction.")
                    })
                    return@withTimeout
                }
                if (isAutomationTool) {
                    if (preferences.isSilentExecutionMode) audioPlayer?.flush()
                    autonomousContinuationAttempts = 0
                        autonomousWaitingForUser = false
                    if (!isAutonomousTaskRunning) {
                        synchronized(autonomousSpokenFingerprints) {
                            autonomousSpokenFingerprints.clear()
                            autonomousSpokenUpdateCount = 0
                        }
                        isAutonomousTaskRunning = true
                        autonomousStepCount = 1
                        isGoogleFlowCreationTask = false
                        flowPromptVerified = false
                        flowGenerationVerified = false
                        lastVerifiedFlowPrompt = ""
                        val userText = currentTurnUserText.toString().trim()
                        autonomousTaskGoal = if (userText.isNotEmpty()) userText else "Complete $name automation task"
                        com.jarvis.assistant.automation.agent.AgentTaskEngine.begin(autonomousTaskGoal, "gemini-live-tools")
                        bulkEndOfListVerified = false
                        bulkNoProgressScrollCount = 0
                        lastBulkScreenSignature = null
                        val activeRoot = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance?.getActiveRootNode()
                        val activeElements = com.jarvis.assistant.vision.UiGroundingEngine().scanScreen(activeRoot)
                        isGoogleFlowCreationTask = com.jarvis.assistant.vision.UiGroundingEngine().isGoogleFlowSurface(activeElements) &&
                            isFlowCreationIntent(autonomousTaskGoal)
                        Log.i("JarvisService", "Started autonomous task loop with goal: '$autonomousTaskGoal'")
                    } else {
                        autonomousStepCount++
                        Log.i("JarvisService", "Autonomous task advancing to step $autonomousStepCount")
                    }
                }

                if (name in setOf("click_ui_element", "type_text", "scroll_screen", "press_key")) {
                    val expectedPackage = expectedPackageForTask(autonomousTaskGoal)
                    val activePackage = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance
                        ?.getActiveRootNode()?.packageName?.toString()?.lowercase(Locale.ROOT).orEmpty()
                    if (expectedPackage != null && !activePackage.contains(expectedPackage)) {
                        Log.w("JarvisService", "Blocked stale cross-app action '$name': task expects '$expectedPackage', foreground is '$activePackage'.")
                        val screenSummary = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance().inspectScreen(waitForContent = true)
                        val mismatchResult = JSONObject().apply {
                            put("success", false)
                            put("verified", false)
                            put("message", "Action blocked because the foreground app does not match the user's current task. Expected an app matching '$expectedPackage', but the current app is '$activePackage'. Reopen the intended app and inspect it before continuing.")
                            put("current_screen_elements", screenSummary)
                        }
                        liveWebSocket?.sendToolResponse(callId, name, mismatchResult)
                        return@withTimeout
                    }
                }

                Log.i("JarvisService", "Handling native toolCall: $name with args: $args")
                val result = JSONObject()

                when (name) {
                    "open_app" -> {
                        val appName = args.optString("app_name", "")
                        val appNumber = if (args.has("app_number")) args.optInt("app_number", 1) else null

                        // 1. FAST PATH: Web platform tools (Google Flow, Runway, etc.) -> open directly in Chrome without scanning apps!
                        val directWebUrl = app.phoneControlManager.parseTargetUrl(appName)
                        if (directWebUrl != null) {
                            if (directWebUrl.contains("flow.google", ignoreCase = true) && isFlowCreationIntent(autonomousTaskGoal)) {
                                isGoogleFlowCreationTask = true
                            }
                            Log.i("JarvisService", "open_app: '$appName' is web platform, target URL: $directWebUrl")
                            val a11y = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance
                            val currentPkg = a11y?.getActiveRootNode()?.packageName?.toString() ?: ""
                            val isAlreadyInBrowser = currentPkg.contains("chrome", ignoreCase = true) || currentPkg.contains("browser", ignoreCase = true)
                            val now = System.currentTimeMillis()

                            // ANTI-RELOAD GUARD: If Chrome is ALREADY in foreground and website was opened within 20s, do not reload!
                            if (isAlreadyInBrowser && lastOpenedWebUrl == directWebUrl && (now - lastOpenedWebTime < 20_000L)) {
                                Log.i("JarvisService", "open_app: already on $directWebUrl in Chrome. Suppressing redundant re-open.")
                                val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                                val (_, summary) = waitForWebDestination(orchestrator, directWebUrl)
                                result.put("success", true)
                                result.put("verified", true)
                                result.put("message", "Already on $directWebUrl in Chrome. The page is currently open on screen. DO NOT call open_app or open_website again! Locate UI elements on screen (e.g. '+ New project' or prompt box) and proceed.")
                                if (summary.isNotBlank()) result.put("current_screen_elements", summary)
                            } else {
                                lastOpenedWebUrl = directWebUrl
                                lastOpenedWebTime = now
                                val webLaunched = executeSerializedTaskMutation("open-url:$directWebUrl") {
                                    app.phoneControlManager.openUrlsInChromeTabs(listOf(directWebUrl))
                                }
                                result.put("success", webLaunched)
                                result.put("message", if (webLaunched) "Opened $directWebUrl in Chrome." else "Failed to open $directWebUrl.")
                                val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                                val (destinationReady, summary) = waitForWebDestination(orchestrator, directWebUrl)
                                if (summary.isNotBlank()) {
                                    result.put("current_screen_elements", summary)
                                } else {
                                    result.put("current_screen_elements", "Navigated to $directWebUrl. Use the latest available screen context; inspect_screen returns accessibility text unless Screen Share has a confirmed frame.")
                                }
                                if (!destinationReady) {
                                    result.put("message", "Navigation was requested, but Chrome has not yet confirmed the destination page. Wait and inspect the current screen before tapping or typing.")
                                }
                                result.put("verified", destinationReady)
                            }
                        } else {
                            // 2. Native app launch via AppLauncher
                            val launched = executeSerializedTaskMutation("open-app:$appName") {
                                com.jarvis.assistant.util.AppLauncher.launchApp(this@JarvisConversationService, appName, appNumber)
                            }
                            if (launched) {
                                Log.i("JarvisService", "open_app: launched native app '$appName'")
                                result.put("success", true)
                                result.put("message", "Opened $appName app.")
                                val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                                val startupWait = orchestrator.waitForUiState(
                                    expectedPackage = expectedPackageForTask(autonomousTaskGoal),
                                    timeoutMs = 12_000L
                                )
                                val summary = com.jarvis.assistant.vision.UiGroundingEngine().formatElementsSummary(startupWait.elements, startupWait.root)
                                if (summary.isNotBlank()) {
                                    result.put("current_screen_elements", summary)
                                } else {
                                    result.put("current_screen_elements", "Opened $appName. Use the latest available screen context; inspect_screen returns accessibility text unless Screen Share has a confirmed frame.")
                                }
                                val foregroundPackage = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance
                                    ?.getActiveRootNode()?.packageName?.toString().orEmpty()
                                val expectedPackage = expectedPackageForTask(autonomousTaskGoal)
                                val appVerified = startupWait.ready &&
                                    (expectedPackage?.let { foregroundPackage.contains(it, ignoreCase = true) } ?: foregroundPackage.isNotBlank())
                                result.put("verified", appVerified)
                                val spotifyPlaybackRequest = expectedPackageForTask(autonomousTaskGoal) == "spotify" &&
                                    listOf("play", "bajao", "chalao", "gaana chala", "gana chala")
                                        .any { autonomousTaskGoal.contains(it, ignoreCase = true) }
                                if (launched && spotifyPlaybackRequest && appName.contains("spotify", ignoreCase = true)) {
                                    val playback = orchestrator.runSpotifySmartSearch(autonomousTaskGoal)
                                    result.put("success", playback.success)
                                    result.put("verified", playback.verified ?: false)
                                    result.put("message", playback.message)
                                    if (playback.currentStateSummary.isNotBlank()) {
                                        result.put("current_screen_elements", playback.currentStateSummary)
                                    }
                                }
                            } else {
                                result.put("success", false)
                                result.put("message", "Could not find or open $appName.")
                            }
                        }
                    }

                    "open_website" -> {
                        val targetUrls = mutableListOf<String>()
                        val jsonUrls = args.optJSONArray("urls")
                        if (jsonUrls != null) {
                            for (i in 0 until jsonUrls.length()) {
                                val u = jsonUrls.getString(i).trim()
                                if (u.isNotEmpty()) targetUrls.add(u)
                            }
                        }
                        val query = args.optString("query", "").trim()
                        if (query.isNotEmpty()) {
                            val extracted = app.phoneControlManager.extractUrlsFromText(query)
                            for (u in extracted) {
                                if (!targetUrls.contains(u)) targetUrls.add(u)
                            }
                            if (targetUrls.isEmpty()) {
                                val single = app.phoneControlManager.parseTargetUrl(query)
                                if (single != null) targetUrls.add(single)
                            }
                        }
                        if (targetUrls.isEmpty() && query.isNotBlank()) {
                            targetUrls.add("https://www.google.com/search?q=${Uri.encode(query)}")
                        }
                        val primaryUrl = targetUrls.firstOrNull() ?: ""
                        if (targetUrls.any { it.contains("flow.google", ignoreCase = true) } && isFlowCreationIntent(autonomousTaskGoal)) {
                            isGoogleFlowCreationTask = true
                        }
                        val a11y = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance
                        val currentPkg = a11y?.getActiveRootNode()?.packageName?.toString() ?: ""
                        val isAlreadyInBrowser = currentPkg.contains("chrome", ignoreCase = true) || currentPkg.contains("browser", ignoreCase = true)
                        val now = System.currentTimeMillis()

                        // ANTI-RELOAD LOOP GUARD: If Chrome is ALREADY in foreground and website was launched within 20 seconds,
                        // do NOT re-fire Intent to reload Chrome! Give Chrome time to render and inspect the screen!
                        if (isAlreadyInBrowser && primaryUrl.isNotBlank() && lastOpenedWebUrl == primaryUrl && (now - lastOpenedWebTime < 20_000L)) {
                            Log.i("JarvisService", "open_website: already on $primaryUrl in Chrome. Suppressing redundant reload.")
                            val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                            val (_, summary) = waitForWebDestination(orchestrator, primaryUrl)
                            result.put("success", true)
                            result.put("message", "Already on $primaryUrl in Chrome. The web page is currently loading/open on screen. DO NOT call open_website again! Look at current_screen_elements or video feed to type prompt or click buttons.")
                            if (summary.isNotBlank()) result.put("current_screen_elements", summary)
                        } else {
                            if (primaryUrl.isNotBlank()) {
                                lastOpenedWebUrl = primaryUrl
                                lastOpenedWebTime = now
                            }
                            val ok = executeSerializedTaskMutation("open-urls") {
                                app.phoneControlManager.openUrlsInChromeTabs(targetUrls)
                            }
                            result.put("success", ok)
                            if (ok) {
                                result.put("message", if (targetUrls.size > 1) "Opened ${targetUrls.size} websites in separate Chrome tabs: ${targetUrls.joinToString(", ")}." else "Opened ${targetUrls.firstOrNull() ?: "website"} in Chrome.")
                                val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                                val (destinationReady, summary) = waitForWebDestination(orchestrator, primaryUrl)
                                if (summary.isNotBlank()) {
                                    result.put("current_screen_elements", summary)
                                }
                                if (!destinationReady) {
                                    result.put("message", "Navigation was requested, but Chrome has not confirmed the destination page yet. Wait and inspect before acting.")
                                }
                            } else {
                                result.put("message", "Could not open the requested websites.")
                            }
                        }
                    }

                    "search_in_chrome" -> {
                        val query = args.optString("query", "").trim()
                        val extracted = app.phoneControlManager.extractUrlsFromText(query)
                        if (extracted.isNotEmpty()) {
                            val ok = executeSerializedTaskMutation("open-search-results") {
                                app.phoneControlManager.openUrlsInChromeTabs(extracted)
                            }
                            result.put("success", ok)
                            result.put("message", if (extracted.size > 1) "Opened ${extracted.size} websites in separate Chrome tabs: ${extracted.joinToString(", ")}." else "Opened ${extracted.first()} in Chrome.")
                            delay(200)
                            val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                            val summary = orchestrator.inspectScreen(waitForContent = true)
                            if (summary.isNotBlank()) {
                                result.put("current_screen_elements", summary)
                            }
                        } else {
                            val targetUrl = app.phoneControlManager.parseTargetUrl(query)
                            val searchUrl = targetUrl ?: "https://www.google.com/search?q=${Uri.encode(query)}"
                            val ok = executeSerializedTaskMutation("open-search-url") {
                                app.phoneControlManager.openUrlsInChromeTabs(listOf(searchUrl))
                            }
                            result.put("success", ok)
                            result.put("message", if (targetUrl != null) "Opened $targetUrl in Chrome." else "Searched \"$query\" in Chrome.")
                            delay(200)
                            val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                            val summary = orchestrator.inspectScreen(waitForContent = true)
                            if (summary.isNotBlank()) {
                                result.put("current_screen_elements", summary)
                            }
                            if (targetUrl == null) {
                                result.put("action_required", "CRITICAL NEXT STEP: You are on the Google Search results page for \"$query\". Look at the search result links in current_screen_elements and IMMEDIATELY call click_ui_element with the link name or element_id to open the website! Do NOT claim you refined or created the video until you enter the website and submit the generation!")
                            }
                        }
                    }

                    "search_and_play_youtube" -> {
                        val query = args.optString("query", "").trim()
                        audioPlayer?.flush()
                        val apiKey = app.youTubePreferences.youtubeApiKey
                        val effectiveQuery = if (query.isBlank() || query.equals("video", ignoreCase = true) || query.equals("song", ignoreCase = true) || query.equals("a song", ignoreCase = true) || query.equals("songs", ignoreCase = true)) {
                            "my favorite song"
                        } else {
                            query
                        }
                        val resolvedSong = app.memoryManager.resolveSongQuery(effectiveQuery)
                        app.memoryManager.trackSongPlay(resolvedSong)
                        val playResult = com.jarvis.assistant.automation.youtube.YouTubeController.searchAndPlay(this@JarvisConversationService, resolvedSong, apiKey)
                        result.put("success", playResult.success)
                        result.put("message", playResult.message ?: if (playResult.success) "Playing $resolvedSong on YouTube." else "Could not play on YouTube.")
                    }

                    "search_youtube" -> {
                        val query = args.optString("query", "").trim()
                        val lower = query.lowercase()
                        val isPlayIntent = lower.startsWith("play ") ||
                                lower == "play" || lower == "video" || lower == "play video" ||
                                lower == "a video" || lower == "song" || lower == "play song" ||
                                lower == "a song" || lower == "music" ||
                                lower.contains(" chalao") || lower.contains(" bajao")
                        if (isPlayIntent) {
                            Log.i("JarvisService", "STRICT RULE INTERCEPTION: search_youtube called with play intent ('$query') -> rerouting to search_and_play_youtube!")
                            audioPlayer?.flush()
                            val apiKey = app.youTubePreferences.youtubeApiKey
                            val effectiveQuery = if (query.isBlank() || query.equals("video", ignoreCase = true) || query.equals("play video", ignoreCase = true) || query.equals("song", ignoreCase = true) || query.equals("play song", ignoreCase = true) || query.equals("a song", ignoreCase = true) || query.equals("songs", ignoreCase = true)) {
                                "my favorite song"
                            } else {
                                query.replace(Regex("(?i)^play\\s+"), "")
                            }
                            val resolvedSong = app.memoryManager.resolveSongQuery(effectiveQuery)
                            app.memoryManager.trackSongPlay(resolvedSong)
                            val playResult = com.jarvis.assistant.automation.youtube.YouTubeController.searchAndPlay(this@JarvisConversationService, resolvedSong, apiKey)
                            result.put("success", playResult.success)
                            result.put("message", playResult.message ?: if (playResult.success) "Playing $resolvedSong on YouTube." else "Could not play on YouTube.")
                        } else {
                            val searchResult = com.jarvis.assistant.automation.youtube.YouTubeController.searchYouTube(this@JarvisConversationService, query)
                            result.put("success", searchResult.success)
                            result.put("message", searchResult.message ?: "Opened YouTube search results.")
                        }
                    }

                    "youtube_accessibility_action" -> {
                        val action = args.optString("action", "").trim()
                        val a11y = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance
                        if (a11y != null) {
                            val actionOk = when (action) {
                                "skip_ad" -> a11y.skipAd()
                                "like" -> a11y.likeVideo()
                                "subscribe" -> a11y.subscribeChannel()
                                "open_channel" -> a11y.openChannel()
                                "fullscreen" -> a11y.toggleFullscreen()
                                "click_first" -> a11y.clickFirstVideoResult()
                                else -> false
                            }
                            result.put("success", actionOk)
                            result.put("message", if (actionOk) "Action '$action' executed." else "Could not perform action '$action'.")
                        } else {
                            result.put("success", false)
                            result.put("message", "Accessibility service is not enabled. Please enable it in Settings.")
                        }
                    }

                    "media_playback_control" -> {
                        val action = args.optString("action", "").trim()
                        val ok = com.jarvis.assistant.automation.youtube.YouTubeController.sendMediaKey(this@JarvisConversationService, action)
                        result.put("success", ok)
                        result.put("message", "Media action '$action' performed.")
                    }

                    "send_whatsapp_message" -> {
                        val recipient = args.optString("recipient_name", "").trim()
                        val message = args.optString("message", "").trim()
                        val appNumber = if (args.has("app_number")) args.optInt("app_number", 1) else null
                        val confirmed = args.optBoolean("confirmed", true)
                        audioPlayer?.flush()
                        val waResult = com.jarvis.assistant.util.WhatsAppMessenger.sendMessage(this@JarvisConversationService, recipient, message, appNumber, confirmed)
                        when (waResult) {
                            is com.jarvis.assistant.util.WhatsAppMessenger.SendResult.Success -> {
                                result.put("success", true) // WhatsApp opened and the send action was queued.
                                result.put("sent", false) // The asynchronous accessibility tap is not delivery proof.
                                result.put("message", "Opened WhatsApp for ${waResult.contactName} and queued the send action. Sending is not yet verified. Inspect the current chat; only report it sent if the outgoing message is visible, not while it remains a draft.")
                            }
                            is com.jarvis.assistant.util.WhatsAppMessenger.SendResult.RequiresConfirmation -> {
                                result.put("success", false)
                                result.put("requires_confirmation", true)
                                result.put("message", "Please confirm sending the WhatsApp message to ${waResult.contactName}.")
                            }
                            is com.jarvis.assistant.util.WhatsAppMessenger.SendResult.MultipleAppsFound -> {
                                result.put("success", false)
                                result.put("message", "Multiple WhatsApp apps found. Please specify WhatsApp 1 or 2.")
                            }
                            is com.jarvis.assistant.util.WhatsAppMessenger.SendResult.ContactNotFound -> {
                                result.put("success", false)
                                result.put("message", "Could not find contact ${waResult.name}.")
                            }
                            is com.jarvis.assistant.util.WhatsAppMessenger.SendResult.MultipleContactsFound -> {
                                result.put("success", false)
                                result.put("message", "Multiple contacts found for ${waResult.name}.")
                            }
                            is com.jarvis.assistant.util.WhatsAppMessenger.SendResult.MissingPermission -> {
                                result.put("success", false)
                                result.put("message", "Contacts permission not granted.")
                            }
                            is com.jarvis.assistant.util.WhatsAppMessenger.SendResult.Error -> {
                                result.put("success", false)
                                result.put("message", waResult.reason)
                            }
                        }
                    }

                    "whatsapp_call" -> {
                        val recipient = args.optString("recipient_name", "").trim()
                        val callType = args.optString("call_type", "voice").trim()
                        val appNumber = if (args.has("app_number")) args.optInt("app_number", 1) else null
                        val confirmed = args.optBoolean("confirmed", true)
                        audioPlayer?.flush()
                        val callResult = com.jarvis.assistant.util.WhatsAppMessenger.placeCall(this@JarvisConversationService, recipient, callType, appNumber, confirmed)
                        val (ok, msg) = when (callResult) {
                            is com.jarvis.assistant.util.WhatsAppMessenger.CallResult.Success -> Pair(true, "Calling ${callResult.contactName} on WhatsApp.")
                            is com.jarvis.assistant.util.WhatsAppMessenger.CallResult.RequiresConfirmation -> Pair(true, "Please confirm WhatsApp call to ${callResult.contactName}.")
                            is com.jarvis.assistant.util.WhatsAppMessenger.CallResult.MultipleAppsFound -> Pair(false, "Multiple WhatsApp apps found. Please specify WhatsApp 1 or 2.")
                            is com.jarvis.assistant.util.WhatsAppMessenger.CallResult.ContactNotFound -> Pair(false, "Could not find contact ${callResult.name}.")
                            is com.jarvis.assistant.util.WhatsAppMessenger.CallResult.MultipleContactsFound -> Pair(false, "Multiple contacts found for ${callResult.name}.")
                            is com.jarvis.assistant.util.WhatsAppMessenger.CallResult.MissingPermission -> Pair(false, "Contacts permission not granted.")
                            is com.jarvis.assistant.util.WhatsAppMessenger.CallResult.Error -> Pair(false, callResult.reason)
                        }
                        result.put("success", ok)
                        result.put("message", msg)
                    }

                    "call_contact" -> {
                        val contact = args.optString("contact_name", "").trim()
                        audioPlayer?.flush()
                        val callResult = com.jarvis.assistant.util.ContactCaller.callContact(this@JarvisConversationService, contact)
                        val (ok, msg) = when (callResult) {
                            is com.jarvis.assistant.util.ContactCaller.CallResult.Success -> Pair(true, "Calling ${callResult.contact.name}.")
                            is com.jarvis.assistant.util.ContactCaller.CallResult.NoMatch -> Pair(false, "Could not find contact $contact.")
                            is com.jarvis.assistant.util.ContactCaller.CallResult.MultipleMatches -> Pair(false, "Multiple contacts found for $contact.")
                            is com.jarvis.assistant.util.ContactCaller.CallResult.MissingContactsPermission -> Pair(false, "Contacts permission is not granted, so JARVIS cannot look up that saved contact.")
                            is com.jarvis.assistant.util.ContactCaller.CallResult.MissingCallPermission -> Pair(false, "Phone call permission is not granted.")
                            is com.jarvis.assistant.util.ContactCaller.CallResult.CallFailed -> Pair(false, "Could not place phone call.")
                        }
                        result.put("success", ok)
                        result.put("message", msg)
                    }

                    "set_volume" -> {
                        val action = args.optString("action", "").trim()
                        val pct = if (args.has("percentage")) args.optInt("percentage", 50) else null
                        val msg = when {
                            action == "set" && pct != null -> app.phoneControlManager.setVolumePercent(pct)
                            action == "increase" -> app.phoneControlManager.adjustVolume(true)
                            action == "decrease" -> app.phoneControlManager.adjustVolume(false)
                            else -> "Volume unchanged."
                        }
                        result.put("success", true)
                        result.put("message", msg)
                    }

                    "set_brightness" -> {
                        val action = args.optString("action", "").trim()
                        val pct = if (args.has("percentage")) args.optInt("percentage", 50) else null
                        val msg = when {
                            action == "set" && pct != null -> app.phoneControlManager.setBrightnessPercent(pct)
                            action == "increase" -> app.phoneControlManager.adjustBrightness(true)
                            action == "decrease" -> app.phoneControlManager.adjustBrightness(false)
                            else -> "Brightness unchanged."
                        }
                        result.put("success", true)
                        result.put("message", msg)
                    }

                    "builtin_chrome_search" -> {
                        val query = args.optString("query", "").trim()
                        val searchExtracted = com.jarvis.assistant.util.BuiltInChromeEngine.searchAndExtract(query)
                        result.put("success", searchExtracted.isNotBlank())
                        result.put("result", searchExtracted)
                    }

                    "go_to_background" -> {
                        val userAskedForStandby = isExplicitStandbyCommand(currentTurnUserText.toString())
                        if (!userAskedForStandby) {
                            result.put("success", false)
                            result.put("message", "REFUSED: The user's current request did not explicitly ask Jarvis to go to standby. Keep the conversation active and continue the requested task.")
                        } else if (isAutonomousTaskRunning) {
                            // Going to standby mid-task stopped the conversation and left the task unfinished.
                            result.put("success", false)
                            result.put("message", "REFUSED: a task is still running. Do NOT go to background. Continue the task, or tell the user honestly what is blocking it.")
                        } else {
                            minimizeToHomeScreen()
                            enterStandby(announce = false)
                            result.put("success", true)
                            result.put("message", "Sent JARVIS to background standby mode.")
                        }
                    }

                    "set_flashlight" -> {
                        val enabled = args.optBoolean("enabled", true)
                        val msg = app.phoneControlManager.setFlashlight(enabled)
                        result.put("success", true)
                        result.put("message", msg)
                    }

                    "click_ui_element" -> {
                        val targetName = args.optString("target_name", "")
                        val elementId = if (args.has("element_id")) args.optInt("element_id") else null
                        val isToggle = args.optBoolean("is_toggle", false)
                        val desc = args.optString("description", "")
                        val x = if (args.has("x")) args.optInt("x") else null
                        val y = if (args.has("y")) args.optInt("y") else null
                        val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                        val activeRootForBatch = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance?.getActiveRootNode()
                        val hasExplicitInstagramUnlike = activeRootForBatch?.packageName?.toString()?.contains("instagram", true) == true &&
                            com.jarvis.assistant.vision.UiGroundingEngine().scanScreen(activeRootForBatch).any {
                                it.isClickable && it.primaryLabel.trim().startsWith("Unlike", true)
                            }
                        val actionRes = if (isInstagramBulkTask() && hasExplicitInstagramUnlike) {
                            orchestrator.runInstagramBulkUnlike(autonomousTaskGoal)
                        } else orchestrator.handleClick(
                                targetName, elementId, desc, isToggle, x, y,
                                allowChromeMenuForSettings = autonomousTaskGoal.contains("chrome", ignoreCase = true) &&
                                    autonomousTaskGoal.contains("settings", ignoreCase = true),
                                forbidAddingInstagramLike = isInstagramBulkTask(),
                                taskGoal = autonomousTaskGoal
                            )
                        result.put("success", actionRes.success)
                        result.put("message", actionRes.message)
                        actionRes.verified?.let { result.put("verified", it) }
                        if (actionRes.currentStateSummary.isNotBlank()) {
                            result.put("current_screen_elements", actionRes.currentStateSummary)
                        }
                        val instagramBatchEnd = isInstagramBulkTask() && actionRes.verified == true && actionRes.message.contains("stable end", true)
                        if (instagramBatchEnd) {
                            bulkEndOfListVerified = true
                            com.jarvis.assistant.automation.agent.AgentTaskEngine.current()?.let { task ->
                                bulkEndOfListVerified = task.completionEvidence == com.jarvis.assistant.automation.agent.AgentTaskEngine.CompletionEvidence.END_REACHED &&
                                    task.processedItemSignatures.isNotEmpty()
                            }
                        }
                        if (!instagramBatchEnd && isAutonomousTaskRunning && com.jarvis.assistant.automation.agent.TaskGoal.fromUserUtterance(autonomousTaskGoal).isBulkAction && actionRes.success) {
                            // Any successful item mutation invalidates a previous end-of-list observation.
                            bulkEndOfListVerified = false
                            bulkNoProgressScrollCount = 0
                            lastBulkScreenSignature = null
                        }
                        val clickTarget = targetName.lowercase(Locale.ROOT)
                        val isGenerateAction = clickTarget.contains("generate") || clickTarget.contains("start generation") ||
                            clickTarget.contains("submit") || clickTarget.contains("create arrow")
                        if (isGoogleFlowCreationTask && flowPromptVerified && isGenerateAction && actionRes.success) {
                            val summaryText = actionRes.currentStateSummary.lowercase(Locale.ROOT)
                            val promptMarker = lastVerifiedFlowPrompt.trim().lowercase(Locale.ROOT).take(20)
                            val promptVisibleInProject = promptMarker.length >= 8 && summaryText.contains(promptMarker)
                            val generatedProjectVisible = listOf("created oct", "generating", "generation in progress", "video generated")
                                .any(summaryText::contains)
                            flowGenerationVerified = promptVisibleInProject && generatedProjectVisible
                            Log.i("JarvisService", "Flow submit verification: prompt=$flowPromptVerified, generation=$flowGenerationVerified, tapVerified=${actionRes.verified}")
                        }
                        if (actionRes.requiresUserConfirmation) {
                            result.put("requires_confirmation", true)
                            autonomousWaitingForUser = true
                            com.jarvis.assistant.automation.agent.AgentTaskEngine.setState(
                                com.jarvis.assistant.automation.agent.AgentTaskEngine.State.BLOCKED
                            )
                        }
                    }

                    "type_text" -> {
                        val text = args.optString("text", "")
                        val targetInput = args.optString("target_input_name", "")
                        val submit = args.optBoolean("submit", false)
                        val x = if (args.has("x")) args.optInt("x") else null
                        val y = if (args.has("y")) args.optInt("y") else null
                        val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                        val actionRes = orchestrator.handleType(text, targetInput.takeIf { it.isNotBlank() }, submit, x, y)
                        result.put("success", actionRes.success)
                        result.put("message", actionRes.message)
                        actionRes.verified?.let { result.put("verified", it) }
                        if (actionRes.currentStateSummary.isNotBlank()) {
                            result.put("current_screen_elements", actionRes.currentStateSummary)
                        }
                        val isPromptTarget = targetInput.contains("prompt", ignoreCase = true) ||
                            targetInput.contains("create", ignoreCase = true) || targetInput.contains("describe", ignoreCase = true)
                        if (isGoogleFlowCreationTask && isPromptTarget && actionRes.success && actionRes.verified == true) {
                            flowPromptVerified = true
                            lastVerifiedFlowPrompt = text
                            flowGenerationVerified = false
                            Log.i("JarvisService", "Google Flow prompt readback verified (${text.length} chars)")
                        }
                    }

                    "scroll_screen" -> {
                        val dir = args.optString("direction", "down")
                        val dist = args.optString("distance", "small")
                        val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                        val activeRootForBatch = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance?.getActiveRootNode()
                        val hasExplicitInstagramUnlike = activeRootForBatch?.packageName?.toString()?.contains("instagram", true) == true &&
                            com.jarvis.assistant.vision.UiGroundingEngine().scanScreen(activeRootForBatch).any {
                                it.isClickable && it.primaryLabel.trim().startsWith("Unlike", true)
                            }
                        val actionRes = if (isInstagramBulkTask() && hasExplicitInstagramUnlike) {
                            orchestrator.runInstagramBulkUnlike(autonomousTaskGoal)
                        } else orchestrator.handleScroll(dir, dist)
                        result.put("success", actionRes.success)
                        result.put("message", actionRes.message)
                        actionRes.verified?.let { result.put("verified", it) }
                        if (actionRes.currentStateSummary.isNotBlank()) {
                            result.put("current_screen_elements", actionRes.currentStateSummary)
                        }
                        val instagramBatchEnd = isInstagramBulkTask() && actionRes.verified == true && actionRes.message.contains("stable end", true)
                        if (instagramBatchEnd) {
                            val task = com.jarvis.assistant.automation.agent.AgentTaskEngine.current()
                            bulkEndOfListVerified = task?.completionEvidence == com.jarvis.assistant.automation.agent.AgentTaskEngine.CompletionEvidence.END_REACHED &&
                                (task.processedItemSignatures.isNotEmpty())
                        }
                        if (!instagramBatchEnd && isAutonomousTaskRunning && com.jarvis.assistant.automation.agent.TaskGoal.fromUserUtterance(autonomousTaskGoal).isBulkAction) {
                            val activeRoot = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance?.getActiveRootNode()
                            val signature = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(activeRoot)
                            val hasUsableObservation = signature.packageName.isNotBlank() && signature.elementCount > 0
                            if (hasUsableObservation && lastBulkScreenSignature?.isEquivalentTo(signature) == true) {
                                bulkNoProgressScrollCount++
                            } else {
                                bulkNoProgressScrollCount = 0
                            }
                            lastBulkScreenSignature = signature.takeIf { hasUsableObservation }
                            bulkEndOfListVerified = bulkNoProgressScrollCount >= 2
                            if (bulkEndOfListVerified) {
                                result.put("success", true)
                                result.put("bulk_end_of_list_verified", true)
                                result.put("message", "Two consecutive fresh screen observations after scrolling showed no further list content. Recheck that the visible batch is processed, then the requested list is at its end.")
                            }
                        }
                    }

                    "press_key" -> {
                        val key = args.optString("key", "back")
                        val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                        val actionRes = orchestrator.handleKey(key)
                        result.put("success", actionRes.success)
                        result.put("message", actionRes.message)
                    }

                    "task_completed" -> {
                        val summary = args.optString("summary", "Task completed.")
                        if (!isAutonomousTaskRunning &&
                            (!lastCompletedTaskSummary.isNullOrBlank() || System.currentTimeMillis() - lastVerifiedCompletionAt < 15_000L)
                        ) {
                            Log.i("JarvisService", "Ignored a duplicate task_completed call after verified task completion")
                            result.put("success", true)
                            result.put("already_completed", true)
                            result.put("message", "This task was already completed and verified. Do not repeat the result.")
                            result.put("system_directive", "DUPLICATE COMPLETION: You already gave the final result. Remain silent and wait for the user.")
                        } else {
                        val goalObj = com.jarvis.assistant.automation.agent.TaskGoal.fromUserUtterance(autonomousTaskGoal)
                        val localCompletionCheck = verifyTaskCompletionLocally(autonomousTaskGoal)
                        if (isGoogleFlowCreationTask && (!flowPromptVerified || !flowGenerationVerified)) {
                            Log.w("JarvisService", "Rejected Google Flow completion without verified prompt and submission (prompt=$flowPromptVerified, generation=$flowGenerationVerified)")
                            result.put("success", false)
                            result.put("message", "Google Flow task is not verified complete. Confirm the prompt text is visible and a generated or processing video item is visible before reporting completion.")
                            result.put("system_directive", "COMPLETION REJECTED: Do not tell the user the video was submitted. Inspect the current Flow screen. If the prompt is missing, enter it and verify it; if Generate has not started, click the visible Generate button and wait for a processing or generated item. Report a blocker honestly if the screen cannot confirm it.")
                        } else if (isAutonomousTaskRunning && goalObj.isBulkAction && !bulkEndOfListVerified) {
                            Log.w("JarvisService", "Premature task_completed rejected for bulk action goal: '$autonomousTaskGoal'")
                            result.put("success", false)
                            result.put("message", "Bulk task completion rejected: no end-of-list evidence yet. Continue processing matching visible items, then scroll and re-observe until two consecutive screen signatures show no further list content.")
                            result.put("system_directive", "COMPLETION REJECTED: The request explicitly applies to ALL matching items. Do not claim completion. Inspect the fresh screen, process each visible matching target once, then scroll and observe again. Repeat until the app shows no further content; do not scroll past a visible target before processing it.")
                        } else if (!isAutonomousTaskRunning || !localCompletionCheck.first) {
                            com.jarvis.assistant.automation.agent.AgentTaskEngine.recordCompletionEvidence(
                                com.jarvis.assistant.automation.agent.AgentTaskEngine.CompletionEvidence.UNKNOWN,
                                if (isAutonomousTaskRunning) localCompletionCheck.second else "There is no active autonomous task to complete"
                            )
                            result.put("success", false)
                            result.put("message", "Completion is unverified: ${if (isAutonomousTaskRunning) localCompletionCheck.second else "There is no active autonomous task to complete"}")
                            result.put("system_directive", "COMPLETION REJECTED: Do not claim the task is done. The app has not verified the requested final state. Re-observe, continue only with a clear safe action, or report the blocker honestly.")
                        } else {
                            com.jarvis.assistant.automation.agent.AgentTaskEngine.recordCompletionEvidence(
                                com.jarvis.assistant.automation.agent.AgentTaskEngine.CompletionEvidence.VERIFIED_GOAL,
                                localCompletionCheck.second
                            )
                            Log.i("JarvisService", "task_completed received: Autonomous task marked COMPLETE.")
                            lastVerifiedCompletionAt = System.currentTimeMillis()
                            isAutonomousTaskRunning = false
                            val engineCompleted = com.jarvis.assistant.automation.agent.AgentTaskEngine.finish(
                                com.jarvis.assistant.automation.agent.AgentTaskEngine.State.COMPLETED
                            )
                            autonomousStepCount = 0
                            bulkEndOfListVerified = false
                            bulkNoProgressScrollCount = 0
                            lastBulkScreenSignature = null
                            isGoogleFlowCreationTask = false
                            flowPromptVerified = false
                            flowGenerationVerified = false
                            lastVerifiedFlowPrompt = ""
                            autonomousLoopJob?.cancel()
                            autonomousLoopJob = null
                            result.put("success", engineCompleted)
                            result.put("message", if (engineCompleted) "Task completed and locally verified: $summary" else "Task completion was rejected because local verification did not pass.")
                            lastCompletedTaskSummary = summary
                            if (preferences.isSilentExecutionMode) {
                                result.put("system_directive", "SILENT EXECUTION: Do NOT speak or play audio. Task completed silently.")
                            } else {
                                val alreadySpoke = synchronized(currentTurnAssistantText) {
                                    currentTurnAssistantText.isNotBlank()
                                }
                                if (alreadySpoke) {
                                    result.put("system_directive", "TASK RECORDED: You already confirmed completion aloud to the user. Do NOT repeat yourself. Remain completely silent.")
                                } else {
                                    result.put("system_directive", "TASK COMPLETED: Speak ONE short confirmation sentence to the user in your natural voice: '$summary'. Do NOT repeat if already spoken.")
                                }
                                if (!alreadySpoke && liveWebSocket?.isSessionReady() != true) {
                                    // Offline fallback: speak via TTS only when Gemini Live is offline
                                    lastCompletedTaskSummary = null
                                    tts?.speak(summary, TextToSpeech.QUEUE_FLUSH, null, "task_done")
                                }
                            }
                        }
                        }
                    }

                    "inspect_screen" -> {
                        val orchestrator = com.jarvis.assistant.vision.VisualTaskOrchestrator.getInstance()
                        val summary = orchestrator.inspectScreen(waitForContent = true)
                        result.put("success", true)
                        result.put("screen_summary", summary)
                        result.put("message", "Screen inspected successfully.")
                    }


                    else -> {
                        Log.w("JarvisService", "Unknown toolCall name: $name")
                        result.put("success", false)
                        result.put("message", "Unknown tool: $name")
                    }
                }

                if (isAutomationTool && name != "task_completed") {
                    val toolSuccess = result.optBoolean("success", true)
                    com.jarvis.assistant.automation.agent.AgentTaskEngine.recordVerifiedStep(
                        name,
                        result.optString("message", "Tool action completed"),
                        result.optBoolean("verified", false)
                    )
                    if (!toolSuccess) {
                        com.jarvis.assistant.automation.agent.AgentTaskEngine.failCurrentStep(
                            result.optString("message", "Tool action failed"),
                            blocked = result.optBoolean("requires_confirmation", false)
                        )
                    }
                    val recentOtp = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.getRecentOtp()
                    val otpNotice = if (recentOtp != null) " [SYSTEM OTP DETECTED: '$recentOtp']" else ""
                    val goalObj = com.jarvis.assistant.automation.agent.TaskGoal.fromUserUtterance(autonomousTaskGoal)
                    val bulkNotice = if (goalObj.isBulkAction) " [PERSISTENT BULK ACTION MODE: Goal involves '${goalObj.bulkKeywords.joinToString()}'. Process ALL matching items by scrolling down iteratively! Do NOT declare completion after only one screen.]" else ""
                    result.put("step_number", autonomousStepCount)
                    result.put("autonomous_goal", autonomousTaskGoal)
                    if (toolSuccess) consecutiveToolFailures = 0 else consecutiveToolFailures++
                    val toolSig = name + ":" + normalizedArgsSignature(args)
                    if (name != "scroll_screen" && toolSig == lastToolSignature) sameToolRepeatCount++
                    else { lastToolSignature = toolSig; sameToolRepeatCount = 1 }
                    if (consecutiveToolFailures >= MAX_CONSECUTIVE_FAILURES ||
                        (sameToolRepeatCount >= 3 && !isInstagramBulkTask()) ||
                        autonomousStepCount >= autonomousTaskStepLimit()) {
                        autonomousHardStop = true
                    }
                    if (autonomousHardStop) {
                        com.jarvis.assistant.automation.agent.AgentTaskEngine.finish(
                            com.jarvis.assistant.automation.agent.AgentTaskEngine.State.FAILED,
                            "Autonomous safety limit reached after repeated failures or actions."
                        )
                        result.put("autonomous_status", "STOPPED")
                        result.put("system_directive", "HARD STOP: you are repeating actions or failing repeatedly. Do NOT call any more tools. Tell the user honestly, in one or two short sentences, what you actually completed and what went wrong (do NOT claim success), then wait for their next instruction.")
                    } else if (toolSuccess) {
                        result.put("autonomous_status", "EXECUTED")
                        result.put("system_directive", "AUTONOMOUS STEP $autonomousStepCount EXECUTED. OVERARCHING GOAL: '$autonomousTaskGoal'$otpNotice$bulkNotice. MANDATE: Inspect the screen. If the OVERARCHING GOAL is not yet 100% finished on screen, you MUST IMMEDIATELY take the next concrete action (click, type, scroll, wait for install/open). NEVER ABANDON THE TASK MID-WAY! NEVER call task_completed until the ultimate goal is fully achieved on screen!")
                    } else {
                        result.put("autonomous_status", "FAILED")
                        val failMsg = result.optString("message", "Action failed")
                        result.put("system_directive", "CRITICAL WARNING: STEP $autonomousStepCount FAILED ($failMsg)$otpNotice. You MUST NOT claim the action succeeded, do NOT say you completed it, and do NOT call task_completed! Either retry the action, tap the field to focus it first, or truthfully inform the user.")
                    }
                }

                            liveWebSocket?.sendToolResponse(callId, name, result)
                        }
                    } catch (e: TimeoutCancellationException) {
                        Log.e("JarvisService", "Tool call '$name' (callId=$callId) timed out after 25 seconds.")
                        val timeoutResult = JSONObject().apply {
                            put("success", false)
                            put("message", "Tool execution timed out after 25 seconds.")
                        }
                        liveWebSocket?.sendToolResponse(callId, name, timeoutResult)
                    } catch (e: CancellationException) {
                        Log.i("JarvisService", "Tool call '$name' (callId=$callId) was cancelled.")
                        throw e
                    } catch (e: Exception) {
                        Log.e("JarvisService", "Tool call '$name' execution failed: ${e.message}", e)
                        val errResult = JSONObject().apply {
                            put("success", false)
                            put("message", "Error: ${e.message}")
                        }
                        liveWebSocket?.sendToolResponse(callId, name, errResult)
                    } finally {
                        isExecutingTool = false
                    }
                }
            } finally {
                if (thisJob != null) activeToolJobs.remove(thisJob)
            }
        }
        activeToolJob = job
    }



    private suspend fun verifyTaskCompletionLocally(goal: String): Pair<Boolean, String> {
        if (isGoogleFlowCreationTask) {
            return (flowPromptVerified && flowGenerationVerified) to
                if (flowPromptVerified && flowGenerationVerified) "Flow prompt and generated/processing item were verified" else "Flow output evidence is incomplete"
        }

        val service = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance
            ?: return false to "Accessibility service is unavailable"
        val root = service.getActiveRootNode()
            ?: return false to "The active application screen is unavailable"
        val packageName = root.packageName?.toString().orEmpty().lowercase(Locale.ROOT)
        val elements = com.jarvis.assistant.vision.UiGroundingEngine().scanScreen(root)
        val signature = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(root)
        val summary = com.jarvis.assistant.vision.UiGroundingEngine().formatElementsSummary(elements, root)
        com.jarvis.assistant.automation.agent.AgentTaskEngine.observe(signature, packageName, summary)

        if (com.jarvis.assistant.automation.agent.AgentTaskEngine.isCancelled()) {
            return false to "The task was cancelled"
        }
        val normalizedGoal = com.jarvis.assistant.automation.agent.AgentTaskEngine.normalize(goal)
        val goalModel = com.jarvis.assistant.automation.agent.TaskGoal.fromUserUtterance(goal)
        if (goalModel.isBulkAction) {
            val task = com.jarvis.assistant.automation.agent.AgentTaskEngine.current()
            val endObserved = task?.completionEvidence == com.jarvis.assistant.automation.agent.AgentTaskEngine.CompletionEvidence.END_REACHED
            val processed = task?.processedItemSignatures?.size ?: 0
            return (endObserved && processed > 0) to
                if (endObserved && processed > 0) "Reached list end after verifying $processed unique items" else "Bulk completion lacks verified per-item outcomes and end-of-list evidence (tracked items: $processed)"
        }

        val expectedPackage = expectedPackageForTask(goal)?.lowercase(Locale.ROOT)
        if (expectedPackage != null && !packageName.contains(expectedPackage)) {
            return false to "Foreground app is '$packageName'; expected an app matching '$expectedPackage'"
        }

        val openIntent = listOf("open", "launch", "start", "kholo", "khol do", "app kholo")
            .any(normalizedGoal::contains)
        val expectedAppWords = when {
            expectedPackage == "spotify" -> setOf("spotify")
            expectedPackage == "instagram" -> setOf("instagram", "insta")
            expectedPackage == "chrome" -> setOf("chrome", "browser", "google")
            expectedPackage == "com.google.android.gm" -> setOf("gmail", "email")
            else -> setOf(expectedPackage.orEmpty().substringAfterLast('.'))
        }
        val openTargetTerms = normalizedGoal.split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 3 }
            .filterNot { it in expectedAppWords || it in setOf("jarvis", "please", "open", "launch", "start", "app", "the", "khol", "kholo", "do") }
        if (expectedPackage != null && openIntent) {
            if (openTargetTerms.isEmpty()) return true to "Expected application is foreground: $packageName"
            val destinationMatched = elements.any { item ->
                !item.isEditable && item.hasTextOrDesc &&
                    openTargetTerms.all { item.primaryLabel.lowercase(Locale.ROOT).contains(it) }
            }
            if (destinationMatched) return true to "Expected app is foreground and requested destination is visible"
        }

        val targetTerms = normalizedGoal.split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 3 }
            .filterNot { it in setOf("jarvis", "please", "open", "launch", "start", "spotify", "youtube", "instagram", "playlist", "meri", "mera", "par", "mein", "find", "search", "look", "song", "track", "play", "karo", "kar", "do", "dhundo", "dhoondh", "liked", "reels", "posts", "unlike", "all", "every", "the", "for", "and", "with", "aur", "ko", "pe", "se", "ke", "ki", "ka", "bajao", "wale", "wali") }
        val matchingVisibleItems = elements.filter { item ->
            !item.isEditable && item.hasTextOrDesc && targetTerms.isNotEmpty() &&
                targetTerms.all { term -> item.primaryLabel.lowercase(Locale.ROOT).contains(term) }
        }

        val playbackRequested = listOf("play", "play karo", "play it", "bajao").any(normalizedGoal::contains)
        if (playbackRequested) {
            val spotifyOrYoutube = packageName.contains("spotify") || packageName.contains("youtube")
            if (!spotifyOrYoutube || matchingVisibleItems.size != 1) {
                return false to "Could not uniquely match the requested track in the active player"
            }
            val playbackEvidence = elements.any { item ->
                val label = item.primaryLabel.lowercase(Locale.ROOT)
                label.contains("pause") || label.contains("now playing") || label.contains("currently playing")
            }
            return playbackEvidence to if (playbackEvidence) "Unique requested track is visible and player exposes a pause/playing state" else "Requested track is visible, but active playback is not confirmed"
        }

        val searchRequested = listOf("search", "find", "look for", "dhundo", "dhoondh", "talaash").any(normalizedGoal::contains)
        if (searchRequested && matchingVisibleItems.size == 1) {
            return true to "One visible, non-editable result matches the requested terms"
        }

        if (openIntent && expectedPackage != null) {
            return false to "The app is foreground, but the requested destination is not verified"
        }
        return false to "No local verifier is available for this goal type"
    }

    private suspend fun executeSerializedTaskMutation(name: String, operation: suspend () -> Boolean): Boolean =
        com.jarvis.assistant.automation.agent.AgentTaskEngine.executeUiMutation(name, operation)

    private fun isFlowCreationIntent(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT)
        val mentionsCreation = listOf("create", "make", "generate", "video", "prompt", "submit", "film").any(lower::contains)
        return mentionsCreation
    }

    private suspend fun waitForWebDestination(
        orchestrator: com.jarvis.assistant.vision.VisualTaskOrchestrator,
        expectedUrl: String
    ): Pair<Boolean, String> {
        val expectedHost = Uri.parse(expectedUrl).host?.lowercase(Locale.ROOT).orEmpty()
        val isFlow = expectedHost.contains("flow.google") || expectedUrl.contains("flow.google", ignoreCase = true)
        var latestSummary = ""
        repeat(12) {
            delay(300)
            val service = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance
            val root = service?.getActiveRootNode()
            val packageName = root?.packageName?.toString().orEmpty()
            if (packageName.contains("chrome", ignoreCase = true) || packageName.contains("browser", ignoreCase = true)) {
                latestSummary = orchestrator.inspectScreen(waitForContent = true)
                val summary = latestSummary.lowercase(Locale.ROOT)
                val pageVisible = if (isFlow) {
                    listOf("what do you want to create", "start creating or drop media", "long live the process", "google flow can make mistakes", "new project")
                        .any(summary::contains)
                } else {
                    expectedHost.isBlank() || summary.contains(expectedHost) || summary.contains("${expectedHost.substringBefore('.')}")
                }
                if (pageVisible) return true to latestSummary
            }
        }
        return false to latestSummary
    }

    private fun isStopCommand(text: String): Boolean {
        val clean = text.lowercase(Locale.ROOT).trim()
        val patterns = listOf(
            "stop", "ruk jao", "ruko", "cancel", "abort", "pause",
            "bas karo", "thahar", "hold on", "ruk ja", "band karo"
        )
        val matched = patterns.firstOrNull { containsPhrase(clean, it) } ?: return false
        val matchIndex = clean.indexOf(matched)
        val precedingWords = clean.take(matchIndex).trim().split(Regex("\\s+")).takeLast(3)
        if (precedingWords.any { it in setOf("not", "dont", "don't", "never", "without", "mat", "nahi") }) {
            return false
        }
        return true
    }

    /**
     * Processes all queued tool calls after speaker verification completes.
     * If [verified] is true, each queued tool call is executed via handleToolCallExecution.
     * If [verified] is false, each queued tool call gets an "access denied" error response.
     */
    private fun processPendingToolCalls(verified: Boolean) {
        var pending = pendingToolCalls.poll()
        while (pending != null) {
            val tc = pending
            if (verified) {
                Log.i("JarvisService", "EXECUTING queued tool call '${tc.name}' (callId=${tc.callId}): Owner verified.")
                handleToolCallExecution(tc.callId, tc.name, tc.args)
            } else {
                Log.w("JarvisService", "REJECTED queued tool call '${tc.name}' (callId=${tc.callId}): Speaker is NOT verified owner.")
                liveWebSocket?.sendToolResponse(tc.callId, tc.name, JSONObject().put("error", "Access denied: Voice does not match owner."))
            }
            pending = pendingToolCalls.poll()
        }
    }

    private fun checkAndExecuteCommand(userSpeech: String) {
        val cleanSpeech = userSpeech.trim()
        if (cleanSpeech.isBlank()) return

        if (cleanSpeech.lowercase(Locale.ROOT).matches(Regex(".*\\b(stop|cancel task|cancel automation|bas karo|ruk jao)\\b.*"))) {
            com.jarvis.assistant.automation.agent.AgentTaskEngine.requestCancellation()
            autonomousLoopJob?.cancel()
            activeToolJobs.forEach { it.cancel() }
            activeToolJob?.cancel()
            isAutonomousTaskRunning = false
            lastHandledCommandText = cleanSpeech
            announce("Okay, I stopped the current task.")
            return
        }
        if (hasExecutedCommandInCurrentTurn || cleanSpeech == lastHandledCommandText) return

        if (preferences.isOwnerVoiceEnabled && preferences.hasOwnerVoiceProfile() && !isCurrentTurnOwnerVoiceVerified) {
            Log.w("JarvisService", "BLOCKED local command execution: Speaker is not verified owner! ('$cleanSpeech')")
            return
        }

        Log.d("JarvisService", "checkAndExecuteCommand: '$cleanSpeech'")

        val app = application as? JarvisApp ?: return
        val isAwaitingConfirm = app.whatsAppAssistant.hasPendingDraft() || pendingGenericCommand != null
        val isAwaitingDisambig = app.whatsAppAssistant.isAwaitingDisambiguation()

        val parsed = com.jarvis.assistant.automation.command.CommandParser.parse(
            input = cleanSpeech,
            isAwaitingConfirmation = isAwaitingConfirm,
            isAwaitingDisambiguation = isAwaitingDisambig
        )

        val cmd = parsed.command

        // A generic pending confirmation (e.g. an unclear "play X" request) takes
        // priority over a WhatsApp draft confirmation if somehow both are pending.
        if (cmd is com.jarvis.assistant.automation.command.JarvisCommand.ConfirmAction && pendingGenericCommand != null) {
            lastHandledCommandText = cleanSpeech
            val genericCmd = pendingGenericCommand
            pendingGenericCommand = null
            if (cmd.confirmed && genericCmd != null) {
                Log.i("JarvisService", "User confirmed pending command: $genericCmd")
                executeDetectedCommand(genericCmd, cleanSpeech)
            } else {
                Log.i("JarvisService", "User cancelled pending command: $genericCmd")
                announce("Okay, I won't do that.")
            }
            return
        }

        if (cmd != null && parsed.confidence >= 0.90f) {
            // If the requested video/song is too vague or could easily be a mis-hearing
            // (e.g. Jarvis only caught one short/filler word), confirm with the user
            // instead of guessing and playing the wrong thing.
            if (cmd is com.jarvis.assistant.automation.command.JarvisCommand.PlayYouTube &&
                com.jarvis.assistant.automation.command.CommandParser.isAmbiguousPlayQuery(cmd.query)
            ) {
                lastHandledCommandText = cleanSpeech
                pendingGenericCommand = cmd
                Log.i("JarvisService", "Ambiguous YouTube query '${cmd.query}', asking for confirmation before playing")
                announce("Did you want me to play \"${cmd.query}\" on YouTube? Say yes to confirm, or tell me the name again.")
                return
            }

            lastHandledCommandText = cleanSpeech
            Log.i("JarvisService", "USER TEXT → Detected command [${parsed.matchedPattern}] confidence=${parsed.confidence}: $cmd")
            executeDetectedCommand(cmd, cleanSpeech)
        } else {
            Log.d("JarvisService", "No command match from user text (confidence=${parsed.confidence})")
        }
    }

    /**
     * Speaks a short message locally via TTS and also surfaces it in the chat/event UI,
     * used for quick confirmations/cancellations that don't need a full Gemini round-trip.
     */
    private fun announce(message: String) {
        serviceScope.launch { _events.emit(message) }
    }

    /**
     * Dual-Path Execution Engine:
     * When user speech parsing doesn't trigger a command due to background noise or slight transcription variances,
     * Gemini Live's natural language comprehension reliably recognizes the user's intent and speaks the standardized
     * action phrase (e.g., "Opening vercel.com in browser", "Searching for techno gamers on google", "Playing Tadipaar on YouTube",
     * "Sending WhatsApp message to Rahul: hello", "Calling Mom").
     *
     * This handler parses those standardized phrases and executes them immediately.
     * Guarded by [hasExecutedCommandInCurrentTurn] to prevent duplicate execution in the same turn.
     */
    private fun checkAssistantTextForCommands(assistantText: String) {
        if (hasExecutedCommandInCurrentTurn || (System.currentTimeMillis() - lastCommandExecutionTime < 3500L)) return
        val rawClean = assistantText.trim()
        val clean = rawClean.lowercase(java.util.Locale.ROOT).trimEnd('.', '!', '?', ',', ' ')
        if (clean.isBlank() || clean == lastHandledAssistantCommand) return

        var command: com.jarvis.assistant.automation.command.JarvisCommand? = null
        var matchSource = ""

        // --- 1. Flashlight ---
        val app = application as? JarvisApp
        val isHardwareTorchOn = app?.phoneControlManager?.isTorchOn ?: false
        if ((clean.contains("turning on") || clean.contains("turned on") || clean.contains("torch on") || clean.contains("flash on") || ((clean.contains("already on") || clean.contains("already turned on")) && !isHardwareTorchOn)) && (clean.contains("flash") || clean.contains("torch") || clean.contains("it"))) {
            command = com.jarvis.assistant.automation.command.JarvisCommand.Flash(true)
            matchSource = "ASSISTANT_FLASH_ON"
        } else if ((clean.contains("turning off") || clean.contains("turned off") || clean.contains("torch off") || clean.contains("flash off") || ((clean.contains("already off") || clean.contains("already turned off")) && isHardwareTorchOn)) && (clean.contains("flash") || clean.contains("torch") || clean.contains("it"))) {
            command = com.jarvis.assistant.automation.command.JarvisCommand.Flash(false)
            matchSource = "ASSISTANT_FLASH_OFF"
        }

        // --- 2. Brightness ---
        else if (clean.startsWith("setting brightness") || clean.startsWith("adjusting brightness") || clean.startsWith("increasing brightness") || clean.startsWith("decreasing brightness")) {
            val numMatch = Regex("(\\d{1,3})\\s*(?:%|percent)?\\b").find(clean)
            if (numMatch != null) {
                val level = numMatch.groupValues[1].toIntOrNull() ?: 50
                command = com.jarvis.assistant.automation.command.JarvisCommand.Brightness(level)
                matchSource = "ASSISTANT_BRIGHTNESS_SET"
            } else if (clean.contains("increas")) {
                command = com.jarvis.assistant.automation.command.JarvisCommand.Brightness(0, isRelative = true, delta = 20)
                matchSource = "ASSISTANT_BRIGHTNESS_UP"
            } else if (clean.contains("decreas")) {
                command = com.jarvis.assistant.automation.command.JarvisCommand.Brightness(0, isRelative = true, delta = -20)
                matchSource = "ASSISTANT_BRIGHTNESS_DOWN"
            }
        }

        // --- 3. Volume ---
        else if (clean.startsWith("setting volume") || clean.startsWith("adjusting volume") || clean.startsWith("increasing volume") || clean.startsWith("decreasing volume") || clean.startsWith("muting")) {
            val numMatch = Regex("(\\d{1,3})\\s*(?:%|percent)?\\b").find(clean)
            if (numMatch != null) {
                val level = numMatch.groupValues[1].toIntOrNull() ?: 50
                command = com.jarvis.assistant.automation.command.JarvisCommand.Volume(level)
                matchSource = "ASSISTANT_VOLUME_SET"
            } else if (clean.contains("increas")) {
                command = com.jarvis.assistant.automation.command.JarvisCommand.Volume(0, isRelative = true, delta = 1)
                matchSource = "ASSISTANT_VOLUME_UP"
            } else if (clean.contains("decreas")) {
                command = com.jarvis.assistant.automation.command.JarvisCommand.Volume(0, isRelative = true, delta = -1)
                matchSource = "ASSISTANT_VOLUME_DOWN"
            } else if (clean.contains("mut")) {
                command = com.jarvis.assistant.automation.command.JarvisCommand.Volume(0)
                matchSource = "ASSISTANT_VOLUME_MUTE"
            }
        }

        // --- 4. Web Search: "Searching for [topic] on Google", "Searching google for [topic]" ---
        else if (clean.startsWith("searching for ") || clean.startsWith("searching google for ")) {
            val searchMatch = Regex("^(?:searching\\s+for\\s+|searching\\s+google\\s+for\\s+)(.+?)(?:\\s+(?:on\\s+google|in\\s+browser))?$").find(clean)
            if (searchMatch != null) {
                val query = searchMatch.groupValues[1].trim()
                if (query.isNotBlank() && query.length > 1) {
                    command = com.jarvis.assistant.automation.command.JarvisCommand.SearchWeb(query)
                    matchSource = "ASSISTANT_WEB_SEARCH"
                }
            }
        }

        // --- 5. YouTube Play: "Playing [song] on YouTube", "Playing your favorite song, [song], on YouTube" ---
        else if (clean.startsWith("playing ")) {
            val ytMatch = Regex("^(?:playing\\s+(?:your\\s+favou?rite\\s+song,\\s+)?)(.+?)(?:\\s*,?\\s*on\\s+youtube)?$").find(clean)
            if (ytMatch != null) {
                val song = ytMatch.groupValues[1].trim().trimEnd(',', '!')
                if (song.isNotBlank()) {
                    val finalSong = if (song.equals("music", ignoreCase = true) || song.equals("video", ignoreCase = true) ||
                        song.equals("a video", ignoreCase = true) || song.equals("a song", ignoreCase = true)) {
                        (application as? JarvisApp)?.memoryManager?.resolveSongQuery("my favorite song") ?: "my favorite song"
                    } else {
                        song
                    }
                    command = com.jarvis.assistant.automation.command.JarvisCommand.PlayYouTube(finalSong)
                    matchSource = "ASSISTANT_YOUTUBE_PLAY"
                }
            }
        }

        // --- 5b. YouTube Subscribe: "Subscribing to this channel!" ---
        else if (clean.startsWith("subscribing")) {
            command = com.jarvis.assistant.automation.command.JarvisCommand.SubscribeChannel
            matchSource = "ASSISTANT_YOUTUBE_SUBSCRIBE"
        }

        // --- 5c. YouTube Fullscreen: "Switching to full screen!" ---
        else if (clean.contains("full screen") || clean.contains("fullscreen")) {
            command = com.jarvis.assistant.automation.command.JarvisCommand.ToggleFullscreen
            matchSource = "ASSISTANT_YOUTUBE_FULLSCREEN"
        }

        // --- 5d. WhatsApp Delete: "Deleting the last message for everyone!" / "Deleting the last message!" ---
        else if (clean.startsWith("deleting")) {
            val forEveryone = clean.contains("everyone")
            val contactMatch = Regex("(?:to|for|from)\\s+([a-zA-Z0-9\\s]+?)(?:\\s+(?:for|from)\\s+everyone)?$").find(clean)
            val contact = contactMatch?.groupValues?.getOrNull(1)?.trim()
                ?.takeIf { it.isNotBlank() && it != "everyone" && it != "me" }
            command = com.jarvis.assistant.automation.command.JarvisCommand.WhatsAppDeleteMessage(contact, forEveryone)
            matchSource = "ASSISTANT_WHATSAPP_DELETE"
        }

        // --- 6. WhatsApp Message: "Sending WhatsApp message to [Contact]: [Message]" ---
        else if (clean.startsWith("sending whatsapp message to ") || clean.startsWith("sending message to ")) {
            val waMatch = Regex("^(?:sending\\s+whatsapp\\s+message\\s+to\\s+|sending\\s+message\\s+to\\s+)([a-zA-Z0-9\\s]+?):\\s*(.+)$", RegexOption.IGNORE_CASE).find(rawClean)
            if (waMatch != null) {
                val contact = waMatch.groupValues[1].trim()
                val message = waMatch.groupValues[2].trim()
                if (contact.isNotBlank() && message.isNotBlank()) {
                    command = com.jarvis.assistant.automation.command.JarvisCommand.WhatsAppMessage(contact, message)
                    matchSource = "ASSISTANT_WHATSAPP_SEND"
                }
            }
        }

        // --- 7. Website Navigation: "Opening [url] in browser", "Opening website [url]" ---
        else if (clean.startsWith("opening ") && (clean.contains("in browser") || clean.contains("in chrome") || clean.contains("website") || clean.contains(".com") || clean.contains(".org") || clean.contains(".dev") || clean.contains(".in") || clean.contains(".net") || clean.contains(".io"))) {
            val urlMatch = Regex("^(?:opening\\s+website\\s+|opening\\s+)(.+?)(?:\\s+in\\s+browser|\\s+in\\s+chrome|\\s+website)?$").find(clean)
            if (urlMatch != null) {
                val target = urlMatch.groupValues[1].trim()
                val normalizedUrl = com.jarvis.assistant.automation.phone.DomainNormalizer.normalizeToUrl(target)
                command = com.jarvis.assistant.automation.command.JarvisCommand.OpenWebUrls(listOf(normalizedUrl))
                matchSource = "ASSISTANT_OPEN_WEBSITE"
            }
        }

        // --- 8. Phone / WhatsApp Call: "Calling [Contact]", "Calling [Contact] on WhatsApp" ---
        else if (clean.startsWith("calling ")) {
            val callMatch = Regex("^calling\\s+([a-zA-Z0-9\\s+]+?)(?:\\s+on\\s+whatsapp)?$").find(clean)
            if (callMatch != null) {
                val target = callMatch.groupValues[1].trim()
                if (target.isNotBlank() && target.length >= 2 && !listOf("it", "that", "you", "someone").contains(target)) {
                    command = if (clean.contains("whatsapp")) {
                        com.jarvis.assistant.automation.command.JarvisCommand.WhatsAppCall(target, video = false)
                    } else {
                        com.jarvis.assistant.automation.command.JarvisCommand.PhoneCall(target)
                    }
                    matchSource = "ASSISTANT_CALL"
                }
            }
        }

        // --- 9. App Launch: "Opening [App Name]" (fallback if not a website) ---
        else if (clean.startsWith("opening ")) {
            val appMatch = Regex("^opening\\s+([a-zA-Z0-9\\s]+?)(?:\\s+app)?$").find(clean)
            if (appMatch != null) {
                val app = appMatch.groupValues[1].trim()
                if (app.isNotBlank() && !listOf("website", "tab", "browser", "chrome").contains(app)) {
                    command = com.jarvis.assistant.automation.command.JarvisCommand.OpenApp(app)
                    matchSource = "ASSISTANT_OPEN_APP"
                }
            }
        }

        // --- 10. Background Transition: "Going to the background", "I am going to the background" ---
        else if (clean.contains("going to the background") || clean.contains("going in the background") || clean.contains("going to background")) {
            command = com.jarvis.assistant.automation.command.JarvisCommand.GoToBackground
            matchSource = "ASSISTANT_BACKGROUND"
        }

        if (command != null) {
            lastHandledAssistantCommand = clean
            Log.i("JarvisService", "ASSISTANT TEXT → Detected hardware command [$matchSource]: $command")
            executeDetectedCommand(command, "assistant: $clean")
        }
    }

    private fun executeDetectedCommand(command: com.jarvis.assistant.automation.command.JarvisCommand, source: String) {
        if (command is com.jarvis.assistant.automation.command.JarvisCommand.GoToBackground) {
            minimizeToHomeScreen()
            enterStandby(announce = false)
            return
        }
        hasExecutedCommandInCurrentTurn = true
        lastCommandExecutionTime = System.currentTimeMillis()
        suppressAudioUntilTurnComplete = false
        if (command is com.jarvis.assistant.automation.command.JarvisCommand.PlayYouTube) {
            audioPlayer?.flush()
        }
        val app = application as? JarvisApp ?: return

        serviceScope.launch {
            try {
                val result = app.commandExecutor.execute(command)
                Log.i("JarvisService", "Command executed successfully: $result (source: $source)")
                app.memoryManager.addShortTermTurn(source, result)
            } catch (e: Exception) {
                Log.e("JarvisService", "Command execution FAILED: ${e.message}", e)
            }
        }
    }

    private fun finalizeTurn() {
        val rawReply = currentTurnAssistantText.toString().trim()
        val reply = rawReply.replace(Regex("\\s+"), " ")
        val rawQuery = currentTurnUserText.toString().trim()
        val query = rawQuery.replace(Regex("\\s+"), " ")
        val app = application as? JarvisApp

        if (query.isNotEmpty()) {
            app?.memoryManager?.learnPreferencesFromConversation(query)
        }

        if (reply.isNotEmpty() && app != null) {
            val isOwnerCheckPassed = !preferences.isOwnerVoiceEnabled || !preferences.hasOwnerVoiceProfile() || isCurrentTurnOwnerVoiceVerified
            if (isOwnerCheckPassed) {
                app.chatRepository.addTurn(
                    userText = query.ifEmpty { "Spoken user query" },
                    jarvisText = reply
                )
                app.memoryManager.addShortTermTurn(
                    userText = query.ifEmpty { "Spoken user query" },
                    jarvisText = reply
                )
            }
        }
        currentTurnAssistantText.clear()
        currentTurnUserText.clear()
        _liveUserTranscript.value = ""
        _liveAssistantResponse.value = ""
        hasSpeechInCurrentUtterance = false
        hasSignalledUtteranceEnd = false
        consecutiveVoicedFrames = 0
        totalVoicedFramesInCurrentUtterance = 0
        hasExecutedCommandInCurrentTurn = false
        lastHandledCommandText = ""
        lastHandledAssistantCommand = ""
        val prefs = (application as? JarvisApp)?.preferences
        val isLeaseActive = (System.currentTimeMillis() - lastOwnerVerifiedTimestamp) < 30_000L
        isCurrentTurnOwnerVoiceVerified = prefs == null || !prefs.isOwnerVoiceEnabled || !prefs.hasOwnerVoiceProfile() || isLeaseActive
        pendingToolCalls.clear()
        synchronized(currentUtteranceAudioStream) { currentUtteranceAudioStream.reset() }
    }

    private fun stopActiveConversation() {
        inactivityJob?.cancel()
        inactivityJob = null
        cancelAllActiveTools()
        com.jarvis.assistant.automation.agent.AgentTaskEngine.resetForSession()
        _isSessionOn.value = false
        finalizeTurn()


        currentTurnAssistantText.clear()
        currentTurnUserText.clear()
        preConnectAudioQueue.clear()
        hasSpeechInCurrentUtterance = false
        hasSignalledUtteranceEnd = false

        audioRecorder?.stop()
        audioRecorder = null

        audioPlayer?.flush()
        audioPlayer?.release()
        audioPlayer = null

        liveWebSocket?.disconnect()
        liveWebSocket = null

        setConversationState(ConversationState.IDLE)
        _connectionStatus.value = "READY"
        _audioLevel.value = 0f
        headsetAudioRouter?.stop()
    }

    private fun startInactivityTimer() {
        inactivityJob?.cancel()
        inactivityJob = serviceScope.launch {
            while (isActive && _isSessionOn.value) {
                delay(15_000)
                if (System.currentTimeMillis() - lastUserSpeechDetectedTime >= INACTIVITY_TIMEOUT_MS) {
                    enterStandby(announce = false)
                }
            }
        }
    }

    // ---------------------------------------------------------------------
    // Standby / wake-word listening (Pure Vosk - Continuous Streaming)
    // ---------------------------------------------------------------------

    private fun enterStandby(announce: Boolean = false) {
        if (_isStandby.value) return
        abandonAudioDuckFocus()
        com.jarvis.assistant.audio.JarvisSoundEffects.playStandbySound()
        isPendingBackgroundTransition = false
        stopActiveConversation()
        currentTurnAssistantText.clear()
        currentTurnUserText.clear()
        hasSpeechInCurrentUtterance = false
        hasSignalledUtteranceEnd = false
        _isStandby.value = true
        standbyActivatedTime = System.currentTimeMillis()
        updateNotification()

        serviceScope.launch(Dispatchers.Main) {
            delay(500)
            if (_isStandby.value && voskSpeechService == null) {
                startWakeListening()
            }
        }
    }

    private fun exitStandbyListening() {
        _isStandby.value = false
        try {
            voskSpeechService?.stop()
        } catch (e: Exception) {
            Log.e("JarvisService", "Error stopping Vosk SpeechService: ${e.message}")
        }
        voskSpeechService = null
    }

    private fun startWakeListening() {
        if (!_isStandby.value) return
        if (voskSpeechService != null) return

        val model = VoskModelManager.model
        if (model == null) {
            Log.i("JarvisService", "Vosk model still loading; triggering init and will start once ready")
            VoskModelManager.init(applicationContext, serviceScope)
            serviceScope.launch {
                VoskModelManager.isModelReady.collect { ready ->
                    if (ready && _isStandby.value && voskSpeechService == null) {
                        startWakeListening()
                    }
                }
            }
            return
        }

        try {
            standbyActivatedTime = System.currentTimeMillis()
            // Phrase grammar: allow single-word "jarvis", multi-syllable wake phrases, and [unk]
            val grammar = "[\"jarvis\", \"hey jarvis\", \"hi jarvis\", \"hello jarvis\", \"ok jarvis\", \"okay jarvis\", \"wake up jarvis\", \"sun jarvis\", \"suno jarvis\", \"jarvis jarvis\", \"[unk]\"]"
            val rec = Recognizer(model, 16000.0f, grammar)
            rec.setWords(true)
            val spkModel = VoskModelManager.speakerModel
            if (spkModel != null) {
                rec.setSpeakerModel(spkModel)
                Log.i("JarvisService", "Attached SpeakerModel to Vosk wake recognizer for owner voice gating")
            }
            val service = SpeechService(rec, 16000.0f)
            service.startListening(voskListener)
            voskSpeechService = service
            Log.i("JarvisService", "Vosk wake-word listening active (strict multi-syllable phrase grammar)")
        } catch (e: Exception) {
            Log.e("JarvisService", "Failed to start Vosk SpeechService: ${e.message}", e)
            try {
                voskSpeechService?.stop()
            } catch (_: Exception) {}
            voskSpeechService = null
            serviceScope.launch { _events.emit("Mic error: ${e.message}") }
        }
    }

    private val voskListener = object : VoskRecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            // Partial transcripts are unstable and were waking the active session on
            // incidental audio. Wake only after final word-level/confidence checks.
        }

        override fun onResult(hypothesis: String?) {
            checkVoskHypothesis(hypothesis)
        }

        override fun onFinalResult(hypothesis: String?) {
            checkVoskHypothesis(hypothesis)
        }

        override fun onError(exception: Exception?) {
            Log.e("JarvisService", "Vosk error: ${exception?.message}")
            if (_isStandby.value) {
                serviceScope.launch(Dispatchers.Main) {
                    delay(1500)
                    if (_isStandby.value && voskSpeechService == null) {
                        startWakeListening()
                    }
                }
            }
        }

        override fun onTimeout() {
            if (_isStandby.value && voskSpeechService == null) {
                startWakeListening()
            }
        }
    }

    private val VALID_WAKE_PHRASES = setOf(
        "jarvis",
        "hey jarvis",
        "hi jarvis",
        "hello jarvis",
        "ok jarvis",
        "okay jarvis",
        "wake up jarvis",
        "sun jarvis",
        "suno jarvis",
        "jarvis jarvis"
    )

    private fun checkVoskHypothesis(hypothesisJson: String?) {
        if (hypothesisJson.isNullOrBlank() || !_isStandby.value) return
        if (isPhoneCallActive()) return

        // 1. Standby cooldown: ignore microphone input for 800ms after entering standby
        // to prevent ambient chimes or trailing speech from falsely re-triggering wake.
        if (System.currentTimeMillis() - standbyActivatedTime < 800L) {
            Log.d("JarvisService", "Ignored hypothesis during standby cooldown")
            return
        }

        try {
            val json = JSONObject(hypothesisJson)
            val text = json.optString("text", "").trim().lowercase(Locale.ROOT)
            if (text.isEmpty() || text == "[unk]") return

            // Word-level array must be present: never wake blindly without confidence verification.
            val resultArr = json.optJSONArray("result")
            if (resultArr == null || resultArr.length() == 0) {
                Log.d("JarvisService", "WAKE REJECTED: No word-level result array for '$text'. Ignored.")
                return
            }

            var totalConf = 0.0
            val wordList = mutableListOf<String>()
            val wordConfMap = mutableMapOf<String, Double>()
            for (i in 0 until resultArr.length()) {
                val wObj = resultArr.getJSONObject(i)
                val conf = wObj.optDouble("conf", 0.0)
                val w = wObj.optString("word", "").trim().lowercase(Locale.ROOT)
                if (w.isNotEmpty() && w != "[unk]") {
                    totalConf += conf
                    wordList.add(w)
                    wordConfMap[w] = maxOf(wordConfMap[w] ?: 0.0, conf)
                }
            }

            if (wordList.isEmpty()) return

            val cleanPhrase = wordList.joinToString(" ")
            val isMatch = cleanPhrase in VALID_WAKE_PHRASES ||
                    VALID_WAKE_PHRASES.any { cleanPhrase.contains(it) } ||
                    wordList.contains("jarvis")

            if (!isMatch) {
                Log.d("JarvisService", "WAKE REJECTED: '$cleanPhrase' is not an exact valid wake phrase.")
                return
            }

            val avgConf = totalConf / wordList.size
            val firstStart = resultArr.getJSONObject(0).optDouble("start", 0.0)
            val lastEnd = resultArr.getJSONObject(resultArr.length() - 1).optDouble("end", 0.0)
            val duration = lastEnd - firstStart

            Log.i("JarvisService", "Vosk candidate hypothesis: '$cleanPhrase' (words=$wordList, avgConf=$avgConf, duration=${duration}s)")

            // 4. Acoustic Verification:
            // 4. Acoustic Verification:
            // "jarvis" must be specifically recognized with confidence
            val jarvisConf = wordConfMap["jarvis"] ?: 0.0
            if (jarvisConf < 0.70) {
                Log.w("JarvisService", "WAKE REJECTED: 'jarvis' word confidence too low ($jarvisConf < 0.70). Ignored.")
                return
            }

            if (wordList.size == 1 && wordList[0] == "jarvis") {
                // Standalone single-word "jarvis"
                if (avgConf < 0.75) {
                    Log.w("JarvisService", "WAKE REJECTED: Standalone 'jarvis' failed checks (conf=$avgConf). Ignored.")
                    return
                }
            } else {
                // Multi-word phrases like "hey jarvis", "hello jarvis", "ok jarvis"
                if (avgConf < 0.65) {
                    Log.w("JarvisService", "WAKE REJECTED: Wake phrase failed checks (conf=$avgConf). Ignored.")
                    return
                }
            }

            // 5. Owner Voice Verification (if enabled)
            if (preferences.isOwnerVoiceEnabled && preferences.hasOwnerVoiceProfile()) {
                val spkArray = json.optJSONArray("spk")
                if (spkArray != null && spkArray.length() > 0) {
                    val currentVector = FloatArray(spkArray.length()) { i -> spkArray.getDouble(i).toFloat() }
                    val match = com.jarvis.assistant.audio.OwnerVoiceManager.verifySpeakerVector(currentVector, preferences)
                    if (!match.isMatch) {
                        Log.w("JarvisService", "WAKE REJECTED: Heard '$cleanPhrase', but speaker distance (${match.distance}) > threshold (${match.threshold}). Non-owner ignored!")
                        return
                    } else {
                        lastOwnerVerifiedTimestamp = System.currentTimeMillis()
                        isCurrentTurnOwnerVoiceVerified = true
                        Log.i("JarvisService", "WAKE VERIFIED: Owner voice confirmed for '$cleanPhrase'! (Distance: ${match.distance}, Similarity: ${match.similarityPercent}%)")
                    }
                } else {
                    Log.w("JarvisService", "WAKE REJECTED: No speaker vector found in hypothesis for '$cleanPhrase' while owner voice is enabled. Non-owner ignored!")
                    return
                }
            }

            Log.i("JarvisService", "Vosk confirmed wake word: '$cleanPhrase' (conf=$avgConf, duration=${duration}s)")
            onWakeWordDetected()
        } catch (e: Exception) {
            Log.e("JarvisService", "Error in checkVoskHypothesis: ${e.message}")
        }
    }

    private var currentFocusRequest: Any? = null

    private fun requestAudioDuckFocus() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val focusReq = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .build()
                currentFocusRequest = focusReq
                audioManager.requestAudioFocus(focusReq)
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            }
        } catch (e: Exception) {
            Log.w("JarvisService", "Failed to request audio duck focus: ${e.message}")
        }
    }

    private fun abandonAudioDuckFocus() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                (currentFocusRequest as? AudioFocusRequest)?.let {
                    audioManager.abandonAudioFocusRequest(it)
                }
                currentFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(null)
            }
        } catch (_: Exception) {}
    }

    private fun onWakeWordDetected() {
        if (!_isStandby.value) return
        requestAudioDuckFocus()
        vibrateBriefly()
        com.jarvis.assistant.audio.JarvisSoundEffects.playWakeSound()
        exitStandbyListening()
        currentTurnAssistantText.clear()
        currentTurnUserText.clear()
        hasSpeechInCurrentUtterance = false
        hasSignalledUtteranceEnd = false
        serviceScope.launch { _wakeEvents.emit(Unit) }
        beginActiveConversation(wakeTriggered = true)
    }

    private fun vibrateBriefly() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(40)
            }
        } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------------
    // Lifecycle plumbing
    // ---------------------------------------------------------------------

    private fun fullStop() {
        stopActiveConversation()
        exitStandbyListening()
        _isStandby.value = false
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld != true) {
            wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:JarvisConversation")
                .also { it.acquire(6 * 60 * 60 * 1000L) }
        }
        if (wifiLock?.isHeld != true) {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? android.net.wifi.WifiManager
            wifiLock = wifiManager?.createWifiLock(
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    android.net.wifi.WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF
                },
                "$packageName:JarvisWifi"
            )?.also { it.acquire() }
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.takeIf { it.isHeld }?.release()
        wakeLock = null
        wifiLock?.takeIf { it.isHeld }?.release()
        wifiLock = null
    }

    override fun onDestroy() {
        taskProgressOverlayJob?.cancel()
        taskProgressOverlayJob = null
        taskProgressOverlay?.remove()
        taskProgressOverlay = null
        stopActiveConversation()
        exitStandbyListening()
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
        try {
            voskSpeechService?.stop()
        } catch (_: Exception) {}
        voskSpeechService = null
        releaseWakeLock()
        serviceScope.cancel()
        if (activeInstance === this) activeInstance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------------
    // Command and Call Helpers
    // ---------------------------------------------------------------------

    private fun isExplicitStandbyCommand(text: String): Boolean {
        val clean = text.lowercase(Locale.ROOT).trim()
        val patterns = listOf(
            "go to background", "go background", "go in background", "go in the background",
            "background me jao", "background mein jao", "send to background", "move to background",
            "minimize", "go home", "go to home", "go to home screen",
            "go to sleep", "sleep jarvis", "enter standby", "standby mode", "go to standby",
            "take a break", "so jao"
        )
        return patterns.any { containsPhrase(clean, it) }
    }

    /** Order-independent argument signature (identical calls arrive with JSON keys in different order). */
    private fun normalizedArgsSignature(args: JSONObject): String {
        val keys = mutableListOf<String>()
        val iter = args.keys()
        while (iter.hasNext()) keys.add(iter.next())
        keys.sort()
        return keys.joinToString(",") { k -> "$k=${args.opt(k)}" }
    }

    /** Whole-word/phrase match (so "stop" does not match "stopped"). */
    private fun containsPhrase(text: String, phrase: String): Boolean =
        Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(phrase) + "(?![\\p{L}\\p{N}])").containsMatchIn(text)

    private fun minimizeToHomeScreen() {
        val app = application as? JarvisApp
        val movedBack = app?.moveAppToBack() == true
        if (movedBack) {
            Log.i("JarvisService", "JARVIS foreground activity moved to back safely")
        } else {
            Log.i("JarvisService", "JARVIS going to background standby; leaving active foreground app intact")
        }
    }

    private fun isPhoneCallActive(): Boolean {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
        if (audioManager.mode == AudioManager.MODE_IN_CALL) return true
        try {
            val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as? android.telephony.TelephonyManager
            if (telephonyManager != null && telephonyManager.callState != android.telephony.TelephonyManager.CALL_STATE_IDLE) {
                return true
            }
        } catch (_: Exception) {}
        return false
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        Log.i("JarvisService", "onTaskRemoved: App removed from recents. Keeping service alive in foreground.")
        acquireWakeLock()
        ensureMicrophoneForegroundService()
        updateNotification()
        if (!_isSessionOn.value && !_isStandby.value) {
            enterStandby(announce = false)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun updateNotification() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): android.app.Notification {
        val (title, text) = when {
            _isStandby.value -> "Jarvis is in the background" to "Say \"Hey Jarvis\" to wake me up"
            _isSessionOn.value && !_connectionStatus.value.equals("LIVE", ignoreCase = true) ->
                "Jarvis is reconnecting" to "Connection: ${_connectionStatus.value}. Requests may not be heard yet."
            _isSessionOn.value && lastResponseTimedOut ->
                "Jarvis did not reply" to "Connection is active. Repeat your request."
            _isSessionOn.value && _conversationState.value == ConversationState.SPEAKING ->
                "Jarvis is replying" to "Audio response is playing"
            _isSessionOn.value && _conversationState.value == ConversationState.THINKING ->
                "Jarvis is thinking" to "Processing your request"
            _isSessionOn.value && _conversationState.value == ConversationState.LISTENING ->
                "Jarvis is listening" to "Speak your request now"
            _isSessionOn.value ->
                "Jarvis is ready" to "Connected. Say your request or \"Hey Jarvis\"."
            else -> "Jarvis" to "Starting up\u2026"
        }
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, "Stop", PendingIntent.getService(
                this, 0, Intent(this, JarvisConversationService::class.java).setAction(ACTION_STOP_ALL),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            ))
            .build()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/background/JarvisConversationService.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/memory/MemoryDao.kt ===
```kotlin
package com.jarvis.assistant.data.memory

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {

    @Query("SELECT * FROM memories ORDER BY timestamp DESC")
    fun getAllMemoriesFlow(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories ORDER BY timestamp DESC")
    suspend fun getAllMemories(): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE category = :category ORDER BY timestamp DESC")
    fun getMemoriesByCategoryFlow(category: String): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE rawText LIKE '%' || :query || '%' OR `key` LIKE '%' || :query || '%' OR `value` LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchMemoriesFlow(query: String): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE rawText LIKE '%' || :query || '%' OR `key` LIKE '%' || :query || '%' OR `value` LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    suspend fun searchMemories(query: String): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity): Long

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Delete
    suspend fun deleteMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemoryById(id: Long)

    @Query("DELETE FROM memories WHERE rawText LIKE '%' || :keyword || '%' OR `key` LIKE '%' || :keyword || '%' OR `value` LIKE '%' || :keyword || '%'")
    suspend fun deleteMemoriesByKeyword(keyword: String): Int

    @Query("DELETE FROM memories")
    suspend fun clearAllMemories()
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/memory/MemoryDao.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/memory/MemoryDatabase.kt ===
```kotlin
package com.jarvis.assistant.data.memory

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [MemoryEntity::class], version = 1, exportSchema = false)
abstract class MemoryDatabase : RoomDatabase() {

    abstract fun memoryDao(): MemoryDao

    companion object {
        private const val DATABASE_NAME = "jarvis_memory.db"

        @Volatile
        private var instance: MemoryDatabase? = null

        fun getInstance(context: Context): MemoryDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    MemoryDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/memory/MemoryDatabase.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/memory/MemoryEntity.kt ===
```kotlin
package com.jarvis.assistant.data.memory

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String,
    val key: String,
    val value: String,
    val rawText: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    companion object {
        const val CATEGORY_PERSONAL = "Personal"
        const val CATEGORY_PREFERENCES = "Preferences"
        const val CATEGORY_CONTACTS = "Contacts"
        const val CATEGORY_ROUTINES = "Routines"
        const val CATEGORY_NOTES = "Notes"

        val ALL_CATEGORIES = listOf(
            CATEGORY_PERSONAL,
            CATEGORY_PREFERENCES,
            CATEGORY_CONTACTS,
            CATEGORY_ROUTINES,
            CATEGORY_NOTES
        )
    }

    val formattedDate: String
        get() {
            val sdf = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/memory/MemoryEntity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/memory/MemoryManager.kt ===
```kotlin
package com.jarvis.assistant.data.memory

import android.util.Log
import com.jarvis.assistant.data.model.ChatTurn
import com.jarvis.assistant.data.preferences.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

class MemoryManager(
    private val repository: MemoryRepository,
    private val preferences: AppPreferences,
    private val chatRepository: com.jarvis.assistant.data.repository.ChatRepository,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "MemoryManager"
        private const val MAX_SHORT_TERM_TURNS = 30
    }

    // --- Short-Term Memory (Preloaded with persistent history) ---
    private val _shortTermHistory = MutableStateFlow<List<ChatTurn>>(emptyList())
    val shortTermHistory: StateFlow<List<ChatTurn>> = _shortTermHistory.asStateFlow()
    private val shortTermSummary = StringBuilder()

    init {
        // Preload recent persistent chat turns so memory is continuous across app restarts
        scope.launch(Dispatchers.IO) {
            val savedTurns = chatRepository.turns.value
            _shortTermHistory.value = savedTurns.takeLast(MAX_SHORT_TERM_TURNS)
            Log.i(TAG, "Preloaded ${_shortTermHistory.value.size} persistent turns into active memory.")
        }
    }

    fun addShortTermTurn(userText: String, jarvisText: String) {
        val cleanUser = userText.trim()
        val cleanJarvis = jarvisText.trim()
        if (cleanUser.isEmpty() && cleanJarvis.isEmpty()) return

        val current = _shortTermHistory.value.toMutableList()
        val turn = ChatTurn(
            userTranscript = cleanUser,
            jarvisResponse = cleanJarvis
        )
        current.add(turn)

        if (current.size > MAX_SHORT_TERM_TURNS) {
            val pruned = current.removeAt(0)
            if (shortTermSummary.length < 800) {
                shortTermSummary.append("${pruned.userTranscript} -> ${pruned.jarvisResponse}; ")
            }
        }
        _shortTermHistory.value = current

        // Trigger automatic semantic extraction on user input
        learnPreferencesFromConversation(cleanUser)
    }

    fun clearShortTermMemory() {
        _shortTermHistory.value = emptyList()
        shortTermSummary.clear()
    }

    fun getShortTermContextSummary(): String {
        return shortTermSummary.toString().trim()
    }

    // --- Long-Term Memory (Persistent in SQLite Room Database) ---

    suspend fun rememberFact(rawInput: String): String {
        val clean = rawInput
            .replace(Regex("(?i)^(hey jarvis|jarvis|please)?\\s*(remember that|remember to|remember|yaad rakhna ki|yaad rakhna)\\s*"), "")
            .trim()

        if (clean.isBlank()) {
            return "I didn't catch what you'd like me to remember, Sir."
        }

        learnPreferencesFromConversation(clean)

        val lower = clean.lowercase(Locale.ROOT)
        val category = when {
            lower.contains("favorite") || lower.contains("prefer") || lower.contains("like") || lower.contains("song") || lower.contains("music") || lower.contains("app") || lower.contains("pasand") ->
                MemoryEntity.CATEGORY_PREFERENCES
            lower.contains("routine") || lower.contains("gym") || lower.contains("work") || lower.contains("wake up") || lower.contains("sleep") || lower.contains("at ") || lower.contains("pm") || lower.contains("am") ->
                MemoryEntity.CATEGORY_ROUTINES
            lower.contains("name") || lower.contains("birthday") || lower.contains("live in") || lower.contains("age") || lower.contains("i am") || lower.contains("my ") || lower.contains("mera") || lower.contains("meri") ->
                MemoryEntity.CATEGORY_PERSONAL
            lower.contains("call") || lower.contains("contact") || lower.contains("phone") || lower.contains("number") || lower.contains("friend") || lower.contains("brother") || lower.contains("sister") || lower.contains("mom") || lower.contains("dad") || lower.contains("bhai") || lower.contains("dost") ->
                MemoryEntity.CATEGORY_CONTACTS
            else ->
                MemoryEntity.CATEGORY_NOTES
        }

        val key = clean.take(40).trim()
        repository.saveMemory(
            rawText = clean,
            category = category,
            key = key,
            value = clean
        )
        Log.i(TAG, "Saved long-term memory in category '$category': $clean")
        val response = "Sir, I have permanently committed that to memory: $clean."
        chatRepository.addTurn(clean, response)
        return response
    }

    suspend fun forgetFact(query: String): String {
        val clean = query
            .replace(Regex("(?i)^(hey jarvis|jarvis|please)?\\s*(forget that|forget my|forget about|forget|bhool jao)\\s*"), "")
            .trim()

        if (clean.isBlank()) {
            return "Please tell me what you would like me to forget, Sir."
        }

        val deletedCount = repository.deleteMemoriesByKeyword(clean)
        val response = if (deletedCount > 0) {
            "Sir, I have erased $clean from my persistent memory."
        } else {
            "I couldn't find any memory matching '$clean'."
        }
        chatRepository.addTurn(clean, response)
        return response
    }

    suspend fun getWhatDoYouRemember(): String {
        val all = repository.getAllMemories()
        if (all.isEmpty()) {
            return "My memory core is currently clear, Sir. Tell me anything about your life, habits, or preferences and I will never forget it."
        }

        val count = all.size
        val topFacts = all.take(6).joinToString(". ") { it.rawText }
        val response = "Sir, I remember $count key facts about you in my Memory Core, including: $topFacts."
        chatRepository.addTurn("What do you remember about me?", response)
        return response
    }

    // --- Direct Recall Responses ---

    suspend fun getBirthdayResponse(): String {
        val bday = preferences.userBirthday
        if (bday.isNotBlank()) {
            val reply = "Sir, your birthday is $bday."
            chatRepository.addTurn("When is my birthday?", reply)
            return reply
        }
        val memories = repository.searchMemories("birthday")
        val mem = memories.firstOrNull()
        if (mem != null) {
            preferences.userBirthday = mem.value
            val reply = "Sir, your birthday is ${mem.value}."
            chatRepository.addTurn("When is my birthday?", reply)
            return reply
        }
        val notSet = "Sir, you haven't told me your birthday yet. You can tell me 'My birthday is 15th August' and I will save it."
        chatRepository.addTurn("When is my birthday?", notSet)
        return notSet
    }

    fun getFavoriteSongResponse(): String {
        val song = resolveSongQuery("my favorite song")
        val reply = "Sir, your favorite song is $song."
        chatRepository.addTurn("What is my favorite song?", reply)
        return reply
    }

    suspend fun getRoutineResponse(): String {
        val allMemories = repository.getAllMemories()
        val routines = allMemories.filter { it.category == MemoryEntity.CATEGORY_ROUTINES }
        if (routines.isNotEmpty()) {
            val summary = routines.joinToString("; ") { it.rawText }
            val reply = "Sir, here is your recorded daily routine: $summary."
            chatRepository.addTurn("What is my routine?", reply)
            return reply
        }
        if (preferences.dailyRoutine.isNotBlank()) {
            val reply = "Sir, your daily routine is: ${preferences.dailyRoutine}."
            chatRepository.addTurn("What is my routine?", reply)
            return reply
        }
        val notSet = "Sir, you haven't recorded your routine yet. Tell me 'I wake up at 7 am' or 'I go to the gym at 6 pm' and I will save it."
        chatRepository.addTurn("What is my routine?", notSet)
        return notSet
    }

    // --- Automatic Habit & Preference Learning ---

    fun trackSongPlay(rawQuery: String) {
        val clean = rawQuery
            .replace(Regex("(?i)\\s+(song|video|gana|track|music|audio)$"), "")
            .replace(Regex("(?i)^(play|chalao|bajao)\\s+"), "")
            .trim()

        if (clean.isBlank() || clean.equals("my favorite song", ignoreCase = true) || clean.equals("favorite song", ignoreCase = true)) return

        val currentFav = preferences.recordSongPlay(clean)
        Log.i(TAG, "Tracked song play: '$clean'. Current top favorite: '$currentFav'")

        scope.launch(Dispatchers.IO) {
            repository.saveMemory(
                rawText = "User played and likes the song $clean",
                category = MemoryEntity.CATEGORY_PREFERENCES,
                key = "song_$clean",
                value = clean
            )
            if (currentFav.equals(clean, ignoreCase = true)) {
                repository.deleteMemoriesByKeyword("favorite_song")
                repository.saveMemory(
                    rawText = "User's favorite song is $clean",
                    category = MemoryEntity.CATEGORY_PREFERENCES,
                    key = "favorite_song",
                    value = clean
                )
            }
        }
    }

    fun resolveSongQuery(rawQuery: String): String {
        val clean = rawQuery.lowercase(Locale.ROOT).trim()
        val isFavoriteQuery = clean == "my favorite song" || clean == "my favourite song" ||
                clean == "favorite song" || clean == "favourite song" ||
                clean == "my song" || clean == "my favorite" || clean == "my favourite" ||
                clean == "something i like" || clean == "a song i like" ||
                clean == "mera favorite gana" || clean == "mera favourite gana" ||
                clean == "mera favorite song" || clean == "mera favourite song" ||
                clean == "mera pasandida gana" || clean == "pasandida gana"

        if (!isFavoriteQuery) {
            return rawQuery
        }

        val prefFav = preferences.favoriteSong
        if (prefFav.isNotBlank()) {
            return prefFav
        }

        val mostPlayed = preferences.getSongPlayCounts().maxByOrNull { it.value }?.key
        if (!mostPlayed.isNullOrBlank()) {
            return mostPlayed
        }

        return "Tadipaar"
    }

    /**
     * Expanded Semantic Learning Engine: Extracts personal facts, preferences, routines,
     * relationships, and knowledge from spoken user conversation in English and Hinglish.
     * Everything learned is immediately committed to Room Database (MemoryRepository).
     */
    fun learnPreferencesFromConversation(userSpeech: String) {
        val clean = userSpeech.trim()
        if (clean.isBlank() || clean.length < 3) return

        scope.launch(Dispatchers.IO) {
            val lower = clean.lowercase(Locale.ROOT)

            // 1. EXPLICIT "REMEMBER THAT" / "YAAD RAKHNA" STATEMENTS
            val rememberMatch = Regex("(?i).*(?:remember\\s+that|remember\\s+to|remember|yaad\\s+rakhna\\s+ki|yaad\\s+rakhna)\\s+(.+)$").find(clean)
            if (rememberMatch != null) {
                val fact = rememberMatch.groupValues[1].trim()
                if (fact.length > 3) {
                    repository.saveMemory(
                        rawText = fact,
                        category = MemoryEntity.CATEGORY_NOTES,
                        key = fact.take(30),
                        value = fact
                    )
                    Log.i(TAG, "Learned explicit fact: $fact")
                }
            }

            // 2. USER NAME & IDENTITY
            val nameMatch = Regex("(?i).*\\b(?:my\\s+name\\s+is|call\\s+me|i\\s+am\\s+called|mera\\s+naam\\s+hai|mera\\s+naam)\\s+([a-zA-Z]+)(?:[.,!]|\\s+\$|\\s+hai)?").find(clean)
            if (nameMatch != null) {
                val name = nameMatch.groupValues[1].trim().replaceFirstChar { it.uppercase() }
                if (name.length > 1 && !listOf("jarvis", "sir", "boss", "you", "who", "not").contains(name.lowercase(Locale.ROOT))) {
                    preferences.userName = name
                    repository.saveMemory(
                        rawText = "User's preferred name is $name",
                        category = MemoryEntity.CATEGORY_PERSONAL,
                        key = "user_name",
                        value = name
                    )
                    Log.i(TAG, "Learned user name: $name")
                }
            }

            // 3. BIRTHDAY EXTRACTION (English & Hinglish)
            val bdayMatch = Regex("(?i).*\\b(?:my\\s+birthday\\s+is|born\\s+on|my\\s+bday\\s+is)\\s+(?:on\\s+)?([a-zA-Z0-9\\s,]+?)(?:[.,!]|\$|\\s+sir|\\s+jarvis)").find(clean)
                ?: Regex("(?i).*\\b(?:mera\\s+)?(?:birthday|bday|janamdin)\\s+(?:hai\\s+)?([a-zA-Z0-9\\s]+?)(?:\\s+ko\\s+hai|\\s+ko|\\s+hai)?\$").find(clean)
                ?: Regex("(?i).*\\b([a-zA-Z0-9\\s]+?)\\s+(?:ko\\s+mera\\s+birthday\\s+hai|mera\\s+birthday\\s+hai).*").find(clean)

            if (bdayMatch != null) {
                var bday = bdayMatch.groupValues[1].trim()
                bday = bday.replace(Regex("(?i)^(on|ko|hai)\\s+"), "")
                    .replace(Regex("(?i)\\s+(ko|hai|sir|jarvis|please)$"), "")
                    .trim()
                if (bday.isNotBlank() && bday.length >= 3 && !listOf("sir", "jarvis", "today", "tomorrow", "when").contains(bday.lowercase(Locale.ROOT))) {
                    preferences.userBirthday = bday
                    repository.deleteMemoriesByKeyword("birthday")
                    repository.saveMemory(
                        rawText = "User's birthday is $bday",
                        category = MemoryEntity.CATEGORY_PERSONAL,
                        key = "user_birthday",
                        value = bday
                    )
                    Log.i(TAG, "Learned user's birthday: $bday")
                }
            }

            // 4. USER LOCATION / RESIDENCE
            val locMatch = Regex("(?i).*\\b(?:i\\s+live\\s+in|i\\s+stay\\s+in|my\\s+hometown\\s+is|my\\s+city\\s+is|main\\s+rehta\\s+hoon|mera\\s+ghar\\s+hai)\\s+([a-zA-Z\\s]+?)(?:[.,!]|\$|\\s+me|\\s+mein)").find(clean)
            if (locMatch != null) {
                val loc = locMatch.groupValues[1].trim().replaceFirstChar { it.uppercase() }
                if (loc.isNotBlank() && loc.length > 2 && !listOf("here", "there", "home", "house").contains(loc.lowercase(Locale.ROOT))) {
                    preferences.userLocation = loc
                    repository.saveMemory(
                        rawText = "User lives in $loc",
                        category = MemoryEntity.CATEGORY_PERSONAL,
                        key = "user_location",
                        value = loc
                    )
                    Log.i(TAG, "Learned user location: $loc")
                }
            }

            // 5. USER JOB / PROFESSION
            val jobMatch = Regex("(?i).*\\b(?:i\\s+work\\s+as\\s+(?:a\\s+)?|i\\s+am\\s+a\\s+|my\\s+job\\s+is\\s+(?:a\\s+)?|mera\\s+kaam\\s+hai\\s+)([a-zA-Z\\s]+?)(?:[.,!]|\$|\\s+engineer|\\s+developer|\\s+doctor)").find(clean)
            if (jobMatch != null) {
                val job = jobMatch.groupValues[1].trim()
                if (job.isNotBlank() && job.length > 2 && !listOf("human", "person", "user", "good", "bad").contains(job.lowercase(Locale.ROOT))) {
                    repository.saveMemory(
                        rawText = "User's profession/job is $job",
                        category = MemoryEntity.CATEGORY_PERSONAL,
                        key = "user_profession",
                        value = job
                    )
                    Log.i(TAG, "Learned user profession: $job")
                }
            }

            // 6. FAVORITE SONG LEARNING
            val favSongMatch = Regex("(?i).*\\b(?:my\\s+favou?rite\\s+song\\s+is|i\\s+love\\s+the\\s+song|mera\\s+favou?rite\\s+gana\\s+hai|mera\\s+pasandida\\s+gana)\\s+([a-zA-Z0-9\\s]+?)(?:[.,!]|\$|\\s+by|\\s+hai)").find(clean)
            if (favSongMatch != null) {
                val song = favSongMatch.groupValues[1].trim()
                if (song.isNotBlank() && song.length > 2) {
                    preferences.favoriteSong = song
                    repository.deleteMemoriesByKeyword("favorite_song")
                    repository.saveMemory(
                        rawText = "User's favorite song is $song",
                        category = MemoryEntity.CATEGORY_PREFERENCES,
                        key = "favorite_song",
                        value = song
                    )
                    Log.i(TAG, "Learned user's favorite song: $song")
                }
            }

            // 7. FAVORITE APP LEARNING
            val appMatch = Regex("(?i).*\\b(?:my\\s+favou?rite\\s+app\\s+is|i\\s+use\\s+)([a-zA-Z0-9\\s]+?)(?:\\s+the\\s+most|\\s+app)?(?:[.,!]|\$)?$").find(clean)
            if (appMatch != null) {
                val app = appMatch.groupValues[1].trim()
                if (app.isNotBlank() && app.length > 2 && !listOf("this", "phone", "internet", "device").contains(app.lowercase(Locale.ROOT))) {
                    preferences.favoriteApp = app
                    repository.saveMemory(
                        rawText = "User's favorite app is $app",
                        category = MemoryEntity.CATEGORY_PREFERENCES,
                        key = "favorite_app",
                        value = app
                    )
                    Log.i(TAG, "Learned user's favorite app: $app")
                }
            }

            // 8. PERSONAL RELATIONSHIPS / CONTACTS
            val contactMatch = Regex("(?i).*\\b([a-zA-Z0-9]+)\\s+is\\s+my\\s+(brother|sister|friend|best\\s+friend|mom|dad|father|mother|cousin|boss|wife|husband)[.,!]?$").find(clean)
                ?: Regex("(?i).*\\b([a-zA-Z0-9]+)\\s+mera\\s+(bhai|dost|yaar|papa|mummy)[.,!]?$").find(clean)
            if (contactMatch != null) {
                val name = contactMatch.groupValues[1].trim().replaceFirstChar { it.uppercase() }
                val relation = contactMatch.groupValues[2].trim()
                if (name.isNotBlank() && name.length > 1 && !listOf("who", "he", "she", "this", "that", "it").contains(name.lowercase(Locale.ROOT))) {
                    repository.saveMemory(
                        rawText = "$name is user's $relation",
                        category = MemoryEntity.CATEGORY_CONTACTS,
                        key = "relation_$name",
                        value = relation
                    )
                    Log.i(TAG, "Learned personal relationship: $name is $relation")
                }
            }

            // 9. GENERAL PREFERENCES (e.g. food, vehicles, colors, hobbies)
            val prefMatch = Regex("(?i).*\\b(?:i\\s+love\\s+|i\\s+like\\s+|my\\s+favou?rite\\s+)([a-zA-Z0-9\\s]+?)\\s+(?:is|are)\\s+([a-zA-Z0-9\\s]+?)[.,!]?$").find(clean)
            if (prefMatch != null) {
                val topic = prefMatch.groupValues[1].trim()
                val prefValue = prefMatch.groupValues[2].trim()
                if (topic.isNotBlank() && prefValue.isNotBlank() && topic.length < 25 && prefValue.length < 40) {
                    repository.saveMemory(
                        rawText = "User's favorite $topic is $prefValue",
                        category = MemoryEntity.CATEGORY_PREFERENCES,
                        key = "pref_${topic.take(20)}",
                        value = prefValue
                    )
                    Log.i(TAG, "Learned general preference: $topic -> $prefValue")
                }
            }
        }
    }

    /**
     * Builds the complete prompt context for Gemini Live.
     * Contains:
     * 1. Core Profile
     * 2. All categorized Room database memories (persistent across restarts)
     * 3. Recent 15 conversation turns across sessions (persistent dialogue memory)
     */
    suspend fun getSystemPromptContext(): String {
        val all = repository.getAllMemories()
        val favSong = resolveSongQuery("my favorite song")
        val sb = StringBuilder("\n[USER PERSONAL PROFILE & MEMORY CORE - PERMANENT STORAGE]:\n")
        sb.append("- User's Preferred Name: ${preferences.userName.ifBlank { "Sir" }}\n")
        sb.append("- User's Birthday: ${preferences.userBirthday.ifBlank { "Not specified yet" }}\n")
        sb.append("- User's Known Favorite Song: $favSong\n")
        sb.append("- User's Favorite App: ${preferences.favoriteApp.ifBlank { "YouTube" }}\n")
        if (preferences.userLocation.isNotBlank()) {
            sb.append("- User's Location: ${preferences.userLocation}\n")
        }
        if (preferences.userAge.isNotBlank()) {
            sb.append("- User's Age: ${preferences.userAge} years old\n")
        }
        if (preferences.dailyRoutine.isNotBlank()) {
            sb.append("- User's Daily Routine: ${preferences.dailyRoutine}\n")
        }

        if (all.isNotEmpty()) {
            sb.append("\n[ALL PERMANENT MEMORIES FROM DATABASE]:\n")
            all.take(40).forEach { mem ->
                sb.append("- [${mem.category}] ${mem.rawText}\n")
            }
        }

        // Persistent Dialogue History across App Restarts
        val recentTurns = chatRepository.turns.value.takeLast(15)
        if (recentTurns.isNotEmpty()) {
            sb.append("\n[PERSISTENT DIALOGUE HISTORY ACROSS APP RESTARTS]:\n")
            sb.append("You remember what was discussed in previous conversations with the user:\n")
            recentTurns.forEach { turn ->
                val u = turn.userTranscript.trim()
                val j = turn.jarvisResponse.trim()
                if (u.isNotBlank() && j.isNotBlank() && u != "(Audio query)" && j != "(Audio response)") {
                    sb.append("User: \"$u\"\n")
                    sb.append("JARVIS: \"$j\"\n")
                }
            }
        }

        return sb.toString()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/memory/MemoryManager.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/memory/MemoryRepository.kt ===
```kotlin
package com.jarvis.assistant.data.memory

import kotlinx.coroutines.flow.Flow

class MemoryRepository(private val memoryDao: MemoryDao) {

    fun getAllMemoriesFlow(): Flow<List<MemoryEntity>> = memoryDao.getAllMemoriesFlow()

    suspend fun getAllMemories(): List<MemoryEntity> = memoryDao.getAllMemories()

    fun getMemoriesByCategoryFlow(category: String): Flow<List<MemoryEntity>> {
        return if (category == "All") {
            memoryDao.getAllMemoriesFlow()
        } else {
            memoryDao.getMemoriesByCategoryFlow(category)
        }
    }

    fun searchMemoriesFlow(query: String): Flow<List<MemoryEntity>> = memoryDao.searchMemoriesFlow(query)

    suspend fun searchMemories(query: String): List<MemoryEntity> = memoryDao.searchMemories(query)

    suspend fun saveMemory(
        rawText: String,
        category: String = MemoryEntity.CATEGORY_NOTES,
        key: String = "",
        value: String = ""
    ): Long {
        val calculatedKey = key.ifBlank {
            rawText.take(30).trim()
        }
        val calculatedValue = value.ifBlank { rawText }

        val entity = MemoryEntity(
            category = category,
            key = calculatedKey,
            value = calculatedValue,
            rawText = rawText
        )
        return memoryDao.insertMemory(entity)
    }

    suspend fun updateMemory(memory: MemoryEntity) {
        memoryDao.updateMemory(memory)
    }

    suspend fun deleteMemoryById(id: Long) {
        memoryDao.deleteMemoryById(id)
    }

    suspend fun deleteMemoriesByKeyword(keyword: String): Int {
        return memoryDao.deleteMemoriesByKeyword(keyword)
    }

    suspend fun clearAll() {
        memoryDao.clearAllMemories()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/memory/MemoryRepository.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/model/ChatTurn.kt ===
```kotlin
package com.jarvis.assistant.data.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ChatTurn(
    val id: String = UUID.randomUUID().toString(),
    val userTranscript: String,
    val jarvisResponse: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    val formattedTime: String
        get() {
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/model/ChatTurn.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/model/ConversationState.kt ===
```kotlin
package com.jarvis.assistant.data.model

enum class ConversationState(val displayName: String, val orbKey: String) {
    IDLE("IDLE", "idle"),
    LISTENING("LISTENING", "listening"),
    THINKING("THINKING", "thinking"),
    SPEAKING("SPEAKING", "speaking")
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/model/ConversationState.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/model/GeminiLiveModels.kt ===
```kotlin
package com.jarvis.assistant.data.model

import com.google.gson.annotations.SerializedName

object GeminiConstants {
    const val MODEL_3_1_FLASH = "models/gemini-3.1-flash-live-preview"
    const val MODEL_3_8_LIVE = "models/gemini-3.8-live"
    const val MODEL_3_1_FLASH_AGENT = "models/gemini-3.1-flash-agent"
    const val MODEL_2_0_FLASH = MODEL_3_1_FLASH
    const val MODEL_2_0_FLASH_REALTIME = MODEL_3_1_FLASH

    const val RELEASE_API_KEY = ""

    const val DEFAULT_MODEL = MODEL_3_1_FLASH

    val SUPPORTED_MODELS = listOf(
        MODEL_3_1_FLASH,
        MODEL_3_8_LIVE,
        MODEL_3_1_FLASH_AGENT
    )

    const val DEFAULT_LANGUAGE = "Auto"

    val SUPPORTED_LANGUAGES = listOf(
        "Auto",
        "English",
        "Hindi",
        "Hinglish",
        "Telugu",
        "Tamil",
        "Kannada",
        "Malayalam",
        "Bengali",
        "Marathi",
        "Gujarati",
        "Bhojpuri",
        "Punjabi",
        "Odia",
        "Urdu"
    )

    const val DEFAULT_VOICE = "Puck"

    val SUPPORTED_VOICES = listOf(
        "Aoede",
        "Charon",
        "Kore",
        "Fenrir",
        "Puck",
        "Leda",
        "Orus",
        "Zephyr"
    )

    const val PERSONALITY_ASSISTANT = "Jarvis Pro"
    const val PERSONALITY_GIRLFRIEND = "Girlfriend Mode"
    const val PERSONALITY_BOYFRIEND = "Boyfriend Mode"
    const val PERSONALITY_TECHGPT_X = "TechGPT X Mode"
    const val PERSONALITY_COMPANION = "Companion Mode"
    const val PERSONALITY_PROFESSIONAL = "Professional Mode"
    const val PERSONALITY_FOCUS = "Focus Mode"

    val SUPPORTED_PERSONALITIES = listOf(
        PERSONALITY_ASSISTANT,
        PERSONALITY_GIRLFRIEND,
        PERSONALITY_BOYFRIEND,
        PERSONALITY_TECHGPT_X,
        PERSONALITY_COMPANION,
        PERSONALITY_FOCUS,
        PERSONALITY_PROFESSIONAL
    )

    const val WS_BASE_URL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
    const val SESSION_RENEWAL_MS = 9 * 60 * 1000L // 9 minutes
}

// Request Models
data class GeminiBidiSetup(
    @SerializedName("setup") val setup: SetupPayload
)

data class SetupPayload(
    @SerializedName("model") val model: String,
    @SerializedName("generationConfig") val generationConfig: GenerationConfigPayload,
    @SerializedName("inputAudioTranscription") val inputAudioTranscription: EmptyConfig = EmptyConfig(),
    @SerializedName("outputAudioTranscription") val outputAudioTranscription: EmptyConfig = EmptyConfig(),
    @SerializedName("systemInstruction") val systemInstruction: ContentPayload? = null
)

data class GenerationConfigPayload(
    @SerializedName("responseModalities") val responseModalities: List<String> = listOf("AUDIO"),
    @SerializedName("speechConfig") val speechConfig: SpeechConfigPayload
)

data class EmptyConfig(val unused: String? = null)

data class SpeechConfigPayload(
    @SerializedName("voiceConfig") val voiceConfig: VoiceConfigPayload
)

data class VoiceConfigPayload(
    @SerializedName("prebuiltVoiceConfig") val prebuiltVoiceConfig: PrebuiltVoiceConfigPayload
)

data class PrebuiltVoiceConfigPayload(
    @SerializedName("voiceName") val voiceName: String
)

data class ContentPayload(
    @SerializedName("parts") val parts: List<PartTextPayload>
)

data class PartTextPayload(
    @SerializedName("text") val text: String
)

data class GeminiRealtimeInput(
    @SerializedName("realtimeInput") val realtimeInput: RealtimeAudioInput
)

data class RealtimeAudioInput(
    @SerializedName("audio") val audio: RealtimeAudioPayload? = null,
    // Signals a locally detected end of speech so Gemini need not wait for its
    // slower server-side silence timeout before starting a reply.
    @SerializedName("audioStreamEnd") val audioStreamEnd: Boolean? = null
)

data class RealtimeAudioPayload(
    @SerializedName("mimeType") val mimeType: String = "audio/pcm;rate=16000",
    @SerializedName("data") val data: String
)

// Response Models
data class GeminiBidiServerResponse(
    @SerializedName("serverContent") val serverContent: ServerContentPayload? = null
)

data class ServerContentPayload(
    @SerializedName("modelTurn") val modelTurn: ModelTurnPayload? = null,
    @SerializedName("turnComplete") val turnComplete: Boolean = false,
    @SerializedName("interrupted") val interrupted: Boolean = false
)

data class ModelTurnPayload(
    @SerializedName("parts") val parts: List<ModelPartPayload>? = null
)

data class ModelPartPayload(
    @SerializedName("text") val text: String? = null,
    @SerializedName("inlineData") val inlineData: InlineAudioPayload? = null
)

data class InlineAudioPayload(
    @SerializedName("mimeType") val mimeType: String? = null,
    @SerializedName("data") val data: String? = null
)
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/model/GeminiLiveModels.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/preferences/AppPreferences.kt ===
```kotlin
package com.jarvis.assistant.data.preferences

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.jarvis.assistant.data.model.ChatTurn
import com.jarvis.assistant.data.model.GeminiConstants

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val secureApiPrefs: SharedPreferences? = try {
        val masterKey = MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context.applicationContext,
            ENCRYPTED_API_PREF_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        Log.e(TAG, "Secure API-key storage could not be initialized", e)
        null
    }
    private val gson = Gson()

    init {
        migrateApiKeyToEncryptedStorage()
        val current = prefs.getString(KEY_MODEL, null)
        if (current == null || current !in GeminiConstants.SUPPORTED_MODELS) {
            prefs.edit().putString(KEY_MODEL, GeminiConstants.DEFAULT_MODEL).apply()
        }
    }

    companion object {
        private const val PREF_NAME = "jarvis_prefs"
        private const val ENCRYPTED_API_PREF_NAME = "jarvis_secure_api_prefs"
        private const val TAG = "AppPreferences"
        private const val KEY_API_KEY = "key_api_key"
        private const val KEY_MODEL = "key_model"
        private const val KEY_VOICE = "key_voice"
        private const val KEY_PERSONALITY = "key_personality"
        private const val KEY_USER_NAME = "key_user_name"
        private const val KEY_MIC_MUTED = "key_mic_muted"
        private const val KEY_CHAT_HISTORY = "key_chat_history"
        private const val KEY_FAVORITE_SONG = "key_favorite_song"
        private const val KEY_FAVORITE_APP = "key_favorite_app"
        private const val KEY_SONG_COUNTS = "key_song_counts"
        private const val KEY_USER_BIRTHDAY = "key_user_birthday"
        private const val KEY_USER_LOCATION = "key_user_location"
        private const val KEY_USER_AGE = "key_user_age"
        private const val KEY_DAILY_ROUTINE = "key_daily_routine"
        private const val KEY_OWNER_VOICE_ENABLED = "key_owner_voice_enabled"
        private const val KEY_OWNER_VOICE_PROFILE = "key_owner_voice_profile"
        private const val KEY_OWNER_VOICE_SAMPLES = "key_owner_voice_samples"
        private const val KEY_OWNER_VOICE_THRESHOLD = "key_owner_voice_threshold"
        private const val KEY_OWNER_VOICE_SAMPLE_COUNT = "key_owner_voice_sample_count"
        private const val KEY_LANGUAGE = "key_language"
        private const val KEY_SILENT_EXECUTION_MODE = "key_silent_execution_mode"
        private const val KEY_TASK_OVERLAY_ENABLED = "key_task_overlay_enabled"
        private const val KEY_TASK_OVERLAY_AVATAR = "key_task_overlay_avatar"
        private const val KEY_TASK_OVERLAY_MODE = "key_task_overlay_mode"
        private const val KEY_TASK_OVERLAY_EDGE = "key_task_overlay_edge"
        private const val KEY_TASK_OVERLAY_FREE_POSITION = "key_task_overlay_free_position"
        private const val KEY_TASK_OVERLAY_X = "key_task_overlay_x"
        private const val KEY_TASK_OVERLAY_Y = "key_task_overlay_y"
        private const val KEY_APP_THEME = "key_app_theme"
        private const val KEY_CUSTOM_THEME_COLOR = "key_custom_theme_color"
        private const val KEY_ORB_ANIMATION = "key_orb_animation"
        private const val KEY_ORB_SPEED = "key_orb_speed"
        private const val KEY_ORB_GLOW = "key_orb_glow"
        private const val KEY_ORB_SCALE = "key_orb_scale"
        private const val KEY_ORB_HUE = "key_orb_hue"
        private const val KEY_CUSTOM_ENDPOINT = "key_custom_endpoint"
    }

    var isOwnerVoiceEnabled: Boolean
        get() = prefs.getBoolean(KEY_OWNER_VOICE_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_OWNER_VOICE_ENABLED, value).apply()

    var ownerVoiceThreshold: Float
        get() {
            val stored = prefs.getFloat(KEY_OWNER_VOICE_THRESHOLD, 0.70f)
            // Auto-migrate older builds that saved overly strict 0.50f threshold
            return if (stored < 0.60f) 0.70f else stored
        }
        set(value) = prefs.edit().putFloat(KEY_OWNER_VOICE_THRESHOLD, value).apply()

    var ownerVoiceSampleCount: Int
        get() = prefs.getInt(KEY_OWNER_VOICE_SAMPLE_COUNT, 0)
        set(value) = prefs.edit().putInt(KEY_OWNER_VOICE_SAMPLE_COUNT, value).apply()

    fun hasOwnerVoiceProfile(): Boolean {
        val str = prefs.getString(KEY_OWNER_VOICE_PROFILE, null)
        return !str.isNullOrBlank()
    }

    fun getOwnerVoiceProfile(): FloatArray? {
        val json = prefs.getString(KEY_OWNER_VOICE_PROFILE, null) ?: return null
        return try {
            val arr = org.json.JSONArray(json)
            FloatArray(arr.length()) { i -> arr.getDouble(i).toFloat() }
        } catch (e: Exception) {
            null
        }
    }

    fun getOwnerVoiceSamples(): List<FloatArray> {
        val json = prefs.getString(KEY_OWNER_VOICE_SAMPLES, null) ?: return emptyList()
        return try {
            val root = org.json.JSONArray(json)
            val list = mutableListOf<FloatArray>()
            for (i in 0 until root.length()) {
                val arr = root.getJSONArray(i)
                val vec = FloatArray(arr.length()) { j -> arr.getDouble(j).toFloat() }
                if (vec.isNotEmpty()) list.add(vec)
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveOwnerVoiceProfile(masterProfile: FloatArray, sampleVectors: List<FloatArray>) {
        val masterArr = org.json.JSONArray()
        for (v in masterProfile) {
            masterArr.put(v.toDouble())
        }

        val samplesArr = org.json.JSONArray()
        for (vec in sampleVectors) {
            val arr = org.json.JSONArray()
            for (v in vec) {
                arr.put(v.toDouble())
            }
            samplesArr.put(arr)
        }

        prefs.edit()
            .putString(KEY_OWNER_VOICE_PROFILE, masterArr.toString())
            .putString(KEY_OWNER_VOICE_SAMPLES, samplesArr.toString())
            .putInt(KEY_OWNER_VOICE_SAMPLE_COUNT, sampleVectors.size)
            .putBoolean(KEY_OWNER_VOICE_ENABLED, true)
            .apply()
    }

    fun saveOwnerVoiceProfile(profile: FloatArray, sampleCount: Int) {
        val arr = org.json.JSONArray()
        for (v in profile) {
            arr.put(v.toDouble())
        }
        prefs.edit()
            .putString(KEY_OWNER_VOICE_PROFILE, arr.toString())
            .putInt(KEY_OWNER_VOICE_SAMPLE_COUNT, sampleCount)
            .putBoolean(KEY_OWNER_VOICE_ENABLED, true)
            .apply()
    }

    fun clearOwnerVoiceProfile() {
        prefs.edit()
            .remove(KEY_OWNER_VOICE_PROFILE)
            .remove(KEY_OWNER_VOICE_SAMPLES)
            .remove(KEY_OWNER_VOICE_SAMPLE_COUNT)
            .putBoolean(KEY_OWNER_VOICE_ENABLED, false)
            .apply()
    }

    var apiKey: String
        get() = secureApiPrefs?.getString(KEY_API_KEY, "")?.trim() ?: ""
        set(value) {
            val secure = checkNotNull(secureApiPrefs) { "Secure API-key storage is unavailable on this device." }
            val clean = value.trim()
            val saved = if (clean.isEmpty()) secure.edit().remove(KEY_API_KEY).commit()
            else secure.edit().putString(KEY_API_KEY, clean).commit()
            check(saved) { "Could not save API key to encrypted storage." }
        }

    val canStoreApiKeySecurely: Boolean get() = secureApiPrefs != null

    private fun migrateApiKeyToEncryptedStorage() {
        val legacyKey = prefs.getString(KEY_API_KEY, null)?.trim().orEmpty()
        if (legacyKey.isEmpty()) return
        val secure = secureApiPrefs ?: run {
            prefs.edit().remove(KEY_API_KEY).commit()
            return
        }
        try {
            val existing = secure.getString(KEY_API_KEY, null)
            if (existing.isNullOrEmpty()) {
                check(secure.edit().putString(KEY_API_KEY, legacyKey).commit())
            }
            if (!secure.getString(KEY_API_KEY, null).isNullOrEmpty()) prefs.edit().remove(KEY_API_KEY).commit()
        } catch (e: Exception) {
            Log.e(TAG, "Legacy API-key migration to encrypted storage failed", e)
        }
    }

    var aiModel: String
        get() {
            val stored = prefs.getString(KEY_MODEL, GeminiConstants.DEFAULT_MODEL) ?: GeminiConstants.DEFAULT_MODEL
            if (stored !in GeminiConstants.SUPPORTED_MODELS) {
                prefs.edit().putString(KEY_MODEL, GeminiConstants.DEFAULT_MODEL).apply()
                return GeminiConstants.DEFAULT_MODEL
            }
            return stored
        }
        set(value) {
            val toSave = if (value in GeminiConstants.SUPPORTED_MODELS) value else GeminiConstants.DEFAULT_MODEL
            prefs.edit().putString(KEY_MODEL, toSave).apply()
        }

    var language: String
        get() {
            val stored = prefs.getString(KEY_LANGUAGE, GeminiConstants.DEFAULT_LANGUAGE) ?: GeminiConstants.DEFAULT_LANGUAGE
            return if (stored.contains("Auto", ignoreCase = true)) "Auto" else stored
        }
        set(value) {
            val clean = if (value.contains("Auto", ignoreCase = true)) "Auto" else value.trim()
            prefs.edit().putString(KEY_LANGUAGE, clean).apply()
        }

    var voice: String
        get() = prefs.getString(KEY_VOICE, GeminiConstants.DEFAULT_VOICE) ?: GeminiConstants.DEFAULT_VOICE
        set(value) = prefs.edit().putString(KEY_VOICE, value).apply()

    var personality: String
        get() = prefs.getString(KEY_PERSONALITY, GeminiConstants.PERSONALITY_ASSISTANT) ?: GeminiConstants.PERSONALITY_ASSISTANT
        set(value) = prefs.edit().putString(KEY_PERSONALITY, value).apply()

    var userName: String
        get() {
            val name = prefs.getString(KEY_USER_NAME, "") ?: ""
            return if (name.isBlank() || name == "Salaam") "TechGPT X" else name
        }
        set(value) {
            prefs.edit().putString(KEY_USER_NAME, value.trim()).commit()
        }

    var appTheme: String
        get() {
            val stored = prefs.getString(KEY_APP_THEME, "sunset") ?: "sunset"
            return when (stored) {
                "light", "pearl_white" -> "light"
                "dark", "midnight_onyx", "cyberpunk_neon", "emerald_obsidian" -> "dark"
                "red" -> "red"
                "sunset", "rose_gold" -> "sunset"
                "custom" -> "custom"
                else -> "light"
            }
        }
        set(value) = prefs.edit().putString(KEY_APP_THEME, value).apply()

    var customThemeColor: String
        get() = prefs.getString(KEY_CUSTOM_THEME_COLOR, "#FFFFFF") ?: "#FFFFFF"
        set(value) = prefs.edit().putString(KEY_CUSTOM_THEME_COLOR, value.trim()).apply()

    var orbAnimation: String
        get() {
            val valid = listOf("holographic_plasma", "cosmic_pulsar", "quantum_core", "cyber_ring", "siri_glow")
            val stored = prefs.getString(KEY_ORB_ANIMATION, "holographic_plasma") ?: "holographic_plasma"
            return if (stored in valid) stored else "holographic_plasma"
        }
        set(value) = prefs.edit().putString(KEY_ORB_ANIMATION, value).apply()

    var orbSpeed: Float
        get() = prefs.getFloat(KEY_ORB_SPEED, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_ORB_SPEED, value).apply()

    var orbGlow: Float
        get() = prefs.getFloat(KEY_ORB_GLOW, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_ORB_GLOW, value).apply()

    var orbScale: Float
        get() = prefs.getFloat(KEY_ORB_SCALE, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_ORB_SCALE, value).apply()

    var orbHue: Float
        get() = prefs.getFloat(KEY_ORB_HUE, -1f)
        set(value) = prefs.edit().putFloat(KEY_ORB_HUE, value).apply()

    var customEndpoint: String
        get() = prefs.getString(KEY_CUSTOM_ENDPOINT, "") ?: ""
        set(value) = prefs.edit().putString(KEY_CUSTOM_ENDPOINT, value.trim()).apply()

    var userBirthday: String
        get() = prefs.getString(KEY_USER_BIRTHDAY, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_USER_BIRTHDAY, value.trim()).commit()
        }

    var userLocation: String
        get() = prefs.getString(KEY_USER_LOCATION, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_USER_LOCATION, value.trim()).commit()
        }

    var userAge: String
        get() = prefs.getString(KEY_USER_AGE, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_USER_AGE, value.trim()).commit()
        }

    var dailyRoutine: String
        get() = prefs.getString(KEY_DAILY_ROUTINE, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_DAILY_ROUTINE, value.trim()).commit()
        }

    var favoriteSong: String
        get() = prefs.getString(KEY_FAVORITE_SONG, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_FAVORITE_SONG, value.trim()).commit()
        }

    var favoriteApp: String
        get() = prefs.getString(KEY_FAVORITE_APP, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_FAVORITE_APP, value.trim()).commit()
        }

    var isMicMuted: Boolean
        get() = prefs.getBoolean(KEY_MIC_MUTED, false)
        set(value) = prefs.edit().putBoolean(KEY_MIC_MUTED, value).apply()

    var isSilentExecutionMode: Boolean
        get() = prefs.getBoolean(KEY_SILENT_EXECUTION_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_SILENT_EXECUTION_MODE, value).apply()

    var isTaskOverlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_TASK_OVERLAY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_TASK_OVERLAY_ENABLED, value).apply()

    var taskOverlayAvatar: String
        get() = prefs.getString(KEY_TASK_OVERLAY_AVATAR, "ghost") ?: "ghost"
        set(value) {
            val available = listOf("alien", "blob", "cat", "circle", "cloud", "droid", "drop", "flower", "ghost", "hexagon", "mech", "pebble", "pill", "puddle", "square", "star", "triangle")
            prefs.edit().putString(KEY_TASK_OVERLAY_AVATAR, value.takeIf { it in available } ?: "ghost").apply()
        }

    /** always keeps the avatar visible while the service is alive; working limits it to active tasks. */
    var taskOverlayMode: String
        get() = prefs.getString(KEY_TASK_OVERLAY_MODE, "always") ?: "always"
        set(value) = prefs.edit().putString(KEY_TASK_OVERLAY_MODE, if (value == "working") "working" else "always").apply()

    /** Preferred dock edge. Dragging the overlay updates this to the closest edge. */
    var taskOverlayEdge: String
        get() = prefs.getString(KEY_TASK_OVERLAY_EDGE, "right") ?: "right"
        set(value) = prefs.edit().putString(KEY_TASK_OVERLAY_EDGE, value.takeIf { it in setOf("left", "right", "top", "bottom") } ?: "right").apply()

    var taskOverlayFreePosition: Boolean
        get() = prefs.getBoolean(KEY_TASK_OVERLAY_FREE_POSITION, false)
        set(value) = prefs.edit().putBoolean(KEY_TASK_OVERLAY_FREE_POSITION, value).apply()

    var taskOverlayX: Int
        get() = prefs.getInt(KEY_TASK_OVERLAY_X, -1)
        set(value) = prefs.edit().putInt(KEY_TASK_OVERLAY_X, value.coerceAtLeast(0)).apply()

    var taskOverlayY: Int
        get() = prefs.getInt(KEY_TASK_OVERLAY_Y, -1)
        set(value) = prefs.edit().putInt(KEY_TASK_OVERLAY_Y, value.coerceAtLeast(0)).apply()

    fun getSongPlayCounts(): MutableMap<String, Int> {
        val json = prefs.getString(KEY_SONG_COUNTS, null) ?: return mutableMapOf()
        return try {
            val type = object : TypeToken<MutableMap<String, Int>>() {}.type
            gson.fromJson(json, type) ?: mutableMapOf()
        } catch (e: Exception) {
            mutableMapOf()
        }
    }

    fun recordSongPlay(rawSong: String): String {
        val cleanSong = rawSong.trim()
        if (cleanSong.isBlank()) return favoriteSong

        val counts = getSongPlayCounts()
        val currentCount = counts.getOrDefault(cleanSong.lowercase(), 0) + 1
        counts[cleanSong.lowercase()] = currentCount

        // Update stored JSON
        prefs.edit().putString(KEY_SONG_COUNTS, gson.toJson(counts)).apply()

        // Auto-promote to favorite song if played at least 2 times, or if favoriteSong is empty
        val currentFav = favoriteSong
        if (currentFav.isBlank() || currentCount >= 2) {
            // Find most played song
            val topSong = counts.maxByOrNull { it.value }?.key
            if (!topSong.isNullOrBlank()) {
                favoriteSong = cleanSong
            }
        }
        return favoriteSong
    }

    fun loadChatHistory(): List<ChatTurn> {
        val json = prefs.getString(KEY_CHAT_HISTORY, null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<ChatTurn>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveChatHistory(history: List<ChatTurn>) {
        val json = gson.toJson(history)
        prefs.edit().putString(KEY_CHAT_HISTORY, json).apply()
    }

    fun clearChatHistory() {
        prefs.edit().remove(KEY_CHAT_HISTORY).apply()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/preferences/AppPreferences.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/preferences/YouTubePreferences.kt ===
```kotlin
package com.jarvis.assistant.data.preferences

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class YouTubePreferences(context: Context) {

    companion object {
        private const val TAG = "YouTubePreferences"
        private const val ENCRYPTED_FILE = "jarvis_youtube_secure_prefs"
        private const val FALLBACK_FILE = "jarvis_youtube_prefs"
        private const val KEY_YOUTUBE_API_KEY = "key_youtube_api_key"
        private const val KEY_YOUTUBE_ENABLED = "key_youtube_enabled"
    }

    private val legacyPrefs = context.getSharedPreferences(FALLBACK_FILE, Context.MODE_PRIVATE)
    private val securePrefs: SharedPreferences? = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            ENCRYPTED_FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        Log.e(TAG, "Encrypted YouTube API-key storage could not be initialized", e)
        null
    }

    init {
        migrateLegacyKey()
    }

    var youtubeApiKey: String
        get() = securePrefs?.getString(KEY_YOUTUBE_API_KEY, "") ?: ""
        set(value) {
            val secure = checkNotNull(securePrefs) { "Secure YouTube API-key storage is unavailable on this device." }
            val clean = value.trim()
            val saved = if (clean.isEmpty()) secure.edit().remove(KEY_YOUTUBE_API_KEY).commit()
            else secure.edit().putString(KEY_YOUTUBE_API_KEY, clean).commit()
            check(saved) { "Could not save YouTube API key to encrypted storage." }
        }

    var isYouTubeEnabled: Boolean
        get() = (securePrefs ?: legacyPrefs).getBoolean(KEY_YOUTUBE_ENABLED, true)
        set(value) = (securePrefs ?: legacyPrefs).edit().putBoolean(KEY_YOUTUBE_ENABLED, value).apply()

    private fun migrateLegacyKey() {
        val legacy = legacyPrefs.getString(KEY_YOUTUBE_API_KEY, null)?.trim().orEmpty()
        if (legacy.isEmpty()) return
        val secure = securePrefs ?: run {
            legacyPrefs.edit().remove(KEY_YOUTUBE_API_KEY).commit()
            return
        }
        try {
            if (secure.getString(KEY_YOUTUBE_API_KEY, null).isNullOrEmpty()) {
                check(secure.edit().putString(KEY_YOUTUBE_API_KEY, legacy).commit())
            }
            if (!secure.getString(KEY_YOUTUBE_API_KEY, null).isNullOrEmpty()) {
                legacyPrefs.edit().remove(KEY_YOUTUBE_API_KEY).commit()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Legacy YouTube API-key migration failed", e)
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/preferences/YouTubePreferences.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/data/repository/ChatRepository.kt ===
```kotlin
package com.jarvis.assistant.data.repository

import com.jarvis.assistant.data.model.ChatTurn
import com.jarvis.assistant.data.preferences.AppPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ChatRepository(private val preferences: AppPreferences) {

    private val _turns = MutableStateFlow<List<ChatTurn>>(emptyList())
    val turns: StateFlow<List<ChatTurn>> = _turns.asStateFlow()

    init {
        _turns.value = preferences.loadChatHistory()
    }

    @Synchronized
    fun addTurn(userText: String, jarvisText: String) {
        val cleanUser = userText.trim()
        val cleanJarvis = jarvisText.trim()

        if (cleanUser.isEmpty() && cleanJarvis.isEmpty()) return

        val currentList = _turns.value.toMutableList()

        if (currentList.isNotEmpty()) {
            val last = currentList.last()
            if (last.userTranscript == cleanUser && last.jarvisResponse == cleanJarvis) {
                return
            }
        }

        val newTurn = ChatTurn(
            userTranscript = cleanUser.ifEmpty { "(Audio query)" },
            jarvisResponse = cleanJarvis.ifEmpty { "(Audio response)" }
        )

        currentList.add(newTurn)
        if (currentList.size > 100) {
            currentList.removeAt(0)
        }

        _turns.value = currentList
        preferences.saveChatHistory(currentList)
    }

    @Synchronized
    fun clearHistory() {
        _turns.value = emptyList()
        preferences.clearChatHistory()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/data/repository/ChatRepository.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/network/GeminiLiveWebSocket.kt ===
```kotlin
package com.jarvis.assistant.network

import android.util.Base64
import android.util.Log
import com.jarvis.assistant.data.model.*
import kotlinx.coroutines.*
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class GeminiLiveWebSocket(
    private val apiKey: String,
    private val model: String,
    private val voiceName: String,
    private val systemPrompt: String,
    private val listener: Listener
) {
    interface Listener {
        fun onConnectionStateChanged(status: String)
        fun onAudioDataReceived(pcmData: ByteArray)
        fun onAssistantTextReceived(textChunk: String)
        fun onUserTextReceived(textChunk: String)
        fun onInterrupted()
        fun onTurnCompleted()
        fun onError(message: String, isFatal: Boolean = false, errorCode: String? = null)
        fun onToolCall(callId: String, name: String, args: JSONObject)
    }

    companion object {
        private const val TAG = "GeminiLiveWebSocket"
        // Shared OkHttpClient across all sessions — reuses connection pool, DNS cache, and TLS sessions
        private val sharedClient = OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .connectTimeout(5, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .pingInterval(60, TimeUnit.SECONDS)
            .build()
    }

    private val client = sharedClient

    private var activeModel: String = when (model) {
        GeminiConstants.MODEL_3_8_LIVE -> GeminiConstants.MODEL_3_8_LIVE
        GeminiConstants.MODEL_3_1_FLASH_AGENT -> GeminiConstants.MODEL_3_1_FLASH
        else -> if (model.isNotBlank() && !model.contains("2.5")) model else GeminiConstants.DEFAULT_MODEL
    }

    private var webSocket: WebSocket? = null
    private val isConnected = AtomicBoolean(false)
    private val isSetupComplete = AtomicBoolean(false)
    private val isManuallyStopped = AtomicBoolean(false)
    private var coroutineScope: CoroutineScope? = null

    private var sessionRenewalJob: Job? = null
    private var reconnectJob: Job? = null
    var promptProvider: (() -> String)? = null

    fun isSessionReady(): Boolean = isConnected.get() && isSetupComplete.get()

    fun connect(scope: CoroutineScope) {
        coroutineScope = scope
        isManuallyStopped.set(false)
        initiateConnection()
    }

    private fun initiateConnection() {
        if (apiKey.isBlank()) {
            Log.e(TAG, "Gemini API Key is empty. Aborting connection.")
            listener.onError("Gemini API Key is missing. Please configure it in Settings.", isFatal = true, errorCode = "API_KEY_MISSING")
            listener.onConnectionStateChanged("OFFLINE")
            return
        }

        listener.onConnectionStateChanged("CONNECTING...")

        try {
            val url = "${GeminiConstants.WS_BASE_URL}?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .build()

            webSocket = client.newWebSocket(request, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    Log.d(TAG, "WebSocket connected to Gemini Live. Sending BidiSetup...")
                    isConnected.set(true)
                    isSetupComplete.set(false)
                    listener.onConnectionStateChanged("CONFIGURING...")
                    // Send setup message FIRST before enabling audio streaming
                    sendSetupMessage(webSocket)
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    handleIncomingMessage(text)
                }

                override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                    handleIncomingMessage(bytes.utf8())
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    Log.d(TAG, "WebSocket closing: $code / $reason")
                    webSocket.close(1000, null)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    Log.d(TAG, "WebSocket closed: $code / $reason")
                    isConnected.set(false)
                    isSetupComplete.set(false)
                    stopTimers()

                    val isApiKeyError = reason.contains("API_KEY_INVALID", ignoreCase = true) ||
                                       reason.contains("API key not valid", ignoreCase = true) ||
                                       reason.contains("API key", ignoreCase = true) ||
                                       reason.contains("key invalid", ignoreCase = true)
                    if (isApiKeyError) {
                        Log.e(TAG, "Gemini rejected session due to invalid API key (code=$code, reason=$reason)")
                        listener.onError("Invalid API Key: Google rejected the key. Please verify your Gemini API key in Settings.", isFatal = true, errorCode = "API_KEY_INVALID")
                        listener.onConnectionStateChanged("ERROR • INVALID KEY")
                        return
                    }

                    val isQuotaError = reason.contains("RESOURCE_EXHAUSTED", ignoreCase = true) ||
                                       reason.contains("quota", ignoreCase = true)
                    if (isQuotaError) {
                        Log.w(TAG, "Gemini rate-limited or connection collision (code=$code, reason=$reason). Retrying in cooldown...")
                        listener.onConnectionStateChanged("COOLDOWN • RETRYING")
                        scheduleReconnect()
                        return
                    }

                    if (code == 1008) {
                        val isModelError = reason.contains("BidiGenerateContent", ignoreCase = true) ||
                                           reason.contains("not found", ignoreCase = true) ||
                                           reason.contains("not supported", ignoreCase = true)
                        if (isModelError) {
                            if (activeModel != GeminiConstants.MODEL_3_8_LIVE) {
                                Log.w(TAG, "Model $activeModel rejected by Gemini ($reason). Auto-falling back to ${GeminiConstants.MODEL_3_8_LIVE}")
                                activeModel = GeminiConstants.MODEL_3_8_LIVE
                                listener.onConnectionStateChanged("RECONNECTING...")
                                scheduleReconnect()
                                return
                            }
                        }
                        listener.onError("Gemini setup was rejected: $reason", isFatal = true, errorCode = "SETUP_REJECTED")
                        listener.onConnectionStateChanged("OFFLINE")
                    } else if (!isManuallyStopped.get()) {
                        listener.onConnectionStateChanged("RECONNECTING...")
                        scheduleReconnect()
                    } else {
                        listener.onConnectionStateChanged("OFFLINE")
                    }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    val code = response?.code ?: 0
                    val responseBody = try { response?.body?.string() } catch (_: Exception) { null }
                    val errorMsg = t.message ?: "WebSocket connection failure"
                    Log.e(TAG, "WebSocket failure: code=$code, errorMsg=$errorMsg, body=$responseBody", t)
                    isConnected.set(false)
                    isSetupComplete.set(false)
                    stopTimers()

                    val isApiKeyError = code == 400 || code == 401 || code == 403 ||
                            errorMsg.contains("400") || errorMsg.contains("403") || errorMsg.contains("401") ||
                            errorMsg.contains("API_KEY_INVALID", ignoreCase = true) ||
                            errorMsg.contains("API key not valid", ignoreCase = true) ||
                            (responseBody?.contains("API_KEY_INVALID", ignoreCase = true) == true) ||
                            (responseBody?.contains("API key not valid", ignoreCase = true) == true)

                    val isQuotaError = code == 429 ||
                            errorMsg.contains("429") ||
                            errorMsg.contains("RESOURCE_EXHAUSTED", ignoreCase = true) ||
                            errorMsg.contains("quota", ignoreCase = true) ||
                            (responseBody?.contains("RESOURCE_EXHAUSTED", ignoreCase = true) == true)

                    if (isApiKeyError) {
                        Log.e(TAG, "Fatal failure: Invalid API Key (HTTP $code: $errorMsg)")
                        listener.onError("Invalid API Key: Google rejected the key. Please verify your Gemini API key in Settings.", isFatal = true, errorCode = "API_KEY_INVALID")
                        listener.onConnectionStateChanged("ERROR • INVALID KEY")
                        return
                    }

                    if (isQuotaError) {
                        Log.w(TAG, "Quota / rate limit hit (HTTP $code: $errorMsg). Retrying in cooldown...")
                        listener.onConnectionStateChanged("COOLDOWN • RETRYING")
                        scheduleReconnect()
                        return
                    }

                    if (!isManuallyStopped.get()) {
                        listener.onError("Connection lost: $errorMsg. Retrying...", isFatal = false, errorCode = "CONNECTION_ERROR")
                        scheduleReconnect()
                    } else {
                        listener.onConnectionStateChanged("OFFLINE")
                    }
                }
            })
        } catch (e: Exception) {
            Log.e(TAG, "Error initiating WebSocket connection: ${e.message}", e)
            listener.onError("Connection failed: ${e.message}", isFatal = true, errorCode = "CONNECTION_FAILED")
            listener.onConnectionStateChanged("OFFLINE")
        }
    }

    private fun sendSetupMessage(ws: WebSocket) {
        val effectivePrompt = systemPrompt
        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", activeModel)
                put("system_instruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", effectivePrompt)))
                })
                put("generation_config", JSONObject().apply {
                    put("response_modalities", JSONArray().put("AUDIO"))
                    put("speech_config", JSONObject().apply {
                        put("voice_config", JSONObject().apply {
                            put("prebuilt_voice_config", JSONObject().apply {
                                put("voice_name", voiceName)
                            })
                        })
                    })
                    put("temperature", 0.6)
                    // Gemini 2.5 Flash native audio has thinking enabled by default (budget=2048),
                    // which causes a 2-3 second delay before generating speech.
                    // Setting thinking_budget to 0 disables chain-of-thought, yielding instant (<1s) conversational response.
                    if (activeModel.contains("2.5")) {
                        put("thinking_config", JSONObject().apply {
                            put("thinking_budget", 0)
                        })
                    }
                })
                put("tools", JSONArray().put(JSONObject().apply {
                    put("functionDeclarations", JSONArray().apply {
                        // 1. open_app
                        put(JSONObject().apply {
                            put("name", "open_app")
                            put("description", "Opens an app installed on the user's phone, e.g. YouTube, WhatsApp, Camera, Settings. If multiple instances exist, app_number specifies 1 or 2.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("app_name", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "The name of the app to open (e.g. \"YouTube\", \"WhatsApp\", \"Instagram\").")
                                    })
                                    put("app_number", JSONObject().apply {
                                        put("type", "INTEGER")
                                        put("description", "Optional 1-based index (1 or 2) when opening a dual/cloned app instance.")
                                    })
                                })
                                put("required", JSONArray().put("app_name"))
                            })
                        })

                        // 2. open_website
                        put(JSONObject().apply {
                            put("name", "open_website")
                            put("description", "Opens one or more websites/URLs in Google Chrome in separate tabs. Use whenever the user asks to open a website, visit a URL, or open multiple websites/URLs in different tabs (e.g. \"open github.com and names21st.dev in different tabs\", \"open website google.com\", \"open vercel.com\").")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("urls", JSONObject().apply {
                                        put("type", "ARRAY")
                                        put("description", "Array of website URLs or domain names to open, each in its own tab (e.g. [\"github.com\", \"names21st.dev\"]).")
                                        put("items", JSONObject().apply { put("type", "STRING") })
                                    })
                                    put("query", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Optional string containing the website URL(s) or query.")
                                    })
                                })
                            })
                        })

                        // 3. search_in_chrome
                        put(JSONObject().apply {
                            put("name", "search_in_chrome")
                            put("description", "Opens Google Chrome and searches for a topic/question, or opens a website URL in a tab (e.g. \"search xyz in Chrome\", \"google xyz\").")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("query", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Query or topic to search in Google Chrome, or website URL.")
                                    })
                                })
                                put("required", JSONArray().put("query"))
                            })
                        })

                        // 4. search_and_play_youtube
                        put(JSONObject().apply {
                            put("name", "search_and_play_youtube")
                            put("description", "Searches YouTube and IMMEDIATELY OPENS AND PLAYS the requested video or song. Use whenever the user directly commands you to PLAY a video or song (e.g. \"play Tum Hi Ho\", \"play Believer on YouTube\", \"play XYZ song or youtube\", \"YouTube pe Arijit Singh chalao\", \"Jarvis video play karo\"). CRITICAL RULE: If the user says 'play', ALWAYS use search_and_play_youtube, NEVER use search_youtube. STRICT PROHIBITION: NEVER use this tool when the user is casually conversing or humming without an explicit play command.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("query", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "What video/song to search for and immediately play, e.g. \"Tum Hi Ho Arijit Singh\".")
                                    })
                                })
                                put("required", JSONArray().put("query"))
                            })
                        })

                        // 5. search_youtube
                        put(JSONObject().apply {
                            put("name", "search_youtube")
                            put("description", "Opens YouTube and searches for a topic/query, displaying the SEARCH RESULTS SCREEN ONLY WITHOUT auto-playing or tapping any video. Use ONLY when the user explicitly asks to SEARCH on YouTube without asking to play (e.g. \"search this on YouTube\", \"YouTube pe search karo xyz\", \"search Python tutorial on YouTube\"). NEVER use this tool when the user says to play a video or song.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("query", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "The query/topic to search on YouTube, e.g. \"Python tutorial\", \"latest news\".")
                                    })
                                })
                                put("required", JSONArray().put("query"))
                            })
                        })

                        // 6. youtube_accessibility_action
                        put(JSONObject().apply {
                            put("name", "youtube_accessibility_action")
                            put("description", "Performs an in-app YouTube action using accessibility: skipping an ad ('skip_ad'), liking the video ('like'), subscribing to the channel ('subscribe'), opening the channel ('open_channel'), or toggling fullscreen ('fullscreen').")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("action", JSONObject().apply {
                                        put("type", "STRING")
                                        put("enum", JSONArray().apply {
                                            put("skip_ad"); put("like"); put("subscribe"); put("open_channel"); put("fullscreen"); put("click_first")
                                        })
                                    })
                                })
                                put("required", JSONArray().put("action"))
                            })
                        })

                        // 7. media_playback_control
                        put(JSONObject().apply {
                            put("name", "media_playback_control")
                            put("description", "Controls whatever video/audio is currently playing (e.g. YouTube): play, pause, next, previous, stop.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("action", JSONObject().apply {
                                        put("type", "STRING")
                                        put("enum", JSONArray().apply {
                                            put("play"); put("pause"); put("next"); put("previous"); put("stop")
                                        })
                                    })
                                })
                                put("required", JSONArray().put("action"))
                            })
                        })

                        // 8. send_whatsapp_message
                        put(JSONObject().apply {
                            put("name", "send_whatsapp_message")
                            put("description", "Opens WhatsApp and queues sending a text to a named contact (e.g. \"message Rahul that I will be late\"). The tool response distinguishes opening/queuing from a verified send; inspect the current chat before claiming the message was sent. If 2 WhatsApp apps exist and app_number is not specified, ask the user which one.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("recipient_name", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Name of the contact as spoken by the user (e.g. \"Rahul\", \"Priya\", \"Dad\").")
                                    })
                                    put("message", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "The text message content to send to the recipient.")
                                    })
                                    put("app_number", JSONObject().apply {
                                        put("type", "INTEGER")
                                        put("description", "Optional 1-based index (1 or 2) if dual WhatsApp is installed.")
                                    })
                                    put("confirmed", JSONObject().apply {
                                        put("type", "BOOLEAN")
                                        put("description", "True if user already confirmed sending.")
                                    })
                                })
                                put("required", JSONArray().apply { put("recipient_name"); put("message") })
                            })
                        })

                        // 9. whatsapp_call
                        put(JSONObject().apply {
                            put("name", "whatsapp_call")
                            put("description", "Initiates a WhatsApp voice call or WhatsApp video call to a contact (e.g. \"WhatsApp call Mom\", \"WhatsApp video call Rahul\").")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("recipient_name", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Name of the contact to call as spoken by the user.")
                                    })
                                    put("call_type", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "\"voice\" for voice call or \"video\" for video call.")
                                    })
                                    put("app_number", JSONObject().apply {
                                        put("type", "INTEGER")
                                        put("description", "Optional 1-based index (1 or 2) if dual WhatsApp is installed.")
                                    })
                                    put("confirmed", JSONObject().apply {
                                        put("type", "BOOLEAN")
                                        put("description", "True if user already confirmed calling.")
                                    })
                                })
                                put("required", JSONArray().apply { put("recipient_name"); put("call_type") })
                            })
                        })

                        // 10. call_contact
                        put(JSONObject().apply {
                            put("name", "call_contact")
                            put("description", "Places a standard phone call to a saved contact by spoken name, e.g. \"call mom\", \"call Rahul\", \"phone Dad\".")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("contact_name", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "The contact's name as the user said it, e.g. \"mom\", \"Rahul\".")
                                    })
                                })
                                put("required", JSONArray().put("contact_name"))
                            })
                        })

                        // 11. set_volume
                        put(JSONObject().apply {
                            put("name", "set_volume")
                            put("description", "Adjusts media volume on device. Supports relative commands ('increase', 'decrease') or exact level ('set').")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("action", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Action to perform: 'increase', 'decrease', or 'set'.")
                                    })
                                    put("percentage", JSONObject().apply {
                                        put("type", "INTEGER")
                                        put("description", "Target percentage level from 0 to 100 if specified.")
                                    })
                                })
                                put("required", JSONArray().put("action"))
                            })
                        })

                        // 12. set_brightness
                        put(JSONObject().apply {
                            put("name", "set_brightness")
                            put("description", "Adjusts screen brightness on device. Supports relative commands ('increase', 'decrease') or exact level ('set').")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("action", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Action to perform: 'increase', 'decrease', or 'set'.")
                                    })
                                    put("percentage", JSONObject().apply {
                                        put("type", "INTEGER")
                                        put("description", "Target percentage level from 0 to 100 if specified.")
                                    })
                                })
                                put("required", JSONArray().put("action"))
                            })
                        })

                        // 13. builtin_chrome_search
                        put(JSONObject().apply {
                            put("name", "builtin_chrome_search")
                            put("description", "Performs invisible, background web research using JARVIS's built-in Chrome engine. Use whenever the user asks a question, topic, real-time factual query, news, weather, or live information that you don't know off-hand.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("query", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Search query or topic to look up on the web.")
                                    })
                                })
                                put("required", JSONArray().put("query"))
                            })
                        })

                        // 14. go_to_background
                        put(JSONObject().apply {
                            put("name", "go_to_background")
                            put("description", "Sends JARVIS to the background, minimizes the app to the home screen, and enters standby wake-word listening. Use immediately whenever user says 'go to background', 'go background', 'minimize', 'close', 'background me jao', 'go to home screen', 'go to sleep', or 'enter standby'.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject())
                            })
                        })

                        // 15. set_flashlight
                        put(JSONObject().apply {
                            put("name", "set_flashlight")
                            put("description", "Turns the phone's torch or flashlight on or off. ALWAYS call this tool unconditionally whenever the user commands to turn on, enable, turn off, or disable the torch/flashlight (e.g. \"turn on flash lite\", \"turn on flashlight\", \"turn off flashlight\", \"torch on\", \"torch off\", \"torch chalu karo\", \"torch band karo\"). NEVER claim it is already on or off without calling this tool.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("enabled", JSONObject().apply {
                                        put("type", "BOOLEAN")
                                        put("description", "True to turn on the torch/flashlight, false to turn it off.")
                                    })
                                })
                                put("required", JSONArray().put("enabled"))
                            })
                        })

                        // 16. click_ui_element
                        put(JSONObject().apply {
                            put("name", "click_ui_element")
                            put("description", "Clicks or toggles a specific UI button, switch, link, icon, tab, or element. Prefer a unique current element_id or target_name. When Screen Share is active, normalized coordinates x/y (0-1000) may be used for a clearly visible unlabeled target; the tool checks the hit target and returns whether a screen change was verified. Never treat a dispatched gesture alone as proof of success.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("target_name", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Label, text, icon name, or description of the UI element to click (e.g., 'Generate', 'Arrow', 'Video', 'Search', 'Install').")
                                    })
                                    put("x", JSONObject().apply {
                                        put("type", "INTEGER")
                                        put("description", "Normalized X coordinate (0-1000) of the visual center of the element on screen.")
                                    })
                                    put("y", JSONObject().apply {
                                        put("type", "INTEGER")
                                        put("description", "Normalized Y coordinate (0-1000) of the visual center of the element on screen.")
                                    })
                                    put("element_id", JSONObject().apply {
                                        put("type", "INTEGER")
                                        put("description", "Optional 1-based element ID if known from current screen state summary.")
                                    })
                                    put("is_toggle", JSONObject().apply {
                                        put("type", "BOOLEAN")
                                        put("description", "True if flipping a toggle switch or checkbox.")
                                    })
                                    put("description", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Additional visual context.")
                                    })
                                })
                                put("required", JSONArray().put("target_name"))
                            })
                        })

                        // 17. type_text
                        put(JSONObject().apply {
                            put("name", "type_text")
                            put("description", "Types text into a grounded input field. The result is successful only when the text is read back from the target; a clipboard paste or dispatched gesture alone is not proof. For Google Flow, use the named prompt field or, only with a confirmed live Screen Share frame, current normalized x/y coordinates of the visible prompt box. Never report text entered unless success=true and verified=true.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("text", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "The exact text query or prompt to type.")
                                    })
                                    put("x", JSONObject().apply {
                                        put("type", "INTEGER")
                                        put("description", "Normalized X coordinate (0-1000) of the text box center on screen.")
                                    })
                                    put("y", JSONObject().apply {
                                        put("type", "INTEGER")
                                        put("description", "Normalized Y coordinate (0-1000) of the text box center on screen.")
                                    })
                                    put("target_input_name", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Optional name or hint of the input field (e.g., 'What do you want to create', 'Search').")
                                    })
                                    put("submit", JSONObject().apply {
                                        put("type", "BOOLEAN")
                                        put("description", "Whether to submit or press enter after typing.")
                                    })
                                })
                                put("required", JSONArray().put("text"))
                            })
                        })

                        // 18. scroll_screen
                        put(JSONObject().apply {
                            put("name", "scroll_screen")
                            put("description", "Scrolls the active screen in a given direction to reveal elements that are offscreen. Supports gentle line-by-line scrolling for inspecting photos and lists.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("direction", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Direction to scroll: 'down', 'up', 'left', or 'right'.")
                                    })
                                    put("distance", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Optional scroll distance: 'small' (gentle line-by-line scroll, moves 1-2 rows at a time with zero fling, mandatory for browsing photos and documents), 'medium' (half screen), or 'large' (full page). Defaults to 'small'.")
                                    })
                                })
                                put("required", JSONArray().put("direction"))
                            })
                        })

                        // 19. press_key
                        put(JSONObject().apply {
                            put("name", "press_key")
                            put("description", "Executes system-level navigation gestures: 'back', 'home', or 'recents'.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("key", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "The system action: 'back', 'home', or 'recents'.")
                                    })
                                })
                                put("required", JSONArray().put("key"))
                            })
                        })

                        // 20. task_completed
                        put(JSONObject().apply {
                            put("name", "task_completed")
                            put("description", "Call this tool only after the user's requested task is visibly confirmed complete. Do not call it right after typing into a search bar; when searching for a chat or file, first open the matching result and verify the resulting screen.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("summary", JSONObject().apply {
                                        put("type", "STRING")
                                        put("description", "Brief summary of what was completed (e.g., 'Opened Bharat's chat on Telegram.').")
                                    })
                                })
                                put("required", JSONArray().put("summary"))
                            })
                        })

                        // 21. inspect_screen
                        put(JSONObject().apply {
                            put("name", "inspect_screen")
                            put("description", "Reads the foreground app, screen title, and accessible UI elements (text, buttons, tabs). This tool returns accessibility text, not a visual image. Only claim live visual access when Screen Share is confirmed active and a recent captured frame has been received. Call when you need current accessible labels or element IDs before interacting, or when the user asks about screen content. Do not use for normal conversation.")
                            put("parameters", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject())
                            })
                        })


                    })
                }))
            })
        }
        val json = setup.toString()
        Log.d(TAG, "Sending BidiSetup payload to Gemini Live with tools")
        ws.send(json)
    }

    private fun handleIncomingMessage(jsonText: String) {
        try {
            val json = JSONObject(jsonText)

            // Check if server returned an error payload
            if (json.has("error")) {
                val errObj = json.optJSONObject("error")
                val errMsg = errObj?.optString("message", "") ?: json.optString("error", "Unknown error")
                val errCode = errObj?.optInt("code", 0) ?: 0
                Log.e(TAG, "Server returned error: code=$errCode, message=$errMsg")
                val isApiKey = errMsg.contains("API_KEY_INVALID", ignoreCase = true) ||
                               errMsg.contains("API key not valid", ignoreCase = true) ||
                               errCode == 400 || errCode == 403
                val isQuota = errMsg.contains("RESOURCE_EXHAUSTED", ignoreCase = true) ||
                              errMsg.contains("quota", ignoreCase = true) ||
                              errCode == 429
                if (isApiKey) {
                    listener.onError("Invalid API Key: $errMsg", isFatal = true, errorCode = "API_KEY_INVALID")
                    listener.onConnectionStateChanged("ERROR • INVALID KEY")
                } else if (isQuota) {
                    listener.onError("API Quota Exceeded: $errMsg", isFatal = true, errorCode = "QUOTA_EXCEEDED")
                    listener.onConnectionStateChanged("ERROR • QUOTA EXCEEDED")
                } else {
                    listener.onError("Gemini Error ($errCode): $errMsg", isFatal = false)
                }
                return
            }

            // 0. Server setupComplete handshake acknowledgment
            if (json.has("setupComplete")) {
                Log.i(TAG, "Server acknowledged setup: setupComplete received. Session is now LIVE!")
                if (!isSetupComplete.getAndSet(true)) {
                    listener.onConnectionStateChanged("LIVE")
                    startSessionRenewal()
                }
                return
            }

            // Ensure session is marked ready if server sends content before explicit setupComplete
            if (!isSetupComplete.get() && (json.has("serverContent") || json.has("toolCall"))) {
                isSetupComplete.set(true)
                listener.onConnectionStateChanged("LIVE")
                startSessionRenewal()
            }

            // 1. Top-level toolCall
            val topToolCall = json.optJSONObject("toolCall")
            if (topToolCall != null) {
                val functionCalls = topToolCall.optJSONArray("functionCalls")
                if (functionCalls != null) {
                    for (i in 0 until functionCalls.length()) {
                        val call = functionCalls.getJSONObject(i)
                        val name = call.optString("name", "")
                        val id = call.optString("id", "")
                        val args = call.optJSONObject("args") ?: JSONObject()
                        if (name.isNotEmpty()) {
                            Log.i(TAG, "Gemini invoked toolCall: $name (id=$id)")
                            listener.onToolCall(id, name, args)
                        }
                    }
                }
                return
            }

            // 2. serverContent
            val serverContent = json.optJSONObject("serverContent")
            if (serverContent != null) {
                val scToolCall = serverContent.optJSONObject("toolCall")
                if (scToolCall != null) {
                    val functionCalls = scToolCall.optJSONArray("functionCalls")
                    if (functionCalls != null) {
                        for (i in 0 until functionCalls.length()) {
                            val call = functionCalls.getJSONObject(i)
                            val name = call.optString("name", "")
                            val id = call.optString("id", "")
                            val args = call.optJSONObject("args") ?: JSONObject()
                            if (name.isNotEmpty()) {
                                Log.i(TAG, "Gemini invoked toolCall (serverContent): $name (id=$id)")
                                listener.onToolCall(id, name, args)
                            }
                        }
                    }
                }

                val inputTrans = serverContent.optJSONObject("inputTranscription")
                if (inputTrans != null) {
                    var userText = inputTrans.optString("text", "").trim()
                    if (userText.isEmpty()) {
                        val parts = inputTrans.optJSONArray("parts")
                        if (parts != null) {
                            val sb = StringBuilder()
                            for (p in 0 until parts.length()) {
                                val pObj = parts.optJSONObject(p)
                                sb.append(pObj?.optString("text", "") ?: "")
                            }
                            userText = sb.toString().trim()
                        }
                    }
                    if (userText.isNotBlank()) {
                        listener.onUserTextReceived(userText)
                    }
                }

                var hasOutputTranscriptionText = false
                val outputTrans = serverContent.optJSONObject("outputTranscription")
                if (outputTrans != null) {
                    var outText = outputTrans.optString("text", "")
                    if (outText.isEmpty()) {
                        val parts = outputTrans.optJSONArray("parts")
                        if (parts != null) {
                            val sb = StringBuilder()
                            for (p in 0 until parts.length()) {
                                val pObj = parts.optJSONObject(p)
                                sb.append(pObj?.optString("text", "") ?: "")
                            }
                            outText = sb.toString()
                        }
                    }
                    if (outText.isNotEmpty()) {
                        hasOutputTranscriptionText = true
                        listener.onAssistantTextReceived(outText)
                    }
                }

                if (serverContent.optBoolean("interrupted", false)) {
                    Log.d(TAG, "Server signaled turn interrupted")
                    listener.onInterrupted()
                }

                val modelTurn = serverContent.optJSONObject("modelTurn")
                if (modelTurn != null) {
                    val parts = modelTurn.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val part = parts.getJSONObject(i)
                            // Filter out internal thinking/reasoning parts (Gemini 2.5 thinking tokens)
                            val isThought = part.optBoolean("thought", false)
                            if (isThought) {
                                Log.d(TAG, "Suppressed model thought part: ${part.optString("text").take(40)}")
                                continue
                            }
                            val text = part.optString("text", "")
                            val isThinkingLeak = text.startsWith("**") && (
                                    text.contains("thinking", ignoreCase = true) ||
                                    text.contains("crafting", ignoreCase = true) ||
                                    text.contains("formulating", ignoreCase = true) ||
                                    text.contains("acknowledge", ignoreCase = true) ||
                                    text.contains("inquire", ignoreCase = true) ||
                                    text.contains("greeting", ignoreCase = true)
                            )
                            if (text.isNotEmpty() && !isThinkingLeak && !hasOutputTranscriptionText) {
                                listener.onAssistantTextReceived(text)
                            }

                            val inlineData = part.optJSONObject("inlineData")
                            if (inlineData != null) {
                                val base64Data = inlineData.optString("data", "")
                                if (base64Data.length > 8) {
                                    val pcmBytes = Base64.decode(base64Data, Base64.DEFAULT)
                                    if (pcmBytes.size >= 16) {
                                        val validLen = pcmBytes.size and 1.inv()
                                        val aligned = if (validLen == pcmBytes.size) pcmBytes else pcmBytes.copyOf(validLen)
                                        listener.onAudioDataReceived(aligned)
                                    }
                                }
                            }
                        }
                    }
                }

                val isTurnDone = serverContent.optBoolean("turnComplete", false) ||
                                 serverContent.optBoolean("generationComplete", false) ||
                                 serverContent.optBoolean("endOfTurn", false)
                if (isTurnDone) {
                    Log.d(TAG, "Server signaled turnComplete/generationComplete")
                    listener.onTurnCompleted()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing incoming server JSON: ${e.message}", e)
        }
    }

    fun sendToolResponse(callId: String, functionName: String, result: JSONObject) {
        try {
            val msg = JSONObject().apply {
                put("tool_response", JSONObject().apply {
                    put("function_responses", JSONArray().put(JSONObject().apply {
                        put("id", callId)
                        put("name", functionName)
                        put("response", result)
                    }))
                })
            }
            webSocket?.send(msg.toString())
            Log.d(TAG, "Sent tool_response for $functionName: $result")
        } catch (e: Exception) {
            Log.e(TAG, "sendToolResponse failed: ${e.message}", e)
        }
    }

    fun sendAudioChunk(pcm16k: ByteArray) {
        if (!isConnected.get() || !isSetupComplete.get() || pcm16k.isEmpty()) return

        try {
            val base64Audio = Base64.encodeToString(pcm16k, Base64.NO_WRAP)
            val json = "{\"realtimeInput\":{\"audio\":{\"mimeType\":\"audio/pcm;rate=16000\",\"data\":\"$base64Audio\"}}}"
            webSocket?.send(json)
        } catch (e: Exception) {
            Log.e(TAG, "Error sending audio chunk: ${e.message}")
        }
    }

    private var mediaChunksSent = 0
    private val lastVideoFrameSentAt = AtomicLong(0L)

    /**
     * Streams real-time screen frames to Gemini Live (BidiGenerateContent).
     */
    fun sendMediaChunk(jpegBytes: ByteArray) {
        if (!isConnected.get() || !isSetupComplete.get() || jpegBytes.isEmpty()) return
        // Gemini Live accepts video as a continuous realtimeInput stream at up to 1 FPS.
        // Enforce the cap here so periodic and post-action frames share one rate limiter.
        val now = android.os.SystemClock.elapsedRealtime()
        while (true) {
            val previous = lastVideoFrameSentAt.get()
            if (now - previous < 1000L) return
            if (lastVideoFrameSentAt.compareAndSet(previous, now)) break
        }
        try {
            val base64Image = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
            val json = "{\"realtimeInput\":{\"video\":{\"mimeType\":\"image/jpeg\",\"data\":\"$base64Image\"}}}"
            val sent = webSocket?.send(json) ?: false
            mediaChunksSent++
            if (mediaChunksSent % 10 == 1) {
                Log.i(TAG, "Sent video frame #$mediaChunksSent to Gemini Live (sent=$sent, size=${jpegBytes.size / 1024} KB)")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error sending media chunk: ${e.message}")
        }
    }

    /**
     * In Gemini Live BidiGenerateContent, streaming audio via realtimeInput handles turn-taking
     * natively via server-side neural VAD. Sending empty client_content cancels active generation.
     */
    fun sendAudioStreamEnd() {
        // No-op: server-side VAD handles turn completion smoothly
    }

    /**
     * Sends a text prompt to Gemini Live using the client_content turn protocol.
     */
    fun sendClientContent(text: String) {
        if (!isConnected.get() || !isSetupComplete.get() || text.isBlank()) return
        try {
            val msg = JSONObject().apply {
                put("client_content", JSONObject().apply {
                    put("turns", JSONArray().put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().put(JSONObject().apply {
                            put("text", text)
                        }))
                    }))
                    put("turn_complete", true)
                })
            }
            webSocket?.send(msg.toString())
            Log.d(TAG, "Sent client_content: $text")
        } catch (e: Exception) {
            Log.e(TAG, "sendClientContent failed: ${e.message}", e)
        }
    }

    private fun startSessionRenewal() {
        sessionRenewalJob?.cancel()
        sessionRenewalJob = coroutineScope?.launch(Dispatchers.IO) {
            delay(GeminiConstants.SESSION_RENEWAL_MS)
            if (isActive && !isManuallyStopped.get()) {
                Log.d(TAG, "9-minute session threshold reached. Seamlessly renewing session...")
                webSocket?.close(1000, "Session renewal")
            }
        }
    }

    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        reconnectJob = coroutineScope?.launch(Dispatchers.IO) {
            delay(500)
            if (!isManuallyStopped.get()) {
                Log.d(TAG, "Attempting auto-reconnect...")
                initiateConnection()
            }
        }
    }

    private fun stopTimers() {
        sessionRenewalJob?.cancel()
        sessionRenewalJob = null
    }

    fun disconnect() {
        isManuallyStopped.set(true)
        stopTimers()
        reconnectJob?.cancel()
        reconnectJob = null
        isConnected.set(false)

        try {
            webSocket?.close(1000, "Client stopped session")
        } catch (e: Exception) {
            Log.e(TAG, "Error closing webSocket: ${e.message}")
        } finally {
            webSocket = null
        }
        listener.onConnectionStateChanged("OFFLINE")
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/network/GeminiLiveWebSocket.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/security/AppIdentityVerifier.kt ===
```kotlin
package com.jarvis.assistant.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.jarvis.assistant.BuildConfig
import java.security.MessageDigest

/** Local identity check. Remote publisher verification still requires the configured HTTPS service. */
object AppIdentityVerifier {
    fun currentSignerSha256(context: Context): List<String> = runCatching {
        val packageManager = context.packageManager
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                .signingInfo?.apkContentsSigners.orEmpty()
        } else {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures.orEmpty()
        }
        signatures.map { signature ->
            MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())
                .joinToString("") { byte -> "%02X".format(byte) }
        }.distinct().sorted()
    }.getOrDefault(emptyList())

    fun isTrustedRelease(context: Context): Boolean {
        if (BuildConfig.DEBUG) return true
        val expected = BuildConfig.PINNED_RELEASE_CERT_SHA256
            .split(',', ';', '\n')
            .map { it.filter(Char::isLetterOrDigit).uppercase() }
            .filter { it.length == 64 }
            .toSet()
        if (expected.isEmpty()) return false
        return currentSignerSha256(context).any { it in expected }
    }

    fun report(context: Context): String {
        val signers = currentSignerSha256(context).ifEmpty { listOf("Unavailable") }
        val localSignature = if (BuildConfig.DEBUG) "Debug build (not publisher verified)"
        else if (isTrustedRelease(context)) "Matches the pinned release certificate"
        else "NOT VERIFIED — release certificate pin missing or mismatched"
        val remote = if (BuildConfig.VERIFICATION_ENDPOINT.startsWith("https://")) {
            "Endpoint configured, but this build does not yet implement a remote verification protocol"
        } else "Remote publisher verification is not configured"
        return buildString {
            appendLine("Developer: ${BuildConfig.DEVELOPER_NAME}")
            appendLine("Copyright: ${BuildConfig.COPYRIGHT_OWNER}")
            appendLine("Official application ID: ${context.packageName}")
            appendLine("Current signing certificate SHA-256:")
            signers.forEach(::appendLine)
            appendLine("Local signature status: $localSignature")
            append("Server status: $remote")
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/security/AppIdentityVerifier.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/security/DeveloperInfo.kt ===
```kotlin
package com.jarvis.assistant.security

/**
 * Permanent Developer Identity — Tech GPTx
 * TAMCL v1.0 License: Content creators MUST credit Tech GPTx in any video using this code.
 */
object DeveloperInfo {
    const val DEVELOPER_NAME      = "Tech GPTx"
    const val COPYRIGHT_YEAR      = "2026"
    const val COPYRIGHT_NOTICE    = "© 2026 Tech GPTx. All Rights Reserved."
    const val GITHUB_URL          = "https://github.com/techgptx/Playlist"
    const val LICENSE             = "TAMCL v1.0"
    const val LICENSE_DETAIL      = "Content creators MUST credit Tech GPTx in any video using this code."
    const val APP_OFFICIAL_ID     = "com.jarvis.assistant"
    const val VERIFIED_DEVELOPER  = "Tech GPTx — Official JARVIS Tutorial Series"
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/security/DeveloperInfo.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/security/SecurityManager.kt ===
```kotlin
package com.jarvis.assistant.security

import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest
import kotlin.system.exitProcess

/**
 * JARVIS ASSISTANT — SECURITY MODULE
 * Developer       : Tech GPTx
 * Copyright © 2026: Tech GPTx. All Rights Reserved.
 * GitHub          : https://github.com/techgptx/Playlist
 */
object SecurityManager {

    const val DEVELOPER_NAME    = "Tech GPTx"
    const val COPYRIGHT_NOTICE  = "Copyright © 2026 Tech GPTx. All Rights Reserved."
    const val GITHUB_REPO       = "https://github.com/techgptx/Playlist"
    const val LICENSE_NAME      = "TAMCL v1.0 — Content creators MUST credit Tech GPTx"

    private const val EXPECTED_PACKAGE = "com.jarvis.assistant"

    fun verify(context: Context) {
        checkPackageName(context)
    }

    private fun checkPackageName(context: Context) {
        if (context.packageName != EXPECTED_PACKAGE) {
            showTamperAlert(
                context,
                "Clone Detected",
                "This is an unauthorised clone of the JARVIS app by $DEVELOPER_NAME.\n\n" +
                "Original: $EXPECTED_PACKAGE\n" +
                "Found   : ${context.packageName}\n\n" +
                "The app will now close. Please download the official version from:\n$GITHUB_REPO"
            )
        }
    }

    @Suppress("unused")
    private fun checkSignature(context: Context) {
        val EXPECTED_SHA256 = "PASTE_YOUR_APK_SHA256_FINGERPRINT_HERE"

        val actual = getApkSignatureSha256(context) ?: run {
            showTamperAlert(context, "Verification Failed", "Unable to verify app authenticity. Closing.")
            return
        }
        if (!actual.equals(EXPECTED_SHA256, ignoreCase = true)) {
            showTamperAlert(
                context,
                "Tampered APK Detected",
                "This APK has been re-signed or modified.\n\n" +
                "$DEVELOPER_NAME only distributes APKs signed with the original certificate.\n\n" +
                "Download the official APK from:\n$GITHUB_REPO"
            )
        }
    }

    private fun getApkSignatureSha256(context: Context): String? {
        return try {
            val sigs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = context.packageManager.getPackageInfo(
                    context.packageName, PackageManager.GET_SIGNING_CERTIFICATES
                )
                info.signingInfo?.apkContentsSigners
            } else {
                @Suppress("DEPRECATION")
                val info = context.packageManager.getPackageInfo(
                    context.packageName, PackageManager.GET_SIGNATURES
                )
                info.signatures
            }
            val firstSig = sigs?.firstOrNull() ?: return null
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(firstSig.toByteArray())
            digest.joinToString(":") { "%02X".format(it) }
        } catch (e: Exception) {
            null
        }
    }

    private fun showTamperAlert(context: Context, title: String, message: String) {
        try {
            AlertDialog.Builder(context)
                .setTitle("⚠️ $title")
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK") { _, _ -> exitProcess(1) }
                .show()
        } catch (_: Exception) {
            exitProcess(1)
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/security/SecurityManager.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/agent/TaskProgressOverlay.kt ===
```kotlin
package com.jarvis.assistant.ui.agent

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.MotionEvent
import android.view.Gravity
import android.view.WindowManager
import android.view.ViewConfiguration
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.jarvis.assistant.JarvisApp
import android.view.ViewGroup
import com.jarvis.assistant.automation.agent.AgentTaskSnapshot
import com.jarvis.assistant.automation.agent.TaskStepStatus

/** Small task HUD owned by the foreground conversation service. */
class TaskProgressOverlay(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val assetLoader = WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
        .build()
    private val root = FrameLayout(context).apply {
        setBackgroundColor(Color.TRANSPARENT)
        clipChildren = false
        clipToPadding = false
    }
    private val pill = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10), dp(7), dp(10), dp(7))
        background = GradientDrawable().apply {
            setColor(Color.argb(146, 8, 9, 12))
            cornerRadius = dp(13).toFloat()
            setStroke(dp(1), Color.argb(65, 225, 230, 238))
        }
        elevation = dp(12).toFloat()
    }
    private val header = TextView(context).apply {
        text = "JARVIS  ⋮⋮"
        setTextColor(Color.rgb(215, 220, 228))
        textSize = 10f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(5))
        contentDescription = "Drag JARVIS task overlay anywhere on screen"
    }
    private val title = label(11f, true).apply { maxLines = 1 }
    private val progressText = label(11f, true).apply {
        setTextColor(Color.rgb(190, 196, 206))
        textSize = 9f
        setPadding(0, dp(2), 0, 0)
    }
    private val stepRows = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private val progress = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100
        progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(8, 9, 12))
        progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(55, 230, 234, 240))
    }
    private val avatar = WebView(context).apply {
        setBackgroundColor(Color.TRANSPARENT)
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
        }
        webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)
        }
        visibility = View.VISIBLE
    }
    private val params = WindowManager.LayoutParams(
        minOf(dp(236), context.resources.displayMetrics.widthPixels - dp(16)),
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        x = dp(8)
        y = dp(90)
    }
    private var attached = false
    private var avatarMode = true
    private var loadedAvatar = ""
    private var displayedTaskId: String? = null
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private var currentEdge = ""
    private var dragging = false
    private var lastTapAt = 0L
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    init {
        pill.visibility = View.GONE
        avatar.visibility = View.VISIBLE
        pill.addView(header)
        pill.addView(title, matchWrap())
        pill.addView(stepRows, matchWrap())
        pill.addView(progress, LinearLayout.LayoutParams(-1, dp(3)).apply { topMargin = dp(4); bottomMargin = dp(1) })
        pill.addView(progressText, matchWrap())
        root.addView(pill, FrameLayout.LayoutParams(-1, -2))
        root.addView(avatar, FrameLayout.LayoutParams(dp(88), dp(88), Gravity.CENTER))
        pill.isClickable = true
        pill.setOnTouchListener { _, event -> handleOverlayTouch(event) }
        avatar.setOnTouchListener { _, event -> handleOverlayTouch(event) }
    }

    fun update(snapshot: AgentTaskSnapshot?, showIdleAvatar: Boolean = false): Boolean {
        if (!Settings.canDrawOverlays(context)) {
            remove()
            return false
        }
        val preferences = JarvisApp.instance.preferences
        if (snapshot == null && !showIdleAvatar && preferences.taskOverlayMode != "always") {
            remove()
            displayedTaskId = null
            return true
        }
        if (!preferences.isTaskOverlayEnabled) {
            remove()
            return true
        }
        val selectedAvatar = preferences.taskOverlayAvatar
        if (selectedAvatar != loadedAvatar) {
            loadedAvatar = selectedAvatar
            avatar.loadUrl("https://appassets.androidplatform.net/assets/overlay-toys/$selectedAvatar.html")
        }
        val nextTaskId = snapshot?.taskId
        if (displayedTaskId != nextTaskId) {
            displayedTaskId = nextTaskId
            avatarMode = true
        }
        if (!attached) {
            try {
                if (preferences.taskOverlayFreePosition && preferences.taskOverlayX >= 0 && preferences.taskOverlayY >= 0) {
                    params.gravity = Gravity.TOP or Gravity.LEFT
                    params.x = preferences.taskOverlayX
                    params.y = preferences.taskOverlayY
                    clampPosition()
                    currentEdge = preferences.taskOverlayEdge
                }
                windowManager.addView(root, params)
                attached = true
            } catch (_: Exception) {
                attached = false
                return false
            }
        }
        if (currentEdge != preferences.taskOverlayEdge) applyEdge(preferences.taskOverlayEdge)
        if (snapshot == null) renderIdle() else render(snapshot)
        applyMode()
        return true
    }

    fun remove() {
        if (attached) {
            try { windowManager.removeView(root) } catch (_: Exception) {}
            attached = false
        }
    }

    private fun render(snapshot: AgentTaskSnapshot) {
        progress.visibility = View.VISIBLE
        title.text = snapshot.originalGoal
        progress.progress = snapshot.progressPercentage.coerceIn(0, 100)
        val completed = snapshot.steps.count { it.status == TaskStepStatus.COMPLETED }
        progressText.text = "$completed/${snapshot.steps.size} done  ·  ${snapshot.progressPercentage}%"
        stepRows.removeAllViews()
        val activeIndex = snapshot.steps.indexOfFirst { it.stepId == snapshot.currentStepId }.coerceAtLeast(0)
        val first = (activeIndex - 2).coerceAtLeast(0)
        snapshot.steps.drop(first).take(4).forEach { step ->
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val active = step.status in setOf(TaskStepStatus.RUNNING, TaskStepStatus.VERIFYING, TaskStepStatus.WAITING_FOR_UI, TaskStepStatus.RECOVERING)
            val marker: View = if (active) {
                ProgressBar(context, null, android.R.attr.progressBarStyleSmall).apply {
                    isIndeterminate = true
                    indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.rgb(205, 210, 218))
                }
            } else TextView(context).apply {
                text = if (step.status == TaskStepStatus.COMPLETED) "✓" else if (step.status in setOf(TaskStepStatus.FAILED, TaskStepStatus.BLOCKED)) "!" else "·"
                setTextColor(if (step.status == TaskStepStatus.COMPLETED) Color.rgb(175, 210, 188) else Color.rgb(165, 171, 181))
                textSize = 10f
                gravity = Gravity.CENTER
            }
            row.addView(marker, LinearLayout.LayoutParams(dp(12), dp(12)))
            row.addView(label(9f, active).apply {
                text = step.title
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                alpha = if (step.status == TaskStepStatus.COMPLETED) 0.72f else 1f
                setPadding(dp(5), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, dp(14), 1f))
            stepRows.addView(row, LinearLayout.LayoutParams(-1, dp(15)))
        }
        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
    }

    private fun renderIdle() {
        title.text = "JARVIS"
        stepRows.removeAllViews()
        stepRows.addView(label(9f, false).apply { text = "Ready · Double-tap for task status" }, matchWrap())
        progress.visibility = View.GONE
        progressText.text = "Double-tap for status"
        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
    }

    private fun handleOverlayTouch(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX
                downRawY = event.rawY
                val location = IntArray(2)
                root.getLocationOnScreen(location)
                startX = location[0]
                startY = location[1]
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                if (dragging || kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop) {
                    dragging = true
                    params.gravity = Gravity.TOP or Gravity.LEFT
                    params.x = startX + dx.toInt()
                    params.y = startY + dy.toInt()
                    clampPosition()
                    try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
                    return true
                }
                return false
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    dragging = false
                    clampPosition()
                    val preferences = JarvisApp.instance.preferences
                    preferences.taskOverlayFreePosition = true
                    preferences.taskOverlayX = params.x
                    preferences.taskOverlayY = params.y
                    return true
                }
                val now = android.os.SystemClock.uptimeMillis()
                if (now - lastTapAt <= 360L) {
                    lastTapAt = 0L
                    toggleAvatarMode()
                    return true
                }
                lastTapAt = now
                return false
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                return false
            }
        }
        return false
    }

    private fun applyEdge(edge: String) {
        currentEdge = edge
        when (edge) {
            "left" -> { params.gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL; params.x = dp(8); params.y = 0 }
            "top" -> { params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; params.x = 0; params.y = dp(90) }
            "bottom" -> { params.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; params.x = 0; params.y = dp(90) }
            else -> { params.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL; params.x = dp(8); params.y = 0 }
        }
        try { if (attached) windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
    }

    private fun toggleAvatarMode() {
        avatarMode = !avatarMode
        applyMode()
    }

    private fun applyMode() {
        pill.visibility = if (avatarMode) View.GONE else View.VISIBLE
        avatar.visibility = if (avatarMode) View.VISIBLE else View.GONE
        params.width = if (avatarMode) dp(88) else minOf(dp(236), context.resources.displayMetrics.widthPixels - dp(16))
        params.height = if (avatarMode) dp(88) else WindowManager.LayoutParams.WRAP_CONTENT
        if (JarvisApp.instance.preferences.taskOverlayFreePosition) clampPosition()
        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
    }

    private fun clampPosition() {
        val metrics = context.resources.displayMetrics
        val overlayWidth = root.width.takeIf { it > 0 } ?: params.width.takeIf { it > 0 } ?: dp(88)
        val overlayHeight = root.height.takeIf { it > 0 } ?: params.height.takeIf { it > 0 } ?: dp(88)
        params.gravity = Gravity.TOP or Gravity.LEFT
        params.x = params.x.coerceIn(0, (metrics.widthPixels - overlayWidth).coerceAtLeast(0))
        params.y = params.y.coerceIn(dp(24), (metrics.heightPixels - overlayHeight).coerceAtLeast(dp(24)))
    }

    private fun label(size: Float, bold: Boolean) = TextView(context).apply {
        setTextColor(Color.rgb(226, 232, 240))
        textSize = size
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * context.resources.displayMetrics.density).toInt()
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/agent/TaskProgressOverlay.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/chat/ChatAdapter.kt ===
```kotlin
package com.jarvis.assistant.ui.chat

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.data.model.ChatTurn
import com.jarvis.assistant.databinding.ItemChatTurnBinding

class ChatAdapter : ListAdapter<ChatTurn, ChatAdapter.ChatViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val binding = ItemChatTurnBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ChatViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ChatViewHolder(private val binding: ItemChatTurnBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(turn: ChatTurn) {
            binding.tvTimestamp.text = turn.formattedTime
            binding.tvUserTranscript.text = turn.userTranscript
            binding.tvJarvisResponse.text = turn.jarvisResponse
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<ChatTurn>() {
        override fun areItemsTheSame(oldItem: ChatTurn, newItem: ChatTurn): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: ChatTurn, newItem: ChatTurn): Boolean =
            oldItem == newItem
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/chat/ChatAdapter.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/chat/ChatFragment.kt ===
```kotlin
package com.jarvis.assistant.ui.chat

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.background.JarvisConversationService
import com.jarvis.assistant.databinding.FragmentChatBinding
import com.jarvis.assistant.ui.home.MainActivity
import com.jarvis.assistant.ui.home.MainViewModel
import kotlinx.coroutines.launch

class ChatFragment : Fragment() {

    private var _binding: FragmentChatBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel get() = (requireActivity() as MainActivity).viewModel

    private val chatAdapter = JarvisChatAdapter(
        onEditUserMessage = { text ->
            binding.etMessageInput.setText(text)
            binding.etMessageInput.setSelection(text.length)
            binding.etMessageInput.requestFocus()
        }
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChatBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)

        // Setup Chat List
        binding.rvChatMessages.layoutManager = LinearLayoutManager(requireContext()).apply {
            stackFromEnd = true
        }
        binding.rvChatMessages.adapter = chatAdapter

        // Send Message
        binding.btnSendMessage.setOnClickListener {
            sendMessage()
        }

        // New Chat / Clear
        binding.btnChatNew.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("New Conversation")
                .setMessage("Start a new conversation and clear current history?")
                .setPositiveButton("New Chat") { _, _ ->
                    JarvisApp.instance.chatRepository.clearHistory()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Back / Menu
        binding.btnChatMenu.setOnClickListener {
            (activity as? MainActivity)?.selectTab(MainActivity.TAB_HOME)
        }

        // Mode Chips
        binding.chipPersona.setOnClickListener {
            Toast.makeText(requireContext(), "Persona: Jarvis Active", Toast.LENGTH_SHORT).show()
        }

        binding.chipMode.setOnClickListener {
            Toast.makeText(requireContext(), "Mode: Code & Assistant", Toast.LENGTH_SHORT).show()
        }

        binding.btnAttach.setOnClickListener {
            Toast.makeText(requireContext(), "Attachment options", Toast.LENGTH_SHORT).show()
        }

        observeChatTurns()
    }

    private fun sendMessage() {
        val text = binding.etMessageInput.text?.toString()?.trim() ?: ""
        if (text.isBlank()) return

        if (!JarvisConversationService.isServiceRunning()) {
            (activity as? MainActivity)?.handleMicOrOrbClick()
        }

        JarvisConversationService.sendTextMessage(text)
        binding.etMessageInput.text?.clear()
    }

    private fun observeChatTurns() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.chatTurns.collect { turns ->
                    chatAdapter.submitList(turns) {
                        if (turns.isNotEmpty()) {
                            binding.rvChatMessages.smoothScrollToPosition(turns.size - 1)
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (_binding != null) {
            com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)
        }
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden && _binding != null) {
            binding.root.visibility = View.VISIBLE
            com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)
        } else if (hidden && _binding != null) {
            binding.root.visibility = View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/chat/ChatFragment.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/chat/ChatHistoryBottomSheet.kt ===
```kotlin
package com.jarvis.assistant.ui.chat

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.databinding.SheetChatHistoryBinding

class ChatHistoryBottomSheet : BottomSheetDialogFragment() {

    private var _binding: SheetChatHistoryBinding? = null
    private val binding get() = _binding!!
    private val adapter = ChatAdapter()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = SheetChatHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvChatHistory.layoutManager = LinearLayoutManager(requireContext()).apply {
            stackFromEnd = true
        }
        binding.rvChatHistory.adapter = adapter

        val chatRepo = JarvisApp.instance.chatRepository
        val turns = chatRepo.turns.value

        updateList(turns)

        binding.btnClearHistory.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Clear History")
                .setMessage("Are you sure you want to clear the conversation history?")
                .setPositiveButton("Clear") { _, _ ->
                    chatRepo.clearHistory()
                    updateList(emptyList())
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun updateList(turns: List<com.jarvis.assistant.data.model.ChatTurn>) {
        if (turns.isEmpty()) {
            binding.tvEmptyHistory.visibility = View.VISIBLE
            binding.rvChatHistory.visibility = View.GONE
        } else {
            binding.tvEmptyHistory.visibility = View.GONE
            binding.rvChatHistory.visibility = View.VISIBLE
            adapter.submitList(turns) {
                binding.rvChatHistory.scrollToPosition(turns.size - 1)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val TAG = "ChatHistoryBottomSheet"
        fun newInstance() = ChatHistoryBottomSheet()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/chat/ChatHistoryBottomSheet.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/chat/JarvisChatAdapter.kt ===
```kotlin
package com.jarvis.assistant.ui.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.data.model.ChatTurn
import com.jarvis.assistant.databinding.ItemNairaChatMessageBinding

class JarvisChatAdapter(
    private val onEditUserMessage: ((String) -> Unit)? = null
) : ListAdapter<ChatTurn, JarvisChatAdapter.MessageViewHolder>(DiffCallback) {

    companion object DiffCallback : DiffUtil.ItemCallback<ChatTurn>() {
        override fun areItemsTheSame(oldItem: ChatTurn, newItem: ChatTurn): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: ChatTurn, newItem: ChatTurn): Boolean = oldItem == newItem
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val binding = ItemNairaChatMessageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MessageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class MessageViewHolder(
        private val binding: ItemNairaChatMessageBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(turn: ChatTurn) {
            val context = binding.root.context

            // User Bubble
            if (turn.userTranscript.isNotBlank()) {
                binding.layoutUserContainer.visibility = View.VISIBLE
                binding.tvUserMessage.text = turn.userTranscript

                binding.btnUserCopy.setOnClickListener {
                    copyToClipboard(context, "User message", turn.userTranscript)
                }

                binding.btnUserEdit.setOnClickListener {
                    onEditUserMessage?.invoke(turn.userTranscript)
                }
            } else {
                binding.layoutUserContainer.visibility = View.GONE
            }

            // Assistant Bubble
            if (turn.jarvisResponse.isNotBlank()) {
                binding.layoutAssistantContainer.visibility = View.VISIBLE
                binding.tvAssistantMessage.text = turn.jarvisResponse

                binding.btnAssistantCopy.setOnClickListener {
                    copyToClipboard(context, "Jarvis response", turn.jarvisResponse)
                }

                binding.btnAssistantPlay.setOnClickListener {
                    Toast.makeText(context, "Playing response...", Toast.LENGTH_SHORT).show()
                }
            } else {
                binding.layoutAssistantContainer.visibility = View.GONE
            }
        }

        private fun copyToClipboard(context: Context, label: String, text: String) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText(label, text)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/chat/JarvisChatAdapter.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/chat/NairaChatAdapter.kt ===
```kotlin
package com.jarvis.assistant.ui.chat

/**
 * Backward compatibility alias for JarvisChatAdapter
 */
typealias NairaChatAdapter = JarvisChatAdapter
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/chat/NairaChatAdapter.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/home/HomeFragment.kt ===
```kotlin
package com.jarvis.assistant.ui.home

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.data.model.ConversationState
import com.jarvis.assistant.databinding.FragmentHomeBinding
import com.jarvis.assistant.ui.memory.MemoryActivity
import com.jarvis.assistant.util.LocationWeatherHelper
import com.jarvis.assistant.util.PermissionHelper
import android.content.res.ColorStateList
import androidx.core.content.ContextCompat
import com.jarvis.assistant.R
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel get() = (requireActivity() as MainActivity).viewModel
    private val preferences by lazy { JarvisApp.instance.preferences }

    private var isPageLoaded = false
    private var pendingOrbState: String? = null
    private var pendingThemeKey: String? = null
    private var pendingCustomHex: String? = null
    private var lastAudioPushTime = 0L
    private var taskFallbackPanel: android.widget.LinearLayout? = null
    private var taskFallbackText: android.widget.TextView? = null

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fineGranted || coarseGranted) {
            fetchLiveWeather()
        } else {
            binding.tvWeatherCondition.text = "Location Permission Needed"
            binding.tvWeatherDetails.text = "Tap here to grant location for accurate weather"
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)
        createTaskFallbackPanel()

        // Top Navigation
        binding.btnTopChat.setOnClickListener {
            (activity as? MainActivity)?.selectTab(MainActivity.TAB_CHAT)
        }

        binding.btnTopSettings.setOnClickListener {
            (activity as? MainActivity)?.selectTab(MainActivity.TAB_SETTINGS)
        }

        binding.btnDismissLiveError.setOnClickListener {
            hideLiveErrorOverlay {
                viewModel.clearLiveError()
            }
        }

        setupOrbWebView()

        // Action Buttons
        binding.btnScreenShareQuick.setOnClickListener {
            (activity as? MainActivity)?.toggleScreenShare()
        }

        binding.btnSavedMemories.setOnClickListener {
            startActivity(Intent(requireContext(), MemoryActivity::class.java))
        }

        binding.btnConversationLanguageQuick.setOnClickListener {
            showLanguageDialog()
        }

        // Weather Card Click -> Refresh or Request Permission
        binding.cardWeather.setOnClickListener {
            if (!PermissionHelper.hasLocationPermission(requireContext())) {
                locationPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            } else {
                fetchLiveWeather()
            }
        }

        updateHomeHeaderAndVoiceStatus()
        observeViewModel()
        checkLocationAndFetchWeather()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupOrbWebView() {
        binding.orbWebView.apply {
            setBackgroundColor(Color.TRANSPARENT)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                @Suppress("DEPRECATION")
                allowFileAccessFromFileURLs = true
                @Suppress("DEPRECATION")
                allowUniversalAccessFromFileURLs = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }

            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    isPageLoaded = true

                    // Sync Theme
                    val currentTheme = pendingThemeKey ?: preferences.appTheme
                    val customHex = pendingCustomHex ?: preferences.customThemeColor
                    setOrbTheme(currentTheme, customHex)

                    // Sync State
                    val state = pendingOrbState ?: when (viewModel.conversationState.value) {
                        ConversationState.LISTENING -> "listening"
                        ConversationState.SPEAKING -> "speaking"
                        ConversationState.THINKING -> "thinking"
                        ConversationState.IDLE -> "idle"
                    }
                    setOrbState(state)
                }
            }

            // Single tap detection triggers mic/conversation without interrupting 3D rotation drag
            val gestureDetector = GestureDetector(requireContext(), object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                    (activity as? MainActivity)?.handleMicOrOrbClick()
                    return true
                }

                override fun onLongPress(e: MotionEvent) {
                    (activity as? MainActivity)?.handleHoldMicOrOrb()
                }
            })

            setOnTouchListener { v, event ->
                gestureDetector.onTouchEvent(event)
                v.onTouchEvent(event)
            }

            loadUrl("file:///android_asset/orb.html?embedded=1")
        }
    }

    fun setOrbState(state: String) {
        pendingOrbState = state
        if (!isPageLoaded) return
        activity?.runOnUiThread {
            binding.orbWebView.evaluateJavascript("window.JarvisOrb && window.JarvisOrb.setState('$state');", null)
        }
    }

    fun setOrbTheme(themeKey: String, customHex: String?) {
        pendingThemeKey = themeKey
        pendingCustomHex = customHex
        if (!isPageLoaded) return
        activity?.runOnUiThread {
            if (themeKey == "custom" && !customHex.isNullOrBlank()) {
                binding.orbWebView.evaluateJavascript("window.JarvisOrb && window.JarvisOrb.setBackground('$customHex');", null)
            } else {
                val mapped = when (themeKey) {
                    "dark" -> "dark"
                    "red" -> "red"
                    "sunset" -> "sunset"
                    else -> "light"
                }
                binding.orbWebView.evaluateJavascript("window.JarvisOrb && window.JarvisOrb.setTheme('$mapped');", null)
            }
        }
    }

    private fun pushExternalAudio(amp: Float, bass: Float, high: Float) {
        if (!isPageLoaded) return
        val now = System.currentTimeMillis()
        if (now - lastAudioPushTime < 33L) return // ~30 calls per second throttle
        lastAudioPushTime = now
        activity?.runOnUiThread {
            binding.orbWebView.evaluateJavascript("window.JarvisOrb && window.JarvisOrb.setExternalAudio($amp, $bass, $high);", null)
        }
    }

    override fun onResume() {
        super.onResume()
        com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)
        binding.orbWebView.onResume()
        binding.orbWebView.resumeTimers()
        renderTaskFallback(com.jarvis.assistant.automation.agent.AgentTaskEngine.taskState.value)

        // Sync theme with settings
        setOrbTheme(preferences.appTheme, preferences.customThemeColor)
        updateHomeHeaderAndVoiceStatus()

        if (PermissionHelper.hasLocationPermission(requireContext())) {
            fetchLiveWeather()
        }
    }

    override fun onPause() {
        super.onPause()
        binding.orbWebView.onPause()
        binding.orbWebView.pauseTimers()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden && _binding != null) {
            binding.root.visibility = View.VISIBLE
            binding.orbWebView.visibility = View.VISIBLE
            binding.orbWebView.onResume()
            binding.orbWebView.resumeTimers()
            com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)
            setOrbTheme(preferences.appTheme, preferences.customThemeColor)
            updateHomeHeaderAndVoiceStatus()
        } else if (hidden && _binding != null) {
            binding.orbWebView.onPause()
            binding.orbWebView.pauseTimers()
            binding.orbWebView.visibility = View.GONE
            binding.root.visibility = View.GONE
        }
    }

    private fun checkLocationAndFetchWeather() {
        if (PermissionHelper.hasLocationPermission(requireContext())) {
            fetchLiveWeather()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun fetchLiveWeather() {
        binding.tvWeatherCondition.text = "Locating • Fetching weather..."
        viewLifecycleOwner.lifecycleScope.launch {
            val weather = LocationWeatherHelper.fetchWeather(requireContext())
            if (_binding != null && weather != null) {
                binding.tvTemperature.text = weather.temperature
                binding.tvWeatherCondition.text = weather.condition
                binding.tvWeatherDetails.text = weather.details
                binding.ivWeatherIcon.setImageResource(weather.iconResId)
                // Keep Jarvis's context aligned with the city shown on Home.
                preferences.userLocation = weather.cityName
            } else if (_binding != null) {
                binding.tvWeatherCondition.text = "Live Weather • Tap to retry"
            }
        }
    }

    private fun updateHomeHeaderAndVoiceStatus() {
        if (_binding == null) return
        val userName = preferences.userName.ifBlank { "Rehaan" }
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val timeGreeting = when (hour) {
            in 4..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            in 17..21 -> "Good evening"
            else -> "Welcome back"
        }
        binding.tvGreeting.text = "$timeGreeting, $userName"

        val currentLang = preferences.language.ifBlank { "Auto" }
        binding.tvQuickLanguageStatus.text = if (currentLang.contains("Auto", ignoreCase = true)) "Auto" else currentLang
    }

    private fun showLanguageDialog() {
        val languages = com.jarvis.assistant.data.model.GeminiConstants.SUPPORTED_LANGUAGES.toTypedArray()
        val currentLang = preferences.language
        val currentIndex = languages.indexOfFirst { it.equals(currentLang, ignoreCase = true) }.let { if (it >= 0) it else 0 }

        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("Select Conversation Language")
            .setSingleChoiceItems(languages, currentIndex) { dialog, which ->
                val chosen = languages[which]
                preferences.language = chosen
                binding.tvQuickLanguageStatus.text = chosen
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    com.jarvis.assistant.automation.agent.AgentTaskEngine.taskState.collect { snapshot ->
                        renderTaskFallback(snapshot)
                    }
                }
                launch {
                    val screenCapture = com.jarvis.assistant.vision.ScreenCaptureManager.getInstance()
                    combine(screenCapture.isSharing, screenCapture.hasReceivedFrame) { sharing, hasFrame -> sharing to hasFrame }
                        .collect { (sharing, hasFrame) ->
                        binding.tvQuickScreenShareStatus.text = when {
                            !sharing -> "Share screen"
                            !hasFrame -> "Starting…"
                            else -> "Stop sharing"
                        }
                        binding.tvQuickScreenShareStatus.setTextColor(
                            if (sharing && hasFrame) Color.parseColor("#10B981")
                            else ContextCompat.getColor(requireContext(), R.color.text_subtle)
                        )
                    }
                }

                launch {
                    combine(
                        viewModel.isSessionOn,
                        viewModel.isMicMuted,
                        viewModel.conversationState,
                        com.jarvis.assistant.background.JarvisConversationService.isStandby
                    ) { isOn, isMuted, state, isStandby ->
                        HomeStatusState(isOn, isMuted, state, isStandby)
                    }.collect { status ->
                        if (!status.isOn) {
                            setOrbState("idle")
                            binding.tvListeningStatus.text = "JARVIS OFF • TAP TO START"
                            binding.tvListeningStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_subtle))
                            binding.tvHoldHint.text = "Tap mic or orb to power on"
                            binding.tvHoldHint.visibility = View.VISIBLE
                            binding.dotStatusGlow.backgroundTintList = ColorStateList.valueOf(
                                Color.parseColor("#64748B")
                            )
                        } else if (status.isMuted) {
                            setOrbState("idle")
                            binding.tvListeningStatus.text = "MIC MUTED (OFF) • TAP TO TALK"
                            binding.tvListeningStatus.setTextColor(Color.parseColor("#EF4444"))
                            binding.tvHoldHint.text = "Microphone is muted • Tap mic to unmute"
                            binding.tvHoldHint.visibility = View.VISIBLE
                            binding.dotStatusGlow.backgroundTintList = ColorStateList.valueOf(
                                Color.parseColor("#EF4444")
                            )
                        } else if (status.isStandby) {
                            setOrbState("idle")
                            binding.tvListeningStatus.text = "STANDBY • SAY 'HEY JARVIS'"
                            binding.tvListeningStatus.setTextColor(Color.parseColor("#3B82F6"))
                            binding.tvHoldHint.text = "Listening for wake word • Hold mic to power off"
                            binding.tvHoldHint.visibility = View.VISIBLE
                            binding.dotStatusGlow.backgroundTintList = ColorStateList.valueOf(
                                Color.parseColor("#3B82F6")
                            )
                        } else {
                            binding.tvHoldHint.visibility = View.VISIBLE
                            when (status.state) {
                                ConversationState.LISTENING -> {
                                    setOrbState("listening")
                                    binding.tvListeningStatus.text = "MIC ON • LISTENING..."
                                    binding.tvListeningStatus.setTextColor(Color.parseColor("#10B981"))
                                    binding.tvHoldHint.text = "Speak now • Tap to mute • Hold to power off"
                                    binding.dotStatusGlow.backgroundTintList = ColorStateList.valueOf(
                                        Color.parseColor("#10B981")
                                    )
                                }
                                ConversationState.SPEAKING -> {
                                    setOrbState("speaking")
                                    binding.tvListeningStatus.text = "JARVIS SPEAKING..."
                                    binding.tvListeningStatus.setTextColor(Color.parseColor("#06B6D4"))
                                    binding.tvHoldHint.text = "Tap mic to interrupt"
                                    binding.dotStatusGlow.backgroundTintList = ColorStateList.valueOf(
                                        Color.parseColor("#06B6D4")
                                    )
                                }
                                ConversationState.THINKING -> {
                                    setOrbState("thinking")
                                    binding.tvListeningStatus.text = "THINKING..."
                                    binding.tvListeningStatus.setTextColor(Color.parseColor("#F59E0B"))
                                    binding.tvHoldHint.text = "Processing request..."
                                    binding.dotStatusGlow.backgroundTintList = ColorStateList.valueOf(
                                        Color.parseColor("#F59E0B")
                                    )
                                }
                                ConversationState.IDLE -> {
                                    setOrbState("idle")
                                    binding.tvListeningStatus.text = "MIC ON • READY"
                                    binding.tvListeningStatus.setTextColor(Color.parseColor("#10B981"))
                                    binding.tvHoldHint.text = "Tap to mute • Hold to power off"
                                    binding.dotStatusGlow.backgroundTintList = ColorStateList.valueOf(
                                        Color.parseColor("#10B981")
                                    )
                                }
                            }
                        }
                    }
                }

                launch {
                    viewModel.audioFrequency.collect { freq ->
                        val amp = freq.amplitude
                        val bass = freq.bass
                        val high = freq.high
                        pushExternalAudio(amp, bass, high)
                    }
                }

                launch {
                    viewModel.liveError.collect { error ->
                        if (error == null) {
                            hideLiveErrorOverlay()
                        } else {
                            showLiveErrorOverlay()
                            binding.tvLiveErrorTitle.text = error.title
                            binding.tvLiveErrorMessage.text = error.message
                            binding.btnFixLiveError.text = error.actionText

                            when (error.errorCode) {
                                "API_KEY_INVALID", "API_KEY_MISSING" -> {
                                    binding.ivLiveErrorIcon.setImageResource(R.drawable.ic_warning)
                                    binding.ivLiveErrorIcon.imageTintList = ColorStateList.valueOf(Color.parseColor("#EF4444"))
                                    binding.tvLiveErrorTitle.setTextColor(Color.parseColor("#EF4444"))
                                    binding.btnFixLiveError.setOnClickListener {
                                        startActivity(Intent(requireContext(), com.jarvis.assistant.ui.settings.ApiConnectionActivity::class.java))
                                    }
                                }
                                "ACCESSIBILITY_DISABLED" -> {
                                    binding.ivLiveErrorIcon.setImageResource(R.drawable.ic_settings_shield)
                                    binding.ivLiveErrorIcon.imageTintList = ColorStateList.valueOf(Color.parseColor("#F59E0B"))
                                    binding.tvLiveErrorTitle.setTextColor(Color.parseColor("#F59E0B"))
                                    binding.btnFixLiveError.setOnClickListener {
                                        PermissionHelper.openAccessibilitySettings(requireContext())
                                    }
                                }
                                "PERMISSIONS_MISSING" -> {
                                    binding.ivLiveErrorIcon.setImageResource(R.drawable.ic_settings_shield)
                                    binding.ivLiveErrorIcon.imageTintList = ColorStateList.valueOf(Color.parseColor("#F59E0B"))
                                    binding.tvLiveErrorTitle.setTextColor(Color.parseColor("#F59E0B"))
                                    binding.btnFixLiveError.setOnClickListener {
                                        startActivity(Intent(requireContext(), com.jarvis.assistant.ui.permission.PermissionActivity::class.java))
                                    }
                                }
                                else -> {
                                    binding.ivLiveErrorIcon.setImageResource(R.drawable.ic_warning)
                                    binding.ivLiveErrorIcon.imageTintList = ColorStateList.valueOf(Color.parseColor("#EF4444"))
                                    binding.tvLiveErrorTitle.setTextColor(Color.parseColor("#EF4444"))
                                    binding.btnFixLiveError.setOnClickListener {
                                        (activity as? MainActivity)?.handleMicOrOrbClick()
                                    }
                                }
                            }
                        }
                    }
                }

                launch {
                    viewModel.connectionStatus.collect { status ->
                        if (status.startsWith("ERROR")) {
                            binding.tvListeningStatus.text = status
                            binding.dotStatusGlow.backgroundTintList = ColorStateList.valueOf(
                                Color.parseColor("#EF4444")
                            )
                        }
                    }
                }
            }
        }
    }

    private fun showLiveErrorOverlay() {
        if (_binding == null) return
        val card = binding.cardLiveError
        if (card.visibility == View.VISIBLE && card.alpha == 1f) return
        card.alpha = 0f
        card.scaleX = 0.85f
        card.scaleY = 0.85f
        card.visibility = View.VISIBLE
        card.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(240)
            .setInterpolator(android.view.animation.OvershootInterpolator(1.15f))
            .start()
    }

    private fun hideLiveErrorOverlay(onEnd: (() -> Unit)? = null) {
        if (_binding == null) {
            onEnd?.invoke()
            return
        }
        val card = binding.cardLiveError
        if (card.visibility != View.VISIBLE) {
            onEnd?.invoke()
            return
        }
        card.animate()
            .alpha(0f)
            .scaleX(0.85f)
            .scaleY(0.85f)
            .setDuration(180)
            .withEndAction {
                if (_binding != null) {
                    card.visibility = View.GONE
                }
                onEnd?.invoke()
            }
            .start()
    }

    private fun createTaskFallbackPanel() {
        val root = binding.root as? androidx.constraintlayout.widget.ConstraintLayout ?: return
        val panel = android.widget.LinearLayout(requireContext()).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.rgb(12, 20, 35))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), android.graphics.Color.rgb(34, 211, 238))
            }
            elevation = dp(8).toFloat()
            visibility = View.GONE
        }
        panel.addView(android.widget.TextView(requireContext()).apply {
            text = "JARVIS AGENT PROGRESS"
            textSize = 11f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(android.graphics.Color.rgb(103, 232, 249))
        })
        val details = android.widget.TextView(requireContext()).apply {
            textSize = 12f
            setTextColor(android.graphics.Color.WHITE)
            maxLines = 4
            setPadding(0, dp(5), 0, dp(2))
        }
        panel.addView(details)
        panel.addView(android.widget.Button(requireContext()).apply {
            text = "Enable floating overlay"
            isAllCaps = false
            setOnClickListener {
                try {
                    startActivity(android.content.Intent(
                        android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        android.net.Uri.parse("package:${requireContext().packageName}")
                    ))
                } catch (_: Exception) {
                    android.widget.Toast.makeText(requireContext(), "Open Android Settings → Apps → JARVIS → Display over other apps.", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }, android.widget.LinearLayout.LayoutParams(-2, dp(44)))
        val params = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams(0, -2).apply {
            startToStart = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.PARENT_ID
            endToEnd = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.PARENT_ID
            topToTop = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.PARENT_ID
            topMargin = dp(70)
            marginStart = dp(16)
            marginEnd = dp(16)
        }
        root.addView(panel, params)
        taskFallbackPanel = panel
        taskFallbackText = details
    }

    private fun renderTaskFallback(snapshot: com.jarvis.assistant.automation.agent.AgentTaskSnapshot?) {
        val panel = taskFallbackPanel ?: return
        val show = snapshot != null && !android.provider.Settings.canDrawOverlays(requireContext())
        panel.visibility = if (show) View.VISIBLE else View.GONE
        if (!show || snapshot == null) return
        val activeStep = snapshot.steps.firstOrNull { it.stepId == snapshot.currentStepId }?.title ?: snapshot.currentStatus
        val checklist = snapshot.steps.take(4).joinToString("\n") { step ->
            val mark = if (step.status == com.jarvis.assistant.automation.agent.TaskStepStatus.COMPLETED) "✓" else "○"
            "$mark ${step.title}"
        }
        taskFallbackText?.text = "${snapshot.originalGoal}\n${snapshot.progressPercentage}% · ${snapshot.currentStatus.replace('_', ' ')}\nCurrent: $activeStep\n$checklist"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

private data class HomeStatusState(
    val isOn: Boolean,
    val isMuted: Boolean,
    val state: ConversationState,
    val isStandby: Boolean
)
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/home/HomeFragment.kt ===
