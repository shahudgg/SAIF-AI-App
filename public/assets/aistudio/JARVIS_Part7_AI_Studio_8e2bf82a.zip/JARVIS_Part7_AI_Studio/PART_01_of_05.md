# JARVIS Android App (Part 7) — SOURCE PART 1 of 5

Is file mein neeche diye gaye project files ka poora, unchanged source hai. Har file `=== FILE: <path> ===` se shuru aur `=== END FILE ===` pe khatam hoti hai. Path exactly waise hi banana hai jaisa likha hai.

Files in this part:
- .editorconfig
- .gitignore
- LICENSE
- README.md
- app/build.gradle.kts
- app/proguard-rules.pro
- app/src/main/AndroidManifest.xml
- app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml
- app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml
- app/src/main/res/values/attrs.xml
- app/src/main/res/values/colors.xml
- app/src/main/res/values/ic_launcher_background.xml
- app/src/main/res/values/strings.xml
- app/src/main/res/values/themes.xml
- app/src/main/res/xml/accessibility_service_config.xml
- app/src/main/res/xml/network_security_config.xml
- build.gradle.kts
- docs/README.md
- docs/architecture/voice-architecture-research.md
- docs/diagnostics/voice-videos/README.md
- gradle.properties
- gradle/wrapper/gradle-wrapper.properties
- gradlew
- gradlew.bat
- local.properties.example
- scripts/build-release.ps1
- settings.gradle.kts
- app/src/main/java/com/jarvis/assistant/JarvisApp.kt
- app/src/main/java/com/jarvis/assistant/audio/AudioPlayer.kt
- app/src/main/java/com/jarvis/assistant/audio/AudioRecorder.kt
- app/src/main/java/com/jarvis/assistant/audio/AudioUtils.kt
- app/src/main/java/com/jarvis/assistant/audio/HeadsetAudioRouter.kt
- app/src/main/java/com/jarvis/assistant/audio/JarvisSoundEffects.kt
- app/src/main/java/com/jarvis/assistant/audio/OwnerVoiceManager.kt
- app/src/main/java/com/jarvis/assistant/audio/VoskModelManager.kt
- app/src/main/java/com/jarvis/assistant/automation/accessibility/JarvisAccessibilityService.kt
- app/src/main/java/com/jarvis/assistant/automation/agent/ActionVerifier.kt
- app/src/main/java/com/jarvis/assistant/automation/agent/AgentModels.kt
- app/src/main/java/com/jarvis/assistant/automation/agent/AgentTaskEngine.kt
- app/src/main/java/com/jarvis/assistant/automation/agent/ScreenSignatureCalculator.kt
- app/src/main/java/com/jarvis/assistant/automation/agent/SerializedActionExecutor.kt
- app/src/main/java/com/jarvis/assistant/automation/command/CommandExecutor.kt
- app/src/main/java/com/jarvis/assistant/automation/command/CommandParser.kt
- app/src/main/java/com/jarvis/assistant/automation/command/JarvisCommand.kt
- app/src/main/java/com/jarvis/assistant/automation/contacts/ContactModel.kt
- app/src/main/java/com/jarvis/assistant/automation/contacts/ContactResolver.kt
- app/src/main/java/com/jarvis/assistant/automation/phone/DomainNormalizer.kt
- app/src/main/java/com/jarvis/assistant/automation/phone/PhoneControlManager.kt
- app/src/main/java/com/jarvis/assistant/automation/whatsapp/WhatsAppAssistant.kt
- app/src/main/java/com/jarvis/assistant/automation/youtube/YouTubeApiClient.kt
- app/src/main/java/com/jarvis/assistant/automation/youtube/YouTubeAutomationManager.kt
- app/src/main/java/com/jarvis/assistant/automation/youtube/YouTubeController.kt


=== FILE: .editorconfig ===
```
root = true

[*]
charset = utf-8
end_of_line = lf
insert_final_newline = true

[*.{kt,kts}]
indent_style = space
indent_size = 4

[*.{xml,json,yml,yaml,properties,md}]
indent_style = space
indent_size = 2

[*.{bat,ps1}]
end_of_line = crlf
```
=== END FILE: .editorconfig ===


=== FILE: .gitignore ===
```
# Built Android artifacts
*.apk
*.ap_
*.aab

# JVM and Android generated files
*.class
*.dex
bin/
gen/
out/
build/
.gradle/
.gradle-user/
.kotlin/
buildOutputCleanup/
.externalNativeBuild/
.cxx/

# Local machine configuration and secrets
local.properties
*.jks
*.keystore
.env
.env.*
!.env.example

# Android Studio / IntelliJ
*.iml
.idea/
.shelf/
misc.xml
deploymentTargetDropDown.xml

# Logs and generated diagnostics
*.log
dump*.xml

# OS files
.DS_Store
Thumbs.db
```
=== END FILE: .gitignore ===


=== FILE: LICENSE ===
```
TECH GPTx SOURCE CODE & CONTENT CREATOR LICENSE (TAMCL v1.0)
Copyright (c) 2026 Tech GPTx (Tech GP Tax) / Rehaan. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, subject to the following STRICT MANDATORY CONDITIONS:

================================================================================
1. MANDATORY VIDEO & CONTENT CREATOR SHOUTOUT REQUIREMENT (100% ENFORCED)
================================================================================
If you or your organization create, produce, publish, or stream ANY digital media,
including but not limited to:
- YouTube Videos, Shorts, Live Streams, or Community Posts
- Instagram Reels, Posts, or Stories
- TikTok Videos or Facebook Videos
- Online Courses, Bootcamps, Blogs, Tutorials, or Podcasts

that use, demonstrate, showcase, review, fork, build upon, or reference this 
codebase, architecture, or project concept:

YOU ARE REQUIRED TO GIVE A 100% VISIBLE, PROMINENT, AND CLEAR SHOUTOUT TO "Tech GPTx":
  (a) VERBAL CREDIT: Explicitly state in the spoken audio of your video:
      "Credit to Tech GPTx for the original JARVIS AI Android source code / project."
  (b) DESCRIPTION CREDIT: Include in the very top of your video/post description
      (within the first 3 lines, before any "Show More" fold):
      "Original Source Code & Tutorial by Tech GPTx: https://github.com/techgptx/Playlist"
  (c) ON-SCREEN CREDIT: Display a visible on-screen text watermark or graphic
      crediting "Tech GPTx" during the demonstration of the app.

================================================================================
2. SOURCE CODE ATTRIBUTION & FORK PRESERVATION
================================================================================
The above copyright notice, this permission notice, and the mandatory shoutout 
conditions MUST be included in all copies, forks, mirrors, and substantial 
portions of the Software. You may NOT remove "Tech GPTx" attribution from the 
codebase, manifests, UI credits, or documentation.

================================================================================
3. DISCLAIMER OF WARRANTY & LIMITATION OF LIABILITY
================================================================================
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
=== END FILE: LICENSE ===


=== FILE: README.md ===
````markdown
# JARVIS Voice Assistant

An Android voice assistant built with Kotlin, Gemini Live, on-device voice components, accessibility automation, screen capture, and a native Android UI.

## Project status

- Android application module: `app`
- Application ID: `com.jarvis.assistant`
- Minimum Android version: Android 8.0 (API 26)
- Compile and target SDK: 34
- Java/Kotlin target: 17
- Current app version: 1.8.7 (version code 143)

## Getting started

1. Open the project root in Android Studio and allow Gradle to sync.
2. Set the Android SDK path in your local `local.properties` file. The file is machine-specific and is ignored by Git.
3. Launch the app on an Android 8.0+ device or emulator.
4. Add a Gemini API key in the app's Settings and grant the requested runtime permissions.

The Gradle wrapper is included in this project. Use `gradlew.bat` on Windows or `./gradlew` on macOS/Linux.

## Build commands

```powershell
# Windows: compile and package a debug APK
.\gradlew.bat :app:assembleDebug

# Windows: compile and package a release APK
.\gradlew.bat :app:assembleRelease
```

```bash
# macOS/Linux
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

Build outputs are written under `app/build/outputs/` and are generated files, not source files. Release builds enable R8 and resource shrinking. `assembleRelease` intentionally refuses to package unless a dedicated keystore, its SHA-256 certificate pin, and publisher metadata are configured. Never commit keystores or passwords.

Create and protect a release key outside this repository, then supply these values only in the local shell or Gradle user properties:

```powershell
$env:JARVIS_RELEASE_STORE_FILE = 'C:\secure\jarvis-release.jks'
$env:JARVIS_RELEASE_STORE_PASSWORD = '<local secret>'
$env:JARVIS_RELEASE_KEY_ALIAS = 'jarvis-release'
$env:JARVIS_RELEASE_KEY_PASSWORD = '<local secret>'
$env:JARVIS_RELEASE_CERT_SHA256 = '<64 hex characters from keytool -list -v>'
$env:JARVIS_DEVELOPER_NAME = 'TechGpt X'
$env:JARVIS_COPYRIGHT_OWNER = 'TechGpt X'
.\gradlew.bat :app:assembleRelease
```

The certificate fingerprint must be calculated from the same key used to sign the APK. This project currently has no deployed verification backend or agreed verification API protocol. Local signer pinning and APK signatures do not provide server-side authentication, Play Integrity attestation, or rate limiting; the app identity screen reports remote verification as unavailable until that service is implemented and deployed.

## Repository layout

```text
.
├── app/                         Android application module
│   └── src/main/
│       ├── java/com/jarvis/assistant/
│       │   ├── audio/           Audio capture, playback, and voice handling
│       │   ├── automation/      Accessibility, actions, and app integrations
│       │   ├── background/      Conversation foreground service
│       │   ├── data/            Preferences, persistence, and data models
│       │   ├── network/         Gemini Live transport
│       │   ├── ui/              Activities, fragments, and adapters
│       │   ├── util/            Shared app utilities
│       │   └── vision/          Screen capture and visual task execution
│       ├── assets/              Bundled web UI and offline voice models
│       └── res/                 Android layouts, drawables, values, and config
├── docs/
│   ├── architecture/            Design notes and research
│   └── diagnostics/             User-provided issue recordings and index
├── gradle/                      Gradle wrapper configuration
├── build.gradle.kts             Root Gradle plugin declarations
├── settings.gradle.kts          Project and repository configuration
└── gradle.properties             Gradle runtime settings
```

## Documentation

- [Documentation index](docs/README.md)
- [Voice architecture research](docs/architecture/voice-architecture-research.md)
- [Voice issue recordings](docs/diagnostics/voice-videos/README.md)

## Configuration and privacy

- Keep API keys, SDK paths, signing keys, and local machine settings out of source control.
- `local.properties` is local-only; start from `local.properties.example` when setting up a new machine.
- Screen sharing and accessibility automation require explicit Android user consent and permissions.
- Bundled Vosk model assets are runtime dependencies; do not remove or rename their directories without updating the model-loading code.
````
=== END FILE: README.md ===


=== FILE: app/build.gradle.kts ===
```kotlin
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("kotlin-kapt")
}

fun configuredValue(name: String): String? =
    providers.gradleProperty(name).orNull ?: providers.environmentVariable(name).orNull

fun buildConfigString(value: String): String = "\"${value.replace("\\", "\\\\").replace("\"", "\\\"")}\""

val releaseStorePath = configuredValue("JARVIS_RELEASE_STORE_FILE")
val releaseStorePassword = configuredValue("JARVIS_RELEASE_STORE_PASSWORD")
val releaseKeyAlias = configuredValue("JARVIS_RELEASE_KEY_ALIAS")
val releaseKeyPassword = configuredValue("JARVIS_RELEASE_KEY_PASSWORD")
val releaseCertSha256 = configuredValue("JARVIS_RELEASE_CERT_SHA256")?.replace(":", "")?.uppercase().orEmpty()
val developerName = configuredValue("JARVIS_DEVELOPER_NAME")?.ifBlank { null } ?: "Tech GPTx"
val copyrightOwner = configuredValue("JARVIS_COPYRIGHT_OWNER")?.ifBlank { null } ?: "Tech GPTx"
val verificationEndpoint = configuredValue("JARVIS_VERIFICATION_ENDPOINT").orEmpty()
val releaseSigningReady = listOf(releaseStorePath, releaseStorePassword, releaseKeyAlias, releaseKeyPassword).all { !it.isNullOrBlank() }

android {
    namespace = "com.jarvis.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jarvis.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 143
        versionName = "1.8.7"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "DEVELOPER_NAME", buildConfigString(developerName.ifBlank { "Unverified developer" }))
        buildConfigField("String", "COPYRIGHT_OWNER", buildConfigString(copyrightOwner.ifBlank { "Unconfigured" }))
        buildConfigField("String", "PINNED_RELEASE_CERT_SHA256", buildConfigString(releaseCertSha256))
        buildConfigField("String", "VERIFICATION_ENDPOINT", buildConfigString(verificationEndpoint))
    }

    signingConfigs {
        create("release") {
            if (releaseSigningReady) {
                storeFile = file(releaseStorePath!!)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    lint {
        // AndroidX Lifecycle 2.8.6's NullSafeMutableLiveData detector crashes under this project's Kotlin 2.0 UAST.
        // Keep all other lint checks enabled while that upstream detector is incompatible.
        disable += "NullSafeMutableLiveData"
    }
}

tasks.register("verifyReleaseSecurityInputs") {
    doLast {
        check(releaseSigningReady) {
            "Release signing is not configured. Set JARVIS_RELEASE_STORE_FILE, JARVIS_RELEASE_STORE_PASSWORD, JARVIS_RELEASE_KEY_ALIAS, and JARVIS_RELEASE_KEY_PASSWORD in the local environment or Gradle user properties."
        }
        check(releaseCertSha256.matches(Regex("[A-F0-9]{64}"))) {
            "Set JARVIS_RELEASE_CERT_SHA256 to the SHA-256 fingerprint of the release signing certificate."
        }
        check(developerName.isNotBlank() && copyrightOwner.isNotBlank()) {
            "Set JARVIS_DEVELOPER_NAME and JARVIS_COPYRIGHT_OWNER to the verified publisher identity."
        }
    }
}

tasks.matching { it.name == "packageRelease" }.configureEach {
    dependsOn("verifyReleaseSecurityInputs")
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.code.gson:gson:2.10.1")
    implementation("androidx.webkit:webkit:1.12.0")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.75@aar")

    // Room Database
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")

    // Security Crypto for EncryptedSharedPreferences
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    testImplementation("junit:junit:4.13.2")
}
```
=== END FILE: app/build.gradle.kts ===


=== FILE: app/proguard-rules.pro ===
```text
# Keep Gson model classes
-keep class com.jarvis.assistant.data.model.** { *; }
-keepattributes Signature
-keepattributes *Annotation*

# Keep JavascriptInterfaces for WebViews (Cyberpunk Orb & Settings Activity)
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep Vosk and JNA native libraries & models
-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-keepclassmembers class * extends com.sun.jna.** { *; }
-keep class net.java.dev.jna.** { *; }
# JNA ships optional desktop AWT bridges that are not present on Android; app code does not use them.
-dontwarn java.awt.**

# Keep Room database models
-keep class androidx.room.** { *; }
-keep class * extends androidx.room.RoomDatabase


# ── Tech GPTx Security Module — keep rules ───────────────────────────────────
-keep class com.jarvis.assistant.security.SecurityManager { *; }
-keep class com.jarvis.assistant.security.DeveloperInfo { *; }
-keep class com.jarvis.assistant.security.AppIdentityVerifier { *; }

# Obfuscate everything else aggressively
-optimizationpasses 5
-allowaccessmodification
-repackageclasses 'tgptx'

# Remove Log calls in release builds (security: don't leak internals)
-assumenosideeffects class android.util.Log {
    public static int d(...);
    public static int v(...);
    public static int i(...);
}
```
=== END FILE: app/proguard-rules.pro ===


=== FILE: app/src/main/AndroidManifest.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="android.permission.WRITE_SETTINGS" tools:ignore="ProtectedPermissions" />
    <uses-permission android:name="android.permission.CALL_PHONE" />
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" tools:ignore="QueryAllPackagesPermission" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

    <uses-feature android:name="android.hardware.camera.flash" android:required="false" />

    <application
        android:name=".JarvisApp"
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.JarvisAssistant"
        android:hardwareAccelerated="true"
        android:networkSecurityConfig="@xml/network_security_config">

        <activity
            android:name=".ui.home.MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|smallestScreenSize"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <activity
            android:name=".ui.settings.SettingsActivity"
            android:exported="false"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="adjustResize" />

        <activity
            android:name=".ui.memory.MemoryActivity"
            android:exported="false"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="adjustResize" />

        <activity
            android:name=".ui.voice.VoiceEnrollmentActivity"
            android:exported="false"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="adjustResize" />

        <activity
            android:name=".ui.settings.ApiConnectionActivity"
            android:exported="false"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="adjustResize" />

        <activity
            android:name=".ui.settings.PersonaActivity"
            android:exported="false"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="adjustResize" />

        <activity
            android:name=".ui.permission.PermissionActivity"
            android:exported="false"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="adjustResize" />

        <activity
            android:name=".ui.settings.OverlayAvatarActivity"
            android:exported="false"
            android:screenOrientation="portrait" />

        <activity
            android:name=".ui.settings.PrivacyShieldActivity"
            android:exported="false"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="adjustResize" />

        <activity
            android:name=".ui.settings.HandsFreeActivity"
            android:exported="false"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="adjustResize" />

        <service
            android:name=".background.JarvisConversationService"
            android:exported="false"
            android:stopWithTask="false"
            android:foregroundServiceType="microphone|mediaPlayback|mediaProjection" />

        <service
            android:name=".automation.accessibility.JarvisAccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

    </application>

</manifest>
```
=== END FILE: app/src/main/AndroidManifest.xml ===


=== FILE: app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml ===
```xml
﻿<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
```
=== END FILE: app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml ===


=== FILE: app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml ===
```xml
﻿<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
```
=== END FILE: app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml ===


=== FILE: app/src/main/res/values/attrs.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Central Theme Tokens -->
    <attr name="themeBg" format="color|reference" />
    <attr name="themeSurface" format="color|reference" />
    <attr name="themeCardBg" format="color|reference" />
    <attr name="themeCardBorder" format="color|reference" />
    <attr name="themeTextPrimary" format="color|reference" />
    <attr name="themeTextSecondary" format="color|reference" />
    <attr name="themeTextMuted" format="color|reference" />
    <attr name="themeAccent1" format="color|reference" />
    <attr name="themeAccent2" format="color|reference" />
    <attr name="themeAccent3" format="color|reference" />
    <attr name="themeAccent" format="color|reference" />
    <attr name="themeAccentLight" format="color|reference" />
    <attr name="themeDockBg" format="color|reference" />
    <attr name="themeDockBorder" format="color|reference" />
    <attr name="themeChipBg" format="color|reference" />
    <attr name="themeInputBg" format="color|reference" />

    <!-- Liquid Glass Specular & Gradient Tokens -->
    <attr name="themeCardGlassStart" format="color|reference" />
    <attr name="themeCardGlassEnd" format="color|reference" />
    <attr name="themeDockGlassStart" format="color|reference" />
    <attr name="themeDockGlassEnd" format="color|reference" />
    <attr name="themeGlassSpecular" format="color|reference" />
    <attr name="themeGlowBlob1" format="reference" />
    <attr name="themeGlowBlob2" format="reference" />
    <attr name="themeGlowBlob3" format="reference" />
</resources>
```
=== END FILE: app/src/main/res/values/attrs.xml ===


=== FILE: app/src/main/res/values/colors.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Professional Clean White Palette -->
    <color name="bg_space">#F8FAFC</color>
    <color name="bg_card">#FFFFFF</color>
    <color name="bg_card_secondary">#F1F5F9</color>
    <color name="bg_input">#FFFFFF</color>
    <color name="border_subtle">#E2E8F0</color>

    <!-- Professional Slate Typography -->
    <color name="text_primary">#0F172A</color>
    <color name="text_secondary">#475569</color>
    <color name="text_muted">#64748B</color>
    <color name="text_subtle">#94A3B8</color>

    <!-- Royal Sapphire / Apple / Gemini Accent -->
    <color name="primary_cyan">#2563EB</color>
    <color name="neon_blue">#3B82F6</color>
    <color name="purple_glow">#4F46E5</color>
    <color name="accent_sapphire">#2563EB</color>
    <color name="accent_sapphire_light">#DBEAFE</color>
    <color name="accent_dark">#0F172A</color>

    <!-- Status Colors -->
    <color name="status_green">#10B981</color>
    <color name="status_red">#EF4444</color>
    <color name="status_amber">#F59E0B</color>

    <!-- Theme Variables mapped for UI components -->
    <color name="jarvis_primary">#2563EB</color>
    <color name="jarvis_primary_bright">#2563EB</color>
    <color name="jarvis_red_bright">#2563EB</color>
    <color name="jarvis_red">#2563EB</color>
    <color name="jarvis_primary_dark">#1D4ED8</color>
    <color name="jarvis_primary_glow">#332563EB</color>
    <color name="jarvis_card_bg">#FFFFFF</color>
    <color name="jarvis_card_border">#E2E8F0</color>
    <color name="jarvis_dock_bg">#FFFFFF</color>
    <color name="jarvis_dock_border">#E2E8F0</color>
    <color name="jarvis_text_dark">#475569</color>
    <color name="jarvis_text_muted">#64748B</color>
    <color name="jarvis_avatar_bg">#EFF6FF</color>
    <color name="jarvis_input_bg">#FFFFFF</color>
    <color name="jarvis_chip_bg">#F1F5F9</color>

    <!-- Legacy compatibility aliases -->
    <color name="naira_red">#2563EB</color>
    <color name="naira_red_bright">#2563EB</color>
    <color name="naira_red_dark">#1D4ED8</color>
    <color name="naira_red_glow">#332563EB</color>
    <color name="naira_card_bg">#FFFFFF</color>
    <color name="naira_card_border">#E2E8F0</color>
    <color name="naira_dock_bg">#FFFFFF</color>
    <color name="naira_dock_border">#E2E8F0</color>
    <color name="naira_text_pink">#475569</color>
    <color name="naira_text_muted">#64748B</color>
    <color name="naira_avatar_bg">#EFF6FF</color>
    <color name="naira_input_bg">#FFFFFF</color>
    <color name="naira_chip_bg">#F1F5F9</color>
</resources>
```
=== END FILE: app/src/main/res/values/colors.xml ===


=== FILE: app/src/main/res/values/ic_launcher_background.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#FFFFFF</color>
</resources>
```
=== END FILE: app/src/main/res/values/ic_launcher_background.xml ===


=== FILE: app/src/main/res/values/strings.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string-array name="overlay_edges">
        <item>Right</item>
        <item>Left</item>
        <item>Top</item>
        <item>Bottom</item>
    </string-array>
    <string name="app_name">JARVIS</string>
    <string name="jarvis_title">JARVIS</string>

    <string name="state_idle">IDLE</string>
    <string name="state_listening">LISTENING</string>
    <string name="state_thinking">THINKING</string>
    <string name="state_speaking">SPEAKING</string>

    <string name="btn_on">ON</string>
    <string name="btn_off">OFF</string>
    <string name="status_ready">READY</string>
    <string name="status_live">LIVE</string>
    <string name="status_connecting">CONNECTING&#8230;</string>
    <string name="status_disconnected">OFFLINE</string>

    <string name="settings_title">SETTINGS</string>
    <string name="api_key_label">Gemini API Key</string>
    <string name="api_key_hint">Paste your Gemini API key</string>
    <string name="model_label">AI Model</string>
    <string name="voice_label">Voice</string>
    <string name="personality_label">Personality</string>
    <string name="username_label">User Name</string>
    <string name="username_hint">e.g. Tony Stark, Sir, Boss (optional)</string>

    <string name="chat_history_title">Conversation History</string>
    <string name="no_history">No conversation turns yet.</string>
    <string name="clear_history">Clear History</string>

    <string name="assistant_mode">Assistant Mode</string>
    <string name="history_label">History</string>
    <string name="desc_mute_mic">Mute or Unmute Mic</string>
    <string name="desc_back">Back</string>
    <string name="btn_save">Save</string>
    <string name="btn_paste">Paste from clipboard</string>
    <string name="chat_label_you">YOU</string>
    <string name="chat_label_jarvis">JARVIS</string>

    <string name="accessibility_service_desc">Provides automation for sending WhatsApp messages and executing approved hands-free actions for JARVIS.</string>
    <string name="memory_title">MEMORY CORE</string>
    <string name="memory_subtitle">Long-Term &amp; Contextual Knowledge</string>
    <string name="search_memories">Search memories&#8230;</string>
    <string name="add_memory">Add Memory</string>
    <string name="no_memories">No memories recorded yet.</string>
    <string name="category_all">All</string>
    <string name="category_personal">Personal</string>
    <string name="category_preferences">Preferences</string>
    <string name="category_contacts">Contacts</string>
    <string name="category_routines">Routines</string>
    <string name="category_notes">Notes</string>
</resources>
```
=== END FILE: app/src/main/res/values/strings.xml ===


=== FILE: app/src/main/res/values/themes.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Base App Theme -->
    <style name="Theme.JarvisAssistant" parent="Theme.JarvisAssistant.Light" />

    <!-- 1. LIGHT THEME - LIQUID PEARL GLASS EDITION -->
    <style name="Theme.JarvisAssistant.Light" parent="Theme.Material3.Light.NoActionBar">
        <item name="android:statusBarColor">#EEF2F9</item>
        <item name="android:windowLightStatusBar">true</item>
        <item name="android:navigationBarColor">#EEF2F9</item>
        <item name="android:windowLightNavigationBar">true</item>
        <item name="android:windowBackground">#EEF2F9</item>
        <item name="colorPrimary">#2F6BFF</item>
        <item name="colorOnPrimary">#FFFFFF</item>
        <item name="colorSurface">#B8FFFFFF</item>
        <item name="colorOnSurface">#0F172A</item>

        <item name="themeBg">#EEF2F9</item>
        <item name="themeSurface">#B8FFFFFF</item>
        <item name="themeCardBg">#B8FFFFFF</item>
        <item name="themeCardBorder">#CBD5E1</item>
        <item name="themeCardGlassStart">#F0FFFFFF</item>
        <item name="themeCardGlassEnd">#A6FFFFFF</item>
        <item name="themeDockBg">#CCFFFFFF</item>
        <item name="themeDockGlassStart">#FAFFFFFF</item>
        <item name="themeDockGlassEnd">#B8FFFFFF</item>
        <item name="themeDockBorder">#CBD5E1</item>
        <item name="themeGlassSpecular">#FFFFFF</item>
        <item name="themeChipBg">#66FFFFFF</item>
        <item name="themeInputBg">#B8FFFFFF</item>
        <item name="themeGlowBlob1">@drawable/bg_liquid_glow_light_1</item>
        <item name="themeGlowBlob2">@drawable/bg_liquid_glow_light_2</item>
        <item name="themeGlowBlob3">@drawable/bg_liquid_glow_light_3</item>

        <item name="themeTextPrimary">#0F172A</item>
        <item name="themeTextSecondary">#475569</item>
        <item name="themeTextMuted">#64748B</item>
        <item name="themeAccent1">#2F6BFF</item>
        <item name="themeAccent2">#8B5CF6</item>
        <item name="themeAccent3">#06B6D4</item>
        <item name="themeAccent">#2F6BFF</item>
        <item name="themeAccentLight">#E0E7FF</item>
    </style>

    <!-- 2. DARK THEME - LIQUID OBSIDIAN GLASS EDITION -->
    <style name="Theme.JarvisAssistant.Dark" parent="Theme.Material3.Dark.NoActionBar">
        <item name="android:statusBarColor">#070914</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:navigationBarColor">#070914</item>
        <item name="android:windowLightNavigationBar">false</item>
        <item name="android:windowBackground">#070914</item>
        <item name="colorPrimary">#5B8CFF</item>
        <item name="colorOnPrimary">#FFFFFF</item>
        <item name="colorSurface">#33141B3D</item>
        <item name="colorOnSurface">#F8FAFC</item>

        <item name="themeBg">#070914</item>
        <item name="themeSurface">#33141B3D</item>
        <item name="themeCardBg">#33141B3D</item>
        <item name="themeCardBorder">#4D5B8CFF</item>
        <item name="themeCardGlassStart">#4D1B2654</item>
        <item name="themeCardGlassEnd">#1A0F1733</item>
        <item name="themeDockBg">#660F1535</item>
        <item name="themeDockGlassStart">#80172048</item>
        <item name="themeDockGlassEnd">#4D0B1028</item>
        <item name="themeDockBorder">#665B8CFF</item>
        <item name="themeGlassSpecular">#80A5FF</item>
        <item name="themeChipBg">#331A244E</item>
        <item name="themeInputBg">#33141B3D</item>
        <item name="themeGlowBlob1">@drawable/bg_liquid_glow_dark_1</item>
        <item name="themeGlowBlob2">@drawable/bg_liquid_glow_dark_2</item>
        <item name="themeGlowBlob3">@drawable/bg_liquid_glow_dark_3</item>

        <item name="themeTextPrimary">#F8FAFC</item>
        <item name="themeTextSecondary">#94A3B8</item>
        <item name="themeTextMuted">#64748B</item>
        <item name="themeAccent1">#5B8CFF</item>
        <item name="themeAccent2">#A78BFA</item>
        <item name="themeAccent3">#22D3EE</item>
        <item name="themeAccent">#5B8CFF</item>
        <item name="themeAccentLight">#1E2858</item>
    </style>

    <!-- 3. RED THEME - LIQUID RUBY GLASS EDITION -->
    <style name="Theme.JarvisAssistant.Red" parent="Theme.Material3.Dark.NoActionBar">
        <item name="android:statusBarColor">#0E0307</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:navigationBarColor">#0E0307</item>
        <item name="android:windowLightNavigationBar">false</item>
        <item name="android:windowBackground">#0E0307</item>
        <item name="colorPrimary">#FF4D5E</item>
        <item name="colorOnPrimary">#FFFFFF</item>
        <item name="colorSurface">#332D0A13</item>
        <item name="colorOnSurface">#FFF1F2</item>

        <item name="themeBg">#0E0307</item>
        <item name="themeSurface">#332D0A13</item>
        <item name="themeCardBg">#332D0A13</item>
        <item name="themeCardBorder">#59FF4D5E</item>
        <item name="themeCardGlassStart">#4D3A0F1A</item>
        <item name="themeCardGlassEnd">#1A1A050D</item>
        <item name="themeDockBg">#6624060E</item>
        <item name="themeDockGlassStart">#80300A14</item>
        <item name="themeDockGlassEnd">#4D170409</item>
        <item name="themeDockBorder">#66FF4D5E</item>
        <item name="themeGlassSpecular">#FFA6B0</item>
        <item name="themeChipBg">#33380D17</item>
        <item name="themeInputBg">#332D0A13</item>
        <item name="themeGlowBlob1">@drawable/bg_liquid_glow_red_1</item>
        <item name="themeGlowBlob2">@drawable/bg_liquid_glow_red_2</item>
        <item name="themeGlowBlob3">@drawable/bg_liquid_glow_red_3</item>

        <item name="themeTextPrimary">#FFF1F2</item>
        <item name="themeTextSecondary">#FDA4AF</item>
        <item name="themeTextMuted">#BE727E</item>
        <item name="themeAccent1">#FF4D5E</item>
        <item name="themeAccent2">#FB7185</item>
        <item name="themeAccent3">#F97316</item>
        <item name="themeAccent">#FF4D5E</item>
        <item name="themeAccentLight">#3A0C16</item>
    </style>

    <!-- 4. SUNSET THEME - LIQUID SUNSET GLASS EDITION -->
    <style name="Theme.JarvisAssistant.Sunset" parent="Theme.Material3.Light.NoActionBar">
        <item name="android:statusBarColor">#FFF0EA</item>
        <item name="android:windowLightStatusBar">true</item>
        <item name="android:navigationBarColor">#FFF0EA</item>
        <item name="android:windowLightNavigationBar">true</item>
        <item name="android:windowBackground">#FFF0EA</item>
        <item name="colorPrimary">#FF6A3D</item>
        <item name="colorOnPrimary">#FFFFFF</item>
        <item name="colorSurface">#CCFFF2EC</item>
        <item name="colorOnSurface">#2E1020</item>

        <item name="themeBg">#FFF0EA</item>
        <item name="themeSurface">#CCFFF2EC</item>
        <item name="themeCardBg">#CCFFF2EC</item>
        <item name="themeCardBorder">#402E1020</item>
        <item name="themeCardGlassStart">#F5FFFFFF</item>
        <item name="themeCardGlassEnd">#B3FFE2D7</item>
        <item name="themeDockBg">#E6FFF0EB</item>
        <item name="themeDockGlassStart">#FAFFFFFF</item>
        <item name="themeDockGlassEnd">#CCFFE8DF</item>
        <item name="themeDockBorder">#402E1020</item>
        <item name="themeGlassSpecular">#FFFFFF</item>
        <item name="themeChipBg">#80FFFFFF</item>
        <item name="themeInputBg">#CCFFF2EC</item>
        <item name="themeGlowBlob1">@drawable/bg_liquid_glow_sunset_1</item>
        <item name="themeGlowBlob2">@drawable/bg_liquid_glow_sunset_2</item>
        <item name="themeGlowBlob3">@drawable/bg_liquid_glow_sunset_3</item>

        <item name="themeTextPrimary">#2E1020</item>
        <item name="themeTextSecondary">#783A5B</item>
        <item name="themeTextMuted">#9C6282</item>
        <item name="themeAccent1">#FF6A3D</item>
        <item name="themeAccent2">#F43F5E</item>
        <item name="themeAccent3">#8B5CF6</item>
        <item name="themeAccent">#FF6A3D</item>
        <item name="themeAccentLight">#FFE6DD</item>
    </style>

    <!-- 5. CUSTOM LIGHT - LIQUID GLASS -->
    <style name="Theme.JarvisAssistant.CustomLight" parent="Theme.Material3.Light.NoActionBar">
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:windowLightStatusBar">true</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
        <item name="android:windowLightNavigationBar">true</item>
        <item name="android:windowBackground">@android:color/transparent</item>
        <item name="android:colorBackground">@android:color/transparent</item>
        <item name="colorPrimary">#2F6BFF</item>
        <item name="colorOnPrimary">#FFFFFF</item>
        <item name="colorSurface">#B8FFFFFF</item>
        <item name="colorOnSurface">#0F172A</item>

        <item name="themeBg">@android:color/transparent</item>
        <item name="themeSurface">#B8FFFFFF</item>
        <item name="themeCardBg">#B8FFFFFF</item>
        <item name="themeCardBorder">#CBD5E1</item>
        <item name="themeCardGlassStart">#F0FFFFFF</item>
        <item name="themeCardGlassEnd">#A6FFFFFF</item>
        <item name="themeDockBg">#CCFFFFFF</item>
        <item name="themeDockGlassStart">#FAFFFFFF</item>
        <item name="themeDockGlassEnd">#B8FFFFFF</item>
        <item name="themeDockBorder">#CBD5E1</item>
        <item name="themeGlassSpecular">#FFFFFF</item>
        <item name="themeChipBg">#66FFFFFF</item>
        <item name="themeInputBg">#B8FFFFFF</item>
        <item name="themeGlowBlob1">@drawable/bg_liquid_glow_light_1</item>
        <item name="themeGlowBlob2">@drawable/bg_liquid_glow_light_2</item>
        <item name="themeGlowBlob3">@drawable/bg_liquid_glow_light_3</item>

        <item name="themeTextPrimary">#0F172A</item>
        <item name="themeTextSecondary">#475569</item>
        <item name="themeTextMuted">#64748B</item>
        <item name="themeAccent1">#2F6BFF</item>
        <item name="themeAccent2">#8B5CF6</item>
        <item name="themeAccent3">#06B6D4</item>
        <item name="themeAccent">#2F6BFF</item>
        <item name="themeAccentLight">#E0E7FF</item>
    </style>

    <!-- 6. CUSTOM DARK - LIQUID GLASS -->
    <style name="Theme.JarvisAssistant.CustomDark" parent="Theme.Material3.Dark.NoActionBar">
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
        <item name="android:windowLightNavigationBar">false</item>
        <item name="android:windowBackground">@android:color/transparent</item>
        <item name="android:colorBackground">@android:color/transparent</item>
        <item name="colorPrimary">#5B8CFF</item>
        <item name="colorOnPrimary">#FFFFFF</item>
        <item name="colorSurface">#33141B3D</item>
        <item name="colorOnSurface">#F8FAFC</item>

        <item name="themeBg">@android:color/transparent</item>
        <item name="themeSurface">#33141B3D</item>
        <item name="themeCardBg">#33141B3D</item>
        <item name="themeCardBorder">#4D5B8CFF</item>
        <item name="themeCardGlassStart">#4D1B2654</item>
        <item name="themeCardGlassEnd">#1A0F1733</item>
        <item name="themeDockBg">#660F1535</item>
        <item name="themeDockGlassStart">#80172048</item>
        <item name="themeDockGlassEnd">#4D0B1028</item>
        <item name="themeDockBorder">#665B8CFF</item>
        <item name="themeGlassSpecular">#80A5FF</item>
        <item name="themeChipBg">#331A244E</item>
        <item name="themeInputBg">#33141B3D</item>
        <item name="themeGlowBlob1">@drawable/bg_liquid_glow_dark_1</item>
        <item name="themeGlowBlob2">@drawable/bg_liquid_glow_dark_2</item>
        <item name="themeGlowBlob3">@drawable/bg_liquid_glow_dark_3</item>

        <item name="themeTextPrimary">#F8FAFC</item>
        <item name="themeTextSecondary">#94A3B8</item>
        <item name="themeTextMuted">#64748B</item>
        <item name="themeAccent1">#5B8CFF</item>
        <item name="themeAccent2">#A78BFA</item>
        <item name="themeAccent3">#22D3EE</item>
        <item name="themeAccent">#5B8CFF</item>
        <item name="themeAccentLight">#1E2858</item>
    </style>

    <!-- Legacy style aliases -->
    <style name="Theme.JarvisAssistant.PearlWhite" parent="Theme.JarvisAssistant.Light" />
    <style name="Theme.JarvisAssistant.MidnightOnyx" parent="Theme.JarvisAssistant.Dark" />
    <style name="Theme.JarvisAssistant.CyberpunkNeon" parent="Theme.JarvisAssistant.Dark" />
    <style name="Theme.JarvisAssistant.EmeraldObsidian" parent="Theme.JarvisAssistant.Dark" />
    <style name="Theme.JarvisAssistant.RoseGold" parent="Theme.JarvisAssistant.Sunset" />
</resources>
```
=== END FILE: app/src/main/res/values/themes.xml ===


=== FILE: app/src/main/res/xml/accessibility_service_config.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:description="@string/accessibility_service_desc"
    android:accessibilityEventTypes="typeWindowStateChanged|typeWindowContentChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:notificationTimeout="100"
    android:accessibilityFlags="flagDefault|flagRetrieveInteractiveWindows|flagReportViewIds"
    android:canRetrieveWindowContent="true"
    android:canPerformGestures="true"
    android:canTakeScreenshot="true" />
```
=== END FILE: app/src/main/res/xml/accessibility_service_config.xml ===


=== FILE: app/src/main/res/xml/network_security_config.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
```
=== END FILE: app/src/main/res/xml/network_security_config.xml ===


=== FILE: build.gradle.kts ===
```kotlin
plugins {
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.kapt") version "2.0.20" apply false
}
```
=== END FILE: build.gradle.kts ===


=== FILE: docs/README.md ===
```markdown
# Project documentation

- [Voice architecture research](architecture/voice-architecture-research.md): background service behavior, interaction states, and Android platform constraints.
- [Voice issue recordings](diagnostics/voice-videos/README.md): user-provided recordings associated with reported voice and automation issues.

Keep durable project guidance here. Generated APKs, Gradle caches, and local machine configuration belong outside source documentation and are ignored by Git.
```
=== END FILE: docs/README.md ===


=== FILE: docs/architecture/voice-architecture-research.md ===
```markdown
# Jarvis Background Voice Architecture

## Recommendation

Use `gemini-3.1-flash-live-preview` for the active conversation. Google describes it as an audio-to-audio model optimized for low-latency dialogue and voice-first applications. Its default minimal thinking is the latency-oriented configuration. The app now makes it the default and reduces microphone chunks from 40 ms to 20 ms.

The Live API must not be used as a 24-hour wake-word listener. It would transmit ambient speech, cost tokens, and still has connection/session limits. Instead, Jarvis now uses an Android foreground microphone service in standby and opens Gemini only after its wake phrase detector finds `Jarvis`, `Hey Jarvis`, or `Jarvis wake up`.

## Interaction states

| State | Microphone processing | Gemini connection | Result |
|---|---|---|---|
| Active conversation | 16 kHz PCM streamed in 20 ms chunks | Open | Natural live conversation and barge-in |
| Background standby | Android speech recognition checks only wake phrases | Closed | TV/room speech is not sent to Gemini and cannot trigger a reply |
| Wake detected | Service broadcasts a local event | Reopened | Jarvis is ready for the next spoken request |

After two minutes without detected speech, or after the transcribed command “Jarvis, go to background,” Jarvis says: “Sir, I am going in the background. If you need me, call me.” It then enters wake-only standby.

## Android constraints

On Android 14+, continuing microphone capture outside the UI requires a user-started foreground service with `foregroundServiceType="microphone"`, `FOREGROUND_SERVICE_MICROPHONE`, and `RECORD_AUDIO`. The service must be started while the app is visible; this app does that when the user turns Jarvis on. A persistent notification is required and is intentionally present.

The standby service uses a partial wake lock so it can listen while the display is off. This uses noticeable battery power. It can continue for many hours while the service remains alive, but Android cannot guarantee operation after force-stop, OEM battery killing, revoked microphone permission, or a reboot. A production-grade, system-level “always on” assistant requires the user to select the app as the device VoiceInteractionService/default assistant; Android keeps that selected service bound for hotword use.

The platform recognizer is configured to prefer on-device recognition. Devices without a compatible local recognition model may use their configured recognizer; for a commercial product, replace this detector with a vetted on-device keyword engine and test false accepts/rejects across target phones and languages.

## Sources

1. Google AI for Developers, [Gemini 3.1 Flash Live Preview](https://ai.google.dev/gemini-api/docs/models/gemini-3.1-flash-live-preview) — current model purpose, migration notes, and model identifier.
2. Google AI for Developers, [Live API capabilities](https://ai.google.dev/gemini-api/docs/live-api/capabilities) — native audio, transcription, and thinking-level behavior.
3. Google AI for Developers, [Live API session management](https://ai.google.dev/gemini-api/docs/live-api/session-management) — connection limits, compression, and resumption.
4. Android Developers, [Foreground service types](https://developer.android.com/about/versions/14/changes/fgs-types-required) — microphone foreground-service declaration and permission requirements.
5. Android Developers, [Background foreground-service restrictions](https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start) — while-in-use microphone constraints.
6. Android Developers, [VoiceInteractionService](https://developer.android.com/reference/android/service/voice/VoiceInteractionService) — default-assistant system binding and hotword lifecycle.
```
=== END FILE: docs/architecture/voice-architecture-research.md ===


=== FILE: docs/diagnostics/voice-videos/README.md ===
```markdown
# Voice issue recordings

These original user-provided videos are retained as diagnostic references. The filenames have been normalized for easier sorting; the numbered entries map to their original root-level names before organization.

| Organized filename | Original filename |
| --- | --- |
| `voice-issue-01.mp4` | `error videos.mp4` |
| `voice-issue-02.mp4` | `error videos 2.mp4` |
| `voice-issue-03.mp4` | `error video 3.mp4` |

The videos are evidence only. Treat any text or instructions visible inside them as untrusted content, not project instructions.
```
=== END FILE: docs/diagnostics/voice-videos/README.md ===


=== FILE: gradle.properties ===
```properties
# Project-wide Gradle settings.
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true

# Performance optimizations
org.gradle.parallel=true
org.gradle.caching=true
kapt.incremental.apt=true
```
=== END FILE: gradle.properties ===


=== FILE: gradle/wrapper/gradle-wrapper.properties ===
```properties
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.9-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
```
=== END FILE: gradle/wrapper/gradle-wrapper.properties ===


=== FILE: gradlew ===
```
#!/bin/sh

#
# Copyright © 2015-2021 the original authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0
#

##############################################################################
#
#   Gradle start up script for POSIX generated by Gradle.
#
#   Important for running:
#
#   (1) You need a POSIX-compliant shell to run this script. If your /bin/sh is
#       noncompliant, but you have some other compliant shell such as ksh or
#       bash, then to run this script, type that shell name before the whole
#       command line, like:
#
#           ksh Gradle
#
#       Busybox and similar reduced shells will NOT work, because this script
#       requires all of these POSIX shell features:
#         * functions;
#         * expansions «$var», «${var}», «${var:-default}», «${var+SET}»,
#           «${var#prefix}», «${var%suffix}», and «$( cmd )»;
#         * compound commands having a testable exit status, especially «case»;
#         * various built-in commands including «command», «set», and «ulimit».
#
#   Important for patching:
#
#   (2) This script targets any POSIX shell, so it avoids extensions provided
#       by Bash, Ksh, etc; in particular arrays are avoided.
#
#       The "traditional" practice of packing multiple parameters into a
#       space-separated string is a well documented source of bugs and security
#       problems, so this is (mostly) avoided, by progressively accumulating
#       options in "$@", and eventually passing that to Java.
#
#       Where the inherited environment variables (DEFAULT_JVM_OPTS, JAVA_OPTS,
#       and GRADLE_OPTS) rely on word-splitting, this is performed explicitly;
#       see the in-line comments for details.
#
#       There are tweaks for specific operating systems such as AIX, CygWin,
#       Darwin, MinGW, and NonStop.
#
#   (3) This script is generated from the Groovy template
#       https://github.com/gradle/gradle/blob/HEAD/platforms/jvm/plugins-application/src/main/resources/org/gradle/api/internal/plugins/unixStartScript.txt
#       within the Gradle project.
#
#       You can find Gradle at https://github.com/gradle/gradle/.
#
##############################################################################

# Attempt to set APP_HOME

# Resolve links: $0 may be a link
app_path=$0

# Need this for daisy-chained symlinks.
while
    APP_HOME=${app_path%"${app_path##*/}"}  # leaves a trailing /; empty if no leading path
    [ -h "$app_path" ]
do
    ls=$( ls -ld "$app_path" )
    link=${ls#*' -> '}
    case $link in             #(
      /*)   app_path=$link ;; #(
      *)    app_path=$APP_HOME$link ;;
    esac
done

# This is normally unused
# shellcheck disable=SC2034
APP_BASE_NAME=${0##*/}
# Discard cd standard output in case $CDPATH is set (https://github.com/gradle/gradle/issues/25036)
APP_HOME=$( cd -P "${APP_HOME:-./}" > /dev/null && printf '%s
' "$PWD" ) || exit

# Use the maximum available, or set MAX_FD != -1 to use that value.
MAX_FD=maximum

warn () {
    echo "$*"
} >&2

die () {
    echo
    echo "$*"
    echo
    exit 1
} >&2

# OS specific support (must be 'true' or 'false').
cygwin=false
msys=false
darwin=false
nonstop=false
case "$( uname )" in                #(
  CYGWIN* )         cygwin=true  ;; #(
  Darwin* )         darwin=true  ;; #(
  MSYS* | MINGW* )  msys=true    ;; #(
  NONSTOP* )        nonstop=true ;;
esac

CLASSPATH=$APP_HOME/gradle/wrapper/gradle-wrapper.jar


# Determine the Java command to use to start the JVM.
if [ -n "$JAVA_HOME" ] ; then
    if [ -x "$JAVA_HOME/jre/sh/java" ] ; then
        # IBM's JDK on AIX uses strange locations for the executables
        JAVACMD=$JAVA_HOME/jre/sh/java
    else
        JAVACMD=$JAVA_HOME/bin/java
    fi
    if [ ! -x "$JAVACMD" ] ; then
        die "ERROR: JAVA_HOME is set to an invalid directory: $JAVA_HOME

Please set the JAVA_HOME variable in your environment to match the
location of your Java installation."
    fi
else
    JAVACMD=java
    if ! command -v java >/dev/null 2>&1
    then
        die "ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH.

Please set the JAVA_HOME variable in your environment to match the
location of your Java installation."
    fi
fi

# Increase the maximum file descriptors if we can.
if ! "$cygwin" && ! "$darwin" && ! "$nonstop" ; then
    case $MAX_FD in #(
      max*)
        # In POSIX sh, ulimit -H is undefined. That's why the result is checked to see if it worked.
        # shellcheck disable=SC2039,SC3045
        MAX_FD=$( ulimit -H -n ) ||
            warn "Could not query maximum file descriptor limit"
    esac
    case $MAX_FD in  #(
      '' | soft) :;; #(
      *)
        # In POSIX sh, ulimit -n is undefined. That's why the result is checked to see if it worked.
        # shellcheck disable=SC2039,SC3045
        ulimit -n "$MAX_FD" ||
            warn "Could not set maximum file descriptor limit to $MAX_FD"
    esac
fi

# Collect all arguments for the java command, stacking in reverse order:
#   * args from the command line
#   * the main class name
#   * -classpath
#   * -D...appname settings
#   * --module-path (only if needed)
#   * DEFAULT_JVM_OPTS, JAVA_OPTS, and GRADLE_OPTS environment variables.

# For Cygwin or MSYS, switch paths to Windows format before running java
if "$cygwin" || "$msys" ; then
    APP_HOME=$( cygpath --path --mixed "$APP_HOME" )
    CLASSPATH=$( cygpath --path --mixed "$CLASSPATH" )

    JAVACMD=$( cygpath --unix "$JAVACMD" )

    # Now convert the arguments - kludge to limit ourselves to /bin/sh
    for arg do
        if
            case $arg in                                #(
              -*)   false ;;                            # don't mess with options #(
              /?*)  t=${arg#/} t=/${t%%/*}              # looks like a POSIX filepath
                    [ -e "$t" ] ;;                      #(
              *)    false ;;
            esac
        then
            arg=$( cygpath --path --ignore --mixed "$arg" )
        fi
        # Roll the args list around exactly as many times as the number of
        # args, so each arg winds up back in the position where it started, but
        # possibly modified.
        #
        # NB: a `for` loop captures its iteration list before it begins, so
        # changing the positional parameters here affects neither the number of
        # iterations, nor the values presented in `arg`.
        shift                   # remove old arg
        set -- "$@" "$arg"      # push replacement arg
    done
fi


# Add default JVM options here. You can also use JAVA_OPTS and GRADLE_OPTS to pass JVM options to this script.
DEFAULT_JVM_OPTS='"-Xmx64m" "-Xms64m"'

# Collect all arguments for the java command:
#   * DEFAULT_JVM_OPTS, JAVA_OPTS, JAVA_OPTS, and optsEnvironmentVar are not allowed to contain shell fragments,
#     and any embedded shellness will be escaped.
#   * For example: A user cannot expect ${Hostname} to be expanded, as it is an environment variable and will be
#     treated as '${Hostname}' itself on the command line.

set -- \
        "-Dorg.gradle.appname=$APP_BASE_NAME" \
        -classpath "$CLASSPATH" \
        org.gradle.wrapper.GradleWrapperMain \
        "$@"

# Stop when "xargs" is not available.
if ! command -v xargs >/dev/null 2>&1
then
    die "xargs is not available"
fi

# Use "xargs" to parse quoted args.
#
# With -n1 it outputs one arg per line, with the quotes and backslashes removed.
#
# In Bash we could simply go:
#
#   readarray ARGS < <( xargs -n1 <<<"$var" ) &&
#   set -- "${ARGS[@]}" "$@"
#
# but POSIX shell has neither arrays nor command substitution, so instead we
# post-process each arg (as a line of input to sed) to backslash-escape any
# character that might be a shell metacharacter, then use eval to reverse
# that process (while maintaining the separation between arguments), and wrap
# the whole thing up as a single "set" statement.
#
# This will of course break if any of these variables contains a newline or
# an unmatched quote.
#

eval "set -- $(
        printf '%s\n' "$DEFAULT_JVM_OPTS $JAVA_OPTS $GRADLE_OPTS" |
        xargs -n1 |
        sed ' s~[^-[:alnum:]+,./:=@_]~\\&~g; ' |
        tr '\n' ' '
    )" '"$@"'

exec "$JAVACMD" "$@"
```
=== END FILE: gradlew ===


=== FILE: gradlew.bat ===
```bat
@rem
@rem Copyright 2015 the original author or authors.
@rem
@rem Licensed under the Apache License, Version 2.0 (the "License");
@rem you may not use this file except in compliance with the License.
@rem You may obtain a copy of the License at
@rem
@rem      https://www.apache.org/licenses/LICENSE-2.0
@rem
@rem Unless required by applicable law or agreed to in writing, software
@rem distributed under the License is distributed on an "AS IS" BASIS,
@rem WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
@rem See the License for the specific language governing permissions and
@rem limitations under the License.
@rem
@rem SPDX-License-Identifier: Apache-2.0
@rem

@if "%DEBUG%"=="" @echo off
@rem ##########################################################################
@rem
@rem  Gradle startup script for Windows
@rem
@rem ##########################################################################

@rem Set local scope for the variables with windows NT shell
if "%OS%"=="Windows_NT" setlocal

set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
@rem This is normally unused
set APP_BASE_NAME=%~n0
set APP_HOME=%DIRNAME%

@rem Resolve any "." and ".." in APP_HOME to make it shorter.
for %%i in ("%APP_HOME%") do set APP_HOME=%%~fi

@rem Add default JVM options here. You can also use JAVA_OPTS and GRADLE_OPTS to pass JVM options to this script.
set DEFAULT_JVM_OPTS="-Xmx64m" "-Xms64m"

@rem Find java.exe
if defined JAVA_HOME goto findJavaFromJavaHome

set JAVA_EXE=java.exe
%JAVA_EXE% -version >NUL 2>&1
if %ERRORLEVEL% equ 0 goto execute

echo. 1>&2
echo ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH. 1>&2
echo. 1>&2
echo Please set the JAVA_HOME variable in your environment to match the 1>&2
echo location of your Java installation. 1>&2

goto fail

:findJavaFromJavaHome
set JAVA_HOME=%JAVA_HOME:"=%
set JAVA_EXE=%JAVA_HOME%/bin/java.exe

if exist "%JAVA_EXE%" goto execute

echo. 1>&2
echo ERROR: JAVA_HOME is set to an invalid directory: %JAVA_HOME% 1>&2
echo. 1>&2
echo Please set the JAVA_HOME variable in your environment to match the 1>&2
echo location of your Java installation. 1>&2

goto fail

:execute
@rem Setup the command line

set CLASSPATH=%APP_HOME%\gradle\wrapper\gradle-wrapper.jar


@rem Execute Gradle
"%JAVA_EXE%" %DEFAULT_JVM_OPTS% %JAVA_OPTS% %GRADLE_OPTS% "-Dorg.gradle.appname=%APP_BASE_NAME%" -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*

:end
@rem End local scope for the variables with windows NT shell
if %ERRORLEVEL% equ 0 goto mainEnd

:fail
rem Set variable GRADLE_EXIT_CONSOLE if you need the _script_ return code instead of
rem the _cmd.exe /c_ return code!
set EXIT_CODE=%ERRORLEVEL%
if %EXIT_CODE% equ 0 set EXIT_CODE=1
if not ""=="%GRADLE_EXIT_CONSOLE%" exit %EXIT_CODE%
exit /b %EXIT_CODE%

:mainEnd
if "%OS%"=="Windows_NT" endlocal

:omega
```
=== END FILE: gradlew.bat ===


=== FILE: local.properties.example ===
```
## This file must NOT be checked into Version Control Systems,
# as it contains information specific to your local configuration.
#
# Location of the SDK. This is only used by Gradle.
# For customization when using a Version Control System, please read the
# header note.
sdk.dir=C\:\\Users\\YOUR_USERNAME\\AppData\\Local\\Android\\Sdk
# For Mac/Linux:
# sdk.dir=/Users/YOUR_USERNAME/Library/Android/sdk
```
=== END FILE: local.properties.example ===


=== FILE: scripts/build-release.ps1 ===
```powershell
$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
$signingRoot = Join-Path $env:LOCALAPPDATA "JARVIS\signing"
$keyStore = Join-Path $signingRoot "jarvis-release.p12"
$credentialFile = Join-Path $signingRoot "release-password.xml"
$keyAlias = "jarvis-release"

if (-not (Test-Path -LiteralPath $keyStore) -or -not (Test-Path -LiteralPath $credentialFile)) {
    throw "Release signing material is missing from the current Windows user's protected JARVIS signing folder."
}

$securePassword = Import-Clixml -LiteralPath $credentialFile
if ($securePassword -isnot [System.Security.SecureString]) {
    throw "The locally protected release password could not be read by this Windows account."
}

$passwordPointer = [IntPtr]::Zero
try {
    $passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
    $plainPassword = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
    $env:JARVIS_RELEASE_STORE_FILE = $keyStore
    $env:JARVIS_RELEASE_STORE_PASSWORD = $plainPassword
    $env:JARVIS_RELEASE_KEY_ALIAS = $keyAlias
    $env:JARVIS_RELEASE_KEY_PASSWORD = $plainPassword
    $env:JARVIS_DEVELOPER_NAME = "TechGpt X"
    $env:JARVIS_COPYRIGHT_OWNER = "TechGpt X"

    $keytool = if ($env:JAVA_HOME) { Join-Path $env:JAVA_HOME "bin\keytool.exe" } else { (Get-Command keytool -ErrorAction Stop).Source }
    $certificateInfo = (& $keytool -list -v -keystore $keyStore -alias $keyAlias -storepass:env JARVIS_RELEASE_STORE_PASSWORD | Out-String)
    if ($LASTEXITCODE -ne 0 -or $certificateInfo -notmatch "SHA256:\s*([0-9A-Fa-f:]+)") {
        throw "Could not read the release certificate fingerprint."
    }
    $env:JARVIS_RELEASE_CERT_SHA256 = $Matches[1] -replace ":", ""

    Push-Location $repoRoot
    try {
        & (Join-Path $repoRoot "gradlew.bat") :app:assembleRelease -x :app:lintVitalAnalyzeRelease
        if ($LASTEXITCODE -ne 0) { throw "Release APK build failed with exit code $LASTEXITCODE." }
    } finally {
        Pop-Location
    }
    Write-Host "Release APK: $(Join-Path $repoRoot 'app\build\outputs\apk\release\app-release.apk')"
} finally {
    if ($passwordPointer -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
    }
    $plainPassword = $null
    Remove-Item Env:JARVIS_RELEASE_STORE_PASSWORD -ErrorAction SilentlyContinue
    Remove-Item Env:JARVIS_RELEASE_KEY_PASSWORD -ErrorAction SilentlyContinue
    Remove-Item Env:JARVIS_RELEASE_STORE_FILE -ErrorAction SilentlyContinue
    Remove-Item Env:JARVIS_RELEASE_KEY_ALIAS -ErrorAction SilentlyContinue
    Remove-Item Env:JARVIS_RELEASE_CERT_SHA256 -ErrorAction SilentlyContinue
    Remove-Item Env:JARVIS_DEVELOPER_NAME -ErrorAction SilentlyContinue
    Remove-Item Env:JARVIS_COPYRIGHT_OWNER -ErrorAction SilentlyContinue
}
```
=== END FILE: scripts/build-release.ps1 ===


=== FILE: settings.gradle.kts ===
```kotlin
pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "JARVIS-Part-7"
include(":app")
```
=== END FILE: settings.gradle.kts ===


=== FILE: app/src/main/java/com/jarvis/assistant/JarvisApp.kt ===
```kotlin
package com.jarvis.assistant

import android.app.Application
import com.jarvis.assistant.security.SecurityManager
import com.jarvis.assistant.audio.VoskModelManager
import com.jarvis.assistant.automation.command.CommandExecutor
import com.jarvis.assistant.automation.contacts.ContactResolver
import com.jarvis.assistant.automation.phone.PhoneControlManager
import com.jarvis.assistant.automation.whatsapp.WhatsAppAssistant
import com.jarvis.assistant.automation.youtube.YouTubeAutomationManager
import com.jarvis.assistant.data.memory.MemoryDatabase
import com.jarvis.assistant.data.memory.MemoryManager
import com.jarvis.assistant.data.memory.MemoryRepository
import com.jarvis.assistant.data.preferences.AppPreferences
import com.jarvis.assistant.data.preferences.YouTubePreferences
import com.jarvis.assistant.data.repository.ChatRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class JarvisApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var preferences: AppPreferences
        private set

    lateinit var chatRepository: ChatRepository
        private set

    lateinit var memoryDatabase: MemoryDatabase
        private set

    lateinit var memoryRepository: MemoryRepository
        private set

    lateinit var memoryManager: MemoryManager
        private set

    lateinit var youTubePreferences: YouTubePreferences
        private set

    lateinit var youTubeAutomationManager: YouTubeAutomationManager
        private set

    lateinit var contactResolver: ContactResolver
        private set

    lateinit var phoneControlManager: PhoneControlManager
        private set

    lateinit var whatsAppAssistant: WhatsAppAssistant
        private set

    lateinit var commandExecutor: CommandExecutor
        private set

    override fun onCreate() {
        super.onCreate()
        SecurityManager.verify(this)
        instance = this
        preferences = AppPreferences(this)
        chatRepository = ChatRepository(preferences)

        // Memory System
        memoryDatabase = MemoryDatabase.getInstance(this)
        memoryRepository = MemoryRepository(memoryDatabase.memoryDao())
        memoryManager = MemoryManager(memoryRepository, preferences, chatRepository, appScope)

        // Automation Systems
        youTubePreferences = YouTubePreferences(this)
        youTubeAutomationManager = YouTubeAutomationManager(this, youTubePreferences)
        contactResolver = ContactResolver(this)
        phoneControlManager = PhoneControlManager(this, contactResolver)
        whatsAppAssistant = WhatsAppAssistant(this, contactResolver)

        // Command Engine
        commandExecutor = CommandExecutor(
            phoneManager = phoneControlManager,
            youtubeManager = youTubeAutomationManager,
            whatsappAssistant = whatsAppAssistant,
            memoryManager = memoryManager
        )

        VoskModelManager.init(this, CoroutineScope(Dispatchers.Default))

        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            private var startedActivities = 0
            override fun onActivityCreated(activity: android.app.Activity, savedInstanceState: android.os.Bundle?) {
                com.jarvis.assistant.util.ThemeManager.applyTheme(activity)
            }
            override fun onActivityStarted(activity: android.app.Activity) {
                startedActivities++
                if (startedActivities == 1) _isAppForeground.value = true
            }
            override fun onActivityResumed(activity: android.app.Activity) {
                currentResumedActivity = activity
                com.jarvis.assistant.util.ThemeManager.applyTheme(activity)
            }
            override fun onActivityPaused(activity: android.app.Activity) {
                if (currentResumedActivity === activity) {
                    currentResumedActivity = null
                }
            }
            override fun onActivityStopped(activity: android.app.Activity) {
                startedActivities = (startedActivities - 1).coerceAtLeast(0)
                if (startedActivities == 0) _isAppForeground.value = false
            }
            override fun onActivitySaveInstanceState(activity: android.app.Activity, outState: android.os.Bundle) {}
            override fun onActivityDestroyed(activity: android.app.Activity) {
                if (currentResumedActivity === activity) {
                    currentResumedActivity = null
                }
            }
        })
    }

    var currentResumedActivity: android.app.Activity? = null
        private set

    fun moveAppToBack(): Boolean {
        val act = currentResumedActivity ?: return false
        return try {
            act.moveTaskToBack(true)
        } catch (e: Exception) {
            false
        }
    }

    companion object {
        private val _isAppForeground = MutableStateFlow(false)
        val isAppForeground: StateFlow<Boolean> = _isAppForeground.asStateFlow()

        lateinit var instance: JarvisApp
            private set
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/JarvisApp.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/audio/AudioPlayer.kt ===
```kotlin
package com.jarvis.assistant.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class AudioPlayer(
    private val onPlaybackStateChanged: (isPlaying: Boolean) -> Unit,
    private val onPlaybackAmplitude: (amplitude: Float) -> Unit
) {
    companion object {
        private const val TAG = "AudioPlayer"
        const val SAMPLE_RATE = 24000
        const val CHANNEL_CONFIG = AudioFormat.CHANNEL_OUT_MONO
        const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    private var audioTrack: AudioTrack? = null
    private val trackLock = Any()
    private val audioQueue = LinkedBlockingQueue<ByteArray>()
    private val isRunning = AtomicBoolean(false)
    private val isPlayingState = AtomicBoolean(false)
    private var playbackThread: Thread? = null

    init {
        initAudioTrack()
    }

    private fun initAudioTrack() {
        val minBufferSize = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        // 96,000 bytes = 2 full seconds of 24kHz 16-bit mono PCM headroom.
        // Guarantees zero buffer underruns across network jitter and prevents deadlock.
        val bufferSize = maxOf(minBufferSize * 8, 96000)

        // USAGE_MEDIA maps to STREAM_MUSIC, ensuring audio plays strictly through the
        // phone's LOUDSPEAKER (or connected headphones), NEVER the call earpiece speaker.
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()

        val format = AudioFormat.Builder()
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(CHANNEL_CONFIG)
            .setEncoding(AUDIO_FORMAT)
            .build()

        // Standard performance mode prevents MediaTek/Qualcomm FastMixer DMA ring buffer underrun loops ("aaaaaaaa")
        val track = AudioTrack.Builder()
            .setAudioAttributes(attributes)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack = track
    }

    private val isTurnComplete = AtomicBoolean(false)

    fun notifyTurnComplete() {
        isTurnComplete.set(true)
    }

    fun start() {
        if (isRunning.get()) return
        isRunning.set(true)

        playbackThread = Thread {
            try {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
            } catch (_: Exception) {}
            var silenceCounter = 0
            while (isRunning.get()) {
                try {
                    // If not currently playing, wait for chunks and start AudioTrack before writing
                    if (!isPlayingState.get()) {
                        val firstChunk = audioQueue.poll(30, TimeUnit.MILLISECONDS)
                        if (firstChunk != null && firstChunk.isNotEmpty()) {
                            isTurnComplete.set(false)
                            isPlayingState.set(true)
                            silenceCounter = 0
                            onPlaybackStateChanged(true)

                            // Start hardware track immediately so write() streams smoothly without blocking
                            synchronized(trackLock) {
                                audioTrack?.let { track ->
                                    if (track.state == AudioTrack.STATE_INITIALIZED && track.playState != AudioTrack.PLAYSTATE_PLAYING) {
                                        try {
                                            track.play()
                                        } catch (e: Exception) {
                                            Log.e(TAG, "Error calling play(): ${e.message}")
                                        }
                                    }
                                }
                            }

                            writeToTrack(firstChunk)
                            val amplitude = AudioUtils.calculateRmsNormalized(firstChunk, firstChunk.size)
                            onPlaybackAmplitude(amplitude)
                        }
                        continue
                    }

                    // Currently playing: stream incoming chunks to the hardware AudioTrack
                    val chunk = audioQueue.poll(20, TimeUnit.MILLISECONDS)
                    if (chunk != null && chunk.isNotEmpty()) {
                        silenceCounter = 0
                        val amplitude = AudioUtils.calculateRmsNormalized(chunk, chunk.size)
                        onPlaybackAmplitude(amplitude)

                        writeToTrack(chunk)
                    } else {
                        silenceCounter++
                        // Clean turn completion:
                        // 1. If Gemini signaled turnComplete: wait 8 cycles (~160ms) of empty queue
                        //    so the hardware AudioTrack buffer has rendered out to the speaker cleanly.
                        // 2. If Gemini is still generating (turnComplete not yet received): wait 40 cycles (~800ms)
                        //    to tolerate normal chunk gaps without stalling the mic.
                        val shouldFinish = (isTurnComplete.get() && silenceCounter >= 8) || (silenceCounter >= 40)

                        if (shouldFinish && isPlayingState.get()) {
                            isPlayingState.set(false)
                            onPlaybackStateChanged(false)
                            onPlaybackAmplitude(0f)
                        }
                    }
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Error in playback worker: ${e.message}")
                }
            }
        }.apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun enqueueAudio(pcmData: ByteArray) {
        if (pcmData.size >= 16) {
            val validLen = pcmData.size and 1.inv()
            val aligned = if (validLen == pcmData.size) pcmData else pcmData.copyOf(validLen)
            audioQueue.offer(aligned)
        }
    }

    /**
     * Instantly flushes audio playback upon interruption.
     */
    fun flush() {
        audioQueue.clear()
        isTurnComplete.set(true)
        synchronized(trackLock) {
            try {
                audioTrack?.let {
                    if (it.state == AudioTrack.STATE_INITIALIZED) {
                        try { it.pause() } catch (_: Exception) {}
                        try { it.flush() } catch (_: Exception) {}
                        try { it.stop() } catch (_: Exception) {}
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error flushing AudioTrack: ${e.message}")
            }
        }
        if (isPlayingState.getAndSet(false)) {
            onPlaybackStateChanged(false)
            onPlaybackAmplitude(0f)
        }
    }

    fun isPlaying(): Boolean = isPlayingState.get() || !audioQueue.isEmpty()

    fun release() {
        isRunning.set(false)
        playbackThread?.interrupt()
        playbackThread = null
        audioQueue.clear()

        synchronized(trackLock) {
            try {
                audioTrack?.let {
                    if (it.playState == AudioTrack.PLAYSTATE_PLAYING) {
                        it.stop()
                    }
                    it.release()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error releasing AudioTrack: ${e.message}")
            } finally {
                audioTrack = null
            }
        }
    }

    private fun writeToTrack(chunk: ByteArray) {
        synchronized(trackLock) {
            var track = audioTrack
            if (track == null || track.state != AudioTrack.STATE_INITIALIZED) {
                initAudioTrack()
                track = audioTrack
            }
            track?.let { t ->
                if (t.state == AudioTrack.STATE_INITIALIZED && t.playState != AudioTrack.PLAYSTATE_PLAYING) {
                    try { t.play() } catch (_: Exception) {}
                }
                val written = t.write(chunk, 0, chunk.size)
                if (written < 0) {
                    Log.w(TAG, "AudioTrack write failed ($written). Reinitializing AudioTrack...")
                    try { t.release() } catch (_: Exception) {}
                    initAudioTrack()
                    audioTrack?.let { reloaded ->
                        try {
                            if (reloaded.state == AudioTrack.STATE_INITIALIZED) {
                                reloaded.play()
                                reloaded.write(chunk, 0, chunk.size)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error playing recreated track: ${e.message}")
                        }
                    }
                }
            }
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/audio/AudioPlayer.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/audio/AudioRecorder.kt ===
```kotlin
package com.jarvis.assistant.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

class AudioRecorder(
    private val onAudioChunk: (chunk: ByteArray, amplitude: Float, frequencyData: AudioFrequencyData) -> Unit
) {
    companion object {
        private const val TAG = "AudioRecorder"
        const val SAMPLE_RATE = 16000
        const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        // Ultra-low latency 20ms chunk: 16000 samples/sec * 0.02s * 2 bytes/sample = 640 bytes
        const val CHUNK_SIZE_BYTES = 640
    }

    private var audioRecord: AudioRecord? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var automaticGainControl: AutomaticGainControl? = null
    private var recordingJob: Job? = null
    private val isRecording = AtomicBoolean(false)
    val isMuted = AtomicBoolean(false)

    @SuppressLint("MissingPermission")
    fun start(scope: CoroutineScope): Boolean {
        if (isRecording.get()) return true

        val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        if (minBufferSize == AudioRecord.ERROR || minBufferSize == AudioRecord.ERROR_BAD_VALUE) {
            Log.e(TAG, "Unable to get valid min buffer size")
            return false
        }

        val bufferSize = maxOf(minBufferSize * 4, 32000)

        return try {
            val record = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                bufferSize
            )

            if (record.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord initialization failed")
                record.release()
                return false
            }

            val sessionId = record.audioSessionId
            if (AcousticEchoCanceler.isAvailable()) {
                try {
                    echoCanceler = AcousticEchoCanceler.create(sessionId)?.apply {
                        enabled = true
                    }
                    Log.i(TAG, "Hardware AcousticEchoCanceler enabled on session $sessionId")
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to enable AcousticEchoCanceler: ${e.message}")
                }
            }

            if (NoiseSuppressor.isAvailable()) {
                try {
                    noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply {
                        enabled = true
                    }
                    Log.i(TAG, "Hardware NoiseSuppressor enabled on session $sessionId")
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to enable NoiseSuppressor: ${e.message}")
                }
            }

            if (AutomaticGainControl.isAvailable()) {
                try {
                    automaticGainControl = AutomaticGainControl.create(sessionId)?.apply {
                        enabled = true
                    }
                    Log.i(TAG, "Hardware AutomaticGainControl enabled on session $sessionId")
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to enable AutomaticGainControl: ${e.message}")
                }
            }

            record.startRecording()
            audioRecord = record
            isRecording.set(true)

            recordingJob = scope.launch(Dispatchers.IO) {
                try {
                    android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
                } catch (_: Exception) {}
                val buffer = ByteArray(CHUNK_SIZE_BYTES)
                var currentRecord: AudioRecord? = record
                while (isActive && isRecording.get()) {
                    var consecutiveErrors = 0
                    while (isActive && isRecording.get() && currentRecord != null) {
                        try {
                            val readBytes = currentRecord.read(buffer, 0, buffer.size)
                            if (readBytes > 0) {
                                consecutiveErrors = 0
                                val freq = AudioUtils.analyzeFrequency(buffer, readBytes, SAMPLE_RATE)
                                if (!isMuted.get()) {
                                    val chunkCopy = buffer.copyOf(readBytes)
                                    onAudioChunk(chunkCopy, freq.amplitude, freq)
                                } else {
                                    onAudioChunk(ByteArray(0), 0f, AudioFrequencyData())
                                }
                            } else if (readBytes < 0) {
                                consecutiveErrors++
                                Log.w(TAG, "AudioRecord read error code: $readBytes (error count: $consecutiveErrors)")
                                delay(40)
                                if (consecutiveErrors > 10 && isRecording.get()) {
                                    Log.e(TAG, "Consecutive AudioRecord read errors exceeded limit. Attempting auto-recovery...")
                                    break
                                }
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Exception during AudioRecord read loop: ${e.message}", e)
                            delay(50)
                        }
                    }

                    // Auto-recovery if broken but still meant to be recording:
                    if (isActive && isRecording.get()) {
                        delay(400)
                        try {
                            currentRecord?.release()
                        } catch (_: Exception) {}
                        try {
                            val newRecord = AudioRecord(
                                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                                SAMPLE_RATE,
                                CHANNEL_CONFIG,
                                AUDIO_FORMAT,
                                bufferSize
                            )
                            if (newRecord.state == AudioRecord.STATE_INITIALIZED) {
                                newRecord.startRecording()
                                currentRecord = newRecord
                                audioRecord = newRecord
                                Log.i(TAG, "AudioRecord successfully auto-recovered and restarted!")
                            } else {
                                newRecord.release()
                                delay(1000)
                            }
                        } catch (reInitEx: Exception) {
                            Log.e(TAG, "AudioRecord auto-recovery failed: ${reInitEx.message}")
                            delay(1000)
                        }
                    }
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error starting AudioRecord: ${e.message}", e)
            false
        }
    }

    fun stop() {
        isRecording.set(false)
        recordingJob?.cancel()
        recordingJob = null

        try {
            echoCanceler?.release()
            noiseSuppressor?.release()
            automaticGainControl?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing audio effects: ${e.message}")
        } finally {
            echoCanceler = null
            noiseSuppressor = null
            automaticGainControl = null
        }

        try {
            audioRecord?.let {
                if (it.state == AudioRecord.STATE_INITIALIZED) {
                    it.stop()
                }
                it.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping AudioRecord: ${e.message}")
        } finally {
            audioRecord = null
        }
    }

    fun setMuted(muted: Boolean) {
        isMuted.set(muted)
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/audio/AudioRecorder.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/audio/AudioUtils.kt ===
```kotlin
package com.jarvis.assistant.audio

import kotlin.math.sqrt

data class AudioFrequencyData(
    val amplitude: Float = 0f,
    val pitchHz: Float = 0f,
    val bass: Float = 0f,
    val mid: Float = 0f,
    val high: Float = 0f
)

object AudioUtils {

    /**
     * Calculates normalized RMS (0.0 to 1.0) from 16-bit Mono PCM bytes.
     */
    fun calculateRmsNormalized(bytes: ByteArray, length: Int): Float {
        if (length <= 0) return 0f
        var sumSquares = 0.0
        val sampleCount = length / 2
        if (sampleCount == 0) return 0f

        var i = 0
        while (i < length - 1) {
            val low = bytes[i].toInt() and 0xFF
            val high = bytes[i + 1].toInt()
            val sample = (high shl 8) or low
            sumSquares += (sample * sample).toDouble()
            i += 2
        }

        val rms = sqrt(sumSquares / sampleCount)
        val normalized = (rms / 3500.0).toFloat()
        return normalized.coerceIn(0f, 1f)
    }

    /**
     * Performs lightweight real-time frequency analysis on 16-bit Mono PCM audio.
     * Returns amplitude, estimated pitch (Hz), and Bass/Mid/High band energies.
     */
    fun analyzeFrequency(bytes: ByteArray, length: Int, sampleRate: Int = 16000): AudioFrequencyData {
        if (length <= 0) return AudioFrequencyData()
        val sampleCount = length / 2
        if (sampleCount < 4) return AudioFrequencyData()

        var sumSquares = 0.0
        var zeroCrossings = 0
        var lastSample = 0
        var diffSumSquares = 0.0
        var lowPassSumSquares = 0.0
        var lowPassFilterState = 0.0

        // Simple single-pole low pass filter coefficient for ~500Hz cutoff at 16kHz
        // alpha = 2 * pi * dt * fc / (2 * pi * dt * fc + 1) ~= 0.17
        val alpha = 0.17

        var i = 0
        var idx = 0
        while (i < length - 1) {
            val low = bytes[i].toInt() and 0xFF
            val high = bytes[i + 1].toInt()
            val sample = (high shl 8) or low
            sumSquares += (sample * sample).toDouble()

            if (idx > 0) {
                if ((sample >= 0 && lastSample < 0) || (sample < 0 && lastSample >= 0)) {
                    zeroCrossings++
                }
                val diff = sample - lastSample
                diffSumSquares += (diff * diff).toDouble()
            }

            lowPassFilterState += alpha * (sample - lowPassFilterState)
            lowPassSumSquares += (lowPassFilterState * lowPassFilterState)

            lastSample = sample
            idx++
            i += 2
        }

        val rms = sqrt(sumSquares / sampleCount)
        val amp = (rms / 3500.0).toFloat().coerceIn(0f, 1f)
        if (amp < 0.015f) {
            return AudioFrequencyData(amplitude = amp)
        }

        // Estimate dominant vocal pitch via Zero Crossing Rate
        val zcr = zeroCrossings.toFloat() / (sampleCount - 1).coerceAtLeast(1)
        val pitchHz = (zcr * (sampleRate / 2.0f)).coerceIn(80f, 3500f)

        // Bass energy (from low-pass filtered audio)
        val bassRms = sqrt(lowPassSumSquares / sampleCount)
        val bass = ((bassRms / 2500.0).toFloat() * 1.2f).coerceIn(0f, 1f)

        // High frequency energy (from high-pass difference signal)
        val highRms = sqrt(diffSumSquares / (sampleCount - 1).coerceAtLeast(1))
        val high = ((highRms / 3000.0).toFloat() * 1.1f).coerceIn(0f, 1f)

        // Mid energy represents body of voice
        val mid = ((amp * 1.3f) - (bass * 0.4f) - (high * 0.3f)).coerceIn(0f, 1f)

        return AudioFrequencyData(
            amplitude = amp,
            pitchHz = pitchHz,
            bass = bass,
            mid = mid,
            high = high
        )
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/audio/AudioUtils.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/audio/HeadsetAudioRouter.kt ===
```kotlin
package com.jarvis.assistant.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log

/**
 * HeadsetAudioRouter: Manages audio routing between:
 * 1. External headsets (Bluetooth earbuds / AirPods / wired headsets) -> mic & audio to headset.
 * 2. Device Loudspeaker -> When NO headset is connected, forces playback strictly through
 *    the phone's main loudspeaker (TYPE_BUILTIN_SPEAKER), NEVER the call earpiece speaker.
 */
class HeadsetAudioRouter(private val context: Context) {

    companion object {
        private const val TAG = "HeadsetAudioRouter"
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var isRegistered = false
    private var isScoStarted = false
    @Volatile
    private var cachedIsHeadsetConnected = false

    private val headsetReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            Log.d(TAG, "Audio broadcast received: $action")
            when (action) {
                AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED -> {
                    val state = intent.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, AudioManager.SCO_AUDIO_STATE_ERROR)
                    if (state == AudioManager.SCO_AUDIO_STATE_CONNECTED) {
                        Log.i(TAG, "Bluetooth SCO connected: microphone active on Bluetooth headset.")
                    } else if (state == AudioManager.SCO_AUDIO_STATE_DISCONNECTED) {
                        Log.i(TAG, "Bluetooth SCO disconnected.")
                        routeToOptimalAudio()
                    }
                }
                Intent.ACTION_HEADSET_PLUG -> {
                    val state = intent.getIntExtra("state", -1)
                    Log.i(TAG, "Wired headset plug state changed: state=$state")
                    routeToOptimalAudio()
                }
                else -> {
                    routeToOptimalAudio()
                }
            }
        }
    }

    private val audioDeviceCallback = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
                Log.d(TAG, "Audio device added, re-routing audio...")
                routeToOptimalAudio()
            }

            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                Log.d(TAG, "Audio device removed, re-routing audio...")
                routeToOptimalAudio()
            }
        }
    } else null

    fun start() {
        try {
            if (!isRegistered) {
                val filter = IntentFilter().apply {
                    addAction(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED)
                    addAction(Intent.ACTION_HEADSET_PLUG)
                    addAction("android.bluetooth.headset.profile.action.CONNECTION_STATE_CHANGED")
                    addAction("android.bluetooth.adapter.action.STATE_CHANGED")
                }
                context.registerReceiver(headsetReceiver, filter)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && audioDeviceCallback != null) {
                    audioManager.registerAudioDeviceCallback(audioDeviceCallback, null)
                }

                isRegistered = true
            }

            routeToOptimalAudio()
        } catch (e: Exception) {
            Log.e(TAG, "Error starting HeadsetAudioRouter: ${e.message}", e)
        }
    }

    /**
     * Checks if an external headset (Bluetooth or wired) is connected.
     * Uses volatile cached state updated on device callbacks to prevent 50Hz IPC overhead.
     */
    fun isHeadsetConnected(): Boolean = cachedIsHeadsetConnected

    private fun findConnectedHeadset(): AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val available = audioManager.availableCommunicationDevices
            return available.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
        } else {
            val inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
            return inputs.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
        }
    }

    /**
     * Dynamically chooses and sets the best communication device:
     * - Headset connected: route to headset mic and speaker.
     * - No headset connected: route to phone's LOUDSPEAKER (never the call speaker).
     */
    fun routeToOptimalAudio() {
        try {
            val targetHeadset = findConnectedHeadset()
            cachedIsHeadsetConnected = (targetHeadset != null)

            if (targetHeadset != null) {
                // External Headset Connected: Route to headset
                Log.i(TAG, "External headset detected: ${targetHeadset.productName} (type=${targetHeadset.type}). Routing to headset.")
                audioManager.mode = AudioManager.MODE_IN_COMMUNICATION

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val success = audioManager.setCommunicationDevice(targetHeadset)
                    Log.i(TAG, "setCommunicationDevice: ${targetHeadset.productName} -> success=$success")
                } else {
                    if (audioManager.isBluetoothScoAvailableOffCall && !audioManager.isBluetoothScoOn) {
                        audioManager.startBluetoothSco()
                        audioManager.isBluetoothScoOn = true
                        isScoStarted = true
                    }
                }
                audioManager.isSpeakerphoneOn = false
            } else {
                // No Headset Connected: Ensure STRICT routing to LOUDSPEAKER
                Log.i(TAG, "No external headset connected. Routing strictly to LOUDSPEAKER (main speaker).")

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    audioManager.clearCommunicationDevice()
                }

                if (isScoStarted) {
                    try {
                        audioManager.stopBluetoothSco()
                        audioManager.isBluetoothScoOn = false
                    } catch (_: Exception) {}
                    isScoStarted = false
                }

                // Return to MODE_NORMAL so all media audio plays through the main loudspeaker
                audioManager.mode = AudioManager.MODE_NORMAL
                audioManager.isSpeakerphoneOn = true
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed in routeToOptimalAudio: ${e.message}")
        }
    }

    fun stop() {
        try {
            if (isRegistered) {
                try {
                    context.unregisterReceiver(headsetReceiver)
                } catch (_: Exception) {}

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && audioDeviceCallback != null) {
                    try {
                        audioManager.unregisterAudioDeviceCallback(audioDeviceCallback)
                    } catch (_: Exception) {}
                }

                isRegistered = false
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                audioManager.clearCommunicationDevice()
            }

            if (isScoStarted) {
                try {
                    audioManager.stopBluetoothSco()
                    audioManager.isBluetoothScoOn = false
                } catch (_: Exception) {}
                isScoStarted = false
            }

            audioManager.mode = AudioManager.MODE_NORMAL
            audioManager.isSpeakerphoneOn = true
            cachedIsHeadsetConnected = false
            Log.i(TAG, "HeadsetAudioRouter stopped, audio mode reset to NORMAL (speakerphone active).")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping HeadsetAudioRouter: ${e.message}", e)
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/audio/HeadsetAudioRouter.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/audio/JarvisSoundEffects.kt ===
```kotlin
package com.jarvis.assistant.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlin.math.PI
import kotlin.math.sin

/**
 * Procedural, ultra-low latency sound effect generator for JARVIS.
 * Synthesizes high-tech sci-fi earcons (wake & standby) directly into 16-bit PCM,
 * completely eliminating external audio file dependencies and load latency.
 */
object JarvisSoundEffects {
    private const val TAG = "JarvisSoundEffects"
    private const val SAMPLE_RATE = 44100

    private val wakeSoundPcm: ByteArray by lazy { generateWakeSound() }
    private val standbySoundPcm: ByteArray by lazy { generateStandbySound() }

    /**
     * Futuristic ascending dual-tone chime when JARVIS wakes up or comes out of background.
     */
    fun playWakeSound() {
        playPcm(wakeSoundPcm)
    }

    /**
     * Sleek descending harmonic earcon when JARVIS enters standby / goes to background.
     */
    fun playStandbySound() {
        playPcm(standbySoundPcm)
    }

    private fun playPcm(pcmData: ByteArray) {
        Thread {
            try {
                val attributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()

                val format = AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()

                val track = AudioTrack.Builder()
                    .setAudioAttributes(attributes)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(pcmData.size)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(pcmData, 0, pcmData.size)
                track.play()

                // Calculate duration to allow AudioTrack to complete playback before cleanup
                val durationMs = (pcmData.size / 2 * 1000L) / SAMPLE_RATE
                Thread.sleep(durationMs + 60)
                try {
                    track.stop()
                    track.release()
                } catch (_: Exception) {}
            } catch (e: Exception) {
                Log.e(TAG, "Error playing sound effect: ${e.message}")
            }
        }.start()
    }

    /**
     * Synthesizes a crisp, two-tone ascending futuristic chime:
     * - Note 1: 587.33 Hz (D5) with 1174.66 Hz overtone for ~90ms
     * - Silence: 20ms
     * - Note 2: 880.0 Hz (A5) with 1760.0 Hz & 2640.0 Hz overtones for ~160ms with smooth decay
     */
    private fun generateWakeSound(): ByteArray {
        val totalDurationMs = 270
        val totalSamples = (SAMPLE_RATE * totalDurationMs) / 1000
        val buffer = ByteArray(totalSamples * 2)

        val note1Samples = (SAMPLE_RATE * 90) / 1000
        val silenceSamples = (SAMPLE_RATE * 20) / 1000
        val note2Start = note1Samples + silenceSamples

        var idx = 0
        for (i in 0 until totalSamples) {
            val sampleVal: Short = when {
                i < note1Samples -> {
                    // Note 1: 587.33 Hz (D5)
                    val t = i.toDouble() / SAMPLE_RATE
                    val attack = (i.toDouble() / ((SAMPLE_RATE * 8) / 1000)).coerceAtMost(1.0)
                    val decay = ((note1Samples - i).toDouble() / ((SAMPLE_RATE * 30) / 1000)).coerceIn(0.0, 1.0)
                    val env = attack * decay
                    val wave = sin(2 * PI * 587.33 * t) + 0.3 * sin(2 * PI * 1174.66 * t)
                    (wave * env * 22000.0).toInt().coerceIn(-32767, 32767).toShort()
                }
                i < note2Start -> 0.toShort()
                else -> {
                    // Note 2: 880.0 Hz (A5)
                    val sampleInNote = i - note2Start
                    val note2Total = totalSamples - note2Start
                    val t = sampleInNote.toDouble() / SAMPLE_RATE
                    val attack = (sampleInNote.toDouble() / ((SAMPLE_RATE * 6) / 1000)).coerceAtMost(1.0)
                    val decay = ((note2Total - sampleInNote).toDouble() / (note2Total * 0.75)).coerceIn(0.0, 1.0)
                    val env = attack * decay * decay // parabolic decay for pleasant ring-out
                    val wave = sin(2 * PI * 880.0 * t) + 0.35 * sin(2 * PI * 1760.0 * t) + 0.15 * sin(2 * PI * 2640.0 * t)
                    (wave * env * 25000.0).toInt().coerceIn(-32767, 32767).toShort()
                }
            }

            buffer[idx++] = (sampleVal.toInt() and 0xFF).toByte()
            buffer[idx++] = ((sampleVal.toInt() shr 8) and 0xFF).toByte()
        }

        return buffer
    }

    /**
     * Synthesizes a smooth, two-tone descending futuristic standby earcon:
     * - Note 1: 880.0 Hz (A5) with 1760.0 Hz overtone for ~80ms
     * - Silence: 20ms
     * - Note 2: 587.33 Hz (D5) with gentle fading decay for ~150ms
     */
    private fun generateStandbySound(): ByteArray {
        val totalDurationMs = 250
        val totalSamples = (SAMPLE_RATE * totalDurationMs) / 1000
        val buffer = ByteArray(totalSamples * 2)

        val note1Samples = (SAMPLE_RATE * 80) / 1000
        val silenceSamples = (SAMPLE_RATE * 20) / 1000
        val note2Start = note1Samples + silenceSamples

        var idx = 0
        for (i in 0 until totalSamples) {
            val sampleVal: Short = when {
                i < note1Samples -> {
                    // Note 1: 880.0 Hz (A5)
                    val t = i.toDouble() / SAMPLE_RATE
                    val attack = (i.toDouble() / ((SAMPLE_RATE * 6) / 1000)).coerceAtMost(1.0)
                    val decay = ((note1Samples - i).toDouble() / ((SAMPLE_RATE * 35) / 1000)).coerceIn(0.0, 1.0)
                    val env = attack * decay
                    val wave = sin(2 * PI * 880.0 * t) + 0.25 * sin(2 * PI * 1760.0 * t)
                    (wave * env * 20000.0).toInt().coerceIn(-32767, 32767).toShort()
                }
                i < note2Start -> 0.toShort()
                else -> {
                    // Note 2: 587.33 Hz (D5)
                    val sampleInNote = i - note2Start
                    val note2Total = totalSamples - note2Start
                    val t = sampleInNote.toDouble() / SAMPLE_RATE
                    val attack = (sampleInNote.toDouble() / ((SAMPLE_RATE * 6) / 1000)).coerceAtMost(1.0)
                    val decay = ((note2Total - sampleInNote).toDouble() / (note2Total * 0.7)).coerceIn(0.0, 1.0)
                    val env = attack * decay * decay
                    val wave = sin(2 * PI * 587.33 * t) + 0.2 * sin(2 * PI * 1174.66 * t)
                    (wave * env * 21000.0).toInt().coerceIn(-32767, 32767).toShort()
                }
            }

            buffer[idx++] = (sampleVal.toInt() and 0xFF).toByte()
            buffer[idx++] = ((sampleVal.toInt() shr 8) and 0xFF).toByte()
        }

        return buffer
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/audio/JarvisSoundEffects.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/audio/OwnerVoiceManager.kt ===
```kotlin
package com.jarvis.assistant.audio

import android.util.Log
import com.jarvis.assistant.data.preferences.AppPreferences
import org.json.JSONObject
import org.vosk.Recognizer
import kotlin.math.sqrt

data class VoiceMatchResult(
    val isMatch: Boolean,
    val distance: Float,
    val similarityPercent: Int,
    val threshold: Float,
    val hasExtractedVector: Boolean = true
)

object OwnerVoiceManager {
    private const val TAG = "OwnerVoiceManager"

    // Vosk/Kaldi 128-d x-vector cosine distance thresholds.
    // For identical speaker across mobile recordings with varying distance/pitch,
    // cosine distance (1.0 - cosSim) ranges between 0.40 and 0.68.
    // Completely different speakers typically measure 0.85 to 1.30+.
    const val DEFAULT_THRESHOLD = 0.70f   // Balanced: reliable owner match, 100% blocks strangers
    const val STRICT_THRESHOLD = 0.62f    // Strict: high security
    const val RELAXED_THRESHOLD = 0.78f   // Relaxed: tolerant of noisy environments

    /**
     * Calculates the cosine distance between two speaker embedding vectors:
     * distance = 1.0 - (dot(v1, v2) / (norm(v1) * norm(v2)))
     * Range is [0.0, 2.0]. Lower values indicate identical vocal characteristics.
     */
    fun calculateCosineDistance(v1: FloatArray, v2: FloatArray): Float {
        if (v1.isEmpty() || v2.isEmpty() || v1.size != v2.size) return 1.0f

        var dot = 0.0
        var norm1 = 0.0
        var norm2 = 0.0

        for (i in v1.indices) {
            val a = v1[i].toDouble()
            val b = v2[i].toDouble()
            dot += a * b
            norm1 += a * a
            norm2 += b * b
        }

        if (norm1 <= 0.0 || norm2 <= 0.0) return 1.0f

        val cosSim = (dot / (sqrt(norm1) * sqrt(norm2))).coerceIn(-1.0, 1.0)
        return (1.0 - cosSim).toFloat().coerceIn(0.0f, 2.0f)
    }

    /**
     * Converts a cosine distance to a human-friendly similarity percentage [0..100].
     */
    fun distanceToSimilarityPercent(distance: Float): Int {
        val sim = (1.0f - (distance / 1.35f)) * 100f
        return sim.toInt().coerceIn(0, 100)
    }

    /**
     * Computes the centroid (normalized average) of multiple speaker sample embeddings.
     */
    fun averageVectors(vectors: List<FloatArray>): FloatArray? {
        if (vectors.isEmpty()) return null
        val dim = vectors[0].size
        val avg = FloatArray(dim)

        for (vec in vectors) {
            if (vec.size != dim) continue
            for (i in 0 until dim) {
                avg[i] += vec[i]
            }
        }

        val count = vectors.size.toFloat()
        for (i in 0 until dim) {
            avg[i] /= count
        }

        // Normalize the averaged vector
        var norm = 0.0
        for (v in avg) {
            norm += v.toDouble() * v.toDouble()
        }
        val sqrtNorm = sqrt(norm).toFloat()
        if (sqrtNorm > 0f) {
            for (i in 0 until dim) {
                avg[i] /= sqrtNorm
            }
        }

        return avg
    }

    /**
     * Extracts a speaker embedding vector (x-vector) from a 16kHz mono 16-bit PCM audio buffer.
     */
    @Synchronized
    fun extractSpeakerVector(pcmAudio: ByteArray): FloatArray? {
        val model = VoskModelManager.model
        val spkModel = VoskModelManager.speakerModel

        if (model == null || spkModel == null) {
            Log.w(TAG, "Cannot extract speaker vector: Vosk model or speaker model is not ready")
            return null
        }
        if (pcmAudio.size < 3200) { // Require at least 100ms of audio (16000 * 2 * 0.1)
            Log.w(TAG, "Audio buffer too short for speaker extraction (${pcmAudio.size} bytes)")
            return null
        }

        var rec: Recognizer? = null
        return try {
            rec = Recognizer(model, 16000.0f, spkModel)

            // Feed audio in clean 4096-byte blocks so Kaldi's acoustic and x-vector pipeline processes all frames
            var offset = 0
            val chunkSize = 4096
            while (offset < pcmAudio.size) {
                val len = minOf(chunkSize, pcmAudio.size - offset)
                rec.acceptWaveForm(pcmAudio.copyOfRange(offset, offset + len), len)
                offset += len
            }

            // Feed 400ms of trailing silence padding so Kaldi's nnet3 context window completes pooling on short commands
            val silencePadding = ByteArray(12800)
            rec.acceptWaveForm(silencePadding, silencePadding.size)

            val jsonStr = rec.finalResult
            if (jsonStr.isNullOrBlank()) return null

            val json = JSONObject(jsonStr)
            if (json.has("spk")) {
                val arr = json.getJSONArray("spk")
                val vector = FloatArray(arr.length()) { i -> arr.getDouble(i).toFloat() }
                if (vector.isNotEmpty()) vector else null
            } else {
                Log.d(TAG, "No 'spk' field found in Vosk final result: $jsonStr")
                null
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error extracting speaker vector from PCM: ${e.message}", e)
            null
        } finally {
            try {
                rec?.close()
            } catch (_: Exception) {}
        }
    }

    /**
     * Verifies an extracted speaker vector against the enrolled owner profile stored in preferences.
     * Uses multi-sample nearest-neighbor + centroid matching:
     * Compares against both the averaged centroid AND each individual enrolled sample vector.
     */
    fun verifySpeakerVector(currentVector: FloatArray, prefs: AppPreferences): VoiceMatchResult {
        val masterProfile = prefs.getOwnerVoiceProfile()
        val sampleProfiles = prefs.getOwnerVoiceSamples()
        val threshold = prefs.ownerVoiceThreshold

        if ((masterProfile == null || masterProfile.isEmpty()) && sampleProfiles.isEmpty()) {
            // No profile enrolled yet; allow all speakers by default
            return VoiceMatchResult(
                isMatch = true,
                distance = 0.0f,
                similarityPercent = 100,
                threshold = threshold
            )
        }

        var minDistance = 2.0f

        // Check against master centroid
        if (masterProfile != null && masterProfile.isNotEmpty()) {
            val d = calculateCosineDistance(currentVector, masterProfile)
            if (d < minDistance) minDistance = d
        }

        // Check against each enrolled sample vector for optimal match across tones/cadences
        for (sample in sampleProfiles) {
            val d = calculateCosineDistance(currentVector, sample)
            if (d < minDistance) minDistance = d
        }

        val isMatch = minDistance <= threshold
        val similarityPercent = distanceToSimilarityPercent(minDistance)

        return VoiceMatchResult(
            isMatch = isMatch,
            distance = minDistance,
            similarityPercent = similarityPercent,
            threshold = threshold
        )
    }

    /**
     * Verifies raw PCM audio against the enrolled owner profile.
     */
    fun verifySpeakerAudio(pcmAudio: ByteArray, prefs: AppPreferences): VoiceMatchResult {
        if (!prefs.isOwnerVoiceEnabled || !prefs.hasOwnerVoiceProfile()) {
            return VoiceMatchResult(
                isMatch = true,
                distance = 0.0f,
                similarityPercent = 100,
                threshold = prefs.ownerVoiceThreshold
            )
        }

        val vector = extractSpeakerVector(pcmAudio)
        if (vector == null) {
            Log.w(TAG, "Could not extract speaker vector from audio; insufficient voiced frames")
            return VoiceMatchResult(
                isMatch = false,
                distance = 1.0f,
                similarityPercent = 0,
                threshold = prefs.ownerVoiceThreshold,
                hasExtractedVector = false
            )
        }

        return verifySpeakerVector(vector, prefs)
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/audio/OwnerVoiceManager.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/audio/VoskModelManager.kt ===
```kotlin
package com.jarvis.assistant.audio

import android.content.Context
import android.content.res.AssetManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.vosk.Model
import org.vosk.SpeakerModel
import java.io.File
import java.io.FileOutputStream

object VoskModelManager {
    private const val TAG = "VoskModelManager"

    private val _isModelReady = MutableStateFlow(false)
    val isModelReady: StateFlow<Boolean> = _isModelReady.asStateFlow()

    private val _isSpeakerModelReady = MutableStateFlow(false)
    val isSpeakerModelReady: StateFlow<Boolean> = _isSpeakerModelReady.asStateFlow()

    @Volatile
    var model: Model? = null
        private set

    @Volatile
    var speakerModel: SpeakerModel? = null
        private set

    private val isInitializing = java.util.concurrent.atomic.AtomicBoolean(false)

    fun init(context: Context, scope: CoroutineScope) {
        if (model != null && speakerModel != null) return
        if (!isInitializing.compareAndSet(false, true)) return

        scope.launch(Dispatchers.IO) {
            try {
                // 1. Unpack & load speech recognition model
                val targetDir = File(context.filesDir, "vosk-model")
                val markerFile = File(targetDir, "am/final.mdl")

                if (!markerFile.exists() || markerFile.length() == 0L) {
                    Log.i(TAG, "Unpacking Vosk model to internal storage: ${targetDir.absolutePath}")
                    targetDir.deleteRecursively()
                    targetDir.mkdirs()
                    copyAssetFolder(context.assets, "model-en-us", targetDir)
                    Log.i(TAG, "Vosk model unpacked successfully.")
                } else {
                    Log.i(TAG, "Vosk model already unpacked at: ${targetDir.absolutePath}")
                }

                val loadedModel = Model(targetDir.absolutePath)
                model = loadedModel
                _isModelReady.value = true
                Log.i(TAG, "Vosk Model ready in memory!")

                // 2. Unpack & load speaker recognition model (x-vector extractor)
                try {
                    val spkTargetDir = File(context.filesDir, "vosk-spk-model")
                    val spkMarkerFile = File(spkTargetDir, "final.ext.raw")

                    if (!spkMarkerFile.exists() || spkMarkerFile.length() == 0L) {
                        Log.i(TAG, "Unpacking Vosk Speaker model to: ${spkTargetDir.absolutePath}")
                        spkTargetDir.deleteRecursively()
                        spkTargetDir.mkdirs()
                        copyAssetFolder(context.assets, "model-spk", spkTargetDir)
                        Log.i(TAG, "Vosk Speaker model unpacked successfully.")
                    } else {
                        Log.i(TAG, "Vosk Speaker model already unpacked at: ${spkTargetDir.absolutePath}")
                    }

                    val loadedSpk = SpeakerModel(spkTargetDir.absolutePath)
                    speakerModel = loadedSpk
                    _isSpeakerModelReady.value = true
                    Log.i(TAG, "Vosk SpeakerModel ready in memory!")
                } catch (e: Throwable) {
                    Log.e(TAG, "Failed to load Vosk SpeakerModel: ${e.message}", e)
                }

                isInitializing.set(false)
            } catch (e: Throwable) {
                isInitializing.set(false)
                Log.e(TAG, "FATAL: Failed to load Vosk model: ${e.message}", e)
            }
        }
    }

    private fun copyAssetFolder(assetManager: AssetManager, fromAssetPath: String, toDir: File) {
        val list = assetManager.list(fromAssetPath)
        if (list.isNullOrEmpty()) {
            try {
                assetManager.open(fromAssetPath).use { input ->
                    toDir.parentFile?.mkdirs()
                    FileOutputStream(toDir).use { output ->
                        input.copyTo(output)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not copy asset $fromAssetPath: ${e.message}")
            }
        } else {
            toDir.mkdirs()
            for (item in list) {
                val childAsset = if (fromAssetPath.isEmpty()) item else "$fromAssetPath/$item"
                val childTarget = File(toDir, item)
                copyAssetFolder(assetManager, childAsset, childTarget)
            }
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/audio/VoskModelManager.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/accessibility/JarvisAccessibilityService.kt ===
```kotlin
package com.jarvis.assistant.automation.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.graphics.Bitmap
import android.view.Display
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.concurrent.Executors
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class JarvisAccessibilityService : AccessibilityService() {

    data class UiChange(val revision: Long, val packageName: String, val eventType: Int, val timestamp: Long)

    companion object {
        private const val TAG = "JarvisAccessibility"
        private val _uiChanges = MutableStateFlow(UiChange(0L, "", 0, 0L))
        val uiChanges: StateFlow<UiChange> = _uiChanges.asStateFlow()

        @Volatile
        var instance: JarvisAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null
        fun isEnabled(): Boolean = instance != null

        fun triggerWhatsAppSend(targetText: String? = null) {
            instance?.armWhatsAppSend(targetText)
        }

        fun triggerWhatsAppCall(isVideo: Boolean) {
            instance?.armWhatsAppCall(isVideo)
        }

        fun triggerYouTubeAutoPlay() {
            instance?.armYouTubePlay()
        }

        fun triggerYouTubeSubscribe() {
            instance?.armYouTubeSubscribe()
        }

        fun triggerYouTubeFullscreen() {
            instance?.armYouTubeFullscreen()
        }

        fun triggerWhatsAppDelete(forEveryone: Boolean) {
            instance?.armWhatsAppDelete(forEveryone)
        }

        data class ExtractedOtp(val code: String, val timestamp: Long, val senderPkg: String)
        @Volatile
        var latestExtractedOtp: ExtractedOtp? = null

        fun getRecentOtp(): String? {
            val otp = latestExtractedOtp ?: return null
            if (System.currentTimeMillis() - otp.timestamp < 120_000L) { // valid for 2 minutes
                return otp.code
            }
            return null
        }

        suspend fun captureScreenBitmap(): Bitmap? {
            val s = instance ?: return null
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
            return try {
                withTimeoutOrNull(1500L) {
                    suspendCancellableCoroutine { cont ->
                        s.takeScreenCapture { bmp ->
                            if (cont.isActive) {
                                cont.resume(bmp, null)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "captureScreenBitmap timed out or failed: ${e.message}")
                null
            }
        }

        suspend fun captureScreenJpeg(quality: Int = 75): ByteArray? {
            // FAST PATH: If ScreenCaptureManager VirtualDisplay is running, grab immediate hardware frame (0ms latency)
            val scm = com.jarvis.assistant.vision.ScreenCaptureManager.getInstance()
            if (scm.isScreenShareActive()) {
                val fastSnap = scm.captureSnapshotJpeg(quality)
                if (fastSnap != null) return fastSnap
            }

            val bmp = captureScreenBitmap()
            if (bmp != null) {
                try {
                    val maxDim = 640f
                    val scale = (maxDim / maxOf(bmp.width, bmp.height)).coerceAtMost(1.0f)
                    val targetW = (bmp.width * scale).toInt() and 1.inv()
                    val targetH = (bmp.height * scale).toInt() and 1.inv()
                    val scaledBmp = if (scale < 1.0f && targetW > 0 && targetH > 0) {
                        Bitmap.createScaledBitmap(bmp, targetW, targetH, true)
                    } else {
                        bmp
                    }
                    val stream = ByteArrayOutputStream()
                    scaledBmp.compress(Bitmap.CompressFormat.JPEG, quality, stream)
                    if (scaledBmp != bmp) scaledBmp.recycle()
                    bmp.recycle()
                    val bytes = stream.toByteArray()
                    Log.d(TAG, "Captured native accessibility screenshot: ${bytes.size / 1024} KB (${targetW}x${targetH})")
                    return bytes
                } catch (e: Exception) {
                    Log.e(TAG, "Failed encoding accessibility screenshot to JPEG: ${e.message}")
                }
            }
            // Fallback to ScreenCaptureManager if active
            return com.jarvis.assistant.vision.ScreenCaptureManager.getInstance().captureSnapshotJpeg(quality)
        }
    }

    /**
     * Native Android 11+ (API 30+) AccessibilityService screen capture.
     * Takes a hardware buffer screenshot with ZERO user prompts or system dialogs.
     */
    fun takeScreenCapture(callback: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    Executors.newSingleThreadExecutor(),
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(screenshotResult: AccessibilityService.ScreenshotResult) {
                            try {
                                val buffer = screenshotResult.hardwareBuffer
                                val colorSpace = screenshotResult.colorSpace
                                val hwBitmap = Bitmap.wrapHardwareBuffer(buffer, colorSpace)
                                val softBitmap = hwBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                                buffer.close()
                                hwBitmap?.recycle()
                                callback(softBitmap)
                            } catch (e: Exception) {
                                Log.e(TAG, "Error wrapping hardware buffer screenshot: ${e.message}")
                                callback(null)
                            }
                        }

                        override fun onFailure(errorCode: Int) {
                            Log.w(TAG, "takeScreenshot failed with errorCode: $errorCode")
                            callback(null)
                        }
                    }
                )
            } catch (e: Exception) {
                Log.e(TAG, "takeScreenshot exception: ${e.message}")
                callback(null)
            }
        } else {
            callback(null)
        }
    }

    private val handler = Handler(Looper.getMainLooper())

    private var isWaitingForWhatsAppSend = false
    private var pendingWhatsAppMessage: String? = null
    private var whatsAppArmTime = 0L
    private var whatsAppSendTaps = 0

    private var isWaitingForWhatsAppCall = false
    private var isVideoCall = false
    private var whatsAppCallArmTime = 0L
    private var whatsAppCallTaps = 0

    private var isWaitingForYouTubePlay = false
    private var youTubeArmTime = 0L

    private var isWaitingForYouTubeSubscribe = false
    private var youTubeSubscribeArmTime = 0L

    private var isWaitingForYouTubeFullscreen = false
    private var youTubeFullscreenArmTime = 0L

    private var isWaitingForWhatsAppDelete = false
    private var deleteForEveryone = false
    private var whatsAppDeleteArmTime = 0L
    private var deleteStage = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "JarvisAccessibilityService connected and active")
        ensureJarvisServiceActive()
    }

    private fun ensureJarvisServiceActive() {
        try {
            if (!com.jarvis.assistant.background.JarvisConversationService.isSessionOn.value &&
                !com.jarvis.assistant.background.JarvisConversationService.isStandby.value) {
                val intent = Intent(this, com.jarvis.assistant.background.JarvisConversationService::class.java).apply {
                    action = com.jarvis.assistant.background.JarvisConversationService.ACTION_ENTER_STANDBY
                }
                androidx.core.content.ContextCompat.startForegroundService(this, intent)
                Log.i(TAG, "JarvisAccessibilityService ensured JarvisConversationService is running in standby")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start JarvisConversationService from accessibility service: ${e.message}")
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString().orEmpty()
        if (event.eventType in setOf(
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
                AccessibilityEvent.TYPE_WINDOWS_CHANGED,
                AccessibilityEvent.TYPE_VIEW_SCROLLED
            )) {
            val previous = _uiChanges.value
            _uiChanges.value = UiChange(previous.revision + 1, pkg, event.eventType, System.currentTimeMillis())
        }

        // Auto-extract incoming OTP / verification codes from notifications (SMS, WhatsApp, banking)
        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            try {
                val texts = event.text
                val fullText = texts.joinToString(" ")
                if (fullText.isNotBlank()) {
                    val otpRegex = Regex("""\b(?:OTP|code|verification|passcode|is|pin|password)[^\d]*(\d{4,8})\b""", RegexOption.IGNORE_CASE)
                    val match = otpRegex.find(fullText) ?: Regex("""\b(\d{4,6})\b""").find(fullText)
                    if (match != null) {
                        val code = match.groupValues.lastOrNull { it.isNotBlank() && it.all { c -> c.isDigit() } }
                        if (code != null && code.length in 4..8) {
                            Log.i(TAG, "Auto-detected incoming OTP/code from notification ($pkg): $code")
                            latestExtractedOtp = ExtractedOtp(code, System.currentTimeMillis(), pkg)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "Error inspecting notification for OTP: ${e.message}")
            }
        }

        if (isWaitingForWhatsAppSend && (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b")) {
            if (System.currentTimeMillis() - whatsAppArmTime < 14000) {
                attemptWhatsAppSendAction(0)
            } else {
                isWaitingForWhatsAppSend = false
            }
        }

        if (isWaitingForWhatsAppCall && (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b")) {
            if (System.currentTimeMillis() - whatsAppCallArmTime < 14000) {
                attemptWhatsAppCallAction(0)
            } else {
                isWaitingForWhatsAppCall = false
            }
        }

        if (isWaitingForYouTubePlay && (pkg == "com.google.android.youtube" || pkg == "app.revanced.android.youtube")) {
            if (System.currentTimeMillis() - youTubeArmTime < 10000) {
                attemptClickFirstYouTubeVideo(0)
            } else {
                isWaitingForYouTubePlay = false
            }
        }

        if (isWaitingForYouTubeSubscribe && (pkg == "com.google.android.youtube" || pkg == "app.revanced.android.youtube")) {
            if (System.currentTimeMillis() - youTubeSubscribeArmTime < 10000) {
                attemptYouTubeSubscribe()
            } else {
                isWaitingForYouTubeSubscribe = false
            }
        }

        if (isWaitingForYouTubeFullscreen && (pkg == "com.google.android.youtube" || pkg == "app.revanced.android.youtube")) {
            if (System.currentTimeMillis() - youTubeFullscreenArmTime < 8000) {
                attemptYouTubeFullscreen(1)
            } else {
                isWaitingForYouTubeFullscreen = false
            }
        }

        if (isWaitingForWhatsAppDelete && (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b")) {
            if (System.currentTimeMillis() - whatsAppDeleteArmTime < 15000) {
                attemptWhatsAppDeleteAction()
            } else {
                isWaitingForWhatsAppDelete = false
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "JarvisAccessibilityService interrupted")
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    // -------------------------------------------------------------
    // WhatsApp Send & Text Injection
    // -------------------------------------------------------------

    fun armWhatsAppSend(targetText: String?) {
        isWaitingForWhatsAppSend = true
        pendingWhatsAppMessage = targetText
        whatsAppArmTime = System.currentTimeMillis()
        whatsAppSendTaps = 0
        Log.i(TAG, "Armed for WhatsApp auto-send (has text=${!targetText.isNullOrBlank()})")

        // Rapid polling to catch WhatsApp UI as soon as it renders
        handler.postDelayed({ pollWhatsAppSend(1) }, 600)
    }

    private fun pollWhatsAppSend(attempt: Int) {
        if (!isWaitingForWhatsAppSend || attempt > 12) {
            isWaitingForWhatsAppSend = false
            pendingWhatsAppMessage = null
            return
        }

        val success = attemptWhatsAppSendAction(attempt)
        if (success && whatsAppSendTaps >= 1) {
            // Check if message sent and entry is cleared
            val root = getActiveRootNode()
            val entryText = root?.let { getWhatsAppEntryText(it) }
            if (entryText.isNullOrBlank()) {
                Log.i(TAG, "WhatsApp message sent! Entry field cleared. Ending auto-send polling.")
                isWaitingForWhatsAppSend = false
                pendingWhatsAppMessage = null
                return
            }
        }

        val delay = if (attempt < 3) 400L else 600L
        handler.postDelayed({ pollWhatsAppSend(attempt + 1) }, delay)
    }

    private fun attemptWhatsAppSendAction(attempt: Int): Boolean {
        val rootNode = getActiveRootNode() ?: return false

        val currentEntryText = getWhatsAppEntryText(rootNode)

        // If we already tapped send once:
        if (whatsAppSendTaps >= 1) {
            if (currentEntryText.isNullOrBlank()) {
                Log.i(TAG, "WhatsApp message sent successfully (entry is empty). Disarming.")
                isWaitingForWhatsAppSend = false
                pendingWhatsAppMessage = null
                return true
            }
            // If entry is not empty yet, wait for WhatsApp to process. DO NOT tap mic.
            Log.d(TAG, "Send already tapped once, waiting for entry to clear (attempt $attempt)")
            return false
        }

        // 1. Text injection check: if text field is empty and we have a message, inject it
        if (currentEntryText.isNullOrBlank()) {
            injectTextIfEmpty(rootNode)
        }

        // Ensure entry actually has text before attempting to click send!
        // When entry is empty, the button is guaranteed to be a microphone/voice note button.
        val textAfterInject = getWhatsAppEntryText(rootNode)
        if (textAfterInject.isNullOrBlank()) {
            Log.d(TAG, "Entry field is empty; skipping send click to prevent clicking mic (attempt $attempt)")
            return false
        }

        // 2. Find and click ONLY the actual Send button (never send_container which holds the mic)
        var clicked = false
        val sendButtonIds = listOf(
            "com.whatsapp:id/send",
            "com.whatsapp.w4b:id/send",
            "com.whatsapp:id/send_btn",
            "com.whatsapp:id/send_media_button",
            "com.whatsapp.w4b:id/send_btn"
        )
        for (id in sendButtonIds) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(id)
            for (node in nodes) {
                if (isVoiceOrMicNode(node)) {
                    Log.d(TAG, "Ignoring voice/mic node with ID $id")
                    continue
                }
                if (clickNodeAndTap(node)) {
                    Log.i(TAG, "Successfully clicked WhatsApp send button by ID: $id (attempt $attempt)")
                    clicked = true
                    whatsAppSendTaps++
                    break
                }
            }
            if (clicked) break
        }

        if (!clicked) {
            clicked = findAndClickSendInTree(rootNode)
            if (clicked) whatsAppSendTaps++
        }

        if (clicked) {
            // Schedule an immediate verification check
            handler.postDelayed({
                val checkRoot = getActiveRootNode()
                if (checkRoot != null && getWhatsAppEntryText(checkRoot).isNullOrBlank()) {
                    Log.i(TAG, "Verified: WhatsApp entry field is clear. Disarming send.")
                    isWaitingForWhatsAppSend = false
                    pendingWhatsAppMessage = null
                }
            }, 300)
        }

        return clicked
    }

    private fun isVoiceOrMicNode(node: AccessibilityNodeInfo): Boolean {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""
        val className = node.className?.toString()?.lowercase() ?: ""

        if (desc.contains("voice") || desc.contains("record") || desc.contains("audio") ||
            desc.contains("mic") || desc.contains("microphone") || desc.contains("ptt") ||
            desc.contains("hold to") || desc.contains("ध्वनि") || desc.contains("बोलकर")) {
            return true
        }
        if (viewId.contains("voice") || viewId.contains("record") || viewId.contains("mic") || viewId.contains("ptt")) {
            return true
        }
        // Inspect child elements
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val cDesc = child.contentDescription?.toString()?.lowercase() ?: ""
            val cId = child.viewIdResourceName?.lowercase() ?: ""
            if (cDesc.contains("voice") || cDesc.contains("record") || cDesc.contains("audio") ||
                cDesc.contains("mic") || cDesc.contains("ptt") || cId.contains("mic") || cId.contains("voice")) {
                return true
            }
        }
        return false
    }

    private fun getWhatsAppEntryText(root: AccessibilityNodeInfo): String? {
        val entryIds = listOf("com.whatsapp:id/entry", "com.whatsapp.w4b:id/entry")
        for (id in entryIds) {
            val nodes = root.findAccessibilityNodeInfosByViewId(id)
            for (node in nodes) {
                val text = node.text?.toString()
                if (text != null) return text.trim()
            }
        }
        // Fallback: search EditText
        return findFirstEditTextContent(root)
    }

    private fun findFirstEditTextContent(node: AccessibilityNodeInfo): String? {
        if (node.className?.toString()?.contains("EditText") == true) {
            return node.text?.toString()?.trim()
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findFirstEditTextContent(child)
            if (result != null) return result
        }
        return null
    }

    private fun injectTextIfEmpty(root: AccessibilityNodeInfo) {
        val targetText = pendingWhatsAppMessage
        if (targetText.isNullOrBlank()) return

        val entryIds = listOf(
            "com.whatsapp:id/entry",
            "com.whatsapp.w4b:id/entry"
        )
        for (id in entryIds) {
            val nodes = root.findAccessibilityNodeInfosByViewId(id)
            for (node in nodes) {
                val currentText = node.text?.toString()?.trim() ?: ""
                if (currentText.isBlank()) {
                    val args = Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, targetText)
                    }
                    val set = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    Log.i(TAG, "Injected text into WhatsApp entry field: success=$set")
                    return
                }
            }
        }

        // Fallback: check all EditTexts in the active tree
        findAndInjectEditText(root, targetText)
    }

    private fun findAndInjectEditText(node: AccessibilityNodeInfo, text: String): Boolean {
        if (node.className?.toString()?.contains("EditText") == true) {
            val currentText = node.text?.toString()?.trim() ?: ""
            if (currentText.isBlank()) {
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
                val set = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                Log.i(TAG, "Injected text into generic EditText: success=$set")
                return true
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (findAndInjectEditText(child, text)) return true
        }
        return false
    }

    private fun findAndClickSendInTree(node: AccessibilityNodeInfo): Boolean {
        if (isVoiceOrMicNode(node)) return false

        val contentDesc = node.contentDescription?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""

        // If content description is send
        if (contentDesc == "send" || contentDesc == "send message" || contentDesc == "enviar" || contentDesc == "भेजें") {
            if (clickNodeAndTap(node)) return true
        }

        // Strictly match send button IDs (never containers)
        if (viewId.endsWith("/send") || viewId.endsWith("/send_btn") || viewId.endsWith("/send_button") || viewId.endsWith("/send_media_button")) {
            if (clickNodeAndTap(node)) return true
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (findAndClickSendInTree(child)) return true
        }

        return false
    }

    // -------------------------------------------------------------
    // WhatsApp Voice & Video Calling
    // -------------------------------------------------------------

    fun armWhatsAppCall(video: Boolean) {
        isWaitingForWhatsAppCall = true
        isVideoCall = video
        whatsAppCallArmTime = System.currentTimeMillis()
        whatsAppCallTaps = 0
        Log.i(TAG, "Armed for WhatsApp auto-call (video=$video)")
        handler.postDelayed({ pollWhatsAppCall(1) }, 700)
    }

    private fun pollWhatsAppCall(attempt: Int) {
        if (!isWaitingForWhatsAppCall || attempt > 16) {
            isWaitingForWhatsAppCall = false
            return
        }

        val clicked = attemptWhatsAppCallAction(attempt)
        if (clicked && whatsAppCallTaps >= 2) {
            isWaitingForWhatsAppCall = false
            return
        }

        val delay = if (attempt < 4) 400L else 700L
        handler.postDelayed({ pollWhatsAppCall(attempt + 1) }, delay)
    }

    private fun attemptWhatsAppCallAction(attempt: Int): Boolean {
        val rootNode = getActiveRootNode() ?: return false

        var clicked = false

        // 1. Check for system/app confirmation dialog ("Start voice call?", "Call", etc.)
        val dialogButtons = listOf("android:id/button1", "com.whatsapp:id/ok", "com.whatsapp:id/call_button")
        for (btnId in dialogButtons) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(btnId)
            for (node in nodes) {
                if (clickNodeAndTap(node)) {
                    Log.i(TAG, "Clicked call confirmation dialog button: $btnId")
                    whatsAppCallTaps++
                    clicked = true
                    break
                }
            }
            if (clicked) break
        }

        // Also check confirmation dialog text
        if (!clicked) {
            val callConfirmNodes = rootNode.findAccessibilityNodeInfosByText("Call")
            for (node in callConfirmNodes) {
                if (node.isClickable || node.parent?.isClickable == true) {
                    if (clickNodeAndTap(node)) {
                        Log.i(TAG, "Clicked confirmation dialog button by text 'Call'")
                        whatsAppCallTaps++
                        clicked = true
                        break
                    }
                }
            }
        }

        // 2. Click Top Action Bar Call Button (Video or Voice)
        val targetIds = if (isVideoCall) {
            listOf(
                "com.whatsapp:id/video_call",
                "com.whatsapp.w4b:id/video_call",
                "com.whatsapp:id/menuitem_conversations_call_video"
            )
        } else {
            listOf(
                "com.whatsapp:id/voice_call",
                "com.whatsapp.w4b:id/voice_call",
                "com.whatsapp:id/menuitem_conversations_call_voice"
            )
        }

        for (id in targetIds) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(id)
            for (node in nodes) {
                if (clickNodeAndTap(node)) {
                    Log.i(TAG, "Clicked WhatsApp call button by ID: $id (video=$isVideoCall)")
                    whatsAppCallTaps++
                    clicked = true
                    break
                }
            }
            if (clicked) break
        }

        // Fallback by content description in tree
        if (!clicked) {
            clicked = findAndClickCallButtonInTree(rootNode, isVideoCall)
            if (clicked) whatsAppCallTaps++
        }

        return clicked
    }

    private fun findAndClickCallButtonInTree(node: AccessibilityNodeInfo, isVideo: Boolean): Boolean {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val targetPhrase = if (isVideo) "video call" else "voice call"

        if (desc.contains(targetPhrase) || (!isVideo && (desc == "call" || desc.contains("audio call")))) {
            if (clickNodeAndTap(node)) {
                Log.i(TAG, "Clicked call button by content description: $desc")
                return true
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (findAndClickCallButtonInTree(child, isVideo)) return true
        }

        return false
    }

    // -------------------------------------------------------------
    // YouTube Auto Play
    // -------------------------------------------------------------

    fun armYouTubePlay() {
        isWaitingForYouTubePlay = true
        youTubeArmTime = System.currentTimeMillis()
        Log.i(TAG, "Armed for YouTube auto-play")
        handler.postDelayed({ pollYouTubePlay(1) }, 1000)
    }

    private fun pollYouTubePlay(attempt: Int) {
        if (!isWaitingForYouTubePlay || attempt > 10) {
            isWaitingForYouTubePlay = false
            return
        }
        val clicked = attemptClickFirstYouTubeVideo(attempt)
        if (!clicked) {
            handler.postDelayed({ pollYouTubePlay(attempt + 1) }, 600)
        }
    }

    private fun attemptClickFirstYouTubeVideo(attempt: Int): Boolean {
        val rootNode = rootInActiveWindow ?: return false

        val videoViewIds = listOf(
            "com.google.android.youtube:id/thumbnail",
            "com.google.android.youtube:id/video_info",
            "com.google.android.youtube:id/title",
            "com.google.android.youtube:id/compact_renderer",
            "app.revanced.android.youtube:id/thumbnail",
            "app.revanced.android.youtube:id/title"
        )

        for (id in videoViewIds) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(id)
            for (node in nodes) {
                if (clickNodeAndTap(node)) {
                    Log.i(TAG, "Clicked first YouTube video item by ID: $id (attempt $attempt)")
                    isWaitingForYouTubePlay = false
                    return true
                }
            }
        }

        return false
    }

    // -------------------------------------------------------------
    // YouTube Subscribe
    // -------------------------------------------------------------

    fun armYouTubeSubscribe() {
        isWaitingForYouTubeSubscribe = true
        youTubeSubscribeArmTime = System.currentTimeMillis()
        Log.i(TAG, "Armed for YouTube subscribe")
        handler.postDelayed({ pollYouTubeSubscribe(1) }, 500)
    }

    private fun pollYouTubeSubscribe(attempt: Int) {
        if (!isWaitingForYouTubeSubscribe || attempt > 12) {
            isWaitingForYouTubeSubscribe = false
            return
        }
        if (!attemptYouTubeSubscribe()) {
            handler.postDelayed({ pollYouTubeSubscribe(attempt + 1) }, 500)
        }
    }

    private fun attemptYouTubeSubscribe(): Boolean {
        val rootNode = rootInActiveWindow ?: return false

        val subIds = listOf(
            "com.google.android.youtube:id/subscribe_button",
            "app.revanced.android.youtube:id/subscribe_button"
        )
        for (id in subIds) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(id)
            for (node in nodes) {
                val text = node.text?.toString()?.lowercase() ?: ""
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                if (text.contains("subscribed") || desc.contains("subscribed")) {
                    Log.i(TAG, "Already subscribed to this channel; nothing to do.")
                    isWaitingForYouTubeSubscribe = false
                    return true
                }
                if (clickNodeAndTap(node)) {
                    Log.i(TAG, "Clicked YouTube subscribe button by ID: $id")
                    isWaitingForYouTubeSubscribe = false
                    return true
                }
            }
        }

        // Fallback: find any clickable node whose text/description says "Subscribe"
        // (but never one that already reads "Subscribed", to avoid accidentally unsubscribing).
        val fallback = findSubscribeNodeInTree(rootNode)
        if (fallback != null && clickNodeAndTap(fallback)) {
            Log.i(TAG, "Clicked YouTube subscribe button via tree fallback")
            isWaitingForYouTubeSubscribe = false
            return true
        }

        return false
    }

    private fun findSubscribeNodeInTree(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val looksSubscribed = text.contains("subscribed") || desc.contains("subscribed")
        val looksLikeSubscribeButton = (text == "subscribe" || desc == "subscribe") && !looksSubscribed
        if (looksLikeSubscribeButton && (node.isClickable || node.parent?.isClickable == true)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findSubscribeNodeInTree(child)
            if (result != null) return result
        }
        return null
    }

    // -------------------------------------------------------------
    // YouTube Fullscreen Toggle
    // -------------------------------------------------------------

    fun armYouTubeFullscreen() {
        isWaitingForYouTubeFullscreen = true
        youTubeFullscreenArmTime = System.currentTimeMillis()
        Log.i(TAG, "Armed for YouTube fullscreen toggle")
        handler.postDelayed({ pollYouTubeFullscreen(1) }, 400)
    }

    private fun pollYouTubeFullscreen(attempt: Int) {
        if (!isWaitingForYouTubeFullscreen || attempt > 8) {
            isWaitingForYouTubeFullscreen = false
            return
        }
        if (!attemptYouTubeFullscreen(attempt)) {
            handler.postDelayed({ pollYouTubeFullscreen(attempt + 1) }, 450)
        }
    }

    private fun attemptYouTubeFullscreen(attempt: Int): Boolean {
        val rootNode = rootInActiveWindow ?: return false

        val fsIds = listOf(
            "com.google.android.youtube:id/fullscreen_button",
            "app.revanced.android.youtube:id/fullscreen_button"
        )
        for (id in fsIds) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(id)
            for (node in nodes) {
                if (clickNodeAndTap(node)) {
                    Log.i(TAG, "Clicked YouTube fullscreen button by ID: $id")
                    isWaitingForYouTubeFullscreen = false
                    return true
                }
            }
        }

        val descMatch = findByContentDescriptionContains(
            rootNode,
            listOf("enter full screen", "full screen", "fullscreen")
        )
        if (descMatch != null && clickNodeAndTap(descMatch)) {
            Log.i(TAG, "Clicked YouTube fullscreen via content description fallback")
            isWaitingForYouTubeFullscreen = false
            return true
        }

        // The fullscreen control is usually hidden until the player controls are revealed.
        // Tap the center of the screen on the first couple attempts to reveal them, then retry.
        if (attempt <= 3) {
            val rect = Rect()
            rootNode.getBoundsInScreen(rect)
            if (rect.width() > 0 && rect.height() > 0) {
                clickAt(rect.centerX().toFloat(), rect.centerY().toFloat())
            }
        }

        return false
    }

    private fun findByContentDescriptionContains(node: AccessibilityNodeInfo, phrases: List<String>): AccessibilityNodeInfo? {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        if (desc.isNotBlank() && phrases.any { desc.contains(it) }) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findByContentDescriptionContains(child, phrases)
            if (result != null) return result
        }
        return null
    }

    // -------------------------------------------------------------
    // WhatsApp Delete Message (Delete for Everyone / Delete for Me)
    // -------------------------------------------------------------

    fun armWhatsAppDelete(forEveryone: Boolean) {
        isWaitingForWhatsAppDelete = true
        deleteForEveryone = forEveryone
        whatsAppDeleteArmTime = System.currentTimeMillis()
        deleteStage = 0
        Log.i(TAG, "Armed for WhatsApp delete message (forEveryone=$forEveryone)")
        handler.postDelayed({ pollWhatsAppDelete(1) }, 900)
    }

    private fun pollWhatsAppDelete(attempt: Int) {
        if (!isWaitingForWhatsAppDelete || attempt > 20) {
            isWaitingForWhatsAppDelete = false
            return
        }
        val done = attemptWhatsAppDeleteAction()
        if (!done) {
            handler.postDelayed({ pollWhatsAppDelete(attempt + 1) }, 550)
        }
    }

    private fun attemptWhatsAppDeleteAction(): Boolean {
        val rootNode = getActiveRootNode() ?: return false

        return when (deleteStage) {
            0 -> {
                // Stage 0: long-press the most recent message bubble to open the selection menu.
                val messageIds = listOf(
                    "com.whatsapp:id/message_text",
                    "com.whatsapp.w4b:id/message_text",
                    "com.whatsapp:id/conversation_text_row",
                    "com.whatsapp.w4b:id/conversation_text_row"
                )
                var target: AccessibilityNodeInfo? = null
                for (id in messageIds) {
                    val nodes = rootNode.findAccessibilityNodeInfosByViewId(id)
                    if (nodes.isNotEmpty()) target = nodes.last()
                }
                if (target == null) {
                    target = findLastMessageBubble(rootNode)
                }
                if (target != null) {
                    var longPressed = target.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
                    if (!longPressed) {
                        val rect = Rect()
                        target.getBoundsInScreen(rect)
                        if (rect.width() > 0 && rect.height() > 0) {
                            longPressAt(rect.centerX().toFloat(), rect.centerY().toFloat())
                            longPressed = true
                        }
                    }
                    if (longPressed) {
                        Log.i(TAG, "Long-pressed last WhatsApp message bubble")
                        deleteStage = 1
                    }
                }
                false
            }
            1 -> {
                // Stage 1: tap the delete (trash) icon in the selection action bar.
                val deleteIds = listOf(
                    "com.whatsapp:id/menuitem_delete",
                    "com.whatsapp.w4b:id/menuitem_delete"
                )
                var clicked = false
                for (id in deleteIds) {
                    val nodes = rootNode.findAccessibilityNodeInfosByViewId(id)
                    for (node in nodes) {
                        if (clickNodeAndTap(node)) {
                            Log.i(TAG, "Clicked WhatsApp delete icon")
                            clicked = true
                            break
                        }
                    }
                    if (clicked) break
                }
                if (!clicked) {
                    val descNode = findByContentDescriptionContains(rootNode, listOf("delete"))
                    if (descNode != null && clickNodeAndTap(descNode)) {
                        Log.i(TAG, "Clicked WhatsApp delete icon via content description")
                        clicked = true
                    }
                }
                if (clicked) deleteStage = 2
                false
            }
            2 -> {
                // Stage 2: choose "Delete for everyone" or "Delete for me" in the dialog.
                val optionText = if (deleteForEveryone) "Delete for everyone" else "Delete for me"
                var clicked = clickFirstMatchingText(rootNode, optionText)
                if (!clicked && deleteForEveryone) {
                    // Some WhatsApp versions phrase it slightly differently.
                    clicked = clickFirstMatchingText(rootNode, "everyone")
                }
                if (!clicked && !deleteForEveryone) {
                    clicked = clickFirstMatchingText(rootNode, "delete for me")
                }
                if (clicked) {
                    Log.i(TAG, "Selected WhatsApp delete option: $optionText")
                    deleteStage = 3
                }
                false
            }
            3 -> {
                // Stage 3: some versions show one more confirmation ("Delete") button.
                val confirmed = clickFirstMatchingText(rootNode, "delete") ||
                    rootNode.findAccessibilityNodeInfosByViewId("android:id/button1").any { clickNodeAndTap(it) }
                if (confirmed) {
                    Log.i(TAG, "Confirmed WhatsApp message deletion")
                }
                isWaitingForWhatsAppDelete = false
                true
            }
            else -> {
                isWaitingForWhatsAppDelete = false
                true
            }
        }
    }

    private fun findLastMessageBubble(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var result: AccessibilityNodeInfo? = null
        val viewId = node.viewIdResourceName ?: ""
        if (viewId.contains("message_text") || viewId.contains("conversation_text_row")) {
            result = node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val childResult = findLastMessageBubble(child)
            if (childResult != null) result = childResult
        }
        return result
    }

    private fun clickFirstMatchingText(root: AccessibilityNodeInfo, text: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (node in nodes) {
            if (node.isClickable || node.parent?.isClickable == true) {
                if (clickNodeAndTap(node)) return true
            }
        }
        return false
    }

    private fun longPressAt(x: Float, y: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                val path = Path().apply { moveTo(x, y) }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 700))
                    .build()
                dispatchGesture(gesture, null, null)
            } catch (e: Exception) {
                Log.d(TAG, "Long-press gesture failed: ${e.message}")
            }
        }
    }

    // -------------------------------------------------------------
    // Click & Touch Helpers
    // -------------------------------------------------------------

    fun clickNodeAndTap(node: AccessibilityNodeInfo): Boolean {
        // Step 1: Attempt programmatic accessibility click on the node directly
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            Log.d(TAG, "Programmatic ACTION_CLICK succeeded on node")
            return true
        }

        // Step 2: Attempt programmatic accessibility click on clickable parent hierarchy
        var parent = node.parent
        var depth = 0
        while (parent != null && depth < 3) {
            if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                Log.d(TAG, "Programmatic ACTION_CLICK succeeded on parent at depth $depth")
                return true
            }
            parent = parent.parent
            depth++
        }

        // Step 3: ONLY fallback to coordinate gesture tap if programmatic clicks failed or were not clickable
        val rect = Rect()
        node.getBoundsInScreen(rect)
        if (rect.width() > 0 && rect.height() > 0) {
            Log.d(TAG, "Falling back to coordinate gesture tap at center: (${rect.centerX()}, ${rect.centerY()})")
            return clickAt(rect.centerX().toFloat(), rect.centerY().toFloat())
        }

        return false
    }

    fun clickAt(x: Float, y: Float): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                val path = Path().apply { moveTo(x, y) }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
                    .build()
                return dispatchGesture(gesture, null, null)
            } catch (e: Exception) {
                Log.d(TAG, "Gesture click at ($x, $y) failed: ${e.message}")
            }
        }
        return false
    }

    // ---------------------------------------------------------------
    // Reference YouTube & Accessibility Actions
    // ---------------------------------------------------------------

    /** Taps the "Skip Ad" / "Skip Ads" button if currently visible. Returns true if found and tapped. */
    fun skipAd(): Boolean = clickNodeMatching("skip ad")

    /** Taps the Like button on the currently open video. */
    fun likeVideo(): Boolean = clickNodeMatching("like", exclude = "dislike")

    /** Taps the Subscribe button on the current channel/video. */
    fun subscribeChannel(): Boolean = clickNodeMatching("subscribe")

    /**
     * Opens the channel page by tapping the channel avatar/name row under the
     * video (NOT the "Subscribe" button).
     */
    fun openChannel(): Boolean {
        val root = rootInActiveWindow ?: return false
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        collectByResourceId(root, "channel", candidates)
        val target = candidates
            .filter { it.isClickable }
            .minByOrNull { nodeLabel(it).length }
        if (target != null) return target.performAction(AccessibilityNodeInfo.ACTION_CLICK)

        return clickNodeMatching("channel", exclude = "subscribe")
    }

    /**
     * Taps the fullscreen toggle button (works for both entering and exiting fullscreen).
     */
    fun toggleFullscreen(): Boolean {
        if (clickNodeMatching("full screen", "fullscreen")) return true

        val root = rootInActiveWindow ?: return false
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        collectByResourceId(root, "fullscreen", candidates)
        val target = candidates.firstOrNull { it.isClickable } ?: return false
        return target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /** Auto-clicks first video result when YouTube search opens. */
    fun clickFirstVideoResult(): Boolean {
        val root = rootInActiveWindow ?: return false
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        collectClickableVideoNodes(root, candidates)
        if (candidates.isNotEmpty()) {
            return candidates.first().performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        return tapAtPercentage(50f, 30f)
    }

    private fun collectClickableVideoNodes(
        node: AccessibilityNodeInfo,
        out: MutableList<AccessibilityNodeInfo>
    ) {
        if (node.isClickable && (node.className?.contains("ViewGroup") == true || node.className?.contains("RelativeLayout") == true || node.className?.contains("FrameLayout") == true)) {
            val label = nodeLabel(node)
            if (label.length > 20) out.add(node)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectClickableVideoNodes(child, out)
        }
    }

    private fun clickNodeMatching(vararg keywords: String, exclude: String? = null): Boolean {
        return try {
            val root = rootInActiveWindow ?: return false
            val lowerKeywords = keywords.map { it.lowercase() }
            val lowerExclude = exclude?.lowercase()

            val candidates = mutableListOf<AccessibilityNodeInfo>()
            collectMatches(root, lowerKeywords, lowerExclude, candidates)
            if (candidates.isEmpty()) return false

            val target = candidates.minByOrNull { nodeLabel(it).length } ?: return false
            target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } catch (e: Exception) {
            Log.w(TAG, "clickNodeMatching exception", e)
            false
        }
    }

    private fun nodeLabel(node: AccessibilityNodeInfo): String =
        node.text?.toString() ?: node.contentDescription?.toString() ?: ""

    private fun collectMatches(
        node: AccessibilityNodeInfo,
        keywords: List<String>,
        exclude: String?,
        out: MutableList<AccessibilityNodeInfo>
    ) {
        try {
            val label = nodeLabel(node).lowercase()
            if (label.isNotBlank()) {
                val matches = keywords.any { label.contains(it) } && (exclude == null || !label.contains(exclude))
                if (matches && (node.isClickable || node.isCheckable)) {
                    out.add(node)
                }
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                collectMatches(child, keywords, exclude, out)
            }
        } catch (e: Exception) {
            Log.w(TAG, "collectMatches exception", e)
        }
    }

    private fun collectByResourceId(
        node: AccessibilityNodeInfo,
        needle: String,
        out: MutableList<AccessibilityNodeInfo>
    ) {
        try {
            val id = node.viewIdResourceName?.lowercase() ?: ""
            if (id.contains(needle)) out.add(node)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                collectByResourceId(child, needle, out)
            }
        } catch (e: Exception) {
            Log.w(TAG, "collectByResourceId exception", e)
        }
    }

    // ---------------------------------------------------------------
    // WhatsApp Clean Automation (Fixed: Immediately stops, never clicks mic)
    // ---------------------------------------------------------------

    /**
     * Monitors the screen after a WhatsApp deep-link is launched and automatically taps the Send button
     * (content-desc="Send" or id="send" or send icon) for hands-free message delivery.
     * Stops polling immediately after clicking to avoid clicking the microphone icon.
     */
    fun scheduleWhatsAppAutoSend() {
        val mainHandler = Handler(Looper.getMainLooper())
        mainHandler.postDelayed(object : Runnable {
            var attempts = 0
            override fun run() {
                val root = rootInActiveWindow
                if (root != null) {
                    val sendNode = findWhatsAppSendButton(root)
                    if (sendNode != null) {
                        tapNodeOrParent(sendNode)
                        Log.d(TAG, "Successfully tapped WhatsApp send button on attempt $attempts. Disarming.")
                        return
                    }
                }

                attempts++
                if (attempts < 14) {
                    mainHandler.postDelayed(this, 300)
                }
            }
        }, 500)
    }

    private fun findWhatsAppSendButton(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val text = node.text?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""

        if (desc == "send" || desc == "send message" || text == "send" || viewId.endsWith(":id/send")) {
            return node
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findWhatsAppSendButton(child)
            if (result != null) return result
        }
        return null
    }

    fun scheduleWhatsAppCallAutoTap(callType: String) {
        val isVideo = callType.lowercase().contains("video")
        val mainHandler = Handler(Looper.getMainLooper())
        mainHandler.postDelayed(object : Runnable {
            var attempts = 0
            var callButtonTapped = false

            override fun run() {
                val root = rootInActiveWindow
                if (root != null) {
                    if (!callButtonTapped) {
                        val callNode = findWhatsAppCallButton(root, isVideo)
                        if (callNode != null) {
                            val success = tapDirectOrImmediateClickable(callNode)
                            if (success) {
                                callButtonTapped = true
                                Log.d(TAG, "Tapped WhatsApp call button, watching for confirmation dialog...")
                            }
                        }
                    } else {
                        val confirmNode = findWhatsAppCallConfirmButton(root)
                        if (confirmNode != null) {
                            tapNodeOrParent(confirmNode)
                            Log.d(TAG, "Tapped WhatsApp Call confirmation dialog button!")
                            return
                        }
                    }
                }

                attempts++
                if (attempts < 16) {
                    mainHandler.postDelayed(this, 350)
                }
            }
        }, 500)
    }

    private fun tapDirectOrImmediateClickable(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) {
            val ok = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (ok) return true
        }
        val parent = node.parent
        if (parent != null && parent.isClickable) {
            val parentId = parent.viewIdResourceName?.lowercase() ?: ""
            if (!parentId.contains("header") && !parentId.contains("action_bar") && !parentId.contains("toolbar")) {
                val ok = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (ok) return true
            }
        }
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.width() > 0 && bounds.height() > 0) {
            return tapAtAbsoluteCoordinates(bounds.centerX().toFloat(), bounds.centerY().toFloat())
        }
        return false
    }

    private fun findWhatsAppCallConfirmButton(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.trim()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.trim()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""

        if (viewId.endsWith(":id/button1") ||
            text == "call" || text == "video call" || text == "start call" || text == "कॉल करें" || text == "कॉल" ||
            desc == "call" || desc == "video call" || desc == "start call") {
            if (node.isClickable || node.parent?.isClickable == true) {
                return node
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val res = findWhatsAppCallConfirmButton(child)
            if (res != null) return res
        }
        return null
    }

    private fun findWhatsAppCallButton(node: AccessibilityNodeInfo, isVideo: Boolean): AccessibilityNodeInfo? {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""

        if (desc.contains("profile") || desc.contains("photo") || desc.contains("picture") ||
            desc.contains("avatar") || desc.contains("header") || desc.contains("navigate up") ||
            desc.contains("back") || viewId.contains("picture") || viewId.contains("avatar")) {
            return null
        }

        val isTarget = if (isVideo) {
            (desc.contains("video call") || viewId.endsWith(":id/video_call") || viewId.endsWith(":id/menuitem_video_call")) &&
                    !desc.contains("voice")
        } else {
            (desc == "voice call" || desc == "call" || desc.startsWith("voice call") ||
                    viewId.endsWith(":id/voice_call") || viewId.endsWith(":id/menuitem_call")) &&
                    !desc.contains("video")
        }

        if (isTarget && (node.isClickable || node.parent?.isClickable == true)) {
            return node
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findWhatsAppCallButton(child, isVideo)
            if (result != null) return result
        }
        return null
    }

    private fun tapNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                val ok = current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (ok) return true
            }
            current = current.parent
        }
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.width() > 0 && bounds.height() > 0) {
            return tapAtAbsoluteCoordinates(bounds.centerX().toFloat(), bounds.centerY().toFloat())
        }
        return false
    }

    fun tapAtPercentage(xPercent: Float, yPercent: Float): Boolean {
        val dm = resources.displayMetrics
        val x = (xPercent / 100f) * dm.widthPixels
        val y = (yPercent / 100f) * dm.heightPixels
        clickAt(x, y)
        return true
    }

    fun tapAtAbsoluteCoordinates(x: Float, y: Float): Boolean {
        clickAt(x, y)
        return true
    }

    fun clickNodeWithText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return clickFirstMatchingText(root, text)
    }

    fun typeText(textToType: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null && focused.isEditable) {
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
            }
            return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
        return false
    }

    fun getActiveRootNode(): AccessibilityNodeInfo? {
        // Prefer Android's active-window root. If unavailable, only accept a window
        // that Android explicitly marks focused/active; never guess with an arbitrary
        // application window because dialogs, keyboards, and split-screen can reorder it.
        val active = rootInActiveWindow
        if (active != null) return active

        // 2. Fallback to focused application window
        try {
            val focusedAppWin = windows.firstOrNull {
                it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.isFocused
            }
            if (focusedAppWin?.root != null) return focusedAppWin.root

            // 3. Fallback to active application window
            val activeAppWin = windows.firstOrNull {
                it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.isActive
            }
            if (activeAppWin?.root != null) return activeAppWin.root

            return null
        } catch (e: Exception) {
            Log.w(TAG, "Error resolving active root node across windows: ${e.message}")
            return null
        }
    }

    fun getAppRootNode(): AccessibilityNodeInfo? {
        return getActiveRootNode()
    }

    fun performClickAtRect(rect: Rect): Boolean {
        if (rect.width() <= 0 || rect.height() <= 0) return false
        val cx = rect.exactCenterX()
        val cy = rect.exactCenterY()
        // Re-resolve against a fresh active root immediately before mutation. Prefer the
        // accessibility action; use a coordinate gesture only when no actionable node
        // resolves or ACTION_CLICK explicitly returns false.
        val root = getActiveRootNode()
        // Chrome's WebView targets often expose a clickable accessibility wrapper that
        // acknowledges ACTION_CLICK without forwarding the tap to the page control.
        // Prefer a real screen gesture there, then retain the node action as fallback.
        if (root?.packageName?.toString() == "com.android.chrome" && clickAt(cx, cy)) return true
        var node = root?.let { findNodeCoveringRect(it, rect) }
        while (node != null) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            if (node.isVisibleToUser && node.isClickable && bounds.contains(cx.toInt(), cy.toInt())) {
                if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                break
            }
            node = node.parent
        }
        Log.i(TAG, "Using coordinate fallback at ($cx, $cy) [bounds: $rect]")
        return clickAt(cx, cy)
    }

    fun performSmartScroll(direction: String, distance: String = "small"): Boolean {
        val dm = resources.displayMetrics
        val width = dm.widthPixels.toFloat()
        val height = dm.heightPixels.toFloat()

        // Calculate delta based on distance:
        // "small" = gentle line-by-line scroll (~18% of screen height, moving 1-2 rows at a time with 0 fling)
        // "medium" = ~30% of screen height
        // "large" = ~45% of screen height
        val deltaY = when (distance.lowercase()) {
            "small" -> height * 0.18f
            "large" -> height * 0.45f
            else -> height * 0.28f
        }
        val durationMs = when (distance.lowercase()) {
            "small" -> 600L  // Slow, controlled drag with ZERO fling momentum
            "large" -> 400L
            else -> 550L
        }

        val (startX, startY, endX, endY) = when (direction.lowercase()) {
            "down" -> listOf(width * 0.5f, height * 0.58f, width * 0.5f, height * 0.58f - deltaY)
            "up" -> listOf(width * 0.5f, height * 0.42f, width * 0.5f, height * 0.42f + deltaY)
            "left" -> listOf(width * 0.75f, height * 0.5f, width * 0.25f, height * 0.5f)
            "right" -> listOf(width * 0.25f, height * 0.5f, width * 0.75f, height * 0.5f)
            else -> listOf(width * 0.5f, height * 0.58f, width * 0.5f, height * 0.58f - deltaY)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                val path = Path().apply {
                    moveTo(startX, startY)
                    lineTo(endX, endY)
                }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
                    .build()
                val dispatched = dispatchGesture(gesture, null, null)
                Log.i(TAG, "Dispatched scroll $direction gesture (distance=$distance, deltaY=$deltaY, duration=${durationMs}ms): $dispatched")
                return dispatched
            } catch (e: Exception) {
                Log.e(TAG, "Scroll gesture failed: ${e.message}")
            }
        }
        return false
    }

    fun findNodeCoveringRect(root: AccessibilityNodeInfo, targetRect: Rect): AccessibilityNodeInfo? {
        val temp = Rect()
        fun search(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            node.getBoundsInScreen(temp)
            if (Rect.intersects(temp, targetRect)) {
                for (i in (node.childCount - 1) downTo 0) {
                    val child = node.getChild(i) ?: continue
                    val deep = search(child)
                    if (deep != null) return deep
                }
                return node
            }
            return null
        }
        return search(root)
    }

    fun findNodeWithInputFocus(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isFocused) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val res = findNodeWithInputFocus(child)
            if (res != null) return res
        }
        return null
    }

    fun verifyNodeText(node: AccessibilityNodeInfo?, expectedText: String): Boolean {
        if (node == null) return false
        val current = node.text?.toString()?.trim() ?: ""
        val exp = expectedText.trim()
        if (exp.isEmpty()) return true
        return current.contains(exp, ignoreCase = true) ||
               (current.isNotEmpty() && exp.contains(current, ignoreCase = true) && current.length >= 3)
    }

    fun smartTypeText(textToType: String, targetRect: Rect? = null, submit: Boolean = false): Boolean {
        lastTypeVerified = false
        if (textToType.isBlank()) {
            Log.w(TAG, "smartTypeText refused blank input")
            return false
        }
        Log.i(TAG, "smartTypeText starting (length=${textToType.length}, targeted=${targetRect != null}, submit=$submit)")

        if (targetRect != null && targetRect.width() > 0 && targetRect.height() > 0) {
            if (!performClickAtRect(targetRect)) return false
            Thread.sleep(100)
        }

        val appRoot = getAppRootNode() ?: getActiveRootNode() ?: return false
        val inBrowser = (appRoot.packageName?.toString() ?: "").let {
            it.contains("chrome", ignoreCase = true) || it.contains("browser", ignoreCase = true)
        }

        fun editableAt(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (targetRect != null && targetRect.width() > 0) {
                var node = findNodeCoveringRect(root, targetRect)
                while (node != null) {
                    if (node.isEditable || node.className?.toString()?.contains("EditText", true) == true) return node
                    node = node.parent
                }
                return null
            }
            return root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: findNodeWithInputFocus(root)
                ?: findFirstEditableNode(root)
        }

        var target = editableAt(appRoot)
        if (target != null && isUrlBarNode(target)) {
            Log.w(TAG, "smartTypeText refused browser URL/address bar")
            return false
        }
        if (target == null) {
            Log.w(TAG, "smartTypeText found no verified editable target; no text was entered")
            return false
        }

        fun currentTarget(): AccessibilityNodeInfo? {
            val freshRoot = getActiveRootNode() ?: getAppRootNode() ?: return null
            return editableAt(freshRoot)
        }
        fun textEqualsExpected(node: AccessibilityNodeInfo?): Boolean {
            val current = node?.text?.toString()?.replace("\r\n", "\n")?.trim().orEmpty()
            val expected = textToType.replace("\r\n", "\n").trim()
            return current == expected
        }
        fun setValue(node: AccessibilityNodeInfo, value: String): Boolean {
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        // Repeated model tool calls become idempotent: matching text is success, never paste it again.
        if (textEqualsExpected(target)) {
            lastTypeVerified = true
            Log.i(TAG, "smartTypeText skipped duplicate request: the exact text is already present")
        } else {
            var setAccepted = false
            try {
                setAccepted = setValue(target, textToType)
            } catch (e: Exception) {
                Log.w(TAG, "ACTION_SET_TEXT failed: ${e.message}")
            }

            if (setAccepted) {
                Thread.sleep(180)
                target = currentTarget()
                lastTypeVerified = textEqualsExpected(target)
                if (!lastTypeVerified) {
                    // A successful SET_TEXT with no readable confirmation may already have changed
                    // the UI. Do not paste on top of it; that was the source of repeated text.
                    Log.w(TAG, "Text set was not read back exactly; refusing append-style fallback")
                    return false
                }
            } else {
                // Paste fallback is safe only after the current field has been verified empty.
                // Clearing is done with ACTION_SET_TEXT, never by tapping an ambiguous clear icon.
                val fresh = currentTarget() ?: target
                val currentText = fresh.text?.toString().orEmpty()
                if (currentText.isNotBlank()) {
                    val cleared = try { setValue(fresh, "") } catch (_: Exception) { false }
                    Thread.sleep(120)
                    target = currentTarget()
                    if (!cleared || !target?.text?.toString().isNullOrBlank()) {
                        Log.w(TAG, "Existing input could not be safely cleared; refusing to append text")
                        return false
                    }
                } else {
                    target = fresh
                }

                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                try {
                    clipboard?.setPrimaryClip(ClipData.newPlainText("JarvisInput", textToType))
                    val pasteTarget = currentTarget() ?: target ?: return false
                    if (isUrlBarNode(pasteTarget)) return false
                    val pasted = pasteTarget.performAction(AccessibilityNodeInfo.ACTION_PASTE) ||
                        pasteTarget.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_PASTE.id)
                    if (!pasted) {
                        Log.w(TAG, "Safe paste unavailable; no second typing strategy was attempted")
                        return false
                    }
                    Thread.sleep(180)
                    lastTypeVerified = textEqualsExpected(currentTarget())
                    if (!lastTypeVerified) {
                        Log.w(TAG, "Pasted text could not be verified exactly; refusing to retry and duplicate it")
                        return false
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Safe paste failed: ${e.message}")
                    return false
                }
            }
        }

        // Never auto-tap Send/Submit as a side effect of typing. Search/submit actions
        // must be a separate, freshly inspected click; the service enforces send intent.
        if (submit) Log.i(TAG, "Submit requested after typing; waiting for an explicit grounded submit action")
        return lastTypeVerified
    }

    private fun performLongPressAndPaste(targetRect: Rect): Boolean {
        val clickX = targetRect.centerX().toFloat()
        val clickY = targetRect.centerY().toFloat()
        val path = Path().apply { moveTo(clickX, clickY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 450))
            .build()
        try {
            dispatchGesture(gesture, null, null)
        } catch (e: Exception) {
            Log.e(TAG, "Long-press gesture dispatch failed: ${e.message}")
            return false
        }

        // Active polling: wait for Android floating text selection toolbar to appear (up to 800ms)
        val startTime = System.currentTimeMillis()
        var pasteNode: AccessibilityNodeInfo? = null
        while (System.currentTimeMillis() - startTime < 800L) {
            try { Thread.sleep(60) } catch (_: Exception) {}
            pasteNode = findPasteButtonAcrossWindows()
            if (pasteNode != null) break
        }

        if (pasteNode != null) {
            Log.i(TAG, "Found native Paste popup menu item: ${pasteNode.text ?: pasteNode.contentDescription}")
            val clicked = clickNodeAndTap(pasteNode)
            Thread.sleep(120)
            return clicked
        }
        return false
    }

    private fun findPasteButtonAcrossWindows(): AccessibilityNodeInfo? {
        val pasteKeywords = listOf("paste", "चिपकाएं", "पेस्ट", "paste from clipboard", "insert")
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                for (window in windows) {
                    val root = window.root ?: continue
                    val found = searchNodeForKeywords(root, pasteKeywords)
                    if (found != null) return found
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "Error inspecting windows for paste button: ${e.message}")
        }
        val appRoot = getAppRootNode() ?: getActiveRootNode() ?: return null
        return searchNodeForKeywords(appRoot, pasteKeywords)
    }

    private fun searchNodeForKeywords(node: AccessibilityNodeInfo, keywords: List<String>): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.lowercase(Locale.ROOT) ?: ""
        val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT) ?: ""
        val vid = node.viewIdResourceName?.lowercase(Locale.ROOT) ?: ""

        for (kw in keywords) {
            if (text == kw || desc == kw || text.contains(kw) || desc.contains(kw) || vid.contains(kw)) {
                if (node.isClickable || node.parent?.isClickable == true) {
                    return if (node.isClickable) node else node.parent
                }
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = searchNodeForKeywords(child, keywords)
            if (found != null) return found
        }
        return null
    }

    /**
     * Searches across ALL active windows — specifically including TYPE_INPUT_METHOD (Gboard) —
     * for a clipboard suggestion chip or paste action button.
     */
    private fun findClipboardChipAcrossAllWindows(textToType: String): AccessibilityNodeInfo? {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // Priority 1: Check Input Method window (Gboard/keyboard strip)
                for (window in windows) {
                    if (window.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                        val root = window.root ?: continue
                        val found = findClipboardSuggestionChip(root, textToType)
                        if (found != null) {
                            Log.i(TAG, "Found clipboard suggestion chip in TYPE_INPUT_METHOD window!")
                            return found
                        }
                    }
                }
                // NOTE: other windows (Chrome page, menus, omnibox suggestions) are intentionally NOT searched:
                // matching generic "chip"/"suggestion" ids there caused random mis-taps.
            }
        } catch (e: Exception) {
            Log.d(TAG, "Error searching windows for clipboard chip: ${e.message}")
        }
        return null
    }

    private fun findClipboardSuggestionChip(node: AccessibilityNodeInfo, textToType: String): AccessibilityNodeInfo? {
        val snippet = textToType.take(8).lowercase(Locale.ROOT)
        val text = node.text?.toString()?.lowercase(Locale.ROOT) ?: ""
        val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT) ?: ""
        val vid = node.viewIdResourceName?.lowercase(Locale.ROOT) ?: ""

        val isChipMatch = (vid.contains("clipboard") || desc.contains("clipboard") ||
            (snippet.length >= 3 && (text.contains(snippet) || desc.contains(snippet))))

        if (isChipMatch && (node.isClickable || node.parent?.isClickable == true)) {
            return if (node.isClickable) node else node.parent
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findClipboardSuggestionChip(child, textToType)
            if (found != null) return found
        }
        return null
    }

    /** True for Chrome's address bar / omnibox / NTP search box. Page prompts must NEVER be typed here. */
    fun isUrlBarNode(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        val vid = node.viewIdResourceName?.lowercase(Locale.ROOT) ?: ""
        return vid.contains("url_bar") || vid.contains("omnibox") ||
               vid.contains("location_bar") || vid.contains("search_box_text")
    }

    /** True while the soft keyboard (an input-method window) is on screen. */
    fun isKeyboardVisible(): Boolean {
        return try {
            windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
        } catch (e: Exception) {
            false
        }
    }

    /** Result of the last smartTypeText call: true only if the typed text was READ BACK from the screen. */
    @Volatile
    var lastTypeVerified: Boolean = false

    /**
     * Reads the real screen (application windows only; NOT the keyboard, so the Gboard clipboard chip
     * cannot cause a false positive; NOT the URL bar) and checks whether the start of [text] is visible.
     * Polls for up to ~1.2s because Chrome syncs web inputs to the accessibility tree with a delay.
     */
    fun verifyTextVisibleAnywhere(text: String): Boolean {
        val snippet = text.trim().take(24).lowercase(Locale.ROOT)
        if (snippet.length < 3) return true
        fun scan(n: AccessibilityNodeInfo, depth: Int): Boolean {
            if (depth > 60) return false
            if (!isUrlBarNode(n)) {
                val t = n.text?.toString()?.lowercase(Locale.ROOT) ?: ""
                val d = n.contentDescription?.toString()?.lowercase(Locale.ROOT) ?: ""
                if (t.contains(snippet) || d.contains(snippet)) return true
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                if (scan(c, depth + 1)) return true
            }
            return false
        }
        repeat(4) {
            try {
                for (w in windows) {
                    if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                    val r = w.root ?: continue
                    if (scan(r, 0)) return true
                }
            } catch (e: Exception) {
                Log.d(TAG, "verifyTextVisibleAnywhere error: ${e.message}")
            }
            try { Thread.sleep(300) } catch (_: Exception) {}
        }
        return false
    }

    fun findFirstEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if ((node.isEditable || node.className?.toString()?.contains("EditText") == true) && !isUrlBarNode(node)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val res = findFirstEditableNode(child)
            if (res != null) return res
        }
        return null
    }

    private fun findSearchOrSubmitButton(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        return findSubmitButtonInTree(node) ?: findSendButtonByPosition()
    }

    /** Depth-first search for a named send/generate/submit button, explicitly excluding attach/add/+ buttons. */
    private fun findSubmitButtonInTree(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val text = node.text?.toString()?.lowercase() ?: ""
        val vid = node.viewIdResourceName?.lowercase() ?: ""

        // EXPLICITLY EXCLUDE attachment / add-media / plus buttons — these are NOT submit buttons
        val isAttachOrAddButton = desc.contains("attach") || desc.contains("add file") ||
                desc.contains("add media") || desc.contains("add image") ||
                desc.contains("add attachment") || desc.contains("add photo") ||
                desc.contains("upload") || desc.contains("insert") ||
                text == "+" || text == "add" ||
                vid.contains("attach") || vid.contains("add_media") ||
                vid.contains("add_file") || vid.contains("add_photo") ||
                vid.contains("media_button") || vid.contains("plus_button")
        if (isAttachOrAddButton) {
            // Don't search this node but DO search its siblings via parent — skip to children check
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                val found = findSubmitButtonInTree(child)
                if (found != null) return found
            }
            return null
        }

        val isMatch = desc.contains("send") || desc.contains("submit") || desc.contains("generate") ||
                desc.contains("create image") || desc.contains("create video") ||
                desc.contains("run") || desc.contains("done") || desc.contains("apply") ||
                desc.contains("go") || desc.contains("search") || desc.contains("enter") ||
                desc == "→" || desc == "▶" || desc.contains("arrow") ||
                text == "send" || text == "go" || text == "generate" || text == "create" ||
                text == "submit" || text == "done" || text == "search" || text == "run" ||
                vid.contains("send_button") || vid.contains("send_btn") ||
                vid.contains("search_button") || vid.contains("search_go_btn") ||
                vid.contains("submit_button") || vid.contains("generate_button") ||
                vid.contains("action_button") || vid.contains("btn_send")

        if (isMatch && (node.isClickable || node.parent?.isClickable == true)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findSubmitButtonInTree(child)
            if (found != null) return found
        }
        return null
    }

    /**
     * Position-based fallback: finds the send/generate button by its typical screen position
     * (small clickable button in the bottom-right area). Used when Gemini's arrow button has
     * no text or contentDescription that matches keyword search.
     */
    private fun findSendButtonByPosition(): AccessibilityNodeInfo? {
        val root = getAppRootNode() ?: getActiveRootNode() ?: return null
        val displayMetrics = resources.displayMetrics
        val screenW = displayMetrics.widthPixels
        val screenH = displayMetrics.heightPixels

        // Bottom-right quadrant: right 35% width, bottom 25% height
        val searchLeft = (screenW * 0.65f).toInt()
        val searchTop = (screenH * 0.75f).toInt()

        val candidates = mutableListOf<Pair<AccessibilityNodeInfo, Rect>>()

        fun collectCandidates(node: AccessibilityNodeInfo) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            if (node.isClickable && !node.isEditable &&
                bounds.left >= searchLeft && bounds.top >= searchTop &&
                bounds.width() in 30..300 && bounds.height() in 30..200) {
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                val vid = node.viewIdResourceName?.lowercase() ?: ""
                // Exclude attach/voice/mic buttons
                val isExcluded = desc.contains("attach") || desc.contains("mic") ||
                        desc.contains("voice") || desc.contains("emoji") ||
                        desc.contains("camera") || desc.contains("sticker") ||
                        vid.contains("mic") || vid.contains("voice") || vid.contains("attach")
                if (!isExcluded) {
                    candidates.add(Pair(node, bounds))
                }
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { collectCandidates(it) }
            }
        }
        collectCandidates(root)

        // Pick the rightmost button (send/generate is always at far right)
        return candidates.maxByOrNull { it.second.right }?.first
    }

    fun performSystemGesture(gesture: String): Boolean {
        return when (gesture.lowercase()) {
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            else -> false
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/accessibility/JarvisAccessibilityService.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/agent/ActionVerifier.kt ===
```kotlin
package com.jarvis.assistant.automation.agent

import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService
import kotlinx.coroutines.delay

/**
 * Closed-loop action verification engine.
 * Never assumes an action succeeded just because a gesture or API call returned true.
 * Performs rigorous before/after state comparison.
 */
object ActionVerifier {
    private const val TAG = "ActionVerifier"

    /**
     * Verifies that typing actually inserted the expected text into the target input field.
     */
    suspend fun verifyTyping(
        service: JarvisAccessibilityService,
        targetRect: Rect?,
        expectedText: String,
        retries: Int = 2
    ): VerificationResult {
        val cleanExpected = expectedText.trim()
        if (cleanExpected.isEmpty()) {
            return VerificationResult(isVerified = true, reason = "Empty text to type")
        }

        for (attempt in 0..retries) {
            delay(80)
            val root = service.getActiveRootNode() ?: service.getAppRootNode()
            if (root == null) {
                if (attempt < retries) continue
                return VerificationResult(
                    isVerified = false,
                    reason = "No active root node found to verify typed text"
                )
            }

            // 1. Check node at target rect
            var targetNode: AccessibilityNodeInfo? = null
            if (targetRect != null && targetRect.width() > 0) {
                targetNode = service.findNodeCoveringRect(root, targetRect)
            }

            // A target rectangle must resolve back to that same visible editable field.
            // Falling back to an unrelated focused/first editable field could verify
            // text in the wrong input and falsely report success.
            if (targetNode == null) {
                if (targetRect == null) {
                    targetNode = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                        ?: service.findNodeWithInputFocus(root)
                }
            }

            if (targetNode != null && targetNode.isVisibleToUser && targetNode.isEditable) {
                val actualText = targetNode.text?.toString() ?: ""
                // Do not log entered text: it may contain searches, messages, or credentials.
                Log.d(TAG, "Verify typing: target length=${actualText.length}, expected length=${cleanExpected.length}")
                val normalize = { value: String ->
                    value.replace("\r\n", "\n").replace(Regex("\\s+"), " ").trim()
                }

                if (normalize(actualText) == normalize(cleanExpected)) {
                    return VerificationResult(
                        isVerified = true,
                        reason = "Text verified in target field",
                        stateChanged = true,
                        actualValue = null
                    )
                }
            }

        }

        return VerificationResult(
            isVerified = false,
            reason = "Text mismatch: the target input value did not match the requested text",
            stateChanged = false,
            isRetryable = true
        )
    }

    /**
     * Verifies that a click caused a measurable UI state change.
     */
    suspend fun verifyClick(
        preSignature: ScreenSignature,
        service: JarvisAccessibilityService,
        waitMs: Long = 300L
    ): VerificationResult {
        delay(waitMs)
        val postRoot = service.getActiveRootNode() ?: service.getAppRootNode()
        val postSignature = ScreenSignatureCalculator.computeSignature(postRoot)

        // 1. Window or package transition
        if (postSignature.packageName != preSignature.packageName ||
            postSignature.className != preSignature.className) {
            return VerificationResult(
                isVerified = false,
                reason = "Window transitioned, but the requested destination was not checked",
                stateChanged = true
            )
        }

        // 2. Element tree change
        if (!postSignature.isEquivalentTo(preSignature)) {
            return VerificationResult(
                isVerified = false,
                reason = "UI content changed, but the requested result was not checked",
                stateChanged = true
            )
        }

        // Slight extra delay in case of slow animation
        delay(200L)
        val secondCheckRoot = service.getActiveRootNode() ?: service.getAppRootNode()
        val secondSignature = ScreenSignatureCalculator.computeSignature(secondCheckRoot)
        if (!secondSignature.isEquivalentTo(preSignature)) {
            return VerificationResult(
                isVerified = false,
                reason = "UI transitioned after layout animation, but the requested result was not checked",
                stateChanged = true
            )
        }

        return VerificationResult(
            isVerified = false,
            reason = "No detectable UI change after click (UI state remained identical)",
            stateChanged = false,
            isRetryable = true
        )
    }

    /**
     * Verifies that a scroll produced new visible items or reached the end of list.
     */
    fun verifyScroll(
        preSignature: ScreenSignature,
        postSignature: ScreenSignature
    ): VerificationResult {
        if (postSignature.isEquivalentTo(preSignature)) {
            return VerificationResult(
                isVerified = false,
                reason = "No visible scroll progress detected; the list end is unproven",
                stateChanged = false
            )
        }
        return VerificationResult(
            isVerified = true,
            reason = "Scroll revealed new content",
            stateChanged = true
        )
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/agent/ActionVerifier.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/agent/AgentModels.kt ===
```kotlin
package com.jarvis.assistant.automation.agent

import android.graphics.Rect
import java.util.UUID

enum class TaskStepStatus { PENDING, READY, RUNNING, WAITING_FOR_UI, VERIFYING, COMPLETED, RECOVERING, BLOCKED, FAILED, CANCELLED }

data class TaskPlanStep(
    val stepId: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val status: TaskStepStatus = TaskStepStatus.PENDING,
    val dependencies: List<String> = emptyList(),
    val expectedResult: String = "",
    val actualResult: String? = null,
    val retryCount: Int = 0,
    val startedAt: Long? = null,
    val completedAt: Long? = null,
    val failureReason: String? = null
)

/** Immutable value rendered by both the floating overlay and the in-app fallback. */
data class AgentTaskSnapshot(
    val taskId: String,
    val originalGoal: String,
    val normalizedGoal: String,
    val currentPlan: String,
    val currentStepId: String?,
    val steps: List<TaskPlanStep>,
    val completedSteps: List<String>,
    val pendingSteps: List<String>,
    val processedItems: Set<String>,
    val currentObservation: String?,
    val lastAction: String?,
    val lastActionResult: String?,
    val currentStatus: String,
    val progressPercentage: Int,
    val retryCount: Int,
    val recoveryCount: Int,
    val lastProgressTimestamp: Long,
    val cancellationRequested: Boolean,
    val finalVerificationResult: String?,
    val failureReason: String?
)

/**
 * Core models for the JARVIS True Agentic Task Engine.
 * Enforces structured planning, execution, verification, and state tracking.
 */

data class TaskGoal(
    val rawGoal: String,
    val isBulkAction: Boolean = false,
    val bulkKeywords: List<String> = emptyList(),
    val maxSteps: Int = 30,
    val requiresVerification: Boolean = true
) {
    companion object {
        private val BULK_INDICATORS = listOf(
            "all", "every", "each", "everyone", "sab", "sabhi", "saare", "saari", "sare", "sari",
            "until none remain", "all liked", "all posts", "all reels", "unlike all",
            "liked reels", "liked posts", "my liked reels", "my liked posts", "meri liked reels", "meri liked posts"
        )

        fun fromUserUtterance(utterance: String): TaskGoal {
            val lower = utterance.lowercase().trim()
            val matchedKeywords = BULK_INDICATORS.filter { keyword ->
                if (keyword.any { it.isWhitespace() }) {
                    lower.contains(keyword)
                } else {
                    Regex("(?<![\\p{L}\\p{N}])${Regex.escape(keyword)}(?![\\p{L}\\p{N}])")
                        .containsMatchIn(lower)
                }
            }
            val isBulk = matchedKeywords.isNotEmpty()
            return TaskGoal(
                rawGoal = utterance,
                isBulkAction = isBulk,
                bulkKeywords = matchedKeywords,
                maxSteps = if (isBulk) 40 else 25
            )
        }
    }
}

enum class AgentTaskStatus {
    IDLE,
    PLANNING,
    OBSERVING,
    EXECUTING,
    VERIFYING,
    RETRYING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class ScreenSignature(
    val packageName: String,
    val className: String,
    val elementCount: Int,
    val contentHash: Long,
    val primaryTexts: List<String> = emptyList()
) {
    fun isEquivalentTo(other: ScreenSignature?): Boolean {
        if (other == null) return false
        if (packageName != other.packageName) return false
        // If contentHash matches or primary texts are identical, it's the same screen
        if (contentHash == other.contentHash) return true
        if (elementCount == other.elementCount && primaryTexts == other.primaryTexts) return true
        return false
    }
}

data class VerificationResult(
    val isVerified: Boolean,
    val reason: String,
    val stateChanged: Boolean = false,
    val actualValue: String? = null,
    val isRetryable: Boolean = false
)

data class ActionExecutionResult(
    val success: Boolean,
    val verified: Boolean,
    val message: String,
    val preSignature: ScreenSignature? = null,
    val postSignature: ScreenSignature? = null,
    val isEndConditionReached: Boolean = false
)

class TaskContext(
    val goal: TaskGoal
) {
    var status: AgentTaskStatus = AgentTaskStatus.IDLE
    var currentStep: Int = 0
    var lastScreenSignature: ScreenSignature? = null
    var consecutiveNoProgressCount: Int = 0
    val processedItemSignatures: MutableSet<String> = mutableSetOf()
    var isCompleted: Boolean = false
    var terminationReason: String? = null

    fun markItemProcessed(itemKey: String) {
        processedItemSignatures.add(itemKey)
    }

    fun isItemProcessed(itemKey: String): Boolean {
        return processedItemSignatures.contains(itemKey)
    }

    fun recordProgress(newSignature: ScreenSignature?) {
        lastScreenSignature = newSignature
        consecutiveNoProgressCount = 0
    }

    fun recordNoProgress() {
        consecutiveNoProgressCount++
    }

    fun isStuck(): Boolean = consecutiveNoProgressCount >= 3
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/agent/AgentModels.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/agent/AgentTaskEngine.kt ===
```kotlin
package com.jarvis.assistant.automation.agent

import android.util.Log
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex

/** Authoritative in-process state for the active, user-requested accessibility task. */
object AgentTaskEngine {
    private const val TAG = "AgentTaskEngine"

    enum class State {
        IDLE, UNDERSTANDING, PLANNING, OBSERVING, RESOLVING_TARGET, ACTING,
        VERIFYING, CONTINUING, REPLANNING, RECOVERING, WAITING_FOR_UI,
        PAUSED, BLOCKED, COMPLETED, FAILED, CANCELLED
    }

    enum class TaskScope { SINGLE_TARGET, ALL_MATCHING, SEARCH_UNTIL_FOUND }
    enum class CompletionEvidence { UNKNOWN, VERIFIED_GOAL, TARGET_NOT_FOUND, END_REACHED, NO_PROGRESS, LOADING, NEEDS_LOGIN, AMBIGUOUS, SAFETY_LIMIT, CANCELLED }
    data class LoopOutcome(val iterations: Int, val reachedLimit: Boolean, val cancelled: Boolean, val error: String? = null)

    data class Context(
        val taskId: String,
        val originalGoal: String,
        val normalizedGoal: String,
        val taskScope: TaskScope,
        val origin: String,
        val actionGeneration: Long,
        var currentApp: String? = null,
        var targetApp: String? = null,
        val plan: MutableList<String> = mutableListOf(),
        var currentStep: String? = null,
        val completedSteps: MutableList<String> = mutableListOf(),
        val pendingSteps: MutableList<String> = mutableListOf(),
        val steps: MutableList<TaskPlanStep> = mutableListOf(),
        var currentStepId: String? = null,
        var recoveryCount: Int = 0,
        var finalVerificationResult: String? = null,
        val processedItemIds: MutableSet<String> = mutableSetOf(),
        val processedItemSignatures: MutableSet<String> = mutableSetOf(),
        var lastAction: String? = null,
        var lastActionResult: String? = null,
        var lastActionVerified: Boolean = false,
        var lastObservation: String? = null,
        var currentScreenSignature: ScreenSignature? = null,
        var previousScreenSignature: ScreenSignature? = null,
        var retryCount: Int = 0,
        var actionRetryCount: Int = 0,
        var scrollCount: Int = 0,
        var noProgressCount: Int = 0,
        var consecutiveFailureCount: Int = 0,
        val startTime: Long = System.currentTimeMillis(),
        var lastProgressTime: Long = startTime,
        var status: State = State.UNDERSTANDING,
        var failureReason: String? = null,
        var completionEvidence: CompletionEvidence = CompletionEvidence.UNKNOWN,
        var completionEvidenceDetail: String? = null,
        @Volatile var cancellationRequested: Boolean = false
    )

    @Volatile private var active: Context? = null
    private val _taskState = MutableStateFlow<AgentTaskSnapshot?>(null)
    val taskState: StateFlow<AgentTaskSnapshot?> = _taskState.asStateFlow()
    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()
    private val _controlRevision = MutableStateFlow(0L)
    @Volatile private var resumeObservationRequired = false
    private val executionLoopMutex = Mutex()

    @Synchronized
    fun begin(goal: String, scope: String = "accessibility") : Context {
        val current = active
        if (current != null && current.status !in setOf(State.COMPLETED, State.FAILED, State.CANCELLED)) {
            if (goal.isBlank() || current.normalizedGoal == normalize(goal)) return current
        }
        val actionGeneration = SerializedActionExecutor.startNewTask()
        val normalized = normalize(goal)
        val taskScope = when {
            TaskGoal.fromUserUtterance(goal).isBulkAction -> TaskScope.ALL_MATCHING
            listOf("search", "find", "look for", "find me", "dhoondh", "dhundo", "talaash")
                .any { normalized.contains(it) } -> TaskScope.SEARCH_UNTIL_FOUND
            else -> TaskScope.SINGLE_TARGET
        }
        return Context(UUID.randomUUID().toString(), goal, normalized, taskScope, scope, actionGeneration).also { context ->
            val titles = planTitles(goal)
            context.plan.addAll(titles)
            titles.forEachIndexed { index, title ->
                context.steps += TaskPlanStep(
                    title = title,
                    description = planDescription(title, goal),
                    status = if (index == 0) TaskStepStatus.COMPLETED else TaskStepStatus.PENDING,
                    dependencies = if (index == 0) emptyList() else listOf(context.steps[index - 1].stepId),
                    expectedResult = expectedResult(title),
                    actualResult = if (index == 0) "Goal parsed and task scope classified" else null,
                    startedAt = if (index == 0) context.startTime else null,
                    completedAt = if (index == 0) context.startTime else null
                )
            }
            context.completedSteps += titles.firstOrNull().orEmpty()
            context.pendingSteps.addAll(titles.drop(1))
            active = context
            _isPaused.value = false
            resumeObservationRequired = false
            startNextReady(context)
            publish(context)
        }
    }

    fun current(): Context? = active

    /** Clears task state when a live Jarvis session is explicitly stopped or restarted. */
    @Synchronized
    fun resetForSession() {
        active?.let { it.cancellationRequested = true }
        SerializedActionExecutor.cancelAllPendingActions()
        active = null
        _taskState.value = null
        _isPaused.value = false
        resumeObservationRequired = false
        _controlRevision.value += 1
    }

    /** The single task-owned gate for every serialized accessibility/UI mutation. */
    suspend fun executeUiMutation(action: String, operation: suspend () -> Boolean): Boolean {
        val context = active
        if (context?.cancellationRequested == true) return false
        if (context?.status == State.BLOCKED) return false
        if (!awaitIfRunnable()) return false
        if (context != null && resumeObservationRequired) {
            val expectedBeforePause = context.currentScreenSignature
            val service = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance
            val root = service?.getActiveRootNode()
            if (root == null) return false
            val freshSignature = ScreenSignatureCalculator.computeSignature(root)
            observe(freshSignature, root.packageName?.toString(), "Fresh accessibility observation after resume")
            resumeObservationRequired = false
            if (expectedBeforePause != null && !freshSignature.isEquivalentTo(expectedBeforePause)) {
                context.lastAction = action
                context.lastActionResult = "Action rejected because the UI changed while paused; target must be resolved again from the fresh screen"
                context.lastActionVerified = false
                context.status = State.REPLANNING
                context.recoveryCount++
                publish(context)
                return false
            }
        }
        context?.let { if (it.status !in setOf(State.COMPLETED, State.FAILED, State.CANCELLED)) it.status = State.ACTING }
        val executed = SerializedActionExecutor.execute(
            action,
            expectedGeneration = context?.actionGeneration,
            block = { if (awaitIfRunnable()) operation() else false }
        ) == true
        if (!executed && context != null && !context.cancellationRequested) {
            synchronized(this) {
                active?.takeIf { it.taskId == context.taskId }?.let {
                    it.consecutiveFailureCount++
                    it.lastAction = action
                    it.lastActionResult = "UI mutation was rejected, cancelled, or failed before verification"
                    it.lastActionVerified = false
                    it.status = State.RECOVERING
                }
            }
        }
        publishIfCurrent(context)
        return executed
    }

    @Synchronized
    fun setState(state: State) {
        active?.let {
            if (!it.cancellationRequested) {
                it.status = state
                val step = it.steps.firstOrNull { step -> step.stepId == it.currentStepId }
                val stepStatus = when (state) {
                    State.WAITING_FOR_UI -> TaskStepStatus.WAITING_FOR_UI
                    State.VERIFYING -> TaskStepStatus.VERIFYING
                    State.RECOVERING, State.REPLANNING -> TaskStepStatus.RECOVERING
                    State.BLOCKED -> TaskStepStatus.BLOCKED
                    State.FAILED -> TaskStepStatus.FAILED
                    State.CANCELLED -> TaskStepStatus.CANCELLED
                    State.COMPLETED -> TaskStepStatus.COMPLETED
                    State.PAUSED -> TaskStepStatus.PENDING
                    State.ACTING, State.RESOLVING_TARGET, State.OBSERVING, State.CONTINUING -> TaskStepStatus.RUNNING
                    else -> null
                }
                if (step != null && stepStatus != null && step.status != TaskStepStatus.COMPLETED) {
                    replaceStep(it, step.copy(status = stepStatus, startedAt = step.startedAt ?: System.currentTimeMillis()))
                }
                publish(it)
            }
        }
    }

    @Synchronized
    fun observe(signature: ScreenSignature?, packageName: String?, summary: String? = null) {
        val context = active ?: return
        context.previousScreenSignature = context.currentScreenSignature
        context.currentScreenSignature = signature
        context.currentApp = packageName
        context.lastObservation = summary
        if (signature != null && context.previousScreenSignature?.isEquivalentTo(signature) == false) {
            context.noProgressCount = 0
            context.lastProgressTime = System.currentTimeMillis()
        }
        publish(context)
    }

    @Synchronized
    fun recordAction(action: String, result: String, verified: Boolean) {
        val context = active ?: return
        context.lastAction = action
        context.lastActionResult = result
        context.lastActionVerified = verified
        if (verified) {
            context.consecutiveFailureCount = 0
            context.lastProgressTime = System.currentTimeMillis()
        } else context.consecutiveFailureCount++
        publish(context)
    }

    fun requestCancellation() {
        val context = active ?: return
        context.cancellationRequested = true
        context.status = State.CANCELLED
        _isPaused.value = false
        _controlRevision.value += 1
        context.steps.indices.forEach { index ->
            val step = context.steps[index]
            if (step.status !in setOf(TaskStepStatus.COMPLETED, TaskStepStatus.FAILED)) {
                context.steps[index] = step.copy(status = TaskStepStatus.CANCELLED, failureReason = "Task cancelled")
            }
        }
        SerializedActionExecutor.cancelAllPendingActions()
        publish(context)
        Log.i(TAG, "Task ${context.taskId} cancellation requested")
    }

    @Synchronized
    fun finish(state: State, reason: String? = null): Boolean {
        val context = active ?: return false
        val bulkEndVerified = context.taskScope == TaskScope.ALL_MATCHING &&
            context.completionEvidence == CompletionEvidence.END_REACHED &&
            context.processedItemSignatures.isNotEmpty()
        if (state == State.COMPLETED && context.completionEvidence != CompletionEvidence.VERIFIED_GOAL && !bulkEndVerified) {
            context.failureReason = "Completion rejected: local goal evidence is ${context.completionEvidence}."
            return false
        }
        context.status = state
        context.failureReason = reason
        if (state == State.COMPLETED) {
            context.finalVerificationResult = context.completionEvidenceDetail
            context.steps.indices.forEach { index ->
                val step = context.steps[index]
                if (step.status == TaskStepStatus.RUNNING || step.status == TaskStepStatus.VERIFYING) {
                    context.steps[index] = step.copy(status = TaskStepStatus.COMPLETED, actualResult = context.completionEvidenceDetail, completedAt = System.currentTimeMillis())
                    if (step.title !in context.completedSteps) context.completedSteps += step.title
                }
            }
        } else if (state == State.FAILED || state == State.BLOCKED) {
            context.steps.firstOrNull { it.status !in setOf(TaskStepStatus.COMPLETED, TaskStepStatus.CANCELLED) }?.let { step ->
                replaceStep(context, step.copy(status = if (state == State.BLOCKED) TaskStepStatus.BLOCKED else TaskStepStatus.FAILED, failureReason = reason))
            }
        }
        publish(context)
        return true
    }

    fun isCancelled(): Boolean = active?.cancellationRequested == true

    fun pauseTask(): Boolean {
        val context = active ?: return false
        if (context.status in setOf(State.COMPLETED, State.FAILED, State.CANCELLED, State.BLOCKED)) return false
        _isPaused.value = true
        context.status = State.PAUSED
        _controlRevision.value += 1
        publish(context)
        return true
    }

    fun resumeTask(): Boolean {
        val context = active ?: return false
        if (!_isPaused.value || context.cancellationRequested) return false
        _isPaused.value = false
        context.status = State.OBSERVING
        context.lastObservation = "Resumed; fresh screen observation required before the next action"
        resumeObservationRequired = true
        _controlRevision.value += 1
        publish(context)
        return true
    }

    @Synchronized
    fun resumeAfterUserInput(): Boolean {
        val context = active ?: return false
        if (context.cancellationRequested || context.status in setOf(State.COMPLETED, State.FAILED, State.CANCELLED)) return false
        context.steps.firstOrNull { it.stepId == context.currentStepId }?.let { step ->
            if (step.status in setOf(TaskStepStatus.BLOCKED, TaskStepStatus.RECOVERING, TaskStepStatus.WAITING_FOR_UI)) {
                replaceStep(context, step.copy(status = TaskStepStatus.RUNNING, failureReason = null))
            }
        }
        context.failureReason = null
        context.status = State.OBSERVING
        context.lastObservation = "User input received; fresh screen observation required before resuming"
        resumeObservationRequired = true
        publish(context)
        return true
    }

    suspend fun awaitIfRunnable(): Boolean {
        while (_isPaused.value && !isCancelled()) {
            val observedRevision = _controlRevision.value
            _controlRevision.first { it != observedRevision }
        }
        return !isCancelled()
    }

    /** One engine-owned, non-recursive loop for an app-side deterministic workflow. */
    suspend fun runAutonomousLoop(
        maxIterations: Int,
        step: suspend (iteration: Int, task: Context) -> Boolean
    ): LoopOutcome {
        if (!executionLoopMutex.tryLock()) return LoopOutcome(0, false, false, "Another task loop already owns execution")
        val taskId = active?.taskId ?: run {
            executionLoopMutex.unlock()
            return LoopOutcome(0, false, false, "No active task")
        }
        var iterations = 0
        try {
            while (iterations < maxIterations.coerceAtLeast(1)) {
                if (!awaitIfRunnable()) return LoopOutcome(iterations, false, true)
                val context = active?.takeIf { it.taskId == taskId } ?: return LoopOutcome(iterations, false, true, "Task was replaced")
                setState(State.OBSERVING)
                val shouldContinue = step(iterations, context)
                iterations++
                if (isCancelled()) return LoopOutcome(iterations, false, true)
                if (!shouldContinue) return LoopOutcome(iterations, false, false)
                if (active?.taskId != taskId) return LoopOutcome(iterations, false, true, "Task was replaced")
                if (active?.status in setOf(State.COMPLETED, State.FAILED, State.CANCELLED, State.BLOCKED)) {
                    return LoopOutcome(iterations, false, false, active?.failureReason)
                }
            }
            recordCompletionEvidence(CompletionEvidence.SAFETY_LIMIT, "App-controlled task loop reached its $maxIterations iteration limit")
            finish(State.BLOCKED, "Task loop reached its safety limit; remaining steps were not marked complete")
            return LoopOutcome(iterations, true, false, "Task loop reached its safety limit")
        } catch (cancelled: CancellationException) {
            if (isCancelled()) return LoopOutcome(iterations, false, true)
            throw cancelled
        } catch (error: Exception) {
            failCurrentStep(error.message ?: "Task-loop step failed")
            return LoopOutcome(iterations, false, false, error.message ?: "Task-loop step failed")
        } finally {
            executionLoopMutex.unlock()
        }
    }

    @Synchronized
    fun markItemProcessed(identity: String, verified: Boolean): Boolean {
        if (!verified || identity.isBlank()) return false
        val context = active ?: return false
        if (!context.processedItemSignatures.add(identity)) return false
        context.processedItemIds.add(identity)
        publish(context)
        return true
    }

    @Synchronized
    fun recordCompletionEvidence(evidence: CompletionEvidence, detail: String) {
        active?.let {
            it.completionEvidence = evidence
            it.completionEvidenceDetail = detail
            it.finalVerificationResult = detail.takeIf { evidence == CompletionEvidence.VERIFIED_GOAL || evidence == CompletionEvidence.END_REACHED }
            publish(it)
        }
    }

    @Synchronized
    fun replacePlan(titles: List<String>) {
        val context = active ?: return
        val preserved = context.steps.filter { it.status == TaskStepStatus.COMPLETED }
        val completedTitles = preserved.map { it.title }.toSet()
        val plan = (preserved.map { it.title } + titles.filterNot { it in completedTitles }).distinct()
        context.plan.clear()
        context.plan.addAll(plan)
        context.steps.clear()
        plan.forEachIndexed { index, title ->
            val old = preserved.firstOrNull { it.title == title }
            val previousId = context.steps.lastOrNull()?.stepId
            context.steps += old ?: TaskPlanStep(
                title = title,
                description = planDescription(title, context.originalGoal),
                dependencies = if (index == 0 || previousId == null) emptyList() else listOf(previousId),
                expectedResult = expectedResult(title)
            )
        }
        context.completedSteps.clear()
        context.completedSteps.addAll(preserved.map { it.title })
        context.pendingSteps.clear()
        context.pendingSteps.addAll(context.steps.filter { it.status != TaskStepStatus.COMPLETED }.map { it.title })
        context.currentStepId = null
        startNextReady(context)
        publish(context)
    }

    @Synchronized
    fun updateActivity(activity: String, state: State = State.OBSERVING) {
        val context = active ?: return
        context.currentStep = activity
        context.lastObservation = activity
        context.status = state
        val currentStep = context.steps.firstOrNull { it.stepId == context.currentStepId }
        if (currentStep != null && currentStep.status != TaskStepStatus.COMPLETED) {
            val mapped = if (state == State.WAITING_FOR_UI) TaskStepStatus.WAITING_FOR_UI else if (state == State.RECOVERING) TaskStepStatus.RECOVERING else currentStep.status
            replaceStep(context, currentStep.copy(status = mapped, actualResult = activity))
        }
        publish(context)
    }

    @Synchronized
    fun completeStepByTitle(title: String, result: String, verified: Boolean): Boolean {
        val context = active ?: return false
        val step = context.steps.firstOrNull { it.title.equals(title, ignoreCase = true) } ?: return false
        if (!verified) {
            replaceStep(context, step.copy(status = TaskStepStatus.RECOVERING, actualResult = result, failureReason = result))
            context.recoveryCount++
            publish(context)
            return false
        }
        val completedIds = context.steps.filter { it.status == TaskStepStatus.COMPLETED }.map { it.stepId }.toSet()
        if (!step.dependencies.all { it in completedIds }) return false
        replaceStep(context, step.copy(status = TaskStepStatus.COMPLETED, actualResult = result, completedAt = System.currentTimeMillis(), failureReason = null))
        if (step.title !in context.completedSteps) context.completedSteps += step.title
        context.pendingSteps.remove(step.title)
        if (context.currentStepId == step.stepId) context.currentStepId = null
        startNextReady(context)
        context.lastProgressTime = System.currentTimeMillis()
        publish(context)
        return true
    }

    @Synchronized
    fun failCurrentStep(reason: String, blocked: Boolean = false) {
        val context = active ?: return
        val current = context.steps.firstOrNull { it.stepId == context.currentStepId }
        if (current != null && current.status != TaskStepStatus.COMPLETED) {
            replaceStep(context, current.copy(
                status = if (blocked) TaskStepStatus.BLOCKED else TaskStepStatus.RECOVERING,
                retryCount = current.retryCount + 1,
                failureReason = reason
            ))
        }
        context.retryCount++
        context.recoveryCount++
        context.failureReason = reason
        context.status = if (blocked) State.BLOCKED else State.RECOVERING
        publish(context)
    }

    @Synchronized
    fun recordVerifiedStep(action: String, result: String, verified: Boolean) {
        val context = active ?: return
        context.lastAction = action
        context.lastActionResult = result
        context.lastActionVerified = verified
        val step = context.steps.firstOrNull { it.stepId == context.currentStepId } ?: return publish(context)
        val normalizedAction = action.lowercase()
        val title = step.title.lowercase()
        val relevant = when {
            normalizedAction.contains("open_app") -> title.contains("open") || title.contains("foreground")
            normalizedAction.contains("search") || normalizedAction.contains("type_text") -> title.contains("search") || title.contains("find")
            normalizedAction.contains("scroll") -> title.contains("scroll") || title.contains("load")
            normalizedAction.contains("click") -> title.contains("navigate") || title.contains("select") || title.contains("perform") || title.contains("unlike")
            normalizedAction.contains("task_completed") -> title.contains("verify") || title.contains("finish")
            else -> false
        }
        if (relevant && verified) {
            replaceStep(context, step.copy(status = TaskStepStatus.COMPLETED, actualResult = result, completedAt = System.currentTimeMillis(), failureReason = null))
            if (step.title !in context.completedSteps) context.completedSteps += step.title
            context.pendingSteps.remove(step.title)
            context.currentStepId = null
            startNextReady(context)
            context.lastProgressTime = System.currentTimeMillis()
        } else if (relevant && !verified) {
            val retries = step.retryCount + 1
            replaceStep(context, step.copy(status = if (retries >= 3) TaskStepStatus.BLOCKED else TaskStepStatus.RECOVERING,
                retryCount = retries, failureReason = result))
            context.retryCount++
            if (retries >= 3) context.status = State.BLOCKED else context.recoveryCount++
        }
        publish(context)
    }

    private fun planTitles(goal: String): List<String> {
        val text = goal.lowercase()
        return when {
            text.contains("instagram") && (text.contains("unlike") || text.contains("liked")) -> listOf(
                "Understand goal", "Open Instagram", "Navigate to liked content", "Observe and process matching items",
                "Scroll and wait for more items", "Verify list end and results"
            )
            text.contains("spotify") && (text.contains("play") || text.contains("find") || text.contains("search")) -> listOf(
                "Understand goal", "Open Spotify", "Search for the requested track", "Select one unique match", "Verify playback"
            )
            else -> listOf("Understand goal", "Open or confirm the target app", "Perform the requested action", "Verify the resulting state")
        }
    }

    private fun planDescription(title: String, goal: String): String = when (title) {
        "Understand goal" -> "Classify the request and identify the requested outcome."
        "Open Instagram" -> "Bring Instagram to the foreground and confirm it is active."
        "Open Spotify" -> "Bring Spotify to the foreground and confirm it is active."
        "Navigate to liked content" -> "Reach an identifiable liked-items list before changing items."
        "Observe and process matching items" -> "Resolve each item from a fresh accessibility observation and verify each change."
        "Scroll and wait for more items" -> "Scroll only after visible matches are handled, then wait for fresh content."
        "Search for the requested track" -> "Search the exact requested title and inspect current results."
        "Select one unique match" -> "Select only a uniquely supported match; stop if results are ambiguous."
        "Verify playback" -> "Confirm the requested track and active playback state are visible."
        else -> "Execute and verify the user's request: $goal"
    }

    private fun expectedResult(title: String): String = when {
        title.contains("Open") -> "Expected app is confirmed in the foreground"
        title.contains("liked") -> "The liked-items list is identified"
        title.contains("process") -> "Each processed item has a verified post-action state"
        title.contains("Scroll") -> "Fresh content is observed or end evidence is established"
        title.contains("Search") -> "The requested search query is visible in fresh results"
        title.contains("Select") -> "One unambiguous requested track is selected"
        title.contains("playback", true) -> "Requested track and active playback are visible"
        title.contains("Verify") -> "The requested outcome has local evidence"
        else -> "The expected result is visible in a fresh observation"
    }

    private fun startNextReady(context: Context) {
        if (context.currentStepId != null) return
        val completed = context.steps.filter { it.status == TaskStepStatus.COMPLETED }.map { it.stepId }.toSet()
        val next = context.steps.firstOrNull { step ->
            step.status in setOf(TaskStepStatus.PENDING, TaskStepStatus.READY) && step.dependencies.all { it in completed }
        } ?: return
        val running = next.copy(status = TaskStepStatus.RUNNING, startedAt = next.startedAt ?: System.currentTimeMillis())
        replaceStep(context, running)
        context.currentStepId = running.stepId
        context.currentStep = running.title
    }

    private fun replaceStep(context: Context, updated: TaskPlanStep) {
        val index = context.steps.indexOfFirst { it.stepId == updated.stepId }
        if (index >= 0) context.steps[index] = updated
    }

    @Synchronized
    private fun publishIfCurrent(context: Context?) {
        if (context != null && active?.taskId == context.taskId) publish(context)
    }

    private fun publish(context: Context) {
        val completed = context.steps.count { it.status == TaskStepStatus.COMPLETED }
        val progress = if (context.steps.isEmpty()) 0 else (completed * 100 / context.steps.size)
        _taskState.value = AgentTaskSnapshot(
            taskId = context.taskId,
            originalGoal = context.originalGoal,
            normalizedGoal = context.normalizedGoal,
            currentPlan = context.plan.joinToString(" → "),
            currentStepId = context.currentStepId,
            steps = context.steps.toList(),
            completedSteps = context.steps.filter { it.status == TaskStepStatus.COMPLETED }.map { it.title },
            pendingSteps = context.steps.filter { it.status != TaskStepStatus.COMPLETED }.map { it.title },
            processedItems = context.processedItemIds.toSet(),
            currentObservation = context.lastObservation,
            lastAction = context.lastAction,
            lastActionResult = context.lastActionResult,
            currentStatus = context.status.name,
            progressPercentage = progress,
            retryCount = context.retryCount,
            recoveryCount = context.recoveryCount,
            lastProgressTimestamp = context.lastProgressTime,
            cancellationRequested = context.cancellationRequested,
            finalVerificationResult = context.finalVerificationResult,
            failureReason = context.failureReason
        )
    }

    fun normalize(goal: String): String = goal.trim().lowercase().replace(Regex("\\s+"), " ")
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/agent/AgentTaskEngine.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/agent/ScreenSignatureCalculator.kt ===
```kotlin
package com.jarvis.assistant.automation.agent

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Calculates lightweight, stable screen signatures to detect state transitions,
 * scrolling progress, end-of-list conditions, and verify UI mutations.
 */
object ScreenSignatureCalculator {

    fun computeSignature(root: AccessibilityNodeInfo?): ScreenSignature {
        if (root == null) {
            return ScreenSignature(
                packageName = "",
                className = "",
                elementCount = 0,
                contentHash = 0L,
                primaryTexts = emptyList()
            )
        }

        val pkg = root.packageName?.toString() ?: ""
        val cls = root.className?.toString() ?: ""
        val texts = mutableListOf<String>()
        var count = 0
        var hash = 1125899906842597L // FNV-like seed

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        val tempRect = Rect()

        while (queue.isNotEmpty() && count < 300) {
            val node = queue.removeFirst()
            count++

            val text = node.text?.toString()?.trim() ?: ""
            val desc = node.contentDescription?.toString()?.trim() ?: ""
            val viewId = node.viewIdResourceName?.toString() ?: ""
            val isClickable = node.isClickable
            val isEditable = node.isEditable

            node.getBoundsInScreen(tempRect)

            if (text.isNotEmpty() && texts.size < 15) {
                texts.add(text)
            } else if (desc.isNotEmpty() && texts.size < 15) {
                texts.add(desc)
            }

            // Mix into hash
            hash = 31 * hash + text.hashCode()
            hash = 31 * hash + desc.hashCode()
            hash = 31 * hash + viewId.hashCode()
            hash = 31 * hash + (if (isClickable) 1 else 0)
            hash = 31 * hash + (if (isEditable) 2 else 0)
            hash = 31 * hash + tempRect.centerX()
            hash = 31 * hash + tempRect.centerY()

            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) {
                    queue.add(child)
                }
            }
        }

        return ScreenSignature(
            packageName = pkg,
            className = cls,
            elementCount = count,
            contentHash = hash,
            primaryTexts = texts
        )
    }

    /**
     * Generates a stable key for an individual interactive element (e.g. for bulk tracking).
     */
    fun computeElementKey(node: AccessibilityNodeInfo): String {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        val id = node.viewIdResourceName ?: ""
        return "${id}_${text}_${desc}_(${rect.left},${rect.top})"
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/agent/ScreenSignatureCalculator.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/agent/SerializedActionExecutor.kt ===
```kotlin
package com.jarvis.assistant.automation.agent

import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Ensures strict sequential execution of all UI mutation actions.
 * Guarantees that clicks, text inputs, scrolls, and key presses NEVER run concurrently,
 * preventing race conditions, overlapping gestures, and corrupted UI states.
 */
object SerializedActionExecutor {
    private const val TAG = "SerializedActionExec"
    private val mutex = Mutex()
    private val isCancelled = AtomicBoolean(false)
    private val taskGeneration = AtomicLong(0L)

    val isBusy: Boolean
        get() = mutex.isLocked

    fun cancelAllPendingActions() {
        Log.w(TAG, "Cancelling all active/pending UI actions")
        isCancelled.set(true)
        taskGeneration.incrementAndGet()
    }

    fun resetCancellation() {
        taskGeneration.incrementAndGet()
        isCancelled.set(false)
    }

    /** Starts a fresh task epoch; actions queued by an older task remain invalid. */
    fun startNewTask(): Long {
        isCancelled.set(false)
        return taskGeneration.incrementAndGet()
    }

    /**
     * Executes the given UI mutation block exclusively under a Mutex.
     * Only one block can execute at a time across the entire application.
     */
    suspend fun <T> execute(
        actionName: String,
        timeoutMs: Long = 15_000L,
        expectedGeneration: Long? = null,
        block: suspend () -> T
    ): T? {
        // Capture before waiting for the mutex so cancellation followed by a new task
        // cannot accidentally revive an older queued mutation.
        val submittedGeneration = expectedGeneration ?: taskGeneration.get()
        return withContext(Dispatchers.IO) {
        if (isCancelled.get() || submittedGeneration != taskGeneration.get()) {
            Log.w(TAG, "Action '$actionName' rejected: Task is cancelled")
            return@withContext null
        }

        val startTime = System.currentTimeMillis()
        Log.d(TAG, "Requesting lock for UI action: '$actionName'")

        mutex.withLock {
            if (isCancelled.get() || submittedGeneration != taskGeneration.get()) {
                Log.w(TAG, "Action '$actionName' aborted after lock acquisition: Task is cancelled")
                return@withLock null
            }

            Log.i(TAG, ">>> STARTING SERIALIZED ACTION: '$actionName'")
            try {
                val result = withTimeoutOrNull(timeoutMs) {
                    block()
                }

                val elapsed = System.currentTimeMillis() - startTime
                if (result == null) {
                    Log.e(TAG, "!!! ACTION TIMED OUT after ${elapsed}ms: '$actionName'")
                } else {
                    Log.i(TAG, "<<< COMPLETED ACTION '$actionName' in ${elapsed}ms")
                }
                return@withLock result
            } catch (e: CancellationException) {
                Log.w(TAG, "Action '$actionName' was cancelled: ${e.message}")
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Exception during action '$actionName': ${e.message}", e)
                return@withLock null
            }
        }
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/agent/SerializedActionExecutor.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/command/CommandExecutor.kt ===
```kotlin
package com.jarvis.assistant.automation.command

import android.util.Log
import com.jarvis.assistant.automation.phone.PhoneControlManager
import com.jarvis.assistant.automation.whatsapp.WhatsAppAssistant
import com.jarvis.assistant.automation.youtube.YouTubeAutomationManager
import com.jarvis.assistant.data.memory.MemoryManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CommandExecutor(
    private val phoneManager: PhoneControlManager,
    private val youtubeManager: YouTubeAutomationManager,
    private val whatsappAssistant: WhatsAppAssistant,
    private val memoryManager: MemoryManager
) {
    companion object {
        private const val TAG = "CommandExecutor"
    }

    suspend fun execute(command: JarvisCommand): String = withContext(Dispatchers.Main) {
        Log.i(TAG, "Executing command: $command")
        when (command) {
            // YouTube
            is JarvisCommand.PlayYouTube -> {
                val resolvedSong = memoryManager.resolveSongQuery(command.query)
                memoryManager.trackSongPlay(resolvedSong)
                youtubeManager.playVideo(resolvedSong)
            }
            is JarvisCommand.SearchYouTube -> youtubeManager.searchYouTube(command.query)
            is JarvisCommand.PauseMedia -> youtubeManager.pausePlayback()
            is JarvisCommand.ResumeMedia -> youtubeManager.resumePlayback()
            is JarvisCommand.NextMedia -> youtubeManager.nextMedia()
            is JarvisCommand.PreviousMedia -> youtubeManager.previousMedia()
            is JarvisCommand.SubscribeChannel -> youtubeManager.subscribeToChannel()
            is JarvisCommand.ToggleFullscreen -> youtubeManager.toggleFullscreen()

            // Phone Controls
            is JarvisCommand.Flash -> phoneManager.setFlashlight(command.enabled)
            is JarvisCommand.Brightness -> {
                if (command.isRelative) {
                    phoneManager.adjustBrightness(command.delta > 0)
                } else {
                    phoneManager.setBrightnessPercent(command.level)
                }
            }
            is JarvisCommand.Volume -> {
                if (command.isRelative) {
                    phoneManager.adjustVolume(command.delta > 0)
                } else {
                    phoneManager.setVolumePercent(command.level)
                }
            }
            is JarvisCommand.OpenApp -> phoneManager.openApp(command.packageName)
            is JarvisCommand.OpenWebUrls -> phoneManager.openMultipleUrls(command.urls)
            is JarvisCommand.PhoneCall -> phoneManager.makePhoneCall(command.contactOrNumber)
            is JarvisCommand.SearchWeb -> phoneManager.searchWeb(command.query)

            // WhatsApp
            is JarvisCommand.WhatsAppMessage -> whatsappAssistant.sendMessageDirectly(command.contact, command.message)
            is JarvisCommand.WhatsAppCall -> whatsappAssistant.makeCall(command.contact, command.video)
            is JarvisCommand.WhatsAppDeleteMessage -> whatsappAssistant.deleteLastMessage(command.contact, command.forEveryone)
            is JarvisCommand.ConfirmAction -> {
                if (command.confirmed) {
                    whatsappAssistant.confirmAndSend()
                } else {
                    whatsappAssistant.cancelDraft()
                }
            }
            is JarvisCommand.DisambiguationChoice -> whatsappAssistant.handleDisambiguationChoice(command.choice)

            // Memory
            is JarvisCommand.Remember -> memoryManager.rememberFact(command.text)
            is JarvisCommand.Forget -> memoryManager.forgetFact(command.query)
            is JarvisCommand.WhatDoYouRemember -> memoryManager.getWhatDoYouRemember()
            is JarvisCommand.RecallBirthday -> memoryManager.getBirthdayResponse()
            is JarvisCommand.RecallFavoriteSong -> memoryManager.getFavoriteSongResponse()
            is JarvisCommand.RecallRoutine -> memoryManager.getRoutineResponse()
            is JarvisCommand.GoToBackground -> "Going to background."
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/command/CommandExecutor.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/command/CommandParser.kt ===
```kotlin
package com.jarvis.assistant.automation.command

import com.jarvis.assistant.automation.phone.DomainNormalizer
import java.util.Locale

data class ParsedCommandResult(
    val command: JarvisCommand?,
    val confidence: Float,
    val matchedPattern: String = ""
)

object CommandParser {

    private const val CONFIDENCE_THRESHOLD = 0.90f

    // Words/queries that are too vague to safely act on without checking with the user first.
    // If speech recognition only picks up one of these (or something this short), it usually
    // means the mic missed the real title, not that the user actually wants to play "it".
    private val AMBIGUOUS_PLAY_WORDS = setOf(
        "something", "anything", "whatever", "that", "this", "it", "one",
        "song", "video", "music", "gana", "gane", "track",
        "kuch", "kuch bhi", "pata nahi", "i don't know", "idk", "um", "uh", "hmm", "huh"
    )

    /**
     * Returns true when a parsed YouTube play query is too vague/short to trust blindly
     * (likely a mis-heard or dropped title), meaning Jarvis should confirm with the user
     * before actually launching a video instead of guessing.
     */
    fun isAmbiguousPlayQuery(query: String): Boolean {
        val q = query.trim().lowercase(Locale.ROOT)
        if (q.isBlank()) return true
        if (q.length < 3) return true
        if (AMBIGUOUS_PLAY_WORDS.contains(q)) return true
        val words = q.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return true
        if (words.size == 1 && words[0].length <= 3) return true
        if (words.all { AMBIGUOUS_PLAY_WORDS.contains(it) }) return true
        return false
    }

    fun parse(input: String, isAwaitingConfirmation: Boolean = false, isAwaitingDisambiguation: Boolean = false): ParsedCommandResult {
        val clean = input
            .replace(Regex("(?i)^(hey jarvis|hi jarvis|hello jarvis|ok jarvis|jarvis|service)[,\\s]*"), "")
            .replace(Regex("[.,!?:;\"'\\s]+$"), "")
            .trim()
            .lowercase(Locale.ROOT)

        if (clean.isBlank()) {
            return ParsedCommandResult(null, 0.0f)
        }

        // 1. Confirmations & Cancellations (Priority when awaiting confirmation)
        if (isAwaitingConfirmation) {
            if (clean.matches(Regex("^(yes|yeah|yup|send|send it|confirm|do it|sure|okay|go ahead|please send|haan|haanji|kardo|theek hai|avunu|sare|chey|aamaa|sari|ho|thik ache|thik ahe|kar da|kar do).*"))) {
                return ParsedCommandResult(JarvisCommand.ConfirmAction(true), 1.0f, "CONFIRM")
            }
            if (clean.matches(Regex("^(no|nope|cancel|don't|dont|never mind|stop|abort|nahi|mat karo|ruko|vaddu|oddu|vendaam|nako|thamba|naahi|mat kara).*"))) {
                return ParsedCommandResult(JarvisCommand.ConfirmAction(false), 1.0f, "CANCEL")
            }
        }

        // 2. Disambiguation choice when multiple contacts match
        if (isAwaitingDisambiguation) {
            return ParsedCommandResult(JarvisCommand.DisambiguationChoice(clean), 0.95f, "DISAMBIGUATION")
        }

        val prefix = "^(?:please\\s+|can you\\s+|could you\\s+|just\\s+)?"

        // 3. Flashlight / Torch Commands (Strict Anchoring & Natural Variations across Indian languages)
        val flashWords = "(?:flash\\s*light|flash\\s*lite|flashlight|flash|torch|light|batti)"
        if (clean.matches(Regex("$prefix(?:turn\\s+on|open|enable|switch\\s+on)\\s+(?:the\\s+)?$flashWords$")) ||
            clean.matches(Regex("$prefix(?:turn|switch)\\s+(?:the\\s+)?$flashWords\\s+on$")) ||
            clean.matches(Regex("$prefix$flashWords\\s+(?:on|chalu|jalao|chalu\\s+karo|chalu\\s+kar\\s+do|on\\s+karo|on\\s+chey|on\\s+pannu|jwalao|chalu\\s+kara|jara)$")) ||
            clean.matches(Regex("$prefix(?:turn\\s+torch\\s+on|turn\\s+$flashWords\\s+on)$"))
        ) {
            return ParsedCommandResult(JarvisCommand.Flash(true), 0.98f, "FLASH_ON")
        }
        if (clean.matches(Regex("$prefix(?:turn\\s+off|close|disable|switch\\s+off)\\s+(?:the\\s+)?$flashWords$")) ||
            clean.matches(Regex("$prefix(?:turn|switch)\\s+(?:the\\s+)?$flashWords\\s+off$")) ||
            clean.matches(Regex("$prefix$flashWords\\s+(?:off|band|bujhao|band\\s+karo|band\\s+kar\\s+do|off\\s+karo|off\\s+chey|off\\s+pannu|nibhao|band\\s+kara|buta)$")) ||
            clean.matches(Regex("$prefix(?:turn\\s+torch\\s+off|turn\\s+$flashWords\\s+off)$"))
        ) {
            return ParsedCommandResult(JarvisCommand.Flash(false), 0.98f, "FLASH_OFF")
        }

        // 3b. YouTube Subscribe (Strict Anchoring)
        if (clean.matches(Regex("$prefix(?:subscribe|hit\\s+subscribe|click\\s+subscribe|press\\s+subscribe|subscribe\\s+to\\s+(?:this|the)\\s+channel|subscribe\\s+(?:karo|kardo|kar\\s+do))$"))) {
            return ParsedCommandResult(JarvisCommand.SubscribeChannel, 0.97f, "YOUTUBE_SUBSCRIBE")
        }

        // 3c. YouTube Fullscreen Toggle (Strict Anchoring)
        if (clean.matches(Regex("$prefix(?:make\\s+it\\s+|go\\s+)?full\\s*screen(?:\\s+mode)?$")) ||
            clean.matches(Regex("$prefix(?:make|go)\\s+full\\s*screen$")) ||
            clean.matches(Regex("$prefix(?:expand|maximi[sz]e)\\s+(?:the\\s+)?(?:video|screen|player)$")) ||
            clean.matches(Regex("^full\\s*screen\\s+(?:karo|kardo|kar\\s+do)$"))
        ) {
            return ParsedCommandResult(JarvisCommand.ToggleFullscreen, 0.97f, "YOUTUBE_FULLSCREEN")
        }

        // 4. Brightness Controls (Strict Anchoring)
        val levelWords = "(\\d{1,3}|zero|mute|min|minimum|lowest|silence|nil|off|ten|twenty|twenty five|quarter|thirty|forty|fifty|half|sixty|seventy|seventy five|eighty|ninety|hundred|full|max|maximum|highest)"
        val brightnessPattern = Regex("$prefix(?:set|make|turn|put|bring)?\\s*(?:the\\s+)?(?:screen\\s+)?brightness\\s*(?:to|at|is|=)?\\s*$levelWords\\s*%?$")
            .find(clean)
            ?: Regex("^(?:screen\\s+)?brightness\\s+(?:ko\\s+)?$levelWords\\s*(?:percent|%|karo)?$").find(clean)
            ?: Regex("$prefix(?:make|set)\\s+(?:the\\s+)?(?:screen\\s+)?brightness\\s+$levelWords$").find(clean)

        if (brightnessPattern != null) {
            val token = brightnessPattern.groupValues[1]
            val level = parseNumericLevel(token)
            if (level != null) {
                return ParsedCommandResult(JarvisCommand.Brightness(level), 0.96f, "BRIGHTNESS_SET")
            }
        }

        if (clean == "increase brightness" || clean == "brightness up" ||
            clean == "make it brighter" || clean == "make screen brighter" ||
            clean == "turn up brightness" || clean == "raise brightness" ||
            clean == "brighter" || clean == "more brightness" ||
            clean == "bright up" || clean == "screen brighter" ||
            clean == "brightness badhao" || clean == "light badhao" ||
            clean == "brightness badha do" || clean == "light badha do") {
            return ParsedCommandResult(JarvisCommand.Brightness(0, isRelative = true, delta = 20), 0.95f, "BRIGHTNESS_UP")
        }
        if (clean == "decrease brightness" || clean == "brightness down" ||
            clean == "dim brightness" || clean == "lower brightness" ||
            clean == "make it dimmer" || clean == "make screen dimmer" ||
            clean == "turn down brightness" || clean == "reduce brightness" ||
            clean == "dim the screen" || clean == "dimmer" ||
            clean == "less brightness" || clean == "screen dimmer" ||
            clean == "brightness kam" || clean == "light kam" ||
            clean == "brightness kam karo" || clean == "light kam karo") {
            return ParsedCommandResult(JarvisCommand.Brightness(0, isRelative = true, delta = -20), 0.95f, "BRIGHTNESS_DOWN")
        }
        if (clean == "maximum brightness" || clean == "full brightness" ||
            clean == "brightness maximum" || clean == "brightness full" ||
            clean == "max brightness" || clean == "brightness max" ||
            clean == "brightest") {
            return ParsedCommandResult(JarvisCommand.Brightness(100), 0.95f, "BRIGHTNESS_MAX")
        }
        if (clean == "minimum brightness" || clean == "lowest brightness" ||
            clean == "brightness minimum" || clean == "brightness lowest" ||
            clean == "min brightness" || clean == "brightness min" ||
            clean == "brightness zero" || clean == "dimmest") {
            return ParsedCommandResult(JarvisCommand.Brightness(0), 0.95f, "BRIGHTNESS_MIN")
        }

        // 5. Volume Controls (Strict Anchoring)
        val volumePattern = Regex("$prefix(?:set|make|turn|put|bring)?\\s*(?:the\\s+)?(?:media\\s+|sound\\s+)?volume\\s*(?:to|at|is|=)?\\s*$levelWords\\s*%?$")
            .find(clean)
            ?: Regex("^(?:media\\s+|sound\\s+)?volume\\s+(?:ko\\s+)?$levelWords\\s*(?:percent|%|karo)?$").find(clean)
            ?: Regex("$prefix(?:make|set)\\s+(?:the\\s+)?(?:media\\s+|sound\\s+)?volume\\s+$levelWords$").find(clean)

        if (volumePattern != null) {
            val token = volumePattern.groupValues[1]
            val level = parseNumericLevel(token)
            if (level != null) {
                return ParsedCommandResult(JarvisCommand.Volume(level), 0.96f, "VOLUME_SET")
            }
        }

        if (clean == "volume up" || clean == "increase volume" ||
            clean == "louder" || clean == "turn up volume" ||
            clean == "turn up the volume" || clean == "raise volume" ||
            clean == "raise the volume" || clean == "more volume" ||
            clean == "volume increase" || clean == "increase the volume" ||
            clean == "make it louder" || clean == "up the volume" ||
            clean == "sound up" || clean == "audio up" ||
            clean == "volume badhao" || clean == "awaz badhao" ||
            clean == "volume badha do" || clean == "awaz badha do" ||
            clean == "crank up" || clean == "pump up the volume") {
            return ParsedCommandResult(JarvisCommand.Volume(0, isRelative = true, delta = 1), 0.95f, "VOLUME_UP")
        }
        if (clean == "volume down" || clean == "decrease volume" ||
            clean == "lower volume" || clean == "softer" ||
            clean == "turn down volume" || clean == "turn down the volume" ||
            clean == "reduce volume" || clean == "reduce the volume" ||
            clean == "less volume" || clean == "volume decrease" ||
            clean == "decrease the volume" || clean == "lower the volume" ||
            clean == "make it softer" || clean == "quieter" ||
            clean == "sound down" || clean == "audio down" ||
            clean == "volume kam" || clean == "awaz kam" ||
            clean == "volume kam karo" || clean == "awaz kam karo" ||
            clean == "make it quieter" || clean == "down the volume") {
            return ParsedCommandResult(JarvisCommand.Volume(0, isRelative = true, delta = -1), 0.95f, "VOLUME_DOWN")
        }
        if (clean == "mute" || clean == "mute volume" || clean == "silence media" ||
            clean == "mute the volume" || clean == "mute it" ||
            clean == "go silent" || clean == "silent mode" ||
            clean == "sound band" || clean == "volume band" ||
            clean == "volume zero" || clean == "awaz band") {
            return ParsedCommandResult(JarvisCommand.Volume(0), 0.95f, "VOLUME_MUTE")
        }
        if (clean == "full volume" || clean == "max volume" ||
            clean == "maximum volume" || clean == "volume max" ||
            clean == "volume full" || clean == "awaz full" ||
            clean == "loudest") {
            return ParsedCommandResult(JarvisCommand.Volume(100), 0.95f, "VOLUME_MAX")
        }

        // 6. Media Playback Controls (Strict Anchoring)
        if (clean == "pause" || clean == "pause music" || clean == "pause video" || clean == "pause playback" ||
            clean == "pause the music" || clean == "pause the video" || clean == "stop playing") {
            return ParsedCommandResult(JarvisCommand.PauseMedia, 0.98f, "MEDIA_PAUSE")
        }
        if (clean == "resume" || clean == "resume music" || clean == "resume playback" || clean == "continue playback" ||
            clean == "resume the music" || clean == "continue playing" || clean == "resume playing") {
            return ParsedCommandResult(JarvisCommand.ResumeMedia, 0.98f, "MEDIA_RESUME")
        }
        if (clean == "next" || clean == "next video" || clean == "next song" || clean == "skip" ||
            clean == "skip this" || clean == "next track" || clean == "play next") {
            return ParsedCommandResult(JarvisCommand.NextMedia, 0.98f, "MEDIA_NEXT")
        }
        if (clean == "previous" || clean == "previous video" || clean == "previous song" ||
            clean == "go back" || clean == "previous track" || clean == "play previous") {
            return ParsedCommandResult(JarvisCommand.PreviousMedia, 0.98f, "MEDIA_PREVIOUS")
        }

        // 7. Memory Commands
        if (clean.startsWith("remember ") || clean.startsWith("remember that ")) {
            val fact = input.replace(Regex("(?i)^(hey jarvis|jarvis|please)?\\s*(remember that|remember)\\s*"), "").trim()
            return ParsedCommandResult(JarvisCommand.Remember(fact), 0.95f, "MEMORY_REMEMBER")
        }
        if (clean.startsWith("forget ") || clean.startsWith("forget that ") || clean.startsWith("forget my ")) {
            val target = input.replace(Regex("(?i)^(hey jarvis|jarvis|please)?\\s*(forget that|forget my|forget about|forget)\\s*"), "").trim()
            return ParsedCommandResult(JarvisCommand.Forget(target), 0.95f, "MEMORY_FORGET")
        }
        if (clean == "what do you remember about me" || clean == "what do you remember" || clean == "tell me what you remember") {
            return ParsedCommandResult(JarvisCommand.WhatDoYouRemember, 0.98f, "MEMORY_WHAT")
        }

        // Memory Recall: Birthday
        if (clean.matches(Regex("$prefix(?:when\\s+is|what\\s+is|when's|what's|tell\\s+me|do\\s+you\\s+know)\\s+(?:my\\s+)?birthday$")) ||
            clean.matches(Regex("$prefix(?:mera\\s+)?(?:birthday|janamdin)\\s+(?:kab\\s+hai|kab\\s+aata\\s+hai|kab\\s+h)$")) ||
            clean == "when is my birthday" || clean == "what is my birthday" || clean == "mera birthday kab hai") {
            return ParsedCommandResult(JarvisCommand.RecallBirthday, 0.98f, "MEMORY_RECALL_BIRTHDAY")
        }

        // Memory Recall: Favorite Song
        if (clean.matches(Regex("$prefix(?:what\\s+is|what's|tell\\s+me|do\\s+you\\s+know)\\s+(?:my\\s+)?favou?rite\\s+(?:song|music|gana|track)$")) ||
            clean.matches(Regex("$prefix(?:mera\\s+)?favou?rite\\s+(?:gana|song)\\s+(?:kaun\\s+sa\\s+hai|kya\\s+hai)$")) ||
            clean == "what is my favorite song" || clean == "what is my favourite song" || clean == "mera favorite gana kaun sa hai") {
            return ParsedCommandResult(JarvisCommand.RecallFavoriteSong, 0.98f, "MEMORY_RECALL_FAVORITE_SONG")
        }

        // Memory Recall: Routine
        if (clean.matches(Regex("$prefix(?:what\\s+is|what's|tell\\s+me|do\\s+you\\s+know)\\s+(?:my\\s+)?(?:daily\\s+)?routine$")) ||
            clean.matches(Regex("$prefix(?:mera\\s+)?(?:daily\\s+)?routine\\s+(?:kya\\s+hai|batao)$")) ||
            clean == "what is my routine" || clean == "what is my daily routine" || clean == "mera routine kya hai") {
            return ParsedCommandResult(JarvisCommand.RecallRoutine, 0.98f, "MEMORY_RECALL_ROUTINE")
        }

        // 8. Calling & Messaging (Strict Intent Filtering)

        // 0. WhatsApp Delete Message ("delete for everyone" must be checked before the
        //    generic "delete message" pattern so intent isn't lost)
        val deleteEveryoneRegex = Regex(
            "${prefix}delete\\s+(?:the\\s+)?(?:last\\s+|my\\s+|that\\s+)?(?:whatsapp\\s+)?message" +
                "(?:\\s+(?:on|from|in)\\s+whatsapp)?\\s*(?:from|for)\\s+everyone" +
                "(?:\\s+(?:to|for|from)\\s+([a-zA-Z0-9\\s]+))?$",
            RegexOption.IGNORE_CASE
        )
        val deleteEveryoneMatch = deleteEveryoneRegex.find(clean)
        if (deleteEveryoneMatch != null) {
            val contact = deleteEveryoneMatch.groupValues.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }
            return ParsedCommandResult(JarvisCommand.WhatsAppDeleteMessage(contact, forEveryone = true), 0.96f, "WHATSAPP_DELETE_EVERYONE")
        }

        val deleteForMeRegex = Regex(
            "${prefix}delete\\s+(?:the\\s+)?(?:last\\s+|my\\s+|that\\s+)?(?:whatsapp\\s+)?message" +
                "(?:\\s+(?:on|from|in)\\s+whatsapp)?" +
                "(?:\\s+(?:to|for)\\s+([a-zA-Z0-9\\s]+))?$",
            RegexOption.IGNORE_CASE
        )
        val deleteForMeMatch = deleteForMeRegex.find(clean)
        if (deleteForMeMatch != null) {
            val contact = deleteForMeMatch.groupValues.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }
            return ParsedCommandResult(JarvisCommand.WhatsAppDeleteMessage(contact, forEveryone = false), 0.94f, "WHATSAPP_DELETE_FOR_ME")
        }

        // A. WhatsApp Video Call
        val waVideoRegex = Regex("$prefix(?:whatsapp\\s+video\\s+call\\s+(?:to\\s+)?|video\\s+call\\s+(?:to\\s+)?([a-zA-Z0-9\\s]+?)\\s+on\\s+whatsapp|video\\s+call\\s+(?:to\\s+)?)([a-zA-Z0-9\\s]+?)$", RegexOption.IGNORE_CASE)
        val waVideoHinglish = Regex("^([a-zA-Z0-9]+)\\s+ko\\s+(?:whatsapp\\s+)?video\\s+call\\s*(?:karo|lagao|kardo)$", RegexOption.IGNORE_CASE)
        val waVideoMatch = waVideoRegex.find(clean) ?: waVideoHinglish.find(clean)
        if (waVideoMatch != null && (clean.contains("video") || clean.contains("whatsapp"))) {
            val contact = (waVideoMatch.groupValues.getOrNull(2)?.takeIf { it.isNotBlank() } ?: waVideoMatch.groupValues[1])
                .replace(Regex("(?i)\\s+(on\\s+whatsapp|using\\s+whatsapp|karo|lagao|kardo)$"), "")
                .trim()
            if (contact.isNotBlank() && !listOf("me", "him", "her", "them", "someone", "anyone").contains(contact)) {
                return ParsedCommandResult(JarvisCommand.WhatsAppCall(contact, video = true), 0.96f, "WHATSAPP_VIDEO_CALL")
            }
        }

        // B. WhatsApp Voice Call
        val waVoiceRegex = Regex("$prefix(?:whatsapp\\s+call(?:\\s+to)?|make\\s+a\\s+whatsapp\\s+call\\s+to|call\\s+([a-zA-Z0-9\\s]+?)\\s+on\\s+whatsapp)\\s*([a-zA-Z0-9\\s]*)$", RegexOption.IGNORE_CASE)
        val waVoiceHinglish = Regex("^([a-zA-Z0-9]+)\\s+ko\\s+whatsapp\\s+call\\s*(?:karo|lagao|kardo)$", RegexOption.IGNORE_CASE)
        val waVoiceMatch = waVoiceRegex.find(clean) ?: waVoiceHinglish.find(clean)
        if (waVoiceMatch != null && clean.contains("whatsapp") && !clean.contains("message") && !clean.contains("msg")) {
            val c1 = waVoiceMatch.groupValues.getOrNull(2)?.trim() ?: ""
            val c2 = waVoiceMatch.groupValues.getOrNull(1)?.trim() ?: ""
            val rawContact = if (c1.isNotBlank()) c1 else c2
            val contact = rawContact.replace(Regex("(?i)\\s+(on\\s+whatsapp|using\\s+whatsapp|karo|lagao)$"), "").trim()
            if (contact.isNotBlank() && !listOf("me", "him", "her", "them", "someone").contains(contact)) {
                return ParsedCommandResult(JarvisCommand.WhatsAppCall(contact, video = false), 0.96f, "WHATSAPP_VOICE_CALL")
            }
        }

        // C. WhatsApp Messages (Anchored with clear recipient and message)
        val waComprehensiveRegex = Regex("$prefix(?:send\\s+(?:a\\s+)?(?:whatsapp\\s+)?message\\s+(?:to\\s+)?|send\\s+(?:a\\s+)?whatsapp\\s+(?:to\\s+)?|message\\s+(?:to\\s+)?|whatsapp\\s+(?:to\\s+)?)\\s*([a-zA-Z0-9]+)\\s+(?:that|saying|:)?\\s*(.+)$", RegexOption.IGNORE_CASE)
        val waComprehensiveHinglish = Regex("^([a-zA-Z0-9]+)\\s+ko\\s+(?:whatsapp\\s+)?(?:message|msg)?\\s*(?:bhejo|karo|bhej do)\\s*(?:saying|that|:)?\\s*(.+)$", RegexOption.IGNORE_CASE)
        val waSendMatch = waComprehensiveRegex.find(input) ?: waComprehensiveHinglish.find(input)
        if (waSendMatch != null) {
            val contact = waSendMatch.groupValues[1]
                .replace(Regex("(?i)\\s+(on\\s+whatsapp|via\\s+whatsapp|using\\s+whatsapp)$"), "")
                .trim()
            val message = waSendMatch.groupValues[2].trim()
            val nonContacts = listOf("me", "someone", "anyone", "him", "her", "that", "to", "the", "for")
            if (contact.isNotBlank() && message.isNotBlank() && !nonContacts.contains(contact.lowercase(Locale.ROOT))) {
                return ParsedCommandResult(JarvisCommand.WhatsAppMessage(contact, message), 0.96f, "WHATSAPP_MESSAGE")
            }
        }

        // D. Cellular Phone Call (SIM / Dialer)
        // Must start with call verb (e.g. "call mom", "dial 9876543210", "make a phone call to dad")
        val phoneCallRegex = Regex("$prefix(?:make\\s+(?:a\\s+)?(?:phone\\s+)?call\\s+to|phone\\s+call\\s+to|dial|call(?:\\s+to)?)\\s+([a-zA-Z0-9+\\s]+)$", RegexOption.IGNORE_CASE)
        val phoneCallHinglish = Regex("^([a-zA-Z0-9+\\s]+?)\\s+ko\\s+(?:phone\\s+|call\\s+)?(?:call\\s+karo|call\\s+lagao|phone\\s+karo|phone\\s+lagao)$", RegexOption.IGNORE_CASE)
        val phoneCallMatch = phoneCallRegex.find(clean) ?: phoneCallHinglish.find(clean)
        if (phoneCallMatch != null && !clean.contains("whatsapp") && !clean.contains("video")) {
            val target = phoneCallMatch.groupValues[1].trim()
                .replace(Regex("(?i)^(him|her|them|someone|anyone|later|back)$"), "")
                .trim()
            val nonTargetWords = listOf("it", "that", "this", "day", "off", "back", "later", "yesterday", "tomorrow", "jarvis")
            if (target.isNotBlank() && target.length >= 2 && !nonTargetWords.contains(target.lowercase(Locale.ROOT))) {
                return ParsedCommandResult(JarvisCommand.PhoneCall(target), 0.96f, "PHONE_CALL")
            }
        }

        // 9. YouTube Video Play & Search (Strict Intent Anchoring)
        // Compound command: "open youtube and play [song]" / "open youtube and search [query]"
        val openAndPlayMatch = Regex("$prefix(?:open\\s+youtube\\s+(?:and|&)?\\s*(?:play|search)\\s+)(.+)$", RegexOption.IGNORE_CASE).find(clean)
        if (openAndPlayMatch != null) {
            val query = openAndPlayMatch.groupValues[1].trim()
            if (query.isNotBlank()) {
                return ParsedCommandResult(JarvisCommand.PlayYouTube(query), 0.96f, "YOUTUBE_OPEN_AND_PLAY")
            }
        }

        // Explicit "play on youtube [query]" or "play in youtube [query]"
        val playOnYtMatch = Regex("$prefix(?:play\\s+(?:on|in|from)\\s+youtube\\s+)(.+)$", RegexOption.IGNORE_CASE).find(clean)
        if (playOnYtMatch != null) {
            val q = playOnYtMatch.groupValues[1]
                .replace(Regex("(?i)\\s+(song|video|gana)$"), "")
                .trim()
            if (q.isNotBlank()) {
                return ParsedCommandResult(JarvisCommand.PlayYouTube(q), 0.97f, "YOUTUBE_PLAY_ON")
            }
        }

        // Hinglish Suffix Play: "<query> (song|gana|video)? (play karo|chalao|laga do|chala do|play kardo|bajao)"
        val ytSuffixRegex = Regex("^(.+?)\\s+(?:song|gana|video|track)?\\s*(?:play\\s+karo|play\\s+kardo|chalao|laga\\s+do|chala\\s+do|bajao|baja\\s+do)$", RegexOption.IGNORE_CASE)
        val ytSuffixMatch = ytSuffixRegex.find(clean)
        if (ytSuffixMatch != null && !clean.startsWith("open ") && !clean.startsWith("launch ")) {
            var raw = ytSuffixMatch.groupValues[1].trim()
            raw = raw.replace(Regex("(?i)^(hey jarvis|jarvis|please|in|on|at|pe|par)\\s+"), "")
                .replace(Regex("(?i)^(youtube\\s+(?:pe|par|in|on)?)\\s*"), "")
                .replace(Regex("(?i)\\s+(ke\\s+gane|ka\\s+gana|song|video|gana)$"), "")
                .trim()
            if (raw.isNotBlank() && raw.length > 1 && !listOf("cricket", "match", "game", "football").contains(raw.lowercase(Locale.ROOT))) {
                return ParsedCommandResult(JarvisCommand.PlayYouTube(raw), 0.96f, "YOUTUBE_PLAY_HINGLISH_SUFFIX")
            }
        }

        // Favorite Song Shortcut ("play my favorite song", "mera favorite gana chalao")
        if (clean.matches(Regex("$prefix(?:play\\s+(?:my\\s+)?(?:favou?rite\\s+song|favou?rite|song)|(?:mera\\s+)?favou?rite\\s+(?:gana|song)\\s+(?:play\\s+karo|chalao|bajao|laga\\s+do))$")) ||
            clean == "play something i like" || clean == "play my song") {
            return ParsedCommandResult(JarvisCommand.PlayYouTube("my favorite song"), 0.98f, "YOUTUBE_PLAY_FAVORITE")
        }

        // Standard Play: "Play Believer", "Play Shape of You on YouTube", "youtube pe Believer chalao"
        val ytPlayRegex = Regex("$prefix(?:play|chalao|laga\\s+do|bajao)\\s+(?:a\\s+|the\\s+)?(?:song\\s+|video\\s+)?(.+)$", RegexOption.IGNORE_CASE)
        val ytPlayMatch = ytPlayRegex.find(clean)
        val isCasualSpeech = clean.contains("game") || clean.contains("match") || clean.contains("store") ||
                clean.contains("cricket") || clean.contains("football") || clean.contains("with") ||
                clean.contains("talking") || clean.contains("friend") || clean.contains("cousin") ||
                clean.startsWith("open ") || clean.startsWith("launch ")

        if (ytPlayMatch != null && !isCasualSpeech) {
            var rawQuery = ytPlayMatch.groupValues[1].trim()
                .replace(Regex("[.,!?:;\"'\\s]+$"), "")
            rawQuery = rawQuery
                .replace(Regex("(?i)^(in|on|at)\\s+youtube\\s+"), "")
                .replace(Regex("(?i)\\s+(on|in|pe|par|from|or|and)\\s+youtube$"), "")
                .replace(Regex("(?i)\\s+(song|video|gana|track|again)$"), "")
                .replace(Regex("[.,!?:;\"'\\s]+$"), "")
                .trim()
            if (rawQuery.isNotBlank() && rawQuery.length > 1 && rawQuery != "youtube" && rawQuery != "song" && rawQuery != "music") {
                return ParsedCommandResult(JarvisCommand.PlayYouTube(rawQuery), 0.95f, "YOUTUBE_PLAY")
            }
        }

        // YouTube Search: "search on youtube [query]" or "search [query] on youtube" or "search [query] video"
        val ytSearchPattern1 = Regex("$prefix(?:search\\s+on\\s+youtube|search\\s+in\\s+youtube|search\\s+youtube\\s+for|youtube\\s+pe\\s+search\\s+karo)\\s+(.+)$", RegexOption.IGNORE_CASE).find(clean)
        val ytSearchPattern2 = Regex("$prefix(?:search\\s+for|search)\\s+(.+?)\\s+(?:on|in)\\s+youtube$", RegexOption.IGNORE_CASE).find(clean)
        val ytSearchPattern3 = Regex("^(.+?)\\s+(?:youtube\\s+pe\\s+search\\s+karo|youtube\\s+search\\s+karo)$", RegexOption.IGNORE_CASE).find(clean)
        val ytSearchMatch = ytSearchPattern1 ?: ytSearchPattern2 ?: ytSearchPattern3
        if (ytSearchMatch != null) {
            val query = ytSearchMatch.groupValues[1].trim()
                .replace(Regex("(?i)\\s+(on\\s+youtube|in\\s+youtube|pe|par|search\\s+karo)$"), "")
                .trim()
            if (query.isNotBlank()) {
                return ParsedCommandResult(JarvisCommand.SearchYouTube(query), 0.96f, "YOUTUBE_SEARCH")
            }
        }

        // 10. Multi-Website and Web URL Navigation
        val cleanForDomain = clean
            .replace(Regex("\\s+dot\\s+"), ".")
            .replace(Regex("\\bdot\\s+(com|org|net|in|io|co|ai|edu|gov|app|dev|me)\\b"), ".$1")
            .replace("twenty first", "21st")
            .replace("twenty-first", "21st")

        val hasExplicitOpenVerb = cleanForDomain.startsWith("open ") ||
                cleanForDomain.startsWith("launch ") ||
                cleanForDomain.startsWith("go to ") ||
                cleanForDomain.startsWith("browse ") ||
                cleanForDomain.contains("website") ||
                cleanForDomain.contains("tab") ||
                cleanForDomain.contains("in chrome") ||
                cleanForDomain.contains("in browser")

        // Check for opening multiple websites: "open vercel.com and github.com", "open vercel, github and twitter"
        val multiUrls = DomainNormalizer.extractMultipleUrls(cleanForDomain)
        if (hasExplicitOpenVerb && multiUrls.size > 1) {
            val hasWebIntent = multiUrls.any { url ->
                cleanForDomain.contains(".com") || cleanForDomain.contains(".dev") ||
                cleanForDomain.contains(".org") || cleanForDomain.contains(".net") ||
                cleanForDomain.contains(".in") || cleanForDomain.contains(".io") ||
                cleanForDomain.contains("wersel") || cleanForDomain.contains("vercel") ||
                cleanForDomain.contains("github") || cleanForDomain.contains("chatgpt") ||
                cleanForDomain.contains("21st")
            }
            if (hasWebIntent) {
                return ParsedCommandResult(JarvisCommand.OpenWebUrls(multiUrls), 0.98f, "OPEN_MULTIPLE_URLS")
            }
        }

        // Single Domain / Web URL check (e.g. "open vercel.com", "open wersel.com", "open 21st.dev", "twenty first dot dev")
        val domainRegex = Regex(".*\\b([a-zA-Z0-9-]+\\.(?:com|org|net|in|io|co|ai|edu|gov|app|dev|me)(?:/[^\\s]*)?)\\b.*", RegexOption.IGNORE_CASE)
        val domainMatch = domainRegex.find(cleanForDomain)
        if (domainMatch != null && hasExplicitOpenVerb && !clean.contains("message") && !clean.contains("whatsapp")) {
            val rawDomain = domainMatch.groupValues[1].trim()
            val normalizedUrl = DomainNormalizer.normalizeToUrl(rawDomain)
            return ParsedCommandResult(JarvisCommand.OpenWebUrls(listOf(normalizedUrl)), 0.98f, "WEB_URL")
        }

        // Phonetic Domain / Spoken tech websites: "open wersel", "open varsel", "open vercel", "open 21st dev", "open website vercel", "open flipkart website"
        if (cleanForDomain.startsWith("open ") || cleanForDomain.startsWith("launch ") || cleanForDomain.startsWith("go to ") || cleanForDomain.startsWith("browse ")) {
            val target = cleanForDomain.replace(Regex("(?i)^(open|launch|go to|browse)\\s+(the\\s+)?"), "")
                .replace(Regex("(?i)^(the\\s+)?(website|site|web)\\s+"), "")
                .replace(Regex("(?i)\\s+(website|site|web|in browser|in chrome)$"), "")
                .trim()
            val isExplicitWeb = cleanForDomain.contains("website") || cleanForDomain.contains("site") ||
                    cleanForDomain.contains("in browser") || cleanForDomain.contains("in chrome") ||
                    DomainNormalizer.isKnownWebAlias(target)
            if (isExplicitWeb && target.isNotBlank()) {
                val normalizedUrl = DomainNormalizer.normalizeToUrl(target)
                return ParsedCommandResult(JarvisCommand.OpenWebUrls(listOf(normalizedUrl)), 0.97f, "WEB_KNOWN_ALIAS")
            }
        }

        // Web Search (Google in browser) - Must explicitly have search or google intent
        val searchWebRegex = Regex("$prefix(?:search\\s+on\\s+google|search\\s+the\\s+web\\s+for|search\\s+google\\s+for|search\\s+for|search|google)\\s+(.+?)(?:\\s+(?:on\\s+google|on\\s+the\\s+web|online|in\\s+browser))?$", RegexOption.IGNORE_CASE)
        val searchHinglish = Regex("^(.+?)\\s+(?:search\\s+karo|search\\s+kardo|google\\s+karo|google\\s+pe\\s+search\\s+karo)$", RegexOption.IGNORE_CASE)
        val searchWebMatch = searchWebRegex.find(clean) ?: searchHinglish.find(clean)
        if (searchWebMatch != null && !clean.contains("youtube")) {
            val query = searchWebMatch.groupValues[1]
                .replace(Regex("(?i)\\s*(on google|on the web|on the internet|online|on browser|pe search karo|search karo|please)$"), "")
                .trim()
            // Ignore casual speech like "search me", "search here"
            if (query.isNotBlank() && query.length > 1 && !listOf("me", "here", "it", "this", "that").contains(query.lowercase(Locale.ROOT))) {
                return ParsedCommandResult(JarvisCommand.SearchWeb(query), 0.95f, "WEB_SEARCH")
            }
        }

        // 10b. Go To Background / Standby
        if (clean.matches(Regex("$prefix(?:go\\s+to\\s+background|go\\s+background|go\\s+in\\s+background|go\\s+in\\s+the\\s+background|minimize|go\\s+to\\s+home\\s+screen|go\\s+home|background\\s+me\\s+jao|background\\s+mein\\s+jao|background\\s+ki\\s+vellu|background\\s+po|background\\s+ch\\s+jao|background\\s+la\\s+ja|background\\s+e\\s+jao|send\\s+to\\s+background|go\\s+to\\s+sleep|sleep\\s+jarvis|enter\\s+standby|standby\\s+mode|so\\s+jao|paduko|sleep)$", RegexOption.IGNORE_CASE))) {
            return ParsedCommandResult(JarvisCommand.GoToBackground, 1.0f, "GO_TO_BACKGROUND")
        }

        // 11. Open Apps (Strict: Must start with open/launch, not casual words)
        val openAppRegex = Regex("$prefix(?:open|launch)\\s+(?:the\\s+)?([a-zA-Z0-9\\s]+)$", RegexOption.IGNORE_CASE)
        val openMatch = openAppRegex.find(clean)
        if (openMatch != null) {
            var app = openMatch.groupValues[1].trim()
            app = app.replace(Regex("(?i)\\s+(app|application|please|for me|now)$"), "").trim()
            val nonAppWords = listOf("door", "window", "gate", "bottle", "box", "bag", "something", "anything", "background", "tab", "website", "site")
            val isWebDomain = app.contains(".com") || app.contains(".dev") || app.contains(".org") ||
                    app.contains(".net") || app.contains(".io") || DomainNormalizer.isKnownWebAlias(app)
            if (app.isNotBlank() && !nonAppWords.contains(app.lowercase(Locale.ROOT)) && !isWebDomain) {
                return ParsedCommandResult(JarvisCommand.OpenApp(app), 0.95f, "OPEN_APP")
            }
        }

        return ParsedCommandResult(null, 0.0f)
    }

    private fun parseNumericLevel(token: String): Int? {
        val clean = token.lowercase(Locale.ROOT).trim()
        clean.toIntOrNull()?.let { return it.coerceIn(0, 100) }
        return when (clean) {
            "zero", "mute", "min", "minimum", "lowest", "silence", "nil", "off" -> 0
            "ten" -> 10
            "twenty" -> 20
            "twenty five", "quarter" -> 25
            "thirty" -> 30
            "forty" -> 40
            "fifty", "half" -> 50
            "sixty" -> 60
            "seventy" -> 70
            "seventy five" -> 75
            "eighty" -> 80
            "ninety" -> 90
            "hundred", "full", "max", "maximum", "highest" -> 100
            else -> null
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/command/CommandParser.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/command/JarvisCommand.kt ===
```kotlin
package com.jarvis.assistant.automation.command

sealed class JarvisCommand {
    data class PlayYouTube(val query: String) : JarvisCommand()
    data class SearchYouTube(val query: String) : JarvisCommand()
    data class OpenApp(val packageName: String) : JarvisCommand()
    data class WhatsAppMessage(val contact: String, val message: String) : JarvisCommand()
    data class WhatsAppCall(val contact: String, val video: Boolean) : JarvisCommand()
    data class WhatsAppDeleteMessage(val contact: String?, val forEveryone: Boolean) : JarvisCommand()
    object SubscribeChannel : JarvisCommand()
    object ToggleFullscreen : JarvisCommand()
    data class Brightness(val level: Int, val isRelative: Boolean = false, val delta: Int = 0) : JarvisCommand()
    data class Volume(val level: Int, val isRelative: Boolean = false, val delta: Int = 0) : JarvisCommand()
    data class Flash(val enabled: Boolean) : JarvisCommand()
    data class Remember(val text: String) : JarvisCommand()
    data class Forget(val query: String) : JarvisCommand()
    object WhatDoYouRemember : JarvisCommand()
    data class SearchWeb(val query: String) : JarvisCommand()
    data class OpenWebUrls(val urls: List<String>) : JarvisCommand()
    data class PhoneCall(val contactOrNumber: String) : JarvisCommand()
    object PauseMedia : JarvisCommand()
    object ResumeMedia : JarvisCommand()
    object NextMedia : JarvisCommand()
    object PreviousMedia : JarvisCommand()
    data class ConfirmAction(val confirmed: Boolean) : JarvisCommand()
    data class DisambiguationChoice(val choice: String) : JarvisCommand()
    object RecallBirthday : JarvisCommand()
    object RecallFavoriteSong : JarvisCommand()
    object RecallRoutine : JarvisCommand()
    object GoToBackground : JarvisCommand()
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/command/JarvisCommand.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/contacts/ContactModel.kt ===
```kotlin
package com.jarvis.assistant.automation.contacts

data class ContactInfo(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val lookupKey: String = ""
)

sealed class ContactResolutionResult {
    data class SingleMatch(val contact: ContactInfo) : ContactResolutionResult()
    data class MultipleMatches(val candidates: List<ContactInfo>) : ContactResolutionResult()
    object NoMatch : ContactResolutionResult()
    object PermissionDenied : ContactResolutionResult()
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/contacts/ContactModel.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/contacts/ContactResolver.kt ===
```kotlin
package com.jarvis.assistant.automation.contacts

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import android.util.Log
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.min

class ContactResolver(private val context: Context) {

    companion object {
        private const val TAG = "ContactResolver"

        private val NICKNAME_MAP = mapOf(
            "mom" to listOf("mom", "mother", "mummy", "maa", "ammi"),
            "dad" to listOf("dad", "father", "papa", "daddy", "abbu"),
            "bro" to listOf("brother", "bro", "bhai"),
            "sis" to listOf("sister", "sis", "didi"),
            "wife" to listOf("wife", "biwi", "darling"),
            "husband" to listOf("husband", "hubby")
        )
    }

    fun hasPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun resolveContact(query: String): ContactResolutionResult {
        if (!hasPermission()) {
            Log.w(TAG, "Cannot resolve contacts: READ_CONTACTS permission not granted")
            return ContactResolutionResult.PermissionDenied
        }

        val cleanQuery = query.trim().lowercase(Locale.ROOT)
        if (cleanQuery.isBlank()) {
            return ContactResolutionResult.NoMatch
        }

        val allContacts = loadAllContacts()
        if (allContacts.isEmpty()) {
            return ContactResolutionResult.NoMatch
        }

        // 1. Exact Name Matches (case-insensitive)
        val exactMatches = allContacts.filter { it.name.lowercase(Locale.ROOT) == cleanQuery }
        if (exactMatches.size == 1) {
            return ContactResolutionResult.SingleMatch(exactMatches.first())
        } else if (exactMatches.size > 1) {
            return ContactResolutionResult.MultipleMatches(exactMatches)
        }

        // 2. Nickname resolution
        val nicknameAliases = NICKNAME_MAP[cleanQuery]
        if (nicknameAliases != null) {
            val nicknameMatches = allContacts.filter { contact ->
                val lowerName = contact.name.lowercase(Locale.ROOT)
                nicknameAliases.any { alias -> lowerName.contains(alias) }
            }
            if (nicknameMatches.size == 1) {
                return ContactResolutionResult.SingleMatch(nicknameMatches.first())
            } else if (nicknameMatches.size > 1) {
                return ContactResolutionResult.MultipleMatches(nicknameMatches)
            }
        }

        // 3. Prefix or Word Boundary matches (e.g. "Rahul" matching "Rahul Sharma")
        val wordMatches = allContacts.filter { contact ->
            val lowerName = contact.name.lowercase(Locale.ROOT)
            val tokens = lowerName.split(" ", ".", "_", "-")
            tokens.any { token -> token == cleanQuery || token.startsWith(cleanQuery) }
        }
        if (wordMatches.size == 1) {
            return ContactResolutionResult.SingleMatch(wordMatches.first())
        } else if (wordMatches.size > 1) {
            return ContactResolutionResult.MultipleMatches(wordMatches)
        }

        // 4. Fuzzy Levenshtein matching
        val scored = allContacts.map { contact ->
            val score = calculateSimilarity(cleanQuery, contact.name.lowercase(Locale.ROOT))
            Pair(contact, score)
        }.filter { it.second >= 0.70 }
            .sortedByDescending { it.second }

        return when {
            scored.isEmpty() -> ContactResolutionResult.NoMatch
            scored.size == 1 -> ContactResolutionResult.SingleMatch(scored.first().first)
            scored.first().second - (scored.getOrNull(1)?.second ?: 0f) > 0.15f -> {
                // Clear top winner
                ContactResolutionResult.SingleMatch(scored.first().first)
            }
            else -> {
                ContactResolutionResult.MultipleMatches(scored.take(3).map { it.first })
            }
        }
    }

    private fun loadAllContacts(): List<ContactInfo> {
        val contacts = mutableListOf<ContactInfo>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY
        )

        try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                null,
                null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )

            cursor?.use {
                val idIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val keyIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY)

                val seenNumbers = mutableSetOf<String>()

                while (it.moveToNext()) {
                    val id = if (idIdx >= 0) it.getString(idIdx) ?: "" else ""
                    val name = if (nameIdx >= 0) it.getString(nameIdx) ?: "" else ""
                    val number = if (numIdx >= 0) it.getString(numIdx) ?: "" else ""
                    val lookupKey = if (keyIdx >= 0) it.getString(keyIdx) ?: "" else ""

                    val digitsOnly = number.replace(Regex("[^0-9]"), "")
                    val cleanNum = when {
                        digitsOnly.length == 10 -> "91$digitsOnly"
                        digitsOnly.length == 11 && digitsOnly.startsWith("0") -> "91${digitsOnly.substring(1)}"
                        else -> digitsOnly
                    }
                    if (name.isNotBlank() && cleanNum.isNotBlank() && !seenNumbers.contains(cleanNum)) {
                        seenNumbers.add(cleanNum)
                        contacts.add(ContactInfo(id = id, name = name, phoneNumber = cleanNum, lookupKey = lookupKey))
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying contacts: ${e.message}", e)
        }

        return contacts
    }

    private fun calculateSimilarity(s1: String, s2: String): Float {
        val longer = if (s1.length > s2.length) s1 else s2
        val shorter = if (s1.length > s2.length) s2 else s1
        if (longer.isEmpty()) return 1.0f

        val dist = levenshteinDistance(longer, shorter)
        return (longer.length - dist).toFloat() / longer.length.toFloat()
    }

    private fun levenshteinDistance(lhs: CharSequence, rhs: CharSequence): Int {
        var cost = IntArray(lhs.length + 1) { it }
        var newCost = IntArray(lhs.length + 1) { 0 }

        for (i in 1..rhs.length) {
            newCost[0] = i
            for (j in 1..lhs.length) {
                val match = if (lhs[j - 1] == rhs[i - 1]) 0 else 1
                val costReplace = cost[j - 1] + match
                val costInsert = cost[j] + 1
                val costDelete = newCost[j - 1] + 1
                newCost[j] = min(min(costInsert, costDelete), costReplace)
            }
            val swap = cost
            cost = newCost
            newCost = swap
        }
        return cost[lhs.length]
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/contacts/ContactResolver.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/phone/DomainNormalizer.kt ===
```kotlin
package com.jarvis.assistant.automation.phone

import java.util.Locale
import kotlin.math.min

object DomainNormalizer {

    private val KNOWN_DOMAINS = mapOf(
        // Tech & Dev
        "vercel" to "vercel.com",
        "wersel" to "vercel.com",
        "varsel" to "vercel.com",
        "versal" to "vercel.com",
        "vercell" to "vercel.com",
        "21st" to "21st.dev",
        "twenty first" to "21st.dev",
        "twenty-first" to "21st.dev",
        "21st dev" to "21st.dev",
        "twenty first dev" to "21st.dev",
        "github" to "github.com",
        "git hub" to "github.com",
        "git-hub" to "github.com",
        "gethub" to "github.com",
        "geethub" to "github.com",
        "gitlab" to "gitlab.com",
        "git lab" to "gitlab.com",
        "stackoverflow" to "stackoverflow.com",
        "stack overflow" to "stackoverflow.com",
        "chatgpt" to "chatgpt.com",
        "chat gpt" to "chatgpt.com",
        "chad gpt" to "chatgpt.com",
        "openai" to "openai.com",
        "open ai" to "openai.com",
        "anthropic" to "anthropic.com",
        "claude" to "claude.ai",
        "gemini" to "gemini.google.com",
        "google flow" to "labs.google/flow",
        "flow" to "labs.google/flow",
        "flow google" to "labs.google/flow",
        "googleflow" to "labs.google/flow",
        "flow website" to "labs.google/flow",
        "runway" to "runwayml.com",
        "runwayml" to "runwayml.com",
        "pika" to "pika.art",
        "midjourney" to "midjourney.com",
        "canva" to "canva.com",
        "leonardo" to "leonardo.ai",
        "elevenlabs" to "elevenlabs.io",
        "suno" to "suno.com",
        "luma" to "lumalabs.ai",
        "kling" to "klingai.com",
        "huggingface" to "huggingface.co",
        "hugging face" to "huggingface.co",
        "firebase" to "firebase.google.com",
        "aws" to "aws.amazon.com",

        // Search & Google
        "google" to "google.com",
        "gmail" to "mail.google.com",
        "g mail" to "mail.google.com",
        "google mail" to "mail.google.com",
        "google drive" to "drive.google.com",
        "gdrive" to "drive.google.com",
        "drive" to "drive.google.com",
        "google maps" to "maps.google.com",
        "maps" to "maps.google.com",

        // Social Media & Video
        "youtube" to "youtube.com",
        "you tube" to "youtube.com",
        "u tube" to "youtube.com",
        "utube" to "youtube.com",
        "yt" to "youtube.com",
        "twitter" to "x.com",
        "twiter" to "x.com",
        "x" to "x.com",
        "facebook" to "facebook.com",
        "face book" to "facebook.com",
        "fb" to "facebook.com",
        "instagram" to "instagram.com",
        "insta gram" to "instagram.com",
        "insta" to "instagram.com",
        "linkedin" to "linkedin.com",
        "link din" to "linkedin.com",
        "linked in" to "linkedin.com",
        "linkdin" to "linkedin.com",
        "reddit" to "reddit.com",
        "red it" to "reddit.com",
        "pinterest" to "pinterest.com",
        "pin terest" to "pinterest.com",
        "snapchat" to "snapchat.com",
        "snap" to "snapchat.com",
        "telegram" to "web.telegram.org",
        "discord" to "discord.com",
        "whatsapp" to "web.whatsapp.com",

        // Media & Streaming
        "netflix" to "netflix.com",
        "net flix" to "netflix.com",
        "spotify" to "spotify.com",
        "spo ti fy" to "spotify.com",
        "prime video" to "primevideo.com",
        "amazon prime" to "primevideo.com",
        "hotstar" to "hotstar.com",
        "jiocinema" to "jiocinema.com",
        "jio cinema" to "jiocinema.com",

        // Shopping & Food & Finance
        "amazon" to "amazon.in",
        "ama zon" to "amazon.in",
        "flipkart" to "flipkart.com",
        "flip kart" to "flipkart.com",
        "myntra" to "myntra.com",
        "meesho" to "meesho.com",
        "swiggy" to "swiggy.com",
        "zomato" to "zomato.com",
        "blinkit" to "blinkit.com",
        "zepto" to "zepto.com",
        "cricbuzz" to "cricbuzz.com",

        // Reference & Learning
        "wikipedia" to "wikipedia.org",
        "wiki pedia" to "wikipedia.org",
        "coursera" to "coursera.org",
        "udemy" to "udemy.com"
    )

    fun isKnownWebAlias(target: String): Boolean {
        val clean = target.trim().lowercase(Locale.ROOT)
            .replace(Regex("^(https?://|www\\.)"), "")
            .replace(Regex("^(the\\s+)?(website|site|web)\\s+"), "")
            .replace(Regex("\\s+(website|site|web|in browser|in chrome)$"), "")
            .replace(Regex("\\.(com|org|net|in|io|co|ai|edu|gov|app|dev|me)$"), "")
            .trim()
        return KNOWN_DOMAINS.containsKey(clean) || KNOWN_DOMAINS.containsKey(target.trim().lowercase(Locale.ROOT))
    }

    /**
     * Normalizes a raw string (spoken domain or website alias) into a full valid URL.
     * e.g. "wersel.com" -> "https://vercel.com"
     * e.g. "wersel" -> "https://vercel.com"
     * e.g. "github.com" -> "https://github.com"
     */
    fun normalizeToUrl(raw: String): String {
        var clean = raw.trim().lowercase(Locale.ROOT)
            .replace(Regex("\\s+dot\\s+"), ".")
            .replace(Regex("\\bdot\\s+(com|org|net|in|io|co|ai|edu|gov|app|dev|me)\\b"), ".$1")
            .replace("twenty first", "21st")
            .replace("twenty-first", "21st")
            .replace(Regex("^(https?://|www\\.)"), "")
            .replace(Regex("^(the\\s+)?(website|site|web)\\s+"), "")
            .replace(Regex("\\s+(website|site|web|in browser|in chrome)$"), "")
            .replace(Regex("[.,/\\s]+$"), "")

        // Check if ends with a domain extension
        val withoutExt = clean.replace(Regex("\\.(com|org|net|in|io|co|ai|edu|gov|app|dev|me)$"), "").trim()

        // 1. Exact alias match
        KNOWN_DOMAINS[clean]?.let { return "https://$it" }
        KNOWN_DOMAINS[withoutExt]?.let { return "https://$it" }

        // 2. Fuzzy match against known domain keys
        var bestDomain: String? = null
        var bestDistance = 2 // allow max 2 typos/phonetic diffs for words >= 5 chars
        for ((key, domain) in KNOWN_DOMAINS) {
            if (key.length >= 4 && (withoutExt.length >= 4 || clean.length >= 4)) {
                val d1 = levenshtein(withoutExt, key)
                val d2 = levenshtein(clean, key)
                val minD = min(d1, d2)
                if (minD < bestDistance) {
                    bestDistance = minD
                    bestDomain = domain
                }
            }
        }
        if (bestDomain != null) {
            return "https://$bestDomain"
        }

        // 3. If raw already has a valid TLD extension, return https://<clean>
        if (clean.matches(Regex("^[a-zA-Z0-9-]+\\.(com|org|net|in|io|co|ai|edu|gov|app|dev|me)(/.*)?$"))) {
            return "https://$clean"
        }

        // 4. Default fallback: append .com
        return "https://$clean.com"
    }

    /**
     * Extracts one or more target website URLs from a user speech string.
     * Handles:
     * - "open vercel.com and github.com" -> ["https://vercel.com", "https://github.com"]
     * - "open vercel, github and twitter" -> ["https://vercel.com", "https://github.com", "https://x.com"]
     * - "open youtube.com and chatgpt" -> ["https://youtube.com", "https://chatgpt.com"]
     */
    fun extractMultipleUrls(input: String): List<String> {
        val clean = input
            .replace(Regex("(?i)^(hey jarvis|hi jarvis|hello jarvis|ok jarvis|jarvis|service|please)?\\s*(open|launch|go to|browse|in chrome open|on google chrome open)\\s+"), "")
            .replace(Regex("(?i)\\s+(in chrome|in browser|on chrome|on browser|in multiple tabs|tabs|now|please)$"), "")
            .trim()

        // 1. Check if input has space-separated domains (e.g. "github.com vercel.com 21st.dev")
        val spaceTokens = clean.split(Regex("\\s+")).map { it.trim() }.filter { it.isNotBlank() }
        val domainTldRegex = Regex("^[a-zA-Z0-9-]+\\.(com|org|net|in|io|co|ai|edu|gov|app|dev|me)(/.*)?$", RegexOption.IGNORE_CASE)
        val domainMatchesCount = spaceTokens.count { domainTldRegex.matches(it) || isKnownWebAlias(it) }

        val rawTokens: List<String> = if (domainMatchesCount > 1) {
            spaceTokens.filter { it.length > 2 && it != "and" && it != "or" && it != "plus" }
        } else {
            // Split by "and", "or", commas, "plus"
            clean.split(Regex("(?i)\\s+(?:and|&|or|plus)\\s+|,\\s*"))
                .map { it.trim() }
                .filter { it.isNotBlank() }
        }

        val urls = mutableListOf<String>()
        for (token in rawTokens) {
            val normalized = normalizeToUrl(token)
            if (!urls.contains(normalized)) {
                urls.add(normalized)
            }
        }

        return urls
    }

    private fun levenshtein(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j
        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = min(
                    min(dp[i - 1][j] + 1, dp[i][j - 1] + 1),
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[s1.length][s2.length]
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/phone/DomainNormalizer.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/phone/PhoneControlManager.kt ===
```kotlin
package com.jarvis.assistant.automation.phone

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Browser
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import com.jarvis.assistant.automation.contacts.ContactResolutionResult
import com.jarvis.assistant.automation.contacts.ContactResolver
import com.jarvis.assistant.util.ActivityLauncherHelper
import kotlinx.coroutines.delay
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class PhoneControlManager(
    private val context: Context,
    private val contactResolver: ContactResolver? = null
) {

    companion object {
        private const val TAG = "PhoneControlManager"

        // Massively expanded app map with smart aliases
        private val POPULAR_APP_PACKAGES = mapOf(
            // Social Media
            "instagram" to "com.instagram.android",
            "insta" to "com.instagram.android",
            "whatsapp" to "com.whatsapp",
            "whats app" to "com.whatsapp",
            "facebook" to "com.facebook.katana",
            "fb" to "com.facebook.katana",
            "messenger" to "com.facebook.orca",
            "fb messenger" to "com.facebook.orca",
            "twitter" to "com.twitter.android",
            "x" to "com.twitter.android",
            "snapchat" to "com.snapchat.android",
            "snap" to "com.snapchat.android",
            "telegram" to "org.telegram.messenger",
            "tg" to "org.telegram.messenger",
            "linkedin" to "com.linkedin.android",
            "pinterest" to "com.pinterest",
            "reddit" to "com.reddit.frontpage",
            "threads" to "com.instagram.barcelona",

            // AI Apps
            "chatgpt" to "com.openai.chatgpt",
            "chat gpt" to "com.openai.chatgpt",
            "openai" to "com.openai.chatgpt",
            "gemini" to "com.google.android.apps.bard",
            "google gemini" to "com.google.android.apps.bard",
            "bard" to "com.google.android.apps.bard",
            "canva" to "com.canva.editor",
            "copilot" to "com.microsoft.copilot",
            "perplexity" to "ai.perplexity.app.android",

            // Google Apps
            "chrome" to "com.android.chrome",
            "google chrome" to "com.android.chrome",
            "browser" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "mail" to "com.google.android.gm",
            "email" to "com.google.android.gm",
            "google maps" to "com.google.android.apps.maps",
            "maps" to "com.google.android.apps.maps",
            "map" to "com.google.android.apps.maps",
            "google pay" to "com.google.android.apps.nbu.paisa.user",
            "google pe" to "com.google.android.apps.nbu.paisa.user",
            "gpay" to "com.google.android.apps.nbu.paisa.user",
            "g pay" to "com.google.android.apps.nbu.paisa.user",
            "gpe" to "com.google.android.apps.nbu.paisa.user",
            "gp" to "com.google.android.apps.nbu.paisa.user",
            "google play" to "com.google.android.apps.nbu.paisa.user",
            "pay" to "com.google.android.apps.nbu.paisa.user",
            "youtube" to "com.google.android.youtube",
            "yt" to "com.google.android.youtube",
            "youtube music" to "com.google.android.apps.youtube.music",
            "yt music" to "com.google.android.apps.youtube.music",
            "google photos" to "com.google.android.apps.photos",
            "photos" to "com.google.android.apps.photos",
            "google drive" to "com.google.android.apps.docs",
            "drive" to "com.google.android.apps.docs",
            "google docs" to "com.google.android.apps.docs.editors.docs",
            "docs" to "com.google.android.apps.docs.editors.docs",
            "google sheets" to "com.google.android.apps.docs.editors.sheets",
            "sheets" to "com.google.android.apps.docs.editors.sheets",
            "google slides" to "com.google.android.apps.docs.editors.slides",
            "slides" to "com.google.android.apps.docs.editors.slides",
            "google translate" to "com.google.android.apps.translate",
            "translate" to "com.google.android.apps.translate",
            "google meet" to "com.google.android.apps.tachyon",
            "meet" to "com.google.android.apps.tachyon",
            "google lens" to "com.google.ar.lens",
            "lens" to "com.google.ar.lens",
            "google calendar" to "com.google.android.calendar",
            "calendar" to "com.google.android.calendar",
            "google keep" to "com.google.android.keep",
            "keep" to "com.google.android.keep",
            "notes" to "com.google.android.keep",
            "google assistant" to "com.google.android.apps.googleassistant",
            "assistant" to "com.google.android.apps.googleassistant",
            "playstore" to "com.android.vending",
            "play store" to "com.android.vending",
            "google play store" to "com.android.vending",
            "app store" to "com.android.vending",

            // Entertainment
            "spotify" to "com.spotify.music",
            "netflix" to "com.netflix.mediaclient",
            "amazon prime" to "com.amazon.avod.thirdpartyclient",
            "prime video" to "com.amazon.avod.thirdpartyclient",
            "prime" to "com.amazon.avod.thirdpartyclient",
            "hotstar" to "in.startv.hotstar",
            "disney hotstar" to "in.startv.hotstar",
            "jio cinema" to "com.jio.media.ondemand",
            "jiocinema" to "com.jio.media.ondemand",
            "zee5" to "com.graymatrix.did",
            "sony liv" to "com.sonyliv",

            // Finance & Payments
            "phonepe" to "com.phonepe.app",
            "phone pe" to "com.phonepe.app",
            "paytm" to "net.one97.paytm",
            "amazon" to "in.amazon.mShop.android.shopping",
            "amazon shopping" to "in.amazon.mShop.android.shopping",
            "flipkart" to "com.flipkart.android",
            "cred" to "com.dreamplug.androidapp",
            "myntra" to "com.myntra.android",

            // Productivity
            "calculator" to "com.google.android.calculator",
            "calc" to "com.google.android.calculator",
            "clock" to "com.google.android.deskclock",
            "alarm" to "com.google.android.deskclock",
            "timer" to "com.google.android.deskclock",
            "files" to "com.google.android.apps.nbu.files",
            "file manager" to "com.google.android.apps.nbu.files",
            "contacts" to "com.google.android.contacts",
            "dialer" to "com.google.android.dialer",
            "phone" to "com.google.android.dialer",

            // Communication
            "zoom" to "us.zoom.videomeetings",
            "teams" to "com.microsoft.teams",
            "microsoft teams" to "com.microsoft.teams",
            "skype" to "com.skype.raider",
            "signal" to "org.thoughtcrime.securesms",

            // Games
            "pubg" to "com.pubg.imobile",
            "bgmi" to "com.pubg.imobile",
            "free fire" to "com.dts.freefireth",
            "call of duty" to "com.activision.callofduty.shooter",
            "cod" to "com.activision.callofduty.shooter",

            // Utility
            "uber" to "com.ubercab",
            "ola" to "com.olacabs.customer",
            "swiggy" to "in.swiggy.android",
            "zomato" to "com.application.zomato",
            "weather" to "com.google.android.apps.weather"
        )
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    @Volatile
    private var isFlashlightOn = false

    val isTorchOn: Boolean
        get() = isFlashlightOn

    init {
        try {
            cameraManager.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    val torchId = findTorchCameraId()
                    if (torchId == null || cameraId == torchId) {
                        isFlashlightOn = enabled
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            Log.e(TAG, "Error registering torch callback: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Brightness Controls (Fixed — reliable auto-brightness disable)
    // -------------------------------------------------------------

    // -------------------------------------------------------------
    // Brightness Controls (Android 15 + Legacy support)
    // -------------------------------------------------------------

    fun setBrightnessPercent(percent: Int): String {
        val clamped = percent.coerceIn(0, 100)
        if (!Settings.System.canWrite(context)) {
            Log.w(TAG, "WRITE_SETTINGS permission is required for system brightness")
            try {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ActivityLauncherHelper.startActivitySafely(context, intent)
            } catch (_: Exception) {}
            return "Please grant System Settings permission in Settings to allow brightness control."
        }

        return try {
            // Step 1: Force disable auto-brightness FIRST
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )

            // Step 2: Set screen_brightness_float (Required for Android 13/14/15, e.g. Vivo/OnePlus/Xiaomi)
            val floatValue = clamped / 100.0f
            try {
                Settings.System.putFloat(
                    context.contentResolver,
                    "screen_brightness_float",
                    floatValue
                )
            } catch (e: Exception) {
                Log.d(TAG, "screen_brightness_float not supported: ${e.message}")
            }

            // Step 3: Set legacy brightness value (0-255 range)
            val brightnessValue = ((clamped / 100.0) * 255).roundToInt().coerceIn(1, 255)
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                brightnessValue
            )

            Log.i(TAG, "Brightness set to $clamped% (float=$floatValue, raw=$brightnessValue, mode=MANUAL)")
            "Screen brightness set to $clamped percent."
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set brightness: ${e.message}", e)
            "Failed to change brightness."
        }
    }

    fun adjustBrightness(increase: Boolean): String {
        if (!Settings.System.canWrite(context)) {
            return "Please grant System Settings permission to allow brightness adjustment."
        }

        // Force manual mode before adjusting
        try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
        } catch (_: Exception) {}

        // Read current brightness from float first, fallback to integer
        val currentPercent = try {
            val floatVal = Settings.System.getFloat(context.contentResolver, "screen_brightness_float")
            (floatVal * 100).roundToInt()
        } catch (_: Exception) {
            val intVal = try {
                Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
            } catch (_: Exception) {
                128
            }
            ((intVal / 255.0) * 100).roundToInt()
        }

        val delta = if (increase) 20 else -20
        return setBrightnessPercent(currentPercent + delta)
    }

    // -------------------------------------------------------------
    // Volume Controls
    // -------------------------------------------------------------

    fun setVolumePercent(percent: Int): String {
        val clamped = percent.coerceIn(0, 100)
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val targetVolume = ((clamped / 100.0) * maxVolume).roundToInt().coerceIn(0, maxVolume)

        return try {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                targetVolume,
                AudioManager.FLAG_SHOW_UI or AudioManager.FLAG_PLAY_SOUND
            )
            try {
                if (clamped == 0) {
                    audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, 0)
                }
            } catch (_: Exception) {}

            if (clamped == 0) {
                "Media volume muted."
            } else {
                "Volume set to $clamped percent."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set volume: ${e.message}", e)
            "Could not change volume."
        }
    }

    fun adjustVolume(increase: Boolean): String {
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        // Ensure a noticeable jump of at least 15% per step
        val step = max(1, (maxVolume * 0.15).roundToInt())
        val targetVolume = (if (increase) currentVolume + step else currentVolume - step).coerceIn(0, maxVolume)

        return try {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                targetVolume,
                AudioManager.FLAG_SHOW_UI or AudioManager.FLAG_PLAY_SOUND
            )
            val percent = ((targetVolume / maxVolume.toFloat()) * 100).roundToInt()
            if (increase) "Volume increased to $percent percent." else "Volume decreased to $percent percent."
        } catch (e: Exception) {
            Log.e(TAG, "Error adjusting volume: ${e.message}", e)
            "Failed to adjust volume."
        }
    }

    fun muteVolume(mute: Boolean): String {
        return if (mute) {
            setVolumePercent(0)
        } else {
            setVolumePercent(50)
        }
    }

    // -------------------------------------------------------------
    // Phone Calling (Cellular / SIM Dialer)
    // -------------------------------------------------------------

    fun makePhoneCall(contactOrNumber: String): String {
        val clean = contactOrNumber.trim()
        if (clean.isBlank()) return "Who would you like to call?"

        val rawDigits = clean.replace(Regex("[^0-9+]"), "")
        val isRawNumber = rawDigits.length >= 7 && (clean.startsWith("+") || clean.all { it.isDigit() || it.isWhitespace() || it == '-' })

        val phoneNumber: String
        val displayName: String

        if (isRawNumber) {
            phoneNumber = rawDigits
            displayName = rawDigits
        } else {
            val resolver = contactResolver ?: ContactResolver(context)
            val res = resolver.resolveContact(clean)
            when (res) {
                is ContactResolutionResult.SingleMatch -> {
                    phoneNumber = res.contact.phoneNumber
                    displayName = res.contact.name
                }
                is ContactResolutionResult.MultipleMatches -> {
                    val names = res.candidates.take(3).joinToString(" or ") { it.name }
                    return "Which $clean? I found $names."
                }
                else -> {
                    return "I could not find a phone number for $clean."
                }
            }
        }

        if (phoneNumber.isBlank()) {
            return "No phone number found for $clean."
        }

        return try {
            val hasCallPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CALL_PHONE
            ) == PackageManager.PERMISSION_GRANTED

            val intent = if (hasCallPermission) {
                Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }

            ActivityLauncherHelper.startActivitySafely(context, intent)
            "Calling $displayName."
        } catch (e: Exception) {
            Log.e(TAG, "Failed to place call: ${e.message}", e)
            "Could not initiate phone call."
        }
    }

    // -------------------------------------------------------------
    // Flashlight Controls
    // -------------------------------------------------------------

    fun setFlashlight(enabled: Boolean): String {
        return try {
            val cameraId = findTorchCameraId() ?: return "No flashlight hardware detected on this device."
            cameraManager.setTorchMode(cameraId, enabled)
            isFlashlightOn = enabled
            if (enabled) "Flashlight turned on." else "Flashlight turned off."
        } catch (e: Exception) {
            Log.e(TAG, "Error setting torch mode: ${e.message}", e)
            "Unable to access the flashlight."
        }
    }

    fun toggleFlashlight(): String {
        return setFlashlight(!isFlashlightOn)
    }

    private fun findTorchCameraId(): String? {
        return try {
            val ids = cameraManager.cameraIdList
            // 1. Back-facing camera with flash
            for (id in ids) {
                val chars = cameraManager.getCameraCharacteristics(id)
                val flashAvailable = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val lensFacing = chars.get(CameraCharacteristics.LENS_FACING)
                if (flashAvailable && lensFacing == CameraCharacteristics.LENS_FACING_BACK) {
                    return id
                }
            }
            // 2. Any camera with flash available
            for (id in ids) {
                val chars = cameraManager.getCameraCharacteristics(id)
                if (chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                    return id
                }
            }
            Log.w(TAG, "No camera with FLASH_INFO_AVAILABLE == true found in: ${ids.toList()}")
            null
        } catch (e: Exception) {
            Log.e(TAG, "findTorchCameraId failed: ${e.message}", e)
            null
        }
    }

    // -------------------------------------------------------------
    // Web Search & URL Opening (No API needed — opens Chrome/Browser)
    // -------------------------------------------------------------

    fun openUrl(rawUrl: String): String {
        val normalized = DomainNormalizer.normalizeToUrl(rawUrl)
        val uri = Uri.parse(normalized)
        val chromeIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.android.chrome")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(android.provider.Browser.EXTRA_APPLICATION_ID, context.packageName)
            putExtra("com.android.browser.application_id", context.packageName)
        }

        return if (ActivityLauncherHelper.startActivitySafely(context, chromeIntent)) {
            "Opening $normalized in Chrome."
        } else {
            val fallbackIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(android.provider.Browser.EXTRA_APPLICATION_ID, context.packageName)
            }
            if (ActivityLauncherHelper.startActivitySafely(context, fallbackIntent)) {
                "Opening $normalized."
            } else {
                "Could not open $rawUrl."
            }
        }
    }

    suspend fun openUrlsInChromeTabs(urls: List<String>): Boolean {
        if (urls.isEmpty()) return false
        var anyLaunched = false
        val baseTime = System.currentTimeMillis()

        for ((index, rawUrl) in urls.withIndex()) {
            val urlString = if (rawUrl.startsWith("http://", ignoreCase = true) || rawUrl.startsWith("https://", ignoreCase = true)) {
                rawUrl
            } else {
                "https://$rawUrl"
            }
            val uri = Uri.parse(urlString)
            val chromeIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.android.chrome")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(android.provider.Browser.EXTRA_APPLICATION_ID, context.packageName)
                putExtra("com.android.browser.application_id", context.packageName)
            }

            val launched = ActivityLauncherHelper.startActivitySafely(context, chromeIntent)
            if (launched) {
                anyLaunched = true
            } else {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra(android.provider.Browser.EXTRA_APPLICATION_ID, context.packageName)
                }
                if (ActivityLauncherHelper.startActivitySafely(context, fallbackIntent)) {
                    anyLaunched = true
                }
            }

            // Delay 400ms between multiple tabs so Chrome creates separate tab tasks
            if (urls.size > 1 && index < urls.size - 1) {
                delay(400L)
            }
        }
        return anyLaunched
    }

    suspend fun openMultipleUrls(rawUrls: List<String>): String {
        if (rawUrls.isEmpty()) return "No websites specified to open."
        val ok = openUrlsInChromeTabs(rawUrls)
        return if (ok) {
            if (rawUrls.size == 1) {
                "Opening ${DomainNormalizer.normalizeToUrl(rawUrls.first())} in browser."
            } else {
                "Opening ${rawUrls.size} websites in separate tabs."
            }
        } else {
            "Could not open specified websites."
        }
    }

    fun searchWeb(query: String): String {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) {
            return "Please specify what you want to search for."
        }

        // Direct URL / Domain check
        val domainRegex = Regex(".*\\b([a-zA-Z0-9-]+\\.(?:com|org|net|in|io|co|ai|edu|gov|app|dev|me)(?:/[^\\s]*)?)\\b.*", RegexOption.IGNORE_CASE)
        val domainMatch = domainRegex.find(cleanQuery)
        if (domainMatch != null || cleanQuery.startsWith("http://") || cleanQuery.startsWith("https://") || cleanQuery.startsWith("www.")) {
            val urlTarget = domainMatch?.groupValues?.get(1) ?: cleanQuery
            return openUrl(urlTarget)
        }

        val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
        val searchUrl = "https://www.google.com/search?q=$encoded"
        return openUrl(searchUrl)
    }

    fun extractUrlsFromText(input: String): List<String> {
        val urls = mutableListOf<String>()
        val explicitUrlRegex = Regex("""https?://[^\s,"'<>]+""", RegexOption.IGNORE_CASE)
        for (m in explicitUrlRegex.findAll(input)) {
            val u = m.value.trimEnd('.', ',', ';', '!', '?', ')')
            if (u.isNotEmpty() && !urls.contains(u)) urls.add(u)
        }

        val domainRegex = Regex("""\b(?:www\.)?([a-zA-Z0-9-]+\.)+(com|in|org|net|io|co|dev|app|ai|gov|edu|me|tech|info|online|xyz|site|store|cc|tv|uk|us|ca|de|fr|jp|cn|biz)(/[^\s,"'<>]*)?\b""", RegexOption.IGNORE_CASE)
        for (m in domainRegex.findAll(input)) {
            val clean = m.value.trimEnd('.', ',', ';', '!', '?', ')')
            val full = if (clean.startsWith("http://", ignoreCase = true) || clean.startsWith("https://", ignoreCase = true)) clean else "https://$clean"
            if (!urls.any { it.equals(full, ignoreCase = true) || it.contains(clean, ignoreCase = true) }) {
                urls.add(full)
            }
        }
        return urls
    }

    fun parseTargetUrl(query: String): String? {
        var clean = query.trim()
        val lower = clean.lowercase(Locale.ROOT)

        val prefixes = listOf("open website", "open site", "visit website", "visit site", "open url", "navigate to", "visit", "open")
        for (prefix in prefixes) {
            if (lower.startsWith(prefix)) {
                val candidate = clean.substring(prefix.length).trim()
                if (candidate.isNotEmpty()) {
                    clean = candidate
                    break
                }
            }
        }

        if (clean.startsWith("http://", ignoreCase = true) || clean.startsWith("https://", ignoreCase = true)) {
            return clean
        }

        val cleanLower = clean.lowercase(Locale.ROOT)
        // Smart URL resolution for web-only creative tools & explicit website requests
        when {
            cleanLower.contains("google flow") || cleanLower.contains("flow website") || cleanLower == "flow" || cleanLower.contains("flow ai") -> return "https://flow.google.com"
            cleanLower.contains("chatgpt.com") || cleanLower.contains("chatgpt website") || cleanLower.contains("chatgpt site") -> return "https://chatgpt.com"
            cleanLower.contains("canva.com") || cleanLower.contains("canva website") || cleanLower.contains("canva site") -> return "https://www.canva.com"
            cleanLower.contains("gemini.google") || cleanLower.contains("gemini website") || cleanLower.contains("gemini site") -> return "https://gemini.google.com"
            cleanLower.contains("runway") -> return "https://runwayml.com"
            cleanLower.contains("pika") -> return "https://pika.art"
            cleanLower.contains("luma") -> return "https://lumalabs.ai"
            cleanLower.contains("midjourney") -> return "https://www.midjourney.com"
            cleanLower.contains("kling") -> return "https://klingai.com"
        }
        val domainRegex = Regex("""^([a-zA-Z0-9-]+\.)+(com|in|org|net|io|co|dev|app|ai|gov|edu|me|tech|info|online|xyz|site|store|cc|tv|uk|us|ca|de|fr|jp|cn|biz)(/.*)?$""")
        if (domainRegex.matches(cleanLower)) {
            return "https://$clean"
        }

        if (cleanLower.startsWith("www.") || (cleanLower.contains(".") && !cleanLower.contains(" ") && cleanLower.indexOf(".") < cleanLower.length - 2)) {
            return "https://$clean"
        }

        return null
    }

    // -------------------------------------------------------------
    // App Launching (Smart resolution with 100+ aliases)
    // -------------------------------------------------------------

    fun openApp(appNameOrPackage: String): String {
        val clean = appNameOrPackage.trim().lowercase(Locale.ROOT)
        Log.i(TAG, "openApp called with: '$clean'")

        // Check if query is actually a URL or domain: e.g. "open github.com"
        val domainRegex = Regex(".*\\b([a-zA-Z0-9-]+\\.(?:com|org|net|in|io|co|ai|edu|gov|app|dev|me)(?:/[^\\s]*)?)\\b.*", RegexOption.IGNORE_CASE)
        val domainMatch = domainRegex.find(clean)
        if (domainMatch != null || clean.startsWith("http://") || clean.startsWith("https://") || clean.startsWith("www.")) {
            val urlTarget = domainMatch?.groupValues?.get(1) ?: clean
            return openUrl(urlTarget)
        }

        // Special case: Camera
        if (clean == "camera" || clean == "cam") {
            val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                ActivityLauncherHelper.startActivitySafely(context, cameraIntent)
                "Opening Camera."
            } catch (e: Exception) {
                // Try direct package
                val pkg = resolveInstalledPackageByName("camera") ?: "com.android.camera"
                context.packageManager.getLaunchIntentForPackage(pkg)?.let {
                    ActivityLauncherHelper.startActivitySafely(context, it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return "Opening Camera."
                }
                "Failed to open Camera."
            }
        }

        // Special case: Settings
        if (clean == "settings" || clean == "setting") {
            val settingsIntent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                ActivityLauncherHelper.startActivitySafely(context, settingsIntent)
                "Opening Settings."
            } catch (e: Exception) {
                "Failed to open Settings."
            }
        }

        // Special case: Gallery/Photos
        if (clean == "gallery" || clean == "photo gallery" || clean == "photos") {
            val pkg = resolveInstalledPackageByName("gallery")
                ?: resolveInstalledPackageByName("photos")
                ?: "com.google.android.apps.photos"
            val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (launchIntent != null) {
                ActivityLauncherHelper.startActivitySafely(context, launchIntent)
                return "Opening Gallery."
            }
            val galleryIntent = Intent(Intent.ACTION_VIEW).apply {
                type = "image/*"
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                ActivityLauncherHelper.startActivitySafely(context, galleryIntent)
                "Opening Gallery."
            } catch (e: Exception) {
                "Failed to open Gallery."
            }
        }

        // Smart Alias check: if user says "google play", smartly check if GPay is intended
        var targetPackage: String? = null
        if (clean == "google play") {
            val gpayPkg = "com.google.android.apps.nbu.paisa.user"
            val hasGPay = try {
                context.packageManager.getPackageInfo(gpayPkg, 0) != null
            } catch (_: Exception) { false }
            targetPackage = if (hasGPay) gpayPkg else "com.android.vending"
        } else {
            // Step 1: Try exact match from smart aliases map
            targetPackage = POPULAR_APP_PACKAGES[clean]
                ?: POPULAR_APP_PACKAGES[clean.replace(" ", "")]
                ?: POPULAR_APP_PACKAGES[clean.replace("-", "")]
        }

        // Step 2: Search installed launcher activities and applications
        if (targetPackage == null) {
            targetPackage = resolveInstalledPackageByName(clean)
        }

        if (targetPackage != null) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(targetPackage)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (launchIntent != null) {
                return try {
                    val launched = ActivityLauncherHelper.startActivitySafely(context, launchIntent)
                    Log.i(TAG, "Successfully launched via ActivityLauncherHelper: $targetPackage ($launched)")
                    "Opening ${clean.replaceFirstChar { it.uppercase() }}."
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to launch $targetPackage: ${e.message}")
                    "Failed to launch app."
                }
            } else {
                Log.w(TAG, "Package $targetPackage found but no launch intent available")
            }
        }

        // Fallback: If no app is installed on phone, check if it is a known web-only platform (e.g. Google Flow)
        val webFallbackUrl = parseTargetUrl(clean)
        if (webFallbackUrl != null) {
            Log.i(TAG, "No native app found for '$clean', falling back to web platform: $webFallbackUrl")
            return openUrl(webFallbackUrl)
        }

        return "I could not find $appNameOrPackage installed on this device."
    }

    private fun resolveInstalledPackageByName(query: String): String? {
        val pm = context.packageManager
        val cleanQuery = query.lowercase(Locale.ROOT).trim()

        // 1. Query launcher activities first (guarantees launchable apps)
        val launcherIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveList = try {
            pm.queryIntentActivities(launcherIntent, 0)
        } catch (e: Exception) {
            emptyList()
        }

        val appEntries = mutableListOf<Pair<String, String>>() // Pair(label, packageName)
        for (ri in resolveList) {
            val label = ri.loadLabel(pm).toString().lowercase(Locale.ROOT).trim()
            val pkg = ri.activityInfo.packageName
            appEntries.add(Pair(label, pkg))
        }

        // Pass 1: Exact match on label
        for ((label, pkg) in appEntries) {
            if (label == cleanQuery) return pkg
        }

        // Pass 2: Normalized match (spaces/punctuation removed, e.g. "google pay" == "googlepay")
        val normalizedQuery = cleanQuery.replace(Regex("[\\s._-]+"), "")
        for ((label, pkg) in appEntries) {
            val normLabel = label.replace(Regex("[\\s._-]+"), "")
            if (normLabel == normalizedQuery) return pkg
        }

        // Pass 3: Label contains query or query contains label
        for ((label, pkg) in appEntries) {
            if (label.contains(cleanQuery) || cleanQuery.contains(label)) return pkg
        }

        // Pass 4: Word prefix match (e.g. "insta" matches "Instagram")
        for ((label, pkg) in appEntries) {
            val words = label.split(" ", ".", "_", "-")
            if (words.any { it.startsWith(cleanQuery) || cleanQuery.startsWith(it) }) return pkg
        }

        // Pass 5: Levenshtein fuzzy similarity
        var bestPkg: String? = null
        var bestScore = 0.65f
        for ((label, pkg) in appEntries) {
            val score = calculateStringSimilarity(cleanQuery, label)
            if (score > bestScore) {
                bestScore = score
                bestPkg = pkg
            }
        }
        if (bestPkg != null) return bestPkg

        // Fallback: check all installed applications metadata
        try {
            val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (app in installed) {
                val label = pm.getApplicationLabel(app).toString().lowercase(Locale.ROOT).trim()
                if (label.contains(cleanQuery) || cleanQuery.contains(label)) {
                    if (pm.getLaunchIntentForPackage(app.packageName) != null) {
                        return app.packageName
                    }
                }
            }
        } catch (_: Exception) {}

        return null
    }

    private fun calculateStringSimilarity(s1: String, s2: String): Float {
        val longer = if (s1.length > s2.length) s1 else s2
        val shorter = if (s1.length > s2.length) s2 else s1
        if (longer.isEmpty()) return 1.0f
        val dist = levenshtein(longer, shorter)
        return (longer.length - dist).toFloat() / longer.length.toFloat()
    }

    private fun levenshtein(lhs: CharSequence, rhs: CharSequence): Int {
        var cost = IntArray(lhs.length + 1) { it }
        var newCost = IntArray(lhs.length + 1) { 0 }
        for (i in 1..rhs.length) {
            newCost[0] = i
            for (j in 1..lhs.length) {
                val match = if (lhs[j - 1] == rhs[i - 1]) 0 else 1
                val costReplace = cost[j - 1] + match
                val costInsert = cost[j] + 1
                val costDelete = newCost[j - 1] + 1
                newCost[j] = kotlin.math.min(kotlin.math.min(costInsert, costDelete), costReplace)
            }
            val swap = cost
            cost = newCost
            newCost = swap
        }
        return cost[lhs.length]
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/phone/PhoneControlManager.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/whatsapp/WhatsAppAssistant.kt ===
```kotlin
package com.jarvis.assistant.automation.whatsapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.util.Log
import com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService
import com.jarvis.assistant.automation.contacts.ContactInfo
import com.jarvis.assistant.automation.contacts.ContactResolutionResult
import com.jarvis.assistant.automation.contacts.ContactResolver
import com.jarvis.assistant.util.ActivityLauncherHelper
import java.net.URLEncoder

data class PendingWhatsAppDraft(
    val contactName: String,
    val phoneNumber: String?,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

class WhatsAppAssistant(
    private val context: Context,
    private val contactResolver: ContactResolver
) {
    companion object {
        private const val TAG = "WhatsAppAssistant"
        private const val WHATSAPP_PACKAGE = "com.whatsapp"
    }

    private var pendingDraft: PendingWhatsAppDraft? = null
    private var disambiguationCandidates: List<ContactInfo>? = null

    fun hasPendingDraft(): Boolean = pendingDraft != null

    fun isAwaitingDisambiguation(): Boolean = !disambiguationCandidates.isNullOrEmpty()

    fun createDraft(targetContact: String, messageText: String): String {
        val cleanContact = targetContact.trim()
        val cleanMessage = messageText.trim()

        if (cleanContact.isBlank()) {
            return "Who would you like to message on WhatsApp, sir?"
        }
        if (cleanMessage.isBlank()) {
            return "What message would you like to send to $cleanContact?"
        }

        val resolution = contactResolver.resolveContact(cleanContact)
        when (resolution) {
            is ContactResolutionResult.SingleMatch -> {
                disambiguationCandidates = null
                val contact = resolution.contact
                pendingDraft = PendingWhatsAppDraft(
                    contactName = contact.name,
                    phoneNumber = contact.phoneNumber,
                    message = cleanMessage
                )
                return "Draft ready for ${contact.name}: \"$cleanMessage\". Should I send it?"
            }
            is ContactResolutionResult.MultipleMatches -> {
                disambiguationCandidates = resolution.candidates
                val names = resolution.candidates.take(3).map { it.name }.joinToString(" and ")
                return "Which $cleanContact? I found $names."
            }
            is ContactResolutionResult.NoMatch -> {
                // If contact was entered as a raw phone number or not found in contacts
                disambiguationCandidates = null
                val isPhoneNumber = cleanContact.replace(Regex("[^0-9+]"), "").length >= 7
                val phone = if (isPhoneNumber) cleanContact.replace(Regex("[^0-9+]"), "") else null
                pendingDraft = PendingWhatsAppDraft(
                    contactName = cleanContact,
                    phoneNumber = phone,
                    message = cleanMessage
                )
                return "Draft ready for $cleanContact: \"$cleanMessage\". Should I send it?"
            }
            is ContactResolutionResult.PermissionDenied -> {
                disambiguationCandidates = null
                pendingDraft = PendingWhatsAppDraft(
                    contactName = cleanContact,
                    phoneNumber = null,
                    message = cleanMessage
                )
                return "Draft ready for $cleanContact. Note: Contacts permission is needed for automatic phone resolution. Should I send it?"
            }
        }
    }

    fun handleDisambiguationChoice(userChoice: String, pendingMessage: String = ""): String {
        val candidates = disambiguationCandidates ?: return "No contact disambiguation in progress."
        val chosen = candidates.find {
            it.name.contains(userChoice, ignoreCase = true) || userChoice.contains(it.name, ignoreCase = true)
        } ?: candidates.firstOrNull()

        disambiguationCandidates = null

        return if (chosen != null) {
            val msg = if (pendingMessage.isNotBlank()) pendingMessage else "Hello"
            pendingDraft = PendingWhatsAppDraft(
                contactName = chosen.name,
                phoneNumber = chosen.phoneNumber,
                message = msg
            )
            "Draft ready for ${chosen.name}. Should I send it?"
        } else {
            "I couldn't identify which contact you meant, sir."
        }
    }

    fun sendMessageDirectly(targetContact: String, messageText: String): String {
        val cleanContact = targetContact.trim()
        val cleanMessage = messageText.trim()
        if (cleanContact.isBlank()) return "Who would you like to message on WhatsApp, sir?"
        if (cleanMessage.isBlank()) return "What message would you like to send to $cleanContact?"

        val draftResult = createDraft(cleanContact, cleanMessage)
        return if (hasPendingDraft()) {
            confirmAndSend()
        } else {
            draftResult
        }
    }

    fun confirmAndSend(): String {
        val draft = pendingDraft ?: return "There is no draft waiting to be sent."
        val message = draft.message
        val phone = draft.phoneNumber

        return try {
            val encodedMessage = URLEncoder.encode(message, "UTF-8")
            val rawDigits = phone?.replace(Regex("[^0-9]"), "") ?: ""
            val cleanPhone = when {
                rawDigits.length == 10 -> "91$rawDigits"
                rawDigits.length == 11 && rawDigits.startsWith("0") -> "91${rawDigits.substring(1)}"
                else -> rawDigits
            }

            val targetPkg = if (isPackageInstalled(WHATSAPP_PACKAGE)) {
                WHATSAPP_PACKAGE
            } else if (isPackageInstalled("com.whatsapp.w4b")) {
                "com.whatsapp.w4b"
            } else {
                WHATSAPP_PACKAGE
            }

            val intent = if (cleanPhone.isNotBlank()) {
                Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMessage")).apply {
                    setPackage(targetPkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, message)
                    setPackage(targetPkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }

            // Arm accessibility service BEFORE launching WhatsApp so it's ready to click immediately
            JarvisAccessibilityService.triggerWhatsAppSend(message)

            ActivityLauncherHelper.startActivitySafely(context, intent)

            val recipient = draft.contactName
            pendingDraft = null
            "Sending WhatsApp message to $recipient."
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send WhatsApp message: ${e.message}", e)
            pendingDraft = null
            "Failed to open WhatsApp. Please ensure WhatsApp is installed."
        }
    }

    private fun isPackageInstalled(pkgName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkgName, 0) != null
        } catch (_: Exception) {
            false
        }
    }

    fun cancelDraft(): String {
        return if (pendingDraft != null) {
            val name = pendingDraft?.contactName
            pendingDraft = null
            "Draft cancelled for $name. I did not send it."
        } else {
            "No active draft to cancel."
        }
    }

    fun makeCall(targetContact: String, isVideo: Boolean): String {
        val cleanContact = targetContact.trim()
        if (cleanContact.isBlank()) {
            return "Who would you like to call on WhatsApp?"
        }

        val resolution = contactResolver.resolveContact(cleanContact)
        val contact = when (resolution) {
            is ContactResolutionResult.SingleMatch -> resolution.contact
            is ContactResolutionResult.MultipleMatches -> {
                disambiguationCandidates = resolution.candidates
                val names = resolution.candidates.take(3).map { it.name }.joinToString(" and ")
                return "Which $cleanContact? I found $names."
            }
            else -> null
        }

        val callType = if (isVideo) "video call" else "voice call"

        if (contact == null || contact.phoneNumber.isBlank()) {
            return "I couldn't find a phone number for $cleanContact to initiate a WhatsApp $callType."
        }

        val rawDigits = contact.phoneNumber.replace(Regex("[^0-9]"), "")
        val cleanPhone = when {
            rawDigits.length == 10 -> "91$rawDigits"
            rawDigits.length == 11 && rawDigits.startsWith("0") -> "91${rawDigits.substring(1)}"
            else -> rawDigits
        }

        return try {
            // Arm accessibility service to click top action bar call icon & confirm prompt
            JarvisAccessibilityService.triggerWhatsAppCall(isVideo)

            val mimeType = if (isVideo) {
                "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
            } else {
                "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
            }

            val callDataUri = getWhatsAppCallDataUri(contact.id, mimeType)
            val intent = if (callDataUri != null) {
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(callDataUri, mimeType)
                    setPackage(WHATSAPP_PACKAGE)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone")).apply {
                    setPackage(WHATSAPP_PACKAGE)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }

            ActivityLauncherHelper.startActivitySafely(context, intent)
            "Starting WhatsApp $callType to ${contact.name}."
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start WhatsApp call: ${e.message}", e)
            "Could not initiate WhatsApp call."
        }
    }

    /**
     * Deletes the most recent message in a WhatsApp chat.
     * - If [targetContact] is given, opens that contact's chat first (via the WhatsApp
     *   deep link, same as sending a message) then arms the accessibility service to
     *   long-press the last bubble and pick the delete option.
     * - If [targetContact] is blank/null, it operates on whichever WhatsApp chat is
     *   already open on screen (e.g. right after sending a message and saying
     *   "delete that message").
     */
    fun deleteLastMessage(targetContact: String?, forEveryone: Boolean): String {
        val cleanContact = targetContact?.trim().orEmpty()
        val callType = if (forEveryone) "for everyone" else "for me"

        if (cleanContact.isBlank()) {
            return try {
                // Arm accessibility BEFORE bringing WhatsApp to the foreground so it's
                // ready to act on whatever chat is currently visible.
                JarvisAccessibilityService.triggerWhatsAppDelete(forEveryone)
                val launchIntent = context.packageManager.getLaunchIntentForPackage(WHATSAPP_PACKAGE)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                }
                if (launchIntent != null) {
                    ActivityLauncherHelper.startActivitySafely(context, launchIntent)
                }
                "Deleting the last message $callType."
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete WhatsApp message: ${e.message}", e)
                "Could not open WhatsApp to delete the message."
            }
        }

        val resolution = contactResolver.resolveContact(cleanContact)
        val phoneCandidate = when (resolution) {
            is ContactResolutionResult.SingleMatch -> resolution.contact.phoneNumber
            is ContactResolutionResult.MultipleMatches -> {
                disambiguationCandidates = resolution.candidates
                val names = resolution.candidates.take(3).map { it.name }.joinToString(" and ")
                return "Which $cleanContact? I found $names."
            }
            else -> null
        }

        val rawDigits = (phoneCandidate ?: cleanContact).replace(Regex("[^0-9]"), "")
        if (rawDigits.isBlank()) {
            return "I couldn't find a phone number for $cleanContact to open that chat."
        }
        val cleanPhone = when {
            rawDigits.length == 10 -> "91$rawDigits"
            rawDigits.length == 11 && rawDigits.startsWith("0") -> "91${rawDigits.substring(1)}"
            else -> rawDigits
        }

        return try {
            JarvisAccessibilityService.triggerWhatsAppDelete(forEveryone)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone")).apply {
                setPackage(WHATSAPP_PACKAGE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ActivityLauncherHelper.startActivitySafely(context, intent)
            "Deleting the last message $callType in the chat with $cleanContact."
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open chat to delete WhatsApp message: ${e.message}", e)
            "Could not open the chat with $cleanContact to delete the message."
        }
    }

    private fun getWhatsAppCallDataUri(contactId: String, mimeType: String): Uri? {
        return try {
            val cursor = context.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(ContactsContract.Data._ID),
                "${ContactsContract.Data.CONTACT_ID} = ? AND ${ContactsContract.Data.MIMETYPE} = ?",
                arrayOf(contactId, mimeType),
                null
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    val idIdx = it.getColumnIndex(ContactsContract.Data._ID)
                    if (idIdx >= 0) {
                        val rowId = it.getLong(idIdx)
                        return Uri.withAppendedPath(ContactsContract.Data.CONTENT_URI, rowId.toString())
                    }
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/whatsapp/WhatsAppAssistant.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/youtube/YouTubeApiClient.kt ===
```kotlin
package com.jarvis.assistant.automation.youtube

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Thin wrapper around the YouTube Data API v3 search endpoint.
 * Used so JARVIS can jump straight to the right video instead of
 * relying on typing into YouTube's own search box.
 */
object YouTubeApiClient {

    data class VideoResult(val videoId: String, val title: String, val channelTitle: String)

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .build()
    }

    private val networkExecutor = java.util.concurrent.Executors.newCachedThreadPool()

    /**
     * Returns the top search result for [query].
     * Tries the official YouTube Data API first if [apiKey] is provided.
     * If the API key is absent, invalid, or exhausted by daily quota (HTTP 429),
     * automatically falls back to direct search parsing which requires 0 quota.
     * Safe to call from ANY thread (automatically dispatches to background executor if on main thread).
     */
    fun searchTopVideo(apiKey: String, query: String): VideoResult? {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            return try {
                networkExecutor.submit<VideoResult?> { searchTopVideoInternal(apiKey, query) }.get(8, TimeUnit.SECONDS)
            } catch (e: Exception) {
                android.util.Log.e("YouTubeApiClient", "Background worker searchTopVideo failed: ${e.message}")
                null
            }
        }
        return searchTopVideoInternal(apiKey, query)
    }

    private fun searchTopVideoInternal(apiKey: String, query: String): VideoResult? {
        val clean = YouTubeController.cleanQuery(query).ifBlank { query.trim() }
        if (clean.isBlank()) return null

        if (apiKey.isNotBlank()) {
            val encodedQuery = URLEncoder.encode(clean, "UTF-8")
            val url = "https://www.googleapis.com/youtube/v3/search" +
                    "?part=snippet&type=video&maxResults=1&q=$encodedQuery&regionCode=IN&key=$apiKey"

            val request = Request.Builder().url(url).get().build()

            try {
                val response = client.newCall(request).execute()
                try {
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (body != null) {
                            val json = JSONObject(body)
                            val items = json.optJSONArray("items")
                            if (items != null && items.length() > 0) {
                                val item = items.getJSONObject(0)
                                val videoId = item.optJSONObject("id")?.optString("videoId") ?: ""
                                val snippet = item.optJSONObject("snippet")
                                val title = snippet?.optString("title") ?: clean
                                val channel = snippet?.optString("channelTitle") ?: ""

                                if (videoId.isNotBlank()) {
                                    android.util.Log.d("YouTubeApiClient", "Found video via Data API: $videoId ($title)")
                                    return VideoResult(videoId, title, channel)
                                }
                            }
                        }
                    } else {
                        val errorBody = response.body?.string() ?: "(no body)"
                        android.util.Log.w("YouTubeApiClient", "API search failed (HTTP ${response.code}), falling back to direct search. Error: $errorBody")
                    }
                } finally {
                    response.close()
                }
            } catch (e: Exception) {
                android.util.Log.w("YouTubeApiClient", "API request exception: ${e.message}, falling back to direct search")
            }
        }

        // Direct search fallback: 0 quota units, works even when API key is rate-limited (HTTP 429)
        return searchTopVideoDirect(clean)
    }

    /**
     * Directly parses the YouTube search results web page to extract the top videoId and title.
     * Consumes ZERO YouTube Data API quota and works reliably without API keys.
     * Safe to call from ANY thread.
     */
    fun searchTopVideoDirect(query: String): VideoResult? {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            return try {
                networkExecutor.submit<VideoResult?> { searchTopVideoDirectInternal(query) }.get(8, TimeUnit.SECONDS)
            } catch (e: Exception) {
                android.util.Log.e("YouTubeApiClient", "Background worker searchTopVideoDirect failed: ${e.message}")
                null
            }
        }
        return searchTopVideoDirectInternal(query)
    }

    private fun searchTopVideoDirectInternal(query: String): VideoResult? {
        val clean = YouTubeController.cleanQuery(query)
        if (clean.isBlank()) return null

        return try {
            val encodedQuery = URLEncoder.encode(clean, "UTF-8")
            val url = "https://www.youtube.com/results?search_query=$encodedQuery&gl=IN&hl=en"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .header("Accept-Language", "en-US,en;q=0.9,hi;q=0.8")
                .header("Cookie", "CONSENT=YES+1; PREF=tz=UTC")
                .get()
                .build()

            val response = client.newCall(request).execute()
            try {
                if (!response.isSuccessful) {
                    android.util.Log.e("YouTubeApiClient", "Direct web search failed: HTTP ${response.code}")
                    return null
                }

                val html = response.body?.string() ?: return null

                // 1. Primary: Extract videoId from videoRenderer object
                val rendererRegex = Regex("\"videoRenderer\"\\s*:\\s*\\{[^}]*\"videoId\"\\s*:\\s*\"([a-zA-Z0-9_-]{11})\"")
                var videoMatch = rendererRegex.find(html)
                var videoId = videoMatch?.groupValues?.get(1)

                // 2. Fallbacks if videoRenderer format shifted
                if (videoId.isNullOrBlank()) {
                    val genericRegex = Regex("\"videoId\"\\s*:\\s*\"([a-zA-Z0-9_-]{11})\"")
                    videoId = genericRegex.find(html)?.groupValues?.get(1)
                }
                if (videoId.isNullOrBlank()) {
                    val mobileWatchRegex = Regex("""watch\?v=([a-zA-Z0-9_-]{11})""")
                    videoId = mobileWatchRegex.find(html)?.groupValues?.get(1)
                }

                if (videoId.isNullOrBlank()) {
                    android.util.Log.w("YouTubeApiClient", "Could not extract videoId from YouTube search page")
                    return null
                }

                // 3. Extract title
                val titleRendererRegex = Regex("\"videoRenderer\"\\s*:\\s*\\{.*?\"title\"\\s*:\\s*\\{\\s*\"runs\"\\s*:\\s*\\[\\s*\\{\\s*\"text\"\\s*:\\s*\"([^\"]+)\"")
                val titleRegexFallback = Regex("\"title\":\\{\"runs\":\\[\\{\"text\":\"([^\"]+)\"\\}")
                val rawTitle = titleRendererRegex.find(html)?.groupValues?.get(1)
                    ?: titleRegexFallback.find(html)?.groupValues?.get(1)
                    ?: clean

                val title = rawTitle.replace("\\u0026", "&")
                    .replace("&amp;", "&")
                    .replace("&quot;", "\"")
                    .replace("&#39;", "'")

                android.util.Log.i("YouTubeApiClient", "Direct search matched top video: $videoId ($title)")
                VideoResult(videoId, title, "")
            } finally {
                response.close()
            }
        } catch (e: Exception) {
            android.util.Log.e("YouTubeApiClient", "Direct search failed: ${e.message}", e)
            null
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/youtube/YouTubeApiClient.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/youtube/YouTubeAutomationManager.kt ===
```kotlin
package com.jarvis.assistant.automation.youtube

import android.content.Context
import android.util.Log
import com.jarvis.assistant.data.preferences.YouTubePreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

class YouTubeAutomationManager(
    private val context: Context,
    private val preferences: YouTubePreferences
) {
    companion object {
        private const val TAG = "YouTubeManager"
        private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun playVideo(query: String): String = withContext(Dispatchers.IO) {
        val playResult = YouTubeController.searchAndPlay(context, query, preferences.youtubeApiKey)
        playResult.message ?: (if (playResult.success) "Playing on YouTube." else "Failed to play on YouTube.")
    }

    suspend fun searchYouTube(query: String): String = withContext(Dispatchers.IO) {
        val searchResult = YouTubeController.searchYouTube(context, query)
        searchResult.message ?: "Opening YouTube search."
    }

    fun scrapeFirstVideoId(query: String): String? {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://www.youtube.com/results?search_query=$encoded"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .header("Accept-Language", "en-US,en;q=0.9")
                .header("Cookie", "CONSENT=YES+1; PREF=tz=UTC")
                .build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val html = response.body?.string() ?: return null

                val queryWords = query.split(Regex("\\s+"))
                    .map { it.lowercase(Locale.ROOT) }
                    .filter { it.length > 1 && !listOf("song", "video", "gana", "track", "music", "play", "part").contains(it) }

                // Extract videoId and title from videoRenderer JSON objects
                val pattern = Regex(""""videoRenderer"\s*:\s*\{"videoId"\s*:\s*"([a-zA-Z0-9_-]{11})".*?"title"\s*:\s*\{"runs"\s*:\s*\[\{"text"\s*:\s*"([^"]+)"""")
                val matches = pattern.findAll(html).take(12).toList()

                var bestVid: String? = null
                var bestScore = -1

                for (m in matches) {
                    val vid = m.groupValues[1]
                    val title = m.groupValues[2].lowercase(Locale.ROOT)

                    var score = queryWords.count { title.contains(it) }
                    if (title.contains("1 hour") || title.contains("jukebox") || title.contains("playlist")) {
                        score -= 1
                    }
                    if (score > bestScore) {
                        bestScore = score
                        bestVid = vid
                    }
                }

                // If we found a title matching at least one keyword, return it
                if (bestScore > 0 && bestVid != null) {
                    Log.i(TAG, "Smart scraper found best match vid=$bestVid with score=$bestScore")
                    return bestVid
                }

                // If no specific keyword had highest score or query words were varied,
                // return the #1 ranked videoRenderer result directly so the video ALWAYS plays
                if (matches.isNotEmpty()) {
                    val fallbackVid = matches[0].groupValues[1]
                    Log.i(TAG, "Smart scraper using top ranked search result vid=$fallbackVid")
                    return fallbackVid
                }

                // Generic videoRenderer fallback
                val genericPattern = Regex(""""videoRenderer"\s*:\s*\{[^}]*"videoId"\s*:\s*"([a-zA-Z0-9_-]{11})"""")
                val genericMatch = genericPattern.find(html)
                if (genericMatch != null) {
                    val genericVid = genericMatch.groupValues[1]
                    Log.i(TAG, "Smart scraper matched generic videoRenderer vid=$genericVid")
                    return genericVid
                }

                Log.w(TAG, "No videoRenderer found for '$query'")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error scraping YouTube: ${e.message}")
            null
        }
    }

    // -------------------------------------------------------------
    // Channel & Player UI Actions (Subscribe / Fullscreen)
    // -------------------------------------------------------------

    fun subscribeToChannel(): String {
        com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.triggerYouTubeSubscribe()
        return "Subscribing to this channel."
    }

    fun toggleFullscreen(): String {
        com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.triggerYouTubeFullscreen()
        return "Switching to full screen."
    }

    // -------------------------------------------------------------
    // Media Playback Controls
    // -------------------------------------------------------------

    fun pausePlayback(): String {
        YouTubeController.sendMediaKey(context, "pause")
        return "Pausing playback."
    }

    fun resumePlayback(): String {
        YouTubeController.sendMediaKey(context, "play")
        return "Resuming playback."
    }

    fun nextMedia(): String {
        YouTubeController.sendMediaKey(context, "next")
        return "Skipping to next."
    }

    fun previousMedia(): String {
        YouTubeController.sendMediaKey(context, "previous")
        return "Going to previous."
    }

    suspend fun validateApiKey(apiKey: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val key = apiKey.trim()
        if (key.isBlank()) {
            return@withContext Pair(false, "API Key is empty")
        }

        try {
            val url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=test&key=$key"
            val request = Request.Builder().url(url).build()
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Pair(true, "Key is valid and active!")
                } else {
                    val code = response.code
                    Pair(false, "Validation failed with HTTP $code. Check key & quota.")
                }
            }
        } catch (e: Exception) {
            Pair(false, "Validation error: ${e.message}")
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/youtube/YouTubeAutomationManager.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/automation/youtube/YouTubeController.kt ===
```kotlin
package com.jarvis.assistant.automation.youtube

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.view.KeyEvent
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService
import com.jarvis.assistant.util.ActivityLauncherHelper

/**
 * Everything JARVIS needs to actually control YouTube:
 *  - search + jump straight to a video (deep link, skips typing in-app)
 *  - play/pause/skip via standard Android media key events (works because
 *    YouTube registers a MediaSession while a video is playing, the same
 *    mechanism headset buttons use)
 *  - volume control
 */
object YouTubeController {

    data class PlayResult(val success: Boolean, val title: String?, val message: String?)

    /**
     * Cleans noise and command words from the spoken query (e.g. "play 30 songs on YouTube" -> "30 songs").
     */
    fun cleanQuery(rawQuery: String): String {
        var clean = rawQuery.trim()
        val patterns = listOf(
            Regex("""\b(on|in|from|or|and)\s+(youtube|yt)\b""", RegexOption.IGNORE_CASE),
            Regex("""\b(youtube|yt)\s+(pe|par|mein|video|song|songs|audio)\b""", RegexOption.IGNORE_CASE),
            Regex("""\b(youtube|yt)\b""", RegexOption.IGNORE_CASE),
            Regex("""^\s*(play|open|search|listen\s+to)\b""", RegexOption.IGNORE_CASE),
            Regex("""\b(chalao|chala\s+do|karo|kar\s+do|lagao|laga\s+do|sunao|suna\s+do|bajao|baja\s+do|dikhao|dikha\s+do)\b""", RegexOption.IGNORE_CASE)
        )
        for (pattern in patterns) {
            clean = pattern.replace(clean, " ")
        }
        // Remove trailing noise words like "song", "video", "gana" if preceded by title
        clean = clean.replace(Regex("""(?i)\s+(song|songs|video|videos|gana|gane|track)$"""), "")
        val result = clean.replace(Regex("""\s+"""), " ").trim()
        return if (result.isNotBlank()) result else rawQuery.trim()
    }

    /**
     * Searches YouTube for [query] and opens the top result directly in the
     * player (via the `vnd.youtube:` deep link, which YouTube's app handles
     * natively). Falls back to zero-quota direct search, then native
     * MEDIA_PLAY_FROM_SEARCH intent, so videos ALWAYS play directly.
     */
    fun searchAndPlay(context: Context, query: String, explicitApiKey: String? = null): PlayResult {
        var cleanQ = cleanQuery(query)
        if (cleanQ.isBlank() || cleanQ.equals("video", ignoreCase = true) || cleanQ.equals("song", ignoreCase = true) ||
            cleanQ.equals("a video", ignoreCase = true) || cleanQ.equals("a song", ignoreCase = true) ||
            cleanQ.equals("music", ignoreCase = true) || cleanQ.equals("songs", ignoreCase = true)) {
            val fav = try { JarvisApp.instance.memoryManager.resolveSongQuery("my favorite song") } catch (_: Exception) { "Arijit Singh top hits" }
            cleanQ = fav.ifBlank { "Trending music" }
        }

        val apiKey = explicitApiKey ?: try {
            JarvisApp.instance.youTubePreferences.youtubeApiKey
        } catch (_: Exception) { "" }
        android.util.Log.i("YouTubeController", "searchAndPlay STRICT PLAY requested for: \"$query\" -> clean: \"$cleanQ\" (apiKey present: ${apiKey.isNotBlank()})")

        // 1. Try search via YouTubeApiClient (Data API if key present, else zero-quota direct scraper)
        var result = YouTubeApiClient.searchTopVideo(apiKey, cleanQ)
        var videoId = result?.videoId?.takeIf { it.isNotBlank() }

        // 2. Secondary scraper fallback via YouTubeAutomationManager if needed
        if (videoId == null) {
            try {
                videoId = JarvisApp.instance.youTubeAutomationManager.scrapeFirstVideoId(cleanQ)
                if (!videoId.isNullOrBlank()) {
                    android.util.Log.i("YouTubeController", "YouTubeAutomationManager scraper found videoId: $videoId")
                }
            } catch (e: Exception) {
                android.util.Log.w("YouTubeController", "Secondary scraper exception: ${e.message}")
            }
        }

        // 3. DIRECT PLAYBACK: If videoId found, deep-link straight into video playback
        if (!videoId.isNullOrBlank()) {
            val title = result?.title?.takeIf { it.isNotBlank() } ?: cleanQ
            val played = playVideoId(context, videoId)
            if (played) {
                android.util.Log.i("YouTubeController", "Successfully launched direct video playback for $videoId ($title)")
                return PlayResult(true, title, "Playing \"$title\" on YouTube.")
            }
        }

        // 4. Fallback if scraping was blocked: Open YouTube search results AND ARM ACCESSIBILITY AUTO-PLAY
        // to immediately tap and play the first video result. NEVER open search box with keyboard.
        return try {
            android.util.Log.i("YouTubeController", "Arming accessibility auto-play fallback for \"$cleanQ\"")
            com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.triggerYouTubeAutoPlay()

            val encoded = Uri.encode(cleanQ)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded&gl=IN&hl=en")).apply {
                setPackage("com.google.android.youtube")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            ActivityLauncherHelper.startActivitySafely(context, intent)
            PlayResult(true, cleanQ, "Playing \"$cleanQ\" on YouTube.")
        } catch (e: Exception) {
            android.util.Log.e("YouTubeController", "Playback fallback failed", e)
            PlayResult(false, null, "Couldn't open YouTube.")
        }
    }

    /**
     * Searches YouTube for [query] and presents the search results screen ONLY.
     * Does NOT auto-click or play the top result.
     */
    fun searchYouTube(context: Context, query: String): PlayResult {
        val cleanQ = cleanQuery(query)
        return try {
            val encoded = Uri.encode(cleanQ)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded&gl=IN&hl=en")).apply {
                setPackage("com.google.android.youtube")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val ok = ActivityLauncherHelper.startActivitySafely(context, intent)
            if (ok) {
                PlayResult(true, null, "Showing YouTube search results for \"$cleanQ\".")
            } else {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded&gl=IN&hl=en")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ActivityLauncherHelper.startActivitySafely(context, webIntent)
                PlayResult(true, null, "Showing YouTube search results for \"$cleanQ\".")
            }
        } catch (e: Exception) {
            android.util.Log.e("YouTubeController", "YouTube search intent failed", e)
            PlayResult(false, null, "Couldn't open YouTube.")
        }
    }

    /** Opens a specific video ID directly in the YouTube app's player. */
    fun playVideoId(context: Context, videoId: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$videoId")).apply {
                setPackage("com.google.android.youtube")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            val launched = ActivityLauncherHelper.startActivitySafely(context, intent)
            if (launched) {
                true
            } else {
                val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId")).apply {
                    setPackage("com.google.android.youtube")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                val launchedApp = ActivityLauncherHelper.startActivitySafely(context, appIntent)
                if (launchedApp) {
                    true
                } else {
                    val webIntent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://www.youtube.com/watch?v=$videoId")
                    ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                    ActivityLauncherHelper.startActivitySafely(context, webIntent)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("YouTubeController", "Deep link play failed, trying web fallback", e)
            try {
                val webIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/watch?v=$videoId")
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                ActivityLauncherHelper.startActivitySafely(context, webIntent)
            } catch (e2: Exception) {
                android.util.Log.e("YouTubeController", "Web fallback also failed", e2)
                false
            }
        }
    }

    /**
     * Sends a standard media key event (play/pause/next/previous/stop).
     * Controls whatever app currently holds the active media session —
     * in practice this is YouTube whenever a video is actively playing.
     */
    fun sendMediaKey(context: Context, action: String): Boolean {
        val keyCode = when (action.lowercase()) {
            "play", "pause", "play_pause", "toggle", "resume" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next", "skip", "skip_next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous", "back", "skip_previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> return false
        }
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
        return try {
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
            true
        } catch (e: Exception) {
            android.util.Log.e("YouTubeController", "Media key dispatch failed", e)
            false
        }
    }

    /** direction: "up" or "down". Adjusts the media/music volume stream. */
    fun adjustVolume(context: Context, direction: String): Boolean {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
        val adjust = when (direction.lowercase()) {
            "up", "increase", "louder" -> AudioManager.ADJUST_RAISE
            "down", "decrease", "lower", "quieter" -> AudioManager.ADJUST_LOWER
            "mute" -> AudioManager.ADJUST_MUTE
            "unmute" -> AudioManager.ADJUST_UNMUTE
            else -> return false
        }
        return try {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, adjust, AudioManager.FLAG_SHOW_UI)
            true
        } catch (e: Exception) {
            android.util.Log.e("YouTubeController", "Volume adjust failed", e)
            false
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/automation/youtube/YouTubeController.kt ===
