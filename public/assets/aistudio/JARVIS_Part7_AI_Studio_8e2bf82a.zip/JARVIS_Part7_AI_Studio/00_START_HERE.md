# JARVIS Android Assistant (Part 7) — Full Source Pack for Google AI Studio

Original project: **Tech GPTx** — https://github.com/techgptx/Playlist (License: TAMCL v1.0, attribution zaroori hai — LICENSE file PART_01 mein included hai. Attribution/credits code se mat hatana.)

## Ye kya hai
Native **Android app (Kotlin, minSdk 26, targetSdk 34)**: Gemini Live WebSocket voice assistant, offline Vosk wake-word + owner-voice verification, AccessibilityService se phone/WhatsApp/YouTube automation, screen-share vision agent, Room memory DB, WebView-based 3D orb + 17 floating overlay avatars, sound FX.

## Files (sirf text source — 252 files, 100% verified identical to original)
| File | Contents | Size | Range |
|---|---|---|---|
| PART_01_of_05.md | 52 files | ~383 KB | .editorconfig → YouTubeController.kt |
| PART_02_of_05.md | 23 files | ~373 KB | JarvisConversationService.kt → HomeFragment.kt |
| PART_03_of_05.md | 29 files | ~387 KB | MainActivity.kt → VisualTaskOrchestrator.kt |
| PART_04_of_05.md | 125 files | ~390 KB | app/src/main/res/layout/activity_api_connection.xml → README |
| PART_05_of_05.md | 23 files | ~100 KB | app/src/main/assets/model-en-us/conf/mfcc.conf → settings.html |

PART_01 mein: Gradle config, AndroidManifest, proguard, docs, `res/values`, `res/xml`, aur Kotlin ka pehla hissa. PART_02–03: baaki saari Kotlin (package `com.jarvis.assistant`). PART_04: layouts + drawables (XML). PART_05: HTML assets (hud, orb, settings, overlay-toys), unit test, Vosk config files.

## Jo files pack mein NAHI hain (binary / bahut bade)
Ye AI Studio mein paste nahi ho sakti; project mein manually daalni hongi:
- `app/src/main/assets/model-en-us/` — Vosk small US-English model (~70 MB: am/final.mdl, graph/*.fst, ivector/*) → alphacephei.com/vosk/models se **vosk-model-small-en-us** download karke is folder mein rakho (conf/ aur README pack mein hain)
- `app/src/main/assets/model-spk/` — Vosk speaker-ID model (final.ext.raw, mean.vec, transform.mat, mfcc.conf) → alphacephei.com/vosk/models se **vosk-model-spk** download karo
- `app/src/main/assets/three.min.js` — three.js (2010-2021 build, MIT) → cdnjs se download
- `app/src/main/res/drawable/ic_jarvis_logo.png` aur `res/mipmap-*/ic_launcher*.png` — icons (apne bana lo ya placeholder)
- `gradle/wrapper/gradle-wrapper.jar` — Android Studio khud generate kar leta hai

## Important: AI Studio ki limit
Google AI Studio **code generate/samajh** sakta hai, lekin **Android APK compile nahi karta** (Build mode web apps ke liye hai). Final app banane ke liye output ko **Android Studio** mein kholna padega. Aur Gemini API key app ke Settings screen mein daalni hai — code mein hardcoded nahi hai.

## AI Studio mein kaise do
1. Ek naya chat kholo, model **Gemini 2.5/3 Pro** (1M-token context) rakho.
2. Pehle ye **START_HERE** file upload/paste karo, phir PART_01…PART_05 ek ek karke (ya sab ek saath upload).
3. Neeche wala prompt paste karo.

## Ready-to-paste prompt
```
Maine tumhe ek complete Android project ka poora source diya hai (PART_01 se PART_05).
Har file "=== FILE: <path> ===" aur "=== END FILE: <path> ===" ke beech hai.

Kaam: Is project ko bilkul same waisa hi rebuild karo — same package (com.jarvis.assistant),
same folder structure, same file paths, same behavior, same UI, same features. Kuch simplify,
rename ya skip mat karna.

Rules:
1. Pehle project ka architecture summary do (modules, services, data flow, permissions).
2. Phir har file ko uske exact path ke saath output karo, ek ke baad ek, bina kuch chhode.
   Lambi files ho to "continue" bolne par wahin se aage badhna.
3. Binary assets (Vosk models, three.min.js, PNG icons, gradle-wrapper.jar) ko placeholders
   maano; unke liye alag se setup instructions do.
4. Original credits "Tech GPTx" aur TAMCL v1.0 LICENSE code, manifest aur UI mein as-is rakho.
5. Last mein Android Studio mein build/run karne ke steps do (Gradle sync, SDK, API key setup).
```
