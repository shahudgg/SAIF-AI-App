# JARVIS Android App (Part 7) — SOURCE PART 5 of 5

Is file mein neeche diye gaye project files ka poora, unchanged source hai. Har file `=== FILE: <path> ===` se shuru aur `=== END FILE ===` pe khatam hoti hai. Path exactly waise hi banana hai jaisa likha hai.

Files in this part:
- app/src/main/assets/model-en-us/conf/mfcc.conf
- app/src/main/assets/model-en-us/conf/model.conf
- app/src/main/assets/model-en-us/uuid
- app/src/main/assets/orb.html
- app/src/main/assets/overlay-toys/alien.html
- app/src/main/assets/overlay-toys/blob.html
- app/src/main/assets/overlay-toys/cat.html
- app/src/main/assets/overlay-toys/circle.html
- app/src/main/assets/overlay-toys/cloud.html
- app/src/main/assets/overlay-toys/droid.html
- app/src/main/assets/overlay-toys/drop.html
- app/src/main/assets/overlay-toys/flower.html
- app/src/main/assets/overlay-toys/gallery.html
- app/src/main/assets/overlay-toys/ghost.html
- app/src/main/assets/overlay-toys/hexagon.html
- app/src/main/assets/overlay-toys/mech.html
- app/src/main/assets/overlay-toys/pebble.html
- app/src/main/assets/overlay-toys/pill.html
- app/src/main/assets/overlay-toys/puddle.html
- app/src/main/assets/overlay-toys/square.html
- app/src/main/assets/overlay-toys/star.html
- app/src/main/assets/overlay-toys/triangle.html
- app/src/main/assets/settings/settings.html


=== FILE: app/src/main/assets/model-en-us/conf/mfcc.conf ===
```
--sample-frequency=16000
--use-energy=false
--num-mel-bins=40
--num-ceps=40
--low-freq=20
--high-freq=7600
--allow-downsample=true
```
=== END FILE: app/src/main/assets/model-en-us/conf/mfcc.conf ===


=== FILE: app/src/main/assets/model-en-us/conf/model.conf ===
```
--min-active=200
--max-active=3000
--beam=10.0
--lattice-beam=2.0
--acoustic-scale=1.0
--frame-subsampling-factor=3
--endpoint.silence-phones=1:2:3:4:5:6:7:8:9:10
--endpoint.rule2.min-trailing-silence=0.5
--endpoint.rule3.min-trailing-silence=0.75
--endpoint.rule4.min-trailing-silence=1.0
```
=== END FILE: app/src/main/assets/model-en-us/conf/model.conf ===


=== FILE: app/src/main/assets/model-en-us/uuid ===
```
e3b0c442-98fc-1c14-9afb-4c8996fb9242
```
=== END FILE: app/src/main/assets/model-en-us/uuid ===


=== FILE: app/src/main/assets/orb.html ===
```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>JARVIS Particle Orb</title>
<style>
:root{--bg:#fff;--fg:#1d2340;--sub:#6b7390;--glass:rgba(255,255,255,.72);--gb:rgba(255,255,255,.9);--chip:#4a527a;--t1:#2f6bff;--t2:#8b5cf6;--t3:#c15de0;--sh:rgba(70,80,170,.22)}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html,body{height:100%;overflow:hidden}
body{display:flex;flex-direction:column;align-items:center;background:var(--bg);color:var(--fg);font-family:Inter,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;padding:env(safe-area-inset-top) 16px env(safe-area-inset-bottom)}
header{text-align:center;padding-top:clamp(12px,3.5vh,36px);flex:none}
h1{font-size:clamp(22px,4.2vh,34px);font-weight:700;letter-spacing:.3em;padding-left:.3em;background:linear-gradient(90deg,var(--t1),var(--t2) 60%,var(--t3));-webkit-background-clip:text;background-clip:text;color:transparent}
header p{margin-top:6px;font-size:clamp(12px,1.8vh,15px);color:var(--sub);letter-spacing:.04em}
#stage{position:relative;flex:1 1 auto;min-height:0;width:100%;max-width:900px}
#stage canvas{position:absolute;inset:0;width:100%;height:100%;display:block;touch-action:none;cursor:grab}
#shadow{position:absolute;left:50%;height:22px;transform:translateX(-50%);border-radius:50%;background:radial-gradient(closest-side,var(--sh),transparent);filter:blur(4px);animation:float 5s ease-in-out infinite;pointer-events:none}
@keyframes float{50%{opacity:.6;transform:translateX(-50%) scaleX(.9)}}
#status{flex:none;display:flex;align-items:center;gap:10px;padding:9px 20px;border-radius:999px;background:var(--glass);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);box-shadow:0 4px 18px rgba(0,0,0,.12),inset 0 0 0 1px var(--gb);font-size:13px;font-weight:600;letter-spacing:.22em;color:var(--fg)}
#dot{width:8px;height:8px;border-radius:50%;background:var(--t1);animation:ping 1.6s infinite}
@keyframes ping{70%{box-shadow:0 0 0 9px transparent}100%{box-shadow:0 0 0 0 transparent}}
.panel{flex:none;display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:6px;margin-top:10px;padding:6px;border-radius:20px;background:var(--glass);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);box-shadow:0 8px 28px rgba(0,0,0,.12),inset 0 0 0 1px var(--gb);max-width:100%}
#panel{margin-bottom:clamp(12px,2.5vh,24px)}
button{font:inherit;font-size:11.5px;font-weight:600;letter-spacing:.1em;border:0;border-radius:13px;padding:10px 13px;color:var(--chip);background:transparent;cursor:pointer;transition:all .2s}
button.on{color:#fff;background:linear-gradient(135deg,var(--t1),var(--t2));box-shadow:0 4px 14px rgba(0,0,0,.25)}
#bgc{width:34px;height:34px;border:0;border-radius:50%;padding:0;background:none;cursor:pointer;overflow:hidden}
#bgc::-webkit-color-swatch-wrapper{padding:0}#bgc::-webkit-color-swatch{border:2px solid var(--gb);border-radius:50%}
#toast{position:fixed;left:50%;bottom:110px;transform:translate(-50%,20px);opacity:0;background:#1d2340;color:#fff;font-size:13px;padding:10px 16px;border-radius:12px;transition:all .3s;pointer-events:none;max-width:90vw;text-align:center}
#toast.show{opacity:1;transform:translate(-50%,0)}
/* Hide all HTML panels immediately so they never flash */
#themes,
#panel,
#status,
#toast,
#err,
header {
  display: none !important;
}

html, body {
  height: 100%;
  width: 100%;
  overflow: hidden;
  background: transparent !important;
  background-color: transparent !important;
  padding: 0 !important;
  margin: 0 !important;
  display: flex;
  justify-content: center;
  align-items: center;
}

#stage {
  position: relative;
  width: 100%;
  height: 100%;
  margin: 0 !important;
  padding: 0 !important;
}
</style>
</head>
<body class="embedded">
<div id="stage"><canvas id="c"></canvas><div id="shadow"></div></div>

<script src="three.min.js"></script>
<script>
(function(){
"use strict";
const isEmbedded = true;
if (isEmbedded) {
  document.body.classList.add("embedded");
  document.documentElement.style.background = "transparent";
  document.body.style.background = "transparent";
}

const FOV=45, VIS=3.1, ORBIT=36, COUNT=6000;
const STATES={
  idle:     {scale:1.00,speed:.35,cyan:.35,purple:.45,bright:1.00,glow:.50,ring:.15,wob:0},
  listening:{scale:1.05,speed:.85,cyan:1.00,purple:.25,bright:1.12,glow:.95,ring:.35,wob:0},
  thinking: {scale:1.00,speed:1.55,cyan:.30,purple:1.00,bright:1.05,glow:.75,ring:1.00,wob:1},
  speaking: {scale:1.04,speed:1.15,cyan:.90,purple:.90,bright:1.20,glow:1.00,ring:.45,wob:0}
};
const LABELS={idle:"READY",listening:"LISTENING",thinking:"THINKING...",speaking:"SPEAKING"};
const $=s=>document.querySelector(s);
const stage=$("#stage"),canvas=$("#c"),shadowEl=$("#shadow");

let renderer;
try{renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:"high-performance"});}
catch(e){$("#err").style.display="block";stage.style.display="none";return;}
renderer.setClearColor(0x000000,0);
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(FOV,1,.1,50);
camera.position.set(0,0,6);

/* Shared uniforms */
const U={uTime:{value:0},uAmp:{value:0},uBass:{value:0},uHigh:{value:0},uCyan:{value:.35},uPurple:{value:.45},uBright:{value:1},uPx:{value:300},uCamZ:{value:6},DEEP:{value:new THREE.Color()},BLUE:{value:new THREE.Color()},CYAN:{value:new THREE.Color()},PURP:{value:new THREE.Color()}};
const UNI="uniform float uTime,uAmp,uBass,uHigh,uCyan,uPurple,uBright,uPx,uCamZ;uniform vec3 DEEP,BLUE,CYAN,PURP;";
const PAL="";

/* ---------- 3D particle volume ---------- */
const partV=UNI+PAL+`attribute float aRnd;varying vec3 vC;varying float vA;
void main(){
 float base=length(position);vec3 d=position/base;float t=uTime;
 float n=sin(d.x*3.+t*.8+aRnd*6.)*sin(d.y*3.-t*.6)*sin(d.z*3.+t*.5);
 float r=base*(1.+n*.05+uAmp*.1*aRnd+.015*sin(t*2.+aRnd*20.));
 vec4 mv=modelViewMatrix*vec4(d*r,1.);
 float depth=smoothstep(-1.,1.,mv.z+uCamZ);          /* 0 = back, 1 = front */
 vA=mix(.22,1.,depth);
 vec3 c=mix(BLUE,CYAN,smoothstep(-.5,.9,d.y+n)*uCyan);
 c=mix(c,PURP,smoothstep(.1,.9,d.x*.6-d.y*.3+aRnd*.4)*uPurple);
 c=mix(DEEP,c,.5+.5*aRnd);
 vC=c*uBright*mix(.6,1.,depth);
 gl_PointSize=max((.009+aRnd*.017)*(1.+uAmp*.5)*uPx/(-mv.z)*mix(.85,1.2,depth),1.7);
 gl_Position=projectionMatrix*mv;}`;
const dotF="precision highp float;varying vec3 vC;varying float vA;void main(){float d=length(gl_PointCoord-.5);gl_FragColor=vec4(vC,smoothstep(.5,.05,d)*vA);}";
function buildParticles(){
  const pos=new Float32Array(COUNT*3),rnd=new Float32Array(COUNT);
  for(let i=0;i<COUNT;i++){
    const y=1-2*(i+.5)/COUNT,r=Math.sqrt(1-y*y),th=i*2.39996;
    const shell=.93+.07*Math.random();   /* outer skin + filled interior */
    pos.set([Math.cos(th)*r*shell,y*shell,Math.sin(th)*r*shell],i*3);rnd[i]=Math.random();
  }
  const g=new THREE.BufferGeometry();
  g.setAttribute("position",new THREE.BufferAttribute(pos,3));g.setAttribute("aRnd",new THREE.BufferAttribute(rnd,1));
  const p=new THREE.Points(g,new THREE.ShaderMaterial({vertexShader:partV,fragmentShader:dotF,uniforms:U,transparent:true,depthWrite:false}));
  p.frustumCulled=false;p.renderOrder=1;return p;
}

const orb=new THREE.Group();
const pointsMesh=buildParticles();
orb.add(pointsMesh);scene.add(orb);

/* ---------- Glow (outer halo only) ---------- */
let glowMat,glow,ring1,ring2,orbitPts,ptData=[];
function createGlow(){
  glowMat=new THREE.ShaderMaterial({
    vertexShader:"varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
    fragmentShader:`varying vec2 vUv;uniform float uTime,uStrength,uMix;uniform vec3 uA,uB,uC;
void main(){vec2 c=vUv-.5;float d=length(c)*2.,a=atan(c.y,c.x);
 float g=(d>.68?exp(-(d-.68)*6.5)*.75:0.)*smoothstep(1.,.78,d);
 vec3 col=mix(mix(uA,uB,.5+.5*sin(a+uTime*.4)),uC,uMix*(.5+.5*sin(a*2.-uTime*.6)));
 gl_FragColor=vec4(col,clamp(g*uStrength*.5,0.,.55));}`,
    transparent:true,depthWrite:false,depthTest:false,uniforms:{uTime:{value:0},uStrength:{value:.5},uMix:{value:.3},uA:U.BLUE,uB:U.PURP,uC:U.CYAN}});
  glow=new THREE.Mesh(new THREE.PlaneGeometry(VIS,VIS),glowMat);glow.position.z=-.05;glow.renderOrder=-2;scene.add(glow);
}
function createRing(r0,r1,segs,seed,alpha){
  const m=new THREE.Mesh(new THREE.RingGeometry(r0,r1,128,1),new THREE.ShaderMaterial({
    vertexShader:"varying vec2 vP;void main(){vP=position.xy;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
    fragmentShader:`varying vec2 vP;uniform float uAlpha,uSeed,uSegs;uniform vec3 uA,uB,uC;
void main(){float a=atan(vP.y,vP.x);
 float m=smoothstep(-.25,.35,sin(a*uSegs+uSeed))*smoothstep(-.9,-.2,sin(a+uSeed*.7));
 vec3 col=mix(mix(uC,uA,.5+.5*sin(a+uSeed)),uB,.5+.5*sin(a*2.-uSeed));
 gl_FragColor=vec4(col,m*uAlpha);}`,
    transparent:true,depthWrite:false,side:THREE.DoubleSide,uniforms:{uAlpha:{value:alpha},uSeed:{value:seed},uSegs:{value:segs},uA:U.BLUE,uB:U.PURP,uC:U.CYAN}}));
  m.renderOrder=0;scene.add(m);return m;
}
function createParticles(){
  const pos=new Float32Array(ORBIT*3),size=new Float32Array(ORBIT),alpha=new Float32Array(ORBIT),color=new Float32Array(ORBIT*3);
  const pal=[[.1,.7,1],[.2,.4,1],[.55,.3,.95]];
  for(let i=0;i<ORBIT;i++){color.set(pal[i%3],i*3);size[i]=.02+Math.random()*.045;
    ptData.push({a:Math.random()*6.283,r:1.5+Math.random()*.55,sp:(.08+Math.random()*.18)*(Math.random()<.5?-1:1),ph:Math.random()*6.283,tilt:(Math.random()-.5)*1.2,y:(Math.random()-.5)*1.1,fs:.2+Math.random()*.4});}
  const g=new THREE.BufferGeometry();
  g.setAttribute("position",new THREE.BufferAttribute(pos,3));g.setAttribute("aSize",new THREE.BufferAttribute(size,1));
  g.setAttribute("aAlpha",new THREE.BufferAttribute(alpha,1));g.setAttribute("aColor",new THREE.BufferAttribute(color,3));
  orbitPts=new THREE.Points(g,new THREE.ShaderMaterial({
    vertexShader:"attribute float aSize,aAlpha;attribute vec3 aColor;uniform float uPx;varying float vA;varying vec3 vC;void main(){vA=aAlpha;vC=aColor;vec4 mv=modelViewMatrix*vec4(position,1.);gl_PointSize=max(aSize*uPx/(-mv.z),1.);gl_Position=projectionMatrix*mv;}",
    fragmentShader:dotF,transparent:true,depthWrite:false,uniforms:{uPx:U.uPx}}));
  orbitPts.frustumCulled=false;orbitPts.renderOrder=3;scene.add(orbitPts);
}
createGlow();ring1=createRing(1.255,1.272,2,0,.5);ring2=createRing(1.38,1.388,3,2.1,.3);createParticles();

/* ---------- Themes / background ---------- */
const LIGHTPAL=[[.04,.10,.50],[.12,.32,.95],[.10,.78,1],[.55,.28,.95]];
const THEMES={
 light:{bg:"radial-gradient(120% 80% at 50% 35%,#fff 0%,#f4f6fb 60%,#eceff7 100%)",fg:"#1d2340",sub:"#6b7390",glass:"rgba(255,255,255,.72)",gb:"rgba(255,255,255,.9)",chip:"#4a527a",t:["#2f6bff","#8b5cf6","#c15de0"],add:false,sh:"rgba(70,80,170,.22)",pal:LIGHTPAL},
 dark:{bg:"radial-gradient(120% 80% at 50% 35%,#171c40 0%,#0a0d1f 60%,#04050d 100%)",fg:"#e8ecff",sub:"#8f98c8",glass:"rgba(255,255,255,.07)",gb:"rgba(255,255,255,.12)",chip:"#aab3e6",t:["#5b8cff","#9b7bff","#4fe3ff"],add:true,sh:"rgba(80,120,255,.2)",pal:[[.10,.20,.80],[.25,.50,1],[.30,.92,1],[.70,.45,1]]},
 red:{bg:"radial-gradient(120% 80% at 50% 35%,#2a0a10 0%,#120508 60%,#050203 100%)",fg:"#ffe8ea",sub:"#c98a92",glass:"rgba(255,255,255,.07)",gb:"rgba(255,120,130,.18)",chip:"#f0a8b0",t:["#ff4d5e","#ff2d6f","#ff8a5c"],add:true,sh:"rgba(255,60,80,.2)",pal:[[.55,.05,.10],[.95,.15,.20],[1,.45,.30],[1,.25,.55]]},
 sunset:{bg:"radial-gradient(120% 80% at 50% 35%,#fff6ef 0%,#ffe7e1 60%,#fbd8e8 100%)",fg:"#4a2340",sub:"#98677f",glass:"rgba(255,255,255,.6)",gb:"rgba(255,255,255,.85)",chip:"#7a4566",t:["#ff6a3d","#e83e8c","#8b5cf6"],add:false,sh:"rgba(170,70,110,.22)",pal:[[.55,.12,.45],[.95,.30,.45],[1,.55,.20],[.60,.30,.90]]}
};
let themeName="light";
function setBlend(add){
  [pointsMesh.material,orbitPts.material,glowMat,ring1.material,ring2.material].forEach(m=>{m.blending=add?THREE.AdditiveBlending:THREE.NormalBlending;m.needsUpdate=true;});
}
function applyTheme(name,custom){
  let t=THEMES[name]||THEMES.light;
  if(custom){
    const c=new THREE.Color(custom),L=.299*c.r+.587*c.g+.114*c.b,light=L>.55;
    const hsl={h:0,s:0,l:0};
    c.getHSL(hsl);

    let pal;
    if(hsl.s<.06){
      pal=light?LIGHTPAL:[[.10,.20,.80],[.25,.50,1],[.30,.92,1],[.70,.45,1]];
    }else{
      const h=hsl.h;
      const cDeep=new THREE.Color().setHSL(h,Math.min(1,Math.max(.6,hsl.s*1.2)),Math.max(.1,Math.min(.35,hsl.l*.45)));
      const cMain=new THREE.Color().setHSL(h,Math.max(.85,hsl.s),Math.max(.45,Math.min(.65,hsl.l)));
      const cAcc1=new THREE.Color().setHSL((h+.08)%1.,.95,.65);
      const cAcc2=new THREE.Color().setHSL((h-.08+1.)%1.,.95,.70);
      pal=[
        [cDeep.r,cDeep.g,cDeep.b],
        [cMain.r,cMain.g,cMain.b],
        [cAcc1.r,cAcc1.g,cAcc1.b],
        [cAcc2.r,cAcc2.g,cAcc2.b]
      ];
    }

    const baseTheme=light?THEMES.light:THEMES.dark;
    t=Object.assign({},baseTheme,{
      bg:custom,
      fg:light?"#0f172a":"#ffffff",
      sub:light?"#475569":"#cbd5e1",
      glass:light?"rgba(255,255,255,.65)":"rgba(255,255,255,.14)",
      gb:light?"rgba(255,255,255,.85)":"rgba(255,255,255,.22)",
      chip:light?"#1e293b":"#f1f5f9",
      pal:pal,
      add:!light,
      t:[
        "#"+new THREE.Color(pal[1][0],pal[1][1],pal[1][2]).getHexString(),
        "#"+new THREE.Color(pal[2][0],pal[2][1],pal[2][2]).getHexString(),
        "#"+new THREE.Color(pal[3][0],pal[3][1],pal[3][2]).getHexString()
      ]
    });
    name=null;
  }
  themeName=name||themeName;
  const r=document.documentElement.style;
  if(!isEmbedded){
    r.setProperty("--bg",t.bg);
  }else{
    r.setProperty("--bg","transparent");
    document.documentElement.style.background="transparent";
    document.body.style.background="transparent";
  }
  r.setProperty("--fg",t.fg);r.setProperty("--sub",t.sub);r.setProperty("--glass",t.glass);r.setProperty("--gb",t.gb);r.setProperty("--chip",t.chip);
  r.setProperty("--t1",t.t[0]);r.setProperty("--t2",t.t[1]);r.setProperty("--t3",t.t[2]);r.setProperty("--sh",t.sh);
  ["DEEP","BLUE","CYAN","PURP"].forEach((k,i)=>U[k].value.setRGB(t.pal[i][0],t.pal[i][1],t.pal[i][2]));
  const oc=orbitPts.geometry.attributes.aColor,cols=[t.pal[2],t.pal[1],t.pal[3]];
  for(let i=0;i<ORBIT;i++) oc.setXYZ(i,cols[i%3][0],cols[i%3][1],cols[i%3][2]);
  oc.needsUpdate=true;
  setBlend(t.add);
  document.querySelectorAll("[data-t]").forEach(b=>b.classList.toggle("on",!custom&&b.dataset.t===themeName));
}

/* ---------- State ---------- */
let state="idle";
const cur=Object.assign({},STATES.idle),tgt=Object.assign({},STATES.idle);
function setOrbState(s){
  if(!STATES[s]) return;
  state=s;Object.assign(tgt,STATES[s]);
  const lbl = $("#stext");
  if(lbl) lbl.textContent=LABELS[s] || "READY";
  document.querySelectorAll("[data-s]").forEach(b=>b.classList.toggle("on",b.dataset.s===s));
}

/* ---------- Audio (Simulated, Web mic, or External Native) ---------- */
const audio={level:0,bass:0,high:0};
let actx=null,analyser=null,micStream=null,freq=null,micOn=false;
let externalAudioTime=0;
const extAudio={level:0,bass:0,high:0};

function setExternalAudio(level, bass, high){
  const l = Math.max(0, Math.min(1, Number(level) || 0));
  extAudio.level = l;
  extAudio.bass = Math.max(0, Math.min(1, bass !== undefined && bass !== null ? Number(bass) : l));
  extAudio.high = Math.max(0, Math.min(1, high !== undefined && high !== null ? Number(high) : l));
  externalAudioTime = performance.now();
}

function toast(m){const t=$("#toast");if(!t)return;t.textContent=m;t.classList.add("show");clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.remove("show"),2600);}
function updateMicUI(){const b=$("#mic");if(b){b.classList.toggle("on",micOn);b.textContent=micOn?"MIC ON":"MIC TEST";}}
async function startAudioReactive(){
  if(micOn) return true;
  try{
    const AC=window.AudioContext||window.webkitAudioContext;
    micStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});
    actx=new AC();if(actx.state==="suspended") await actx.resume();
    analyser=actx.createAnalyser();analyser.fftSize=256;analyser.smoothingTimeConstant=.8;
    actx.createMediaStreamSource(micStream).connect(analyser);
    freq=new Uint8Array(analyser.frequencyBinCount);micOn=true;updateMicUI();return true;
  }catch(e){micOn=false;updateMicUI();toast("Microphone unavailable — using simulated audio");return false;}
}
function stopAudioReactive(){
  if(micStream) micStream.getTracks().forEach(t=>t.stop());
  if(actx&&actx.close) actx.close().catch(()=>{});
  micStream=null;actx=null;analyser=null;micOn=false;updateMicUI();
}
function simulateAudio(t){
  let l,b,h;
  if(state==="speaking"){const syl=Math.pow(Math.abs(Math.sin(t*7.3)*Math.sin(t*2.1+1)),.8),gate=Math.sin(t*.9)>-.7?1:.15;l=(.3+.45*syl)*gate;b=l*(.6+.4*Math.sin(t*5));h=l*(.5+.5*Math.sin(t*11));}
  else if(state==="listening"){l=.2+.2*Math.abs(Math.sin(t*3.1)*Math.sin(t*1.3));b=l*.8;h=l*.5;}
  else if(state==="thinking"){l=.12+.07*Math.sin(t*2.2);b=l*.7;h=l*.6;}
  else{l=.05+.03*Math.sin(t*1.1);b=l;h=l*.5;}
  return [l,b,h];
}
function readAudio(t,dt){
  let l,b,h;
  if(performance.now() - externalAudioTime < 220){
    l = extAudio.level;
    b = extAudio.bass;
    h = extAudio.high;
  } else if(micOn&&analyser){
    analyser.getByteFrequencyData(freq);
    const avg=(a,z)=>{let s=0;for(let i=a;i<z;i++)s+=freq[i];return s/((z-a)*255);};
    l=Math.min(avg(0,freq.length)*2.6,1);b=Math.min(avg(0,6)*2.2,1);h=Math.min(avg(48,110)*3,1);
  } else {
    [l,b,h]=simulateAudio(t);
  }
  const k=1-Math.exp(-dt*(l>audio.level?18:6));
  audio.level+=(l-audio.level)*k;audio.bass+=(b-audio.bass)*k;audio.high+=(h-audio.high)*k;
}

/* ---------- Drag to rotate (3D) ---------- */
let dragging=false,px=0,py=0,velX=0,velY=0;
canvas.addEventListener("pointerdown",e=>{dragging=true;px=e.clientX;py=e.clientY;canvas.setPointerCapture(e.pointerId);canvas.style.cursor="grabbing";});
canvas.addEventListener("pointermove",e=>{if(!dragging)return;velY+=(e.clientX-px)*.012;velX+=(e.clientY-py)*.012;px=e.clientX;py=e.clientY;});
const endDrag=()=>{dragging=false;canvas.style.cursor="grab";};
canvas.addEventListener("pointerup",endDrag);canvas.addEventListener("pointercancel",endDrag);

/* ---------- Update ---------- */
let time=0,flow=0,r1a=0,r2a=0,pxPerUnit=300;
function updateOrb(dt){
  const k=1-Math.exp(-dt*3.5);
  for(const key in cur) cur[key]+=(tgt[key]-cur[key])*k;
  time+=dt;flow+=dt*cur.speed;r1a+=dt*(.12+cur.ring*.6);r2a-=dt*(.08+cur.ring*.35);
  readAudio(time,dt);
  const idlePulse=Math.pow(Math.max(0,Math.sin(time*.5)),12)*.15*(1-cur.wob);
  const s=cur.scale*(1+.018*Math.sin(time*1.2)+audio.level*.07+cur.wob*.025*Math.sin(time*3.6));
  orb.scale.setScalar(s);
  orb.rotation.y+=dt*.18*(.5+cur.speed)+velY*Math.min(dt*20,1)*.5;
  orb.rotation.x=Math.max(-1.2,Math.min(1.2,orb.rotation.x+velX*Math.min(dt*20,1)*.5));
  velX*=Math.exp(-dt*5);velY*=Math.exp(-dt*5);
  if(!dragging&&Math.abs(orb.rotation.x)>.001) orb.rotation.x*=Math.exp(-dt*.6);
  U.uTime.value=flow;U.uAmp.value=audio.level+cur.wob*.25;U.uBass.value=audio.bass;U.uHigh.value=audio.high;
  U.uCyan.value=cur.cyan;U.uPurple.value=cur.purple;U.uBright.value=cur.bright+idlePulse;
  glowMat.uniforms.uTime.value=time;glowMat.uniforms.uMix.value=cur.cyan;
  glowMat.uniforms.uStrength.value=cur.glow+audio.level*.6+idlePulse*2;
  const pulse=cur.ring*.5*(.5+.5*Math.sin(time*4))+audio.bass*.8;
  ring1.rotation.z=r1a;ring2.rotation.z=r2a;
  ring1.scale.setScalar(s*(1+pulse*.03));ring2.scale.setScalar(s*(1+pulse*.02));
  ring1.material.uniforms.uAlpha.value=.4+cur.ring*.3+audio.level*.35;
  ring2.material.uniforms.uAlpha.value=.22+cur.ring*.2+audio.level*.2;
  shadowEl.style.width=Math.round(pxPerUnit*1.5*s)+"px";
}
function updateParticles(dt){
  const P=orbitPts.geometry.attributes,boost=.6+cur.speed*.8+(state==="thinking"?1.2:0);
  for(let i=0;i<ORBIT;i++){
    const d=ptData[i];d.a+=d.sp*dt*boost;
    const r=d.r+Math.sin(time*d.fs+d.ph)*.12-(state==="thinking"?.15:0)+audio.level*.1;
    const x=Math.cos(d.a)*r,z=Math.sin(d.a)*r*.6,y=d.y*.8+Math.sin(d.a*1.3+d.ph)*.18+x*d.tilt*.25;
    P.position.setXYZ(i,x,y,z);
    P.aAlpha.setX(i,Math.pow(.5+.5*Math.sin(time*d.fs*1.6+d.ph),1.5)*(.55+cur.glow*.3));
  }
  P.position.needsUpdate=true;P.aAlpha.needsUpdate=true;
}

/* ---------- Resize / loop ---------- */
function handleResize(){
  const w=Math.max(stage.clientWidth,1),h=Math.max(stage.clientHeight,1),pr=Math.min(window.devicePixelRatio,2);
  renderer.setPixelRatio(pr);renderer.setSize(w,h,false);
  camera.aspect=w/h;
  const visH=VIS/Math.min(1,w/h),tan=Math.tan(THREE.MathUtils.degToRad(FOV/2));
  camera.position.z=visH/(2*tan);U.uCamZ.value=camera.position.z;camera.updateProjectionMatrix();
  pxPerUnit=h/visH;U.uPx.value=h*pr/(2*tan);
  shadowEl.style.top=Math.round(h/2+pxPerUnit*1.2)+"px";
}
let last=performance.now();
function animate(now){
  requestAnimationFrame(animate);
  const dt=Math.min((now-last)/1000,.05);last=now;
  updateOrb(dt);updateParticles(dt);renderer.render(scene,camera);
}

document.querySelectorAll("[data-s]").forEach(b=>b.addEventListener("click",()=>setOrbState(b.dataset.s)));
document.querySelectorAll("[data-t]").forEach(b=>b.addEventListener("click",()=>applyTheme(b.dataset.t)));
const bgcInput = $("#bgc");
if(bgcInput) bgcInput.addEventListener("input",e=>applyTheme(null,e.target.value));
const micBtn = $("#mic");
if(micBtn) micBtn.addEventListener("click",()=>micOn?stopAudioReactive():startAudioReactive());
window.addEventListener("resize",handleResize);
window.addEventListener("orientationchange",()=>setTimeout(handleResize,200));
if(window.ResizeObserver) new ResizeObserver(handleResize).observe(stage);

window.JarvisOrb={
  setState:setOrbState,
  setTheme:n=>applyTheme(n),
  setBackground:hex=>{
    if(!isEmbedded) document.documentElement.style.setProperty("--bg",hex);
    applyTheme(null,hex);
  },
  setExternalAudio:setExternalAudio,
  startListening:()=>setOrbState("listening"),
  startThinking:()=>setOrbState("thinking"),
  startSpeaking:()=>setOrbState("speaking"),
  stopSpeaking:()=>setOrbState("idle"),
  startAudioReactive:startAudioReactive,
  stopAudioReactive:stopAudioReactive
};

handleResize();
applyTheme("light");
setOrbState("idle");
requestAnimationFrame(animate);
})();
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/orb.html ===


=== FILE: app/src/main/assets/overlay-toys/alien.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Alien avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "alien", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/alien.html ===


=== FILE: app/src/main/assets/overlay-toys/blob.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Blob avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "blob", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/blob.html ===


=== FILE: app/src/main/assets/overlay-toys/cat.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cat avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "cat", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/cat.html ===


=== FILE: app/src/main/assets/overlay-toys/circle.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Circle avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "circle", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/circle.html ===


=== FILE: app/src/main/assets/overlay-toys/cloud.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cloud avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "cloud", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/cloud.html ===


=== FILE: app/src/main/assets/overlay-toys/droid.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Droid avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "droid", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/droid.html ===


=== FILE: app/src/main/assets/overlay-toys/drop.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Drop avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "drop", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/drop.html ===


=== FILE: app/src/main/assets/overlay-toys/flower.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Flower avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "flower", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/flower.html ===


=== FILE: app/src/main/assets/overlay-toys/gallery.html ===
```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    * { box-sizing: border-box; }
    html, body { margin: 0; min-height: 100%; background: transparent; font-family: sans-serif; }
    body { padding: 14px 16px 18px; }
    #gallery { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
    .avatar-card {
      min-height: 104px; padding: 7px 4px 8px; border-radius: 16px;
      display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px;
      background: rgba(120, 130, 160, .10); border: 1px solid rgba(140, 150, 180, .22);
      color: var(--label, #475569); cursor: pointer; -webkit-tap-highlight-color: transparent;
    }
    .avatar-card.selected { border: 2px solid var(--accent, #8b5cf6); background: rgba(139, 92, 246, .13); box-shadow: 0 0 0 2px rgba(139, 92, 246, .10); }
    .avatar-name { font-size: 11px; line-height: 15px; text-transform: capitalize; }
    .avatar-card.selected .avatar-name::after { content: "  ✓"; color: var(--accent, #8b5cf6); font-weight: 700; }
    .avatar-image { width: 72px; height: 68px; display: block; }
  </style>
</head>
<body>
  <div id="gallery"></div>
  <script>
    const avatars = [
      ["alien", "#70d920", "#b9fb54"], ["blob", "#04bd70", "#82ffb3"], ["cat", "#f47b24", "#ffc462"],
      ["circle", "#862deb", "#bd7cff"], ["cloud", "#a9bddb", "#edf5ff"], ["droid", "#879bbd", "#d9e8ff"],
      ["drop", "#08c7c0", "#61fff0"], ["flower", "#20cf70", "#a6ff72"], ["ghost", "#d8e0ed", "#ffffff"],
      ["hexagon", "#ed4847", "#ff9990"], ["mech", "#7895c9", "#c4d7ff"], ["pebble", "#9dcf69", "#d6f49c"],
      ["pill", "#8885d8", "#d0c9ff"], ["puddle", "#ed69bb", "#ffa7dc"], ["square", "#21a9dc", "#88eaff"],
      ["star", "#f1ce48", "#fff39a"], ["triangle", "#b438d4", "#ee85ff"]
    ];
    const shapes = {
      alien: '<ellipse cx="40" cy="37" rx="23" ry="23"/>',
      blob: '<path d="M18 37C15 24 25 14 36 18c8-8 24-2 25 9 12 7 7 27-5 29-8 10-24 5-27-1-10 1-16-8-11-18z"/>',
      cat: '<path d="M18 28 16 10l16 10q8-3 16 0l16-10-2 19q6 9 2 20-6 13-24 13T20 49q-6-10-2-21z"/>',
      circle: '<circle cx="40" cy="36" r="24"/>',
      cloud: '<path d="M21 51q-12-1-12-13 0-11 13-13 4-15 20-12 12 1 14 14 15 1 15 13 0 12-14 12H22z"/>',
      droid: '<path d="M38 14V8q0-4 4-4t4 4v7q16 3 16 17v17q0 10-11 10H29q-11 0-11-10V31q0-14 20-17z"/>',
      drop: '<path d="M40 7Q34 19 22 32 9 47 22 58q16 13 33 0 13-11 0-26Q44 18 40 7z"/>',
      flower: '<path d="M40 10q10-12 17 0 4 6 0 13 14-5 17 8 2 10-10 14 11 7 4 17-6 9-18 2-2 15-14 15-11 0-12-15-13 8-19-2-6-10 5-17Q-2 39 2 29q4-11 18-6-5-14 5-19 9-5 15 6z" transform="translate(2 2) scale(.95)"/>',
      ghost: '<path d="M17 55V32q0-24 23-24t23 24v24q0 5-5 3l-6-5-7 5-7-5-7 5-7-5-6 5q-4 2-4-4z"/>',
      hexagon: '<path d="M25 12h30l17 24-17 24H25L8 36z"/>',
      mech: '<path d="M38 15V8q0-4 4-4t4 4v7q17 3 17 18v17q0 11-12 11H29Q17 61 17 50V33q0-15 21-18z"/>',
      pebble: '<path d="M15 42q-3-15 11-24 16-10 34 0 15 9 7 25-7 14-29 15-20 1-23-16z"/>',
      pill: '<rect x="12" y="19" width="56" height="36" rx="18"/>',
      puddle: '<path d="M17 48q-8-13 6-21 3-16 18-14 11-1 16 11 16 5 10 21-6 14-24 12-20 7-26-9z"/>',
      square: '<rect x="16" y="12" width="48" height="48" rx="11"/>',
      star: '<path d="m40 7 9 18 20 3-15 14 4 21-18-10-18 10 4-21L11 28l20-3z"/>',
      triangle: '<path d="M34 12q6-10 12 0l25 40q5 9-6 9H15q-11 0-6-9z"/>'
    };
    function icon(name, color, light) {
      const antenna = name === "droid" || name === "mech" ? '<path d="M42 15V7" stroke="#526784" stroke-width="3"/><circle cx="42" cy="6" r="4" fill="#91a8ce"/>' : "";
      const arms = name === "mech" || name === "droid" ? '<path d="M16 35h-5m58 0h-5" stroke="#7188ae" stroke-width="5" stroke-linecap="round"/>' : "";
      return `<svg class="avatar-image" viewBox="0 0 80 70" aria-hidden="true"><defs><linearGradient id="g-${name}" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${light}"/><stop offset="1" stop-color="${color}"/></linearGradient></defs>${antenna}${arms}<g fill="url(#g-${name})" stroke="rgba(40,50,70,.12)" stroke-width="1.2">${shapes[name]}</g><ellipse cx="32" cy="34" rx="2.4" ry="3.6" fill="#263247"/><ellipse cx="48" cy="34" rx="2.4" ry="3.6" fill="#263247"/><path d="M33 44q7 7 14 0" fill="none" stroke="#263247" stroke-width="2.4" stroke-linecap="round"/></svg>`;
    }
    const gallery = document.getElementById("gallery");
    gallery.innerHTML = avatars.map(([name, color, light]) => `<button id="avatar-${name}" class="avatar-card" type="button" onclick="window.JarvisAvatarPicker?.selectAvatar('${name}')">${icon(name, color, light)}<span class="avatar-name">${name}</span></button>`).join("");
    window.setSelectedAvatar = name => {
      document.querySelectorAll(".avatar-card").forEach(card => card.classList.remove("selected"));
      document.getElementById(`avatar-${name}`)?.classList.add("selected");
    };
    window.setGalleryTheme = (label, accent) => {
      document.documentElement.style.setProperty("--label", label);
      document.documentElement.style.setProperty("--accent", accent);
    };
    window.JarvisAvatarPicker?.pageReady();
  </script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/gallery.html ===


=== FILE: app/src/main/assets/overlay-toys/ghost.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ghost avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "ghost", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/ghost.html ===


=== FILE: app/src/main/assets/overlay-toys/hexagon.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hexagon avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "hexagon", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/hexagon.html ===


=== FILE: app/src/main/assets/overlay-toys/mech.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mech avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "mech", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/mech.html ===


=== FILE: app/src/main/assets/overlay-toys/pebble.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pebble avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "pebble", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/pebble.html ===


=== FILE: app/src/main/assets/overlay-toys/pill.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pill avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "pill", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/pill.html ===


=== FILE: app/src/main/assets/overlay-toys/puddle.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Puddle avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "puddle", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/puddle.html ===


=== FILE: app/src/main/assets/overlay-toys/square.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Square avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "square", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/square.html ===


=== FILE: app/src/main/assets/overlay-toys/star.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Star avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "star", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/star.html ===


=== FILE: app/src/main/assets/overlay-toys/triangle.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Triangle avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  // Real mouse hover ko library tak jaane se rokte hain (isTrusted = asli input).
  // Sirf hamare banaye hue (synthetic) move events pass honge.
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  // Tap hone par: pehle usi point par ek synthetic pointermove bhejo,
  // phir asli tap library tak jaata hai. Isse library khud accurately
  // tap ki taraf dekhti hai aur ghost par tap karne se hop bhi karta hai.
  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "triangle", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/overlay-toys/triangle.html ===


=== FILE: app/src/main/assets/settings/settings.html ===
```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" name="viewport"/>
<title>JARVIS Settings</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
  :root {
    --bg-void: #070103;
    --card-bg: #120407;
    --card-border: rgba(255, 23, 68, 0.22);
    --card-border-focus: #ff1744;
    --red-core: #ff1744;
    --red-glow: rgba(255, 23, 68, 0.4);
    --red-dim: rgba(255, 23, 68, 0.12);
    --red-ember: #ff5252;
    --gold: #ffb300;
    --green: #00e676;
    --text-primary: #ffffff;
    --text-secondary: #c4a1a7;
    --text-muted: #825e64;
    --line: rgba(255, 255, 255, 0.07);
  }

  /* Universal reset with forced standard sans-serif to prevent phone theme cursive corruption */
  *, *::before, *::after {
    box-sizing: border-box;
    -webkit-tap-highlight-color: transparent;
    font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
  }

  html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    min-height: 100%;
    background-color: var(--bg-void);
    color: var(--text-primary);
    -webkit-font-smoothing: antialiased;
    overflow-x: hidden;
  }

  body {
    background: radial-gradient(circle at 50% 0%, #1e0308 0%, #0d0104 40%, #070103 100%);
    background-attachment: fixed;
    padding-bottom: calc(40px + env(safe-area-inset-bottom, 0px));
  }

  /* Sticky Header */
  .top-header {
    position: sticky;
    top: 0;
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: calc(12px + env(safe-area-inset-top, 0px)) 16px 12px 16px;
    background: rgba(13, 2, 5, 0.94);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border-bottom: 1px solid var(--card-border);
  }

  .nav-back-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border-radius: 12px;
    background: var(--red-dim);
    border: 1px solid var(--card-border);
    color: var(--text-primary);
    cursor: pointer;
    transition: transform 0.15s, background-color 0.15s;
  }
  .nav-back-btn:active {
    transform: scale(0.92);
    background: rgba(255, 23, 68, 0.25);
  }
  .nav-back-btn svg {
    width: 20px;
    height: 20px;
    stroke: var(--text-primary);
  }

  .header-title {
    font-size: 1.15rem;
    font-weight: 800;
    letter-spacing: 0.06em;
    color: var(--text-primary);
    text-transform: uppercase;
  }

  .save-pill-btn {
    padding: 8px 18px;
    border-radius: 20px;
    font-size: 0.82rem;
    font-weight: 800;
    letter-spacing: 0.08em;
    color: #ffffff;
    background: linear-gradient(135deg, #ff1744 0%, #d50000 100%);
    border: 1px solid rgba(255, 255, 255, 0.25);
    box-shadow: 0 2px 12px var(--red-glow);
    cursor: pointer;
    transition: transform 0.15s, box-shadow 0.15s;
  }
  .save-pill-btn:active {
    transform: scale(0.92);
    box-shadow: 0 0 18px var(--red-core);
  }

  /* Container */
  .container {
    max-width: 600px;
    margin: 0 auto;
    padding: 16px;
  }

  /* Section Styling */
  .section {
    margin-bottom: 20px;
  }

  .section-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
    padding-left: 2px;
  }

  .section-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    border-radius: 8px;
    background: var(--red-dim);
    border: 1px solid var(--card-border);
  }
  .section-icon svg {
    width: 16px;
    height: 16px;
    stroke: var(--red-core);
  }

  .section-title {
    font-size: 0.88rem;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: var(--text-primary);
  }

  /* Cards */
  .card {
    background: var(--card-bg);
    border: 1px solid var(--card-border);
    border-radius: 16px;
    padding: 16px;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.5);
  }

  .field-label {
    display: block;
    font-size: 0.76rem;
    font-weight: 700;
    letter-spacing: 0.06em;
    color: var(--text-secondary);
    text-transform: uppercase;
    margin-bottom: 8px;
  }

  .field-hint {
    font-size: 0.74rem;
    color: var(--text-muted);
    margin-top: 6px;
    line-height: 1.4;
  }

  /* Inputs */
  .input-wrapper {
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
  }

  .text-input {
    width: 100%;
    height: 46px;
    padding: 10px 42px 10px 14px;
    border-radius: 12px;
    background: rgba(7, 1, 3, 0.85);
    border: 1px solid rgba(255, 23, 68, 0.3);
    color: var(--text-primary);
    font-size: 0.90rem;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
  }
  .text-input:focus {
    border-color: var(--red-core);
    box-shadow: 0 0 10px rgba(255, 23, 68, 0.35);
  }
  .text-input::placeholder {
    color: var(--text-muted);
  }

  .input-icon-btn {
    position: absolute;
    right: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    background: transparent;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
  }
  .input-icon-btn:active {
    color: var(--red-core);
  }
  .input-icon-btn svg {
    width: 18px;
    height: 18px;
  }

  .paste-link-row {
    display: flex;
    justify-content: flex-end;
    margin-top: 8px;
  }

  .action-text-btn {
    font-size: 0.74rem;
    font-weight: 700;
    color: var(--red-ember);
    background: none;
    border: none;
    cursor: pointer;
    letter-spacing: 0.04em;
    padding: 2px 4px;
  }
  .action-text-btn:active {
    color: #ffffff;
  }

  /* Select dropdown */
  .select-input {
    width: 100%;
    height: 46px;
    padding: 0 14px;
    border-radius: 12px;
    background: rgba(7, 1, 3, 0.85);
    border: 1px solid rgba(255, 23, 68, 0.3);
    color: var(--text-primary);
    font-size: 0.90rem;
    font-weight: 600;
    outline: none;
    cursor: pointer;
  }
  .select-input:focus {
    border-color: var(--red-core);
  }
  .select-input option {
    background: #140306;
    color: #ffffff;
  }

  /* Pills & Chips */
  .pills-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(88px, 1fr));
    gap: 8px;
    margin-top: 4px;
  }

  .pill-choice {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 10px 8px;
    border-radius: 12px;
    background: rgba(255, 23, 68, 0.05);
    border: 1px solid var(--card-border);
    color: var(--text-secondary);
    font-size: 0.80rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.15s;
    text-align: center;
  }
  .pill-choice:active {
    transform: scale(0.94);
  }
  .pill-choice.selected {
    background: linear-gradient(135deg, rgba(255, 23, 68, 0.35) 0%, rgba(213, 0, 0, 0.2) 100%);
    border-color: var(--red-core);
    color: #ffffff;
    font-weight: 800;
    box-shadow: 0 0 12px rgba(255, 23, 68, 0.4);
  }

  /* Switch row */
  .switch-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }

  .switch-label-area {
    flex: 1;
    min-width: 0;
  }

  .switch-title {
    font-size: 0.92rem;
    font-weight: 700;
    color: var(--text-primary);
  }

  .switch-subtitle {
    font-size: 0.74rem;
    color: var(--text-muted);
    margin-top: 3px;
    line-height: 1.35;
  }

  /* Toggle Switch */
  .toggle-switch {
    position: relative;
    display: inline-block;
    width: 48px;
    height: 28px;
    flex-shrink: 0;
  }
  .toggle-switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }
  .slider {
    position: absolute;
    inset: 0;
    background-color: rgba(255, 255, 255, 0.12);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 28px;
    cursor: pointer;
    transition: 0.25s;
  }
  .slider::before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background-color: #ffffff;
    border-radius: 50%;
    transition: 0.25s;
    box-shadow: 0 2px 4px rgba(0,0,0,0.4);
  }
  input:checked + .slider {
    background-color: var(--red-core);
    border-color: var(--red-core);
    box-shadow: 0 0 12px rgba(255, 23, 68, 0.6);
  }
  input:checked + .slider::before {
    transform: translateX(20px);
    background-color: #ffffff;
  }

  /* Buttons */
  .card-action-btn {
    display: block;
    width: 100%;
    padding: 12px 16px;
    border-radius: 12px;
    font-size: 0.82rem;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    text-align: center;
    border: 1px solid var(--card-border);
    cursor: pointer;
    transition: transform 0.15s, background-color 0.15s;
    margin-top: 12px;
  }
  .card-action-btn:active {
    transform: scale(0.96);
  }
  .card-action-btn.primary {
    background: linear-gradient(135deg, rgba(255, 23, 68, 0.25) 0%, rgba(180, 0, 20, 0.15) 100%);
    border-color: var(--red-core);
    color: #ffffff;
    box-shadow: 0 2px 10px rgba(255, 23, 68, 0.25);
  }
  .card-action-btn.secondary {
    background: rgba(255, 255, 255, 0.04);
    color: var(--text-secondary);
  }
  .card-action-btn.danger {
    background: rgba(255, 23, 68, 0.08);
    border-color: rgba(255, 23, 68, 0.4);
    color: var(--red-ember);
  }

  /* Permission Items */
  .perm-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 12px 0;
    border-bottom: 1px solid var(--line);
  }
  .perm-item:last-child {
    border-bottom: none;
    padding-bottom: 4px;
  }
  .perm-info {
    flex: 1;
    min-width: 0;
  }
  .perm-name {
    font-size: 0.88rem;
    font-weight: 700;
    color: var(--text-primary);
  }
  .perm-desc {
    font-size: 0.72rem;
    color: var(--text-muted);
    margin-top: 2px;
  }
  .perm-badge {
    padding: 5px 12px;
    border-radius: 8px;
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.06em;
    cursor: pointer;
    border: 1px solid transparent;
    flex-shrink: 0;
    transition: transform 0.12s;
  }
  .perm-badge:active {
    transform: scale(0.94);
  }
  .perm-badge.granted {
    background: rgba(0, 230, 118, 0.12);
    border-color: rgba(0, 230, 118, 0.35);
    color: var(--green);
    cursor: default;
  }
  .perm-badge.missing {
    background: rgba(255, 23, 68, 0.15);
    border-color: var(--red-core);
    color: #ff8a9e;
  }

  /* Creator Tag */
  .creator-card {
    text-align: center;
    padding: 18px 14px;
    border-radius: 16px;
    background: linear-gradient(180deg, rgba(255, 23, 68, 0.08) 0%, rgba(10, 2, 4, 0.7) 100%);
    border: 1px solid var(--card-border);
  }
  .creator-title {
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.12em;
    color: var(--gold);
    text-transform: uppercase;
  }
  .creator-name {
    font-size: 1.15rem;
    font-weight: 900;
    color: #ffffff;
    margin: 4px 0 2px 0;
    letter-spacing: 0.04em;
  }
  .creator-sub {
    font-size: 0.78rem;
    color: var(--text-secondary);
  }
  .yt-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 10px;
    padding: 6px 14px;
    border-radius: 20px;
    background: #ff0000;
    color: #ffffff;
    font-size: 0.76rem;
    font-weight: 800;
    letter-spacing: 0.04em;
    box-shadow: 0 2px 10px rgba(255, 0, 0, 0.4);
  }

  /* Toast notification */
  #toast {
    position: fixed;
    bottom: 24px;
    left: 50%;
    transform: translateX(-50%) translateY(100px);
    background: rgba(25, 4, 9, 0.95);
    color: #ffffff;
    border: 1px solid var(--red-core);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.8);
    padding: 10px 20px;
    border-radius: 12px;
    font-size: 0.84rem;
    font-weight: 700;
    z-index: 1000;
    opacity: 0;
    transition: transform 0.3s cubic-bezier(0.2, 0.9, 0.3, 1), opacity 0.3s;
    pointer-events: none;
    white-space: nowrap;
  }
  #toast.show {
    transform: translateX(-50%) translateY(0);
    opacity: 1;
  }
</style>
</head>
<body>

<!-- Sticky Header -->
<header class="top-header">
  <button class="nav-back-btn" onclick="goBack()" title="Back">
    <svg fill="none" stroke-width="2.5" viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg>
  </button>
  <div class="header-title">Settings</div>
  <button class="save-pill-btn" onclick="saveAll()">SAVE</button>
</header>

<div class="container">

  <!-- 1. AI Connection & Model -->
  <div class="section">
    <div class="section-header">
      <div class="section-icon">
        <svg fill="none" stroke-width="2" viewBox="0 0 24 24"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
      </div>
      <div class="section-title">Gemini Live Connection</div>
    </div>
    <div class="card">
      <label class="field-label">Gemini API Key</label>
      <div class="input-wrapper">
        <input class="text-input" id="apiKeyInput" placeholder="AIzaSy..." type="password"/>
        <button class="input-icon-btn" onclick="toggleApiKeyVisibility()" title="Show/Hide">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" id="eyeIcon">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
            <circle cx="12" cy="12" r="3"/>
          </svg>
        </button>
      </div>
      <div class="paste-link-row">
        <button class="action-text-btn" onclick="pasteApiKey()">PASTE FROM CLIPBOARD</button>
      </div>

      <div style="margin-top: 14px;">
        <label class="field-label">AI Neural Model</label>
        <select class="select-input" id="modelSelect">
          <option value="models/gemini-3.1-flash-live-preview" selected>Gemini 3.1 Flash Live (Ultra-Low Latency ~700ms - Recommended)</option>
          <option value="models/gemini-3.8-live">Gemini 3.8 Live (~900ms)</option>
          <option value="models/gemini-2.5-flash-native-audio-preview-12-2025">Gemini 2.5 Flash Native Audio Preview (12-2025)</option>
        </select>
        <div class="field-hint">Ultra-low latency streaming model with instant voice response (~700ms).</div>
      </div>
    </div>
  </div>

  <!-- 2. Voice & Persona -->
  <div class="section">
    <div class="section-header">
      <div class="section-icon">
        <svg fill="none" stroke-width="2" viewBox="0 0 24 24"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v5M8 23h8"/></svg>
      </div>
      <div class="section-title">Voice &amp; Personality</div>
    </div>
    <div class="card">
      <label class="field-label">Voice Timbre</label>
      <div class="pills-grid" id="voiceGrid">
        <div class="pill-choice" data-voice="Puck" onclick="selectVoice('Puck')">Puck</div>
        <div class="pill-choice" data-voice="Charon" onclick="selectVoice('Charon')">Charon</div>
        <div class="pill-choice" data-voice="Aoede" onclick="selectVoice('Aoede')">Aoede</div>
        <div class="pill-choice" data-voice="Fenrir" onclick="selectVoice('Fenrir')">Fenrir</div>
        <div class="pill-choice" data-voice="Kore" onclick="selectVoice('Kore')">Kore</div>
      </div>

      <div style="margin-top: 16px;">
        <label class="field-label">Personality Tone</label>
        <div class="pills-grid" id="personalityGrid" style="grid-template-columns: 1fr 1fr;">
          <div class="pill-choice" data-personality="Assistant Mode" onclick="selectPersonality('Assistant Mode')">Assistant</div>
          <div class="pill-choice" data-personality="Girlfriend Mode" onclick="selectPersonality('Girlfriend Mode')">Companion</div>
          <div class="pill-choice" data-personality="Professional Mode" onclick="selectPersonality('Professional Mode')">Executive</div>
          <div class="pill-choice" data-personality="Focus Mode" onclick="selectPersonality('Focus Mode')">Focus</div>
        </div>
      </div>

      <div style="margin-top: 16px;">
        <label class="field-label">Your Preferred Name</label>
        <div class="input-wrapper">
          <input class="text-input" id="userNameInput" placeholder="Sir / Boss / Your Name" type="text"/>
        </div>
        <div class="field-hint">JARVIS will address you respectfully using this name.</div>
      </div>
    </div>
  </div>

  <!-- 3. Spoken Language Core -->
  <div class="section">
    <div class="section-header">
      <div class="section-icon">
        <svg fill="none" stroke-width="2" viewBox="0 0 24 24"><path d="M5 8l6 6M4 14l6-6 2-3M2 5h12M7 2h1M22 22l-5-10-5 10M14 18h6"/></svg>
      </div>
      <div class="section-title">Spoken Language Core</div>
    </div>
    <div class="card">
      <label class="field-label">Conversation Language</label>
      <select class="select-input" id="languageSelect">
        <option value="Auto (All Indian Languages)">Auto (All Indian Languages - Smart Switch)</option>
        <option value="English">English (Indian / Global)</option>
        <option value="Hindi">Hindi (हिंदी)</option>
        <option value="Hinglish">Hinglish (Hindi + English)</option>
        <option value="Telugu">Telugu (తెలుగు / Telugish)</option>
        <option value="Tamil">Tamil (தமிழ் / Tanglish)</option>
        <option value="Bengali">Bengali (বাংলা)</option>
        <option value="Marathi">Marathi (मराठी)</option>
        <option value="Bhojpuri">Bhojpuri / Bihari (भोजपुरी)</option>
        <option value="Punjabi">Punjabi (ਪੰਜਾਬੀ)</option>
        <option value="Gujarati">Gujarati (ગુજરાતી)</option>
        <option value="Kannada">Kannada (ಕನ್ನಡ)</option>
        <option value="Malayalam">Malayalam (മലയാളം)</option>
        <option value="Odia">Odia (ଓଡ଼ିଆ)</option>
        <option value="Urdu">Urdu (اردو)</option>
      </select>
      <div class="field-hint">Select a specific Indian language to force JARVIS to talk ONLY in that language. Select Auto to dynamically mirror whatever language you speak.</div>
    </div>
  </div>

  <!-- 3. Biometrics & Voice Security -->
  <div class="section">
    <div class="section-header">
      <div class="section-icon">
        <svg fill="none" stroke-width="2" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      </div>
      <div class="section-title">Owner Biometrics</div>
    </div>
    <div class="card">
      <div class="switch-row">
        <div class="switch-label-area">
          <div class="switch-title">Enforce Owner Voice Biometrics</div>
          <div class="switch-subtitle">Commands and actions execute only when spoken by the verified owner.</div>
        </div>
        <label class="toggle-switch">
          <input type="checkbox" id="switchOwnerVoice"/>
          <span class="slider"></span>
        </label>
      </div>

      <button class="card-action-btn primary" onclick="openVoiceEnrollment()">TRAIN &amp; TEST OWNER VOICE</button>
    </div>
  </div>

  <!-- 4. Media & Automations -->
  <div class="section">
    <div class="section-header">
      <div class="section-icon">
        <svg fill="none" stroke-width="2" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
      </div>
      <div class="section-title">Automations</div>
    </div>
    <div class="card">
      <div class="switch-row">
        <div class="switch-label-area">
          <div class="switch-title">YouTube Automation</div>
          <div class="switch-subtitle">Seamless song search, direct playback, and media control (zero API key required).</div>
        </div>
        <label class="toggle-switch">
          <input type="checkbox" id="switchYouTube" checked/>
          <span class="slider"></span>
        </label>
      </div>

      <div class="switch-row" style="margin-top: 14px; padding-top: 14px; border-top: 1px solid var(--line);">
        <div class="switch-label-area">
          <div class="switch-title">Silent Execution Mode</div>
          <div class="switch-subtitle">Execute commands silently without talking or verbal commentary.</div>
        </div>
        <label class="toggle-switch">
          <input type="checkbox" id="switchSilentExecution"/>
          <span class="slider"></span>
        </label>
      </div>
    </div>
  </div>

  <!-- 5. Memory Core -->
  <div class="section">
    <div class="section-header">
      <div class="section-icon">
        <svg fill="none" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
      </div>
      <div class="section-title">Memory Core</div>
    </div>
    <div class="card">
      <div class="switch-title">Persistent Neural Memory</div>
      <div class="field-hint">JARVIS remembers your routine, favorite songs, contacts, and preferences across restarts.</div>
      <div style="display:flex; gap:10px; margin-top:12px;">
        <button class="card-action-btn secondary" style="margin-top:0; flex:1;" onclick="viewMemories()">VIEW MEMORIES</button>
        <button class="card-action-btn danger" style="margin-top:0; flex:1;" onclick="clearMemories()">CLEAR ALL</button>
      </div>
    </div>
  </div>

  <!-- 6. System Permissions & Health -->
  <div class="section">
    <div class="section-header">
      <div class="section-icon">
        <svg fill="none" stroke-width="2" viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
      </div>
      <div class="section-title">System Permissions</div>
    </div>
    <div class="card">
      <div class="perm-item">
        <div class="perm-info">
          <div class="perm-name">Microphone Access</div>
          <div class="perm-desc">Required for real-time voice streaming</div>
        </div>
        <div class="perm-badge missing" id="permMic" onclick="requestPerm('mic')">ALLOW</div>
      </div>

      <div class="perm-item">
        <div class="perm-info">
          <div class="perm-name">Background Service / Notifications</div>
          <div class="perm-desc">Allows JARVIS to stay active in background</div>
        </div>
        <div class="perm-badge missing" id="permNotification" onclick="requestPerm('notification')">ALLOW</div>
      </div>

      <div class="perm-item">
        <div class="perm-info">
          <div class="perm-name">Unrestricted Battery</div>
          <div class="perm-desc">Prevents system from killing background assistant</div>
        </div>
        <div class="perm-badge missing" id="permBattery" onclick="requestPerm('battery')">ALLOW</div>
      </div>

      <div class="perm-item">
        <div class="perm-info">
          <div class="perm-name">Accessibility Automation</div>
          <div class="perm-desc">Autonomous phone screen touch, type, and control</div>
        </div>
        <div class="perm-badge missing" id="permAccessibility" onclick="requestPerm('accessibility')">ALLOW</div>
      </div>

      <div class="perm-item">
        <div class="perm-info">
          <div class="perm-name">Modify System Settings</div>
          <div class="perm-desc">Adjust screen brightness and system volume</div>
        </div>
        <div class="perm-badge missing" id="permSettings" onclick="requestPerm('settings')">ALLOW</div>
      </div>

      <div class="perm-item">
        <div class="perm-info">
          <div class="perm-name">Contacts Access</div>
          <div class="perm-desc">Call and message contacts by spoken name</div>
        </div>
        <div class="perm-badge missing" id="permContacts" onclick="requestPerm('contacts')">ALLOW</div>
      </div>

      <button class="card-action-btn primary" onclick="grantAllPerms()">GRANT ALL PERMISSIONS</button>
    </div>
  </div>

  <!-- 7. Creator & Attribution -->
  <div class="section">
    <div class="creator-card">
      <div class="creator-title">Architect &amp; Lead Developer</div>
      <div class="creator-name">Rehaan Sir</div>
      <div class="creator-sub">AI Systems Engineer &amp; Tech Innovator</div>
      <div>
        <div class="yt-badge">
          <svg fill="currentColor" height="14" viewBox="0 0 24 24" width="14"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
          @TechGptX
        </div>
      </div>
      <div style="margin-top:10px; font-size:0.70rem; color:var(--text-muted); font-weight:600;">
        JARVIS Mark 85 System • Neural Core Edition
      </div>
    </div>
  </div>

</div>

<div id="toast"></div>

<script>
  let selectedVoice = "Puck";
  let selectedPersonality = "Assistant Mode";

  function showToast(msg) {
    const t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2400);
  }

  function goBack() {
    if (window.JarvisSettingsBridge && window.JarvisSettingsBridge.onBackClicked) {
      window.JarvisSettingsBridge.onBackClicked();
    }
  }

  function pasteApiKey() {
    if (window.JarvisSettingsBridge && window.JarvisSettingsBridge.pasteApiKey) {
      window.JarvisSettingsBridge.pasteApiKey();
    }
  }

  function setApiKey(key) {
    document.getElementById('apiKeyInput').value = key;
    showToast('API Key pasted');
  }

  function toggleApiKeyVisibility() {
    const input = document.getElementById('apiKeyInput');
    if (input.type === 'password') {
      input.type = 'text';
    } else {
      input.type = 'password';
    }
  }

  function selectVoice(voice) {
    selectedVoice = voice;
    document.querySelectorAll('#voiceGrid .pill-choice').forEach(el => {
      if (el.getAttribute('data-voice') === voice) {
        el.classList.add('selected');
      } else {
        el.classList.remove('selected');
      }
    });
  }

  function selectPersonality(personality) {
    selectedPersonality = personality;
    document.querySelectorAll('#personalityGrid .pill-choice').forEach(el => {
      if (el.getAttribute('data-personality') === personality) {
        el.classList.add('selected');
      } else {
        el.classList.remove('selected');
      }
    });
  }

  function openVoiceEnrollment() {
    if (window.JarvisSettingsBridge && window.JarvisSettingsBridge.openVoiceEnrollment) {
      window.JarvisSettingsBridge.openVoiceEnrollment();
    }
  }

  function viewMemories() {
    if (window.JarvisSettingsBridge && window.JarvisSettingsBridge.viewMemories) {
      window.JarvisSettingsBridge.viewMemories();
    }
  }

  function clearMemories() {
    if (window.JarvisSettingsBridge && window.JarvisSettingsBridge.clearMemories) {
      window.JarvisSettingsBridge.clearMemories();
    }
  }

  function requestPerm(type) {
    if (window.JarvisSettingsBridge && window.JarvisSettingsBridge.requestPermission) {
      window.JarvisSettingsBridge.requestPermission(type);
    }
  }

  function grantAllPerms() {
    if (window.JarvisSettingsBridge && window.JarvisSettingsBridge.requestAllPermissions) {
      window.JarvisSettingsBridge.requestAllPermissions();
    }
  }

  function setBadgeState(elementId, isGranted) {
    const el = document.getElementById(elementId);
    if (!el) return;
    if (isGranted) {
      el.textContent = "ACTIVE";
      el.className = "perm-badge granted";
    } else {
      el.textContent = "ALLOW";
      el.className = "perm-badge missing";
    }
  }

  window.updatePermissions = function(permsJsonStr) {
    try {
      const p = typeof permsJsonStr === 'string' ? JSON.parse(permsJsonStr) : permsJsonStr;
      setBadgeState('permMic', p.mic);
      setBadgeState('permNotification', p.notification);
      setBadgeState('permBattery', p.battery);
      setBadgeState('permAccessibility', p.accessibility);
      setBadgeState('permSettings', p.settings);
      setBadgeState('permContacts', p.contacts);
    } catch (e) {
      console.error("Failed to parse permissions", e);
    }
  };

  window.initSettings = function(settingsJsonStr) {
    try {
      const s = typeof settingsJsonStr === 'string' ? JSON.parse(settingsJsonStr) : settingsJsonStr;
      if (s.apiKey) document.getElementById('apiKeyInput').value = s.apiKey;
      if (s.model) document.getElementById('modelSelect').value = s.model;
      if (s.voice) selectVoice(s.voice);
      if (s.language) document.getElementById('languageSelect').value = s.language;
      if (s.personality) selectPersonality(s.personality);
      if (s.userName) document.getElementById('userNameInput').value = s.userName;
      if (s.ownerVoiceEnabled !== undefined) {
        document.getElementById('switchOwnerVoice').checked = s.ownerVoiceEnabled;
      }
      if (s.youtubeEnabled !== undefined) {
        document.getElementById('switchYouTube').checked = s.youtubeEnabled;
      }
      if (s.silentExecutionMode !== undefined) {
        document.getElementById('switchSilentExecution').checked = s.silentExecutionMode;
      }
      if (s.permissions) {
        window.updatePermissions(s.permissions);
      }
    } catch (e) {
      console.error("Failed to init settings", e);
    }
  };

  window.updateSettings = window.initSettings;

  function saveAll() {
    const payload = {
      apiKey: document.getElementById('apiKeyInput').value.trim(),
      model: document.getElementById('modelSelect').value,
      voice: selectedVoice,
      language: document.getElementById('languageSelect').value,
      personality: selectedPersonality,
      userName: document.getElementById('userNameInput').value.trim(),
      ownerVoiceEnabled: document.getElementById('switchOwnerVoice').checked,
      youtubeEnabled: document.getElementById('switchYouTube').checked,
      silentExecutionMode: document.getElementById('switchSilentExecution').checked
    };

    if (window.JarvisSettingsBridge && window.JarvisSettingsBridge.saveSettings) {
      window.JarvisSettingsBridge.saveSettings(JSON.stringify(payload));
    }
  }

  // Initial defaults
  selectVoice("Puck");
  selectPersonality("Assistant Mode");
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/settings/settings.html ===
