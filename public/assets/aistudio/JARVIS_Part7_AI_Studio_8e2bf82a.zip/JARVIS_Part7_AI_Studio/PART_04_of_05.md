# JARVIS Android App (Part 7) — SOURCE PART 4 of 5

Is file mein neeche diye gaye project files ka poora, unchanged source hai. Har file `=== FILE: <path> ===` se shuru aur `=== END FILE ===` pe khatam hoti hai. Path exactly waise hi banana hai jaisa likha hai.

Files in this part:
- app/src/main/res/layout/activity_api_connection.xml
- app/src/main/res/layout/activity_hands_free.xml
- app/src/main/res/layout/activity_main.xml
- app/src/main/res/layout/activity_memory.xml
- app/src/main/res/layout/activity_overlay_avatar.xml
- app/src/main/res/layout/activity_permission.xml
- app/src/main/res/layout/activity_persona.xml
- app/src/main/res/layout/activity_privacy_shield.xml
- app/src/main/res/layout/activity_settings.xml
- app/src/main/res/layout/activity_voice_enrollment.xml
- app/src/main/res/layout/bottom_sheet_theme_selection.xml
- app/src/main/res/layout/fragment_chat.xml
- app/src/main/res/layout/fragment_home.xml
- app/src/main/res/layout/fragment_settings.xml
- app/src/main/res/layout/fragment_updates.xml
- app/src/main/res/layout/item_chat_turn.xml
- app/src/main/res/layout/item_jarvis_chat_message.xml
- app/src/main/res/layout/item_memory.xml
- app/src/main/res/layout/item_naira_chat_message.xml
- app/src/main/res/layout/sheet_chat_history.xml
- app/src/main/res/drawable/bg_badge_action.xml
- app/src/main/res/drawable/bg_card_futuristic.xml
- app/src/main/res/drawable/bg_chip_selected.xml
- app/src/main/res/drawable/bg_chip_unselected.xml
- app/src/main/res/drawable/bg_dock_item_active.xml
- app/src/main/res/drawable/bg_dock_mic_highlight.xml
- app/src/main/res/drawable/bg_dock_mic_muted.xml
- app/src/main/res/drawable/bg_dock_mic_off.xml
- app/src/main/res/drawable/bg_input_field.xml
- app/src/main/res/drawable/bg_jarvis_action_card.xml
- app/src/main/res/drawable/bg_jarvis_avatar.xml
- app/src/main/res/drawable/bg_jarvis_bubble.xml
- app/src/main/res/drawable/bg_jarvis_card.xml
- app/src/main/res/drawable/bg_jarvis_chat_assistant.xml
- app/src/main/res/drawable/bg_jarvis_chat_user.xml
- app/src/main/res/drawable/bg_jarvis_chip.xml
- app/src/main/res/drawable/bg_jarvis_dock.xml
- app/src/main/res/drawable/bg_jarvis_error_card.xml
- app/src/main/res/drawable/bg_jarvis_icon_square.xml
- app/src/main/res/drawable/bg_jarvis_mic_center.xml
- app/src/main/res/drawable/bg_jarvis_mic_muted.xml
- app/src/main/res/drawable/bg_jarvis_orb_halo.xml
- app/src/main/res/drawable/bg_jarvis_pill_button.xml
- app/src/main/res/drawable/bg_jarvis_row_item.xml
- app/src/main/res/drawable/bg_jarvis_social_btn.xml
- app/src/main/res/drawable/bg_jarvis_status_badge.xml
- app/src/main/res/drawable/bg_jarvis_status_badge_green.xml
- app/src/main/res/drawable/bg_liquid_glow_dark_1.xml
- app/src/main/res/drawable/bg_liquid_glow_dark_2.xml
- app/src/main/res/drawable/bg_liquid_glow_dark_3.xml
- app/src/main/res/drawable/bg_liquid_glow_light_1.xml
- app/src/main/res/drawable/bg_liquid_glow_light_2.xml
- app/src/main/res/drawable/bg_liquid_glow_light_3.xml
- app/src/main/res/drawable/bg_liquid_glow_red_1.xml
- app/src/main/res/drawable/bg_liquid_glow_red_2.xml
- app/src/main/res/drawable/bg_liquid_glow_red_3.xml
- app/src/main/res/drawable/bg_liquid_glow_sunset_1.xml
- app/src/main/res/drawable/bg_liquid_glow_sunset_2.xml
- app/src/main/res/drawable/bg_liquid_glow_sunset_3.xml
- app/src/main/res/drawable/bg_naira_avatar.xml
- app/src/main/res/drawable/bg_naira_card.xml
- app/src/main/res/drawable/bg_naira_chat_assistant.xml
- app/src/main/res/drawable/bg_naira_chat_user.xml
- app/src/main/res/drawable/bg_naira_chip.xml
- app/src/main/res/drawable/bg_naira_dock.xml
- app/src/main/res/drawable/bg_naira_icon_square.xml
- app/src/main/res/drawable/bg_naira_mic_center.xml
- app/src/main/res/drawable/bg_naira_pill_button.xml
- app/src/main/res/drawable/bg_naira_social_btn.xml
- app/src/main/res/drawable/bg_test_result.xml
- app/src/main/res/drawable/bg_user_bubble.xml
- app/src/main/res/drawable/circle_cyan.xml
- app/src/main/res/drawable/ic_arrow_right.xml
- app/src/main/res/drawable/ic_back.xml
- app/src/main/res/drawable/ic_chat_bubble.xml
- app/src/main/res/drawable/ic_checklist_tasks.xml
- app/src/main/res/drawable/ic_close.xml
- app/src/main/res/drawable/ic_code_chip.xml
- app/src/main/res/drawable/ic_copy.xml
- app/src/main/res/drawable/ic_delete.xml
- app/src/main/res/drawable/ic_edit.xml
- app/src/main/res/drawable/ic_menu.xml
- app/src/main/res/drawable/ic_mic_jarvis.xml
- app/src/main/res/drawable/ic_mic_mute_jarvis.xml
- app/src/main/res/drawable/ic_mic_mute_naira.xml
- app/src/main/res/drawable/ic_mic_naira.xml
- app/src/main/res/drawable/ic_nav_bell.xml
- app/src/main/res/drawable/ic_nav_chat.xml
- app/src/main/res/drawable/ic_nav_home.xml
- app/src/main/res/drawable/ic_nav_settings.xml
- app/src/main/res/drawable/ic_plus.xml
- app/src/main/res/drawable/ic_screen_share.xml
- app/src/main/res/drawable/ic_send_up.xml
- app/src/main/res/drawable/ic_settings_apps.xml
- app/src/main/res/drawable/ic_settings_book.xml
- app/src/main/res/drawable/ic_settings_db.xml
- app/src/main/res/drawable/ic_settings_language.xml
- app/src/main/res/drawable/ic_settings_lock.xml
- app/src/main/res/drawable/ic_settings_orb.xml
- app/src/main/res/drawable/ic_settings_owner_voice.xml
- app/src/main/res/drawable/ic_settings_palette.xml
- app/src/main/res/drawable/ic_settings_plug.xml
- app/src/main/res/drawable/ic_settings_shield.xml
- app/src/main/res/drawable/ic_settings_silent.xml
- app/src/main/res/drawable/ic_settings_voice.xml
- app/src/main/res/drawable/ic_settings_wave.xml
- app/src/main/res/drawable/ic_social_instagram.xml
- app/src/main/res/drawable/ic_social_pinterest.xml
- app/src/main/res/drawable/ic_social_telegram.xml
- app/src/main/res/drawable/ic_social_youtube.xml
- app/src/main/res/drawable/ic_sparkle.xml
- app/src/main/res/drawable/ic_stack_memory.xml
- app/src/main/res/drawable/ic_tts_play.xml
- app/src/main/res/drawable/ic_user_profile.xml
- app/src/main/res/drawable/ic_verified_badge.xml
- app/src/main/res/drawable/ic_warning.xml
- app/src/main/res/drawable/ic_weather_cloud.xml
- app/src/main/res/drawable/ic_weather_moon.xml
- app/src/main/res/drawable/ic_weather_rain.xml
- app/src/main/res/drawable/ic_weather_sun.xml
- app/src/main/res/drawable/ic_weather_thunder.xml
- app/src/test/java/com/jarvis/assistant/automation/agent/AgentTaskEngineTest.kt
- app/src/main/assets/ghost-avatar-v2.html
- app/src/main/assets/hud/index.html
- app/src/main/assets/model-en-us/README


=== FILE: app/src/main/res/layout/activity_api_connection.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg">

    <!-- Top App Bar -->
    <LinearLayout
        android:id="@+id/topBar"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:gravity="center_vertical"
        android:paddingStart="16dp"
        android:paddingEnd="16dp"
        android:paddingTop="16dp"
        android:paddingBottom="12dp"
        app:layout_constraintTop_toTopOf="parent">

        <ImageButton
            android:id="@+id/btnBack"
            android:layout_width="44dp"
            android:layout_height="44dp"
            android:background="@drawable/bg_jarvis_icon_square"
            android:src="@drawable/ic_back"
            app:tint="?attr/themeTextPrimary"
            android:contentDescription="Back" />

        <LinearLayout
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:orientation="vertical"
            android:layout_marginStart="14dp">

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="API &amp; Connection"
                android:textColor="@color/text_primary"
                android:textSize="20sp"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold" />

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Gemini Live WebSocket &amp; Engine"
                android:textColor="@color/text_muted"
                android:textSize="12sp"
                android:fontFamily="sans-serif" />
        </LinearLayout>
    </LinearLayout>

    <ScrollView
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:paddingStart="20dp"
        android:paddingEnd="20dp"
        android:scrollbars="none"
        app:layout_constraintTop_toBottomOf="@id/topBar"
        app:layout_constraintBottom_toTopOf="@id/layoutBottomBar">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:paddingTop="8dp"
            android:paddingBottom="24dp">

            <!-- Card 1: Connection Status Card -->
            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="18dp"
                android:layout_marginBottom="18dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical">

                    <View
                        android:id="@+id/viewStatusDot"
                        android:layout_width="10dp"
                        android:layout_height="10dp"
                        android:background="@drawable/bg_jarvis_mic_center"
                        android:backgroundTint="@color/status_green" />

                    <TextView
                        android:id="@+id/tvLiveStatus"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="ONLINE • READY"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="13sp"
                        android:fontFamily="sans-serif-medium"
                        android:textStyle="bold"
                        android:letterSpacing="0.06"
                        android:layout_marginStart="8dp" />

                    <View
                        android:layout_width="0dp"
                        android:layout_height="1dp"
                        android:layout_weight="1" />

                    <TextView
                        android:id="@+id/tvPingResult"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Ping: -- ms"
                        android:textColor="?attr/themeAccent"
                        android:textSize="12sp"
                        android:fontFamily="sans-serif-medium"
                        android:textStyle="bold" />
                </LinearLayout>

                <TextView
                    android:id="@+id/tvEndpointSummary"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="wss://generativelanguage.googleapis.com (Gemini 2.0 Live Protocol)"
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12sp"
                    android:fontFamily="sans-serif"
                    android:layout_marginTop="8dp" />

                <com.google.android.material.button.MaterialButton
                    android:id="@+id/btnTestConnection"
                    style="@style/Widget.Material3.Button.OutlinedButton"
                    android:layout_width="wrap_content"
                    android:layout_height="40dp"
                    app:strokeColor="?attr/themeAccent"
                    app:strokeWidth="1dp"
                    android:text="Test Connection &amp; Latency"
                    android:textColor="?attr/themeAccent"
                    android:textSize="12sp"
                    android:textAllCaps="false"
                    android:fontFamily="sans-serif-medium"
                    android:layout_marginTop="12dp"
                    app:icon="@drawable/ic_settings_wave"
                    app:iconSize="16dp"
                    app:iconTint="?attr/themeAccent" />
            </LinearLayout>

            <!-- Card 2: Gemini API Key -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="API Credentials"
                android:textColor="?attr/themeTextMuted"
                android:textSize="13sp"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold"
                android:layout_marginBottom="8dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="18dp"
                android:layout_marginBottom="18dp">

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Gemini API Key"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="15sp"
                    android:fontFamily="sans-serif-medium"
                    android:textStyle="bold" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Direct authorization key from Google AI Studio"
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12sp"
                    android:fontFamily="sans-serif"
                    android:layout_marginTop="2dp" />

                <com.google.android.material.textfield.TextInputLayout
                    android:id="@+id/tilApiKey"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="12dp"
                    app:boxBackgroundMode="outline"
                    app:boxCornerRadiusTopStart="12dp"
                    app:boxCornerRadiusTopEnd="12dp"
                    app:boxCornerRadiusBottomStart="12dp"
                    app:boxCornerRadiusBottomEnd="12dp"
                    app:boxStrokeColor="?attr/themeAccent"
                    app:passwordToggleEnabled="true">

                    <com.google.android.material.textfield.TextInputEditText
                        android:id="@+id/etApiKey"
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:hint="AIzaSy..."
                        android:inputType="textPassword"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="14sp"
                        android:fontFamily="sans-serif" />
                </com.google.android.material.textfield.TextInputLayout>

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:layout_marginTop="10dp">

                    <com.google.android.material.button.MaterialButton
                        android:id="@+id/btnPasteKey"
                        style="@style/Widget.Material3.Button.OutlinedButton"
                        android:layout_width="wrap_content"
                        android:layout_height="38dp"
                        app:strokeColor="?attr/themeAccent"
                        app:strokeWidth="1dp"
                        android:text="Paste Clipboard"
                        android:textColor="?attr/themeAccent"
                        android:textSize="12sp"
                        android:textAllCaps="false"
                        android:fontFamily="sans-serif-medium"
                        android:layout_marginEnd="8dp" />

                    <com.google.android.material.button.MaterialButton
                        android:id="@+id/btnClearKey"
                        style="@style/Widget.Material3.Button.OutlinedButton"
                        android:layout_width="wrap_content"
                        android:layout_height="38dp"
                        app:strokeColor="?attr/themeTextMuted"
                        app:strokeWidth="1dp"
                        android:text="Clear"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp"
                        android:textAllCaps="false"
                        android:fontFamily="sans-serif-medium" />
                </LinearLayout>
            </LinearLayout>

            <!-- Card 3: AI Model Engine -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Model Engine"
                android:textColor="?attr/themeTextMuted"
                android:textSize="13sp"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold"
                android:layout_marginBottom="8dp" />

            <RadioGroup
                android:id="@+id/rgModelGroup"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:background="@drawable/bg_jarvis_card"
                android:padding="14dp"
                android:layout_marginBottom="18dp">

                <RadioButton
                    android:id="@+id/rbModelFlashThinking"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="gemini-3.1-flash (Ultra-Low Latency Live • ~700ms Recommended)"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="13sp"
                    android:fontFamily="sans-serif-medium"
                    android:paddingTop="8dp"
                    android:paddingBottom="8dp" />

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <RadioButton
                    android:id="@+id/rbModelFlash20"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="gemini-3.8-live (Flagship Conversational Intelligence)"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="13sp"
                    android:fontFamily="sans-serif-medium"
                    android:paddingTop="8dp"
                    android:paddingBottom="8dp" />



                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <RadioButton
                    android:id="@+id/rbModelFlash15"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="gemini-3.1-flash (Balanced Multi-Model Autonomous Agent)"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="13sp"
                    android:fontFamily="sans-serif-medium"
                    android:paddingTop="8dp"
                    android:paddingBottom="8dp" />
            </RadioGroup>

            <!-- Card 4: Custom WebSocket Endpoint -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Custom Endpoint (Optional)"
                android:textColor="?attr/themeTextMuted"
                android:textSize="13sp"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold"
                android:layout_marginBottom="8dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="18dp"
                android:layout_marginBottom="24dp">

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Custom Gateway URL"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="15sp"
                    android:fontFamily="sans-serif-medium"
                    android:textStyle="bold" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Override standard Google endpoint with your proxy or relay (leave empty for default)"
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12sp"
                    android:fontFamily="sans-serif"
                    android:layout_marginTop="2dp" />

                <com.google.android.material.textfield.TextInputLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="12dp"
                    app:boxBackgroundMode="outline"
                    app:boxCornerRadiusTopStart="12dp"
                    app:boxCornerRadiusTopEnd="12dp"
                    app:boxCornerRadiusBottomStart="12dp"
                    app:boxCornerRadiusBottomEnd="12dp"
                    app:boxStrokeColor="?attr/themeAccent">

                    <com.google.android.material.textfield.TextInputEditText
                        android:id="@+id/etCustomEndpoint"
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:hint="wss://your-gateway.com/live"
                        android:inputType="textUri"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="14sp"
                        android:fontFamily="sans-serif" />
                </com.google.android.material.textfield.TextInputLayout>
            </LinearLayout>

        </LinearLayout>
    </ScrollView>

    <!-- Bottom Save Action Bar -->
    <LinearLayout
        android:id="@+id/layoutBottomBar"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:paddingStart="20dp"
        android:paddingEnd="20dp"
        android:paddingTop="12dp"
        android:paddingBottom="20dp"
        android:background="?attr/themeBg"
        app:layout_constraintBottom_toBottomOf="parent">

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btnSaveConnection"
            android:layout_width="match_parent"
            android:layout_height="54dp"
            android:background="@drawable/bg_jarvis_pill_button"
            app:backgroundTint="@null"
            android:text="Save &amp; Apply Configuration"
            android:textColor="#FFFFFF"
            android:textSize="15sp"
            android:textStyle="bold"
            android:fontFamily="sans-serif-medium"
            android:textAllCaps="false" />
    </LinearLayout>

</androidx.constraintlayout.widget.ConstraintLayout>
```
=== END FILE: app/src/main/res/layout/activity_api_connection.xml ===


=== FILE: app/src/main/res/layout/activity_hands_free.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.coordinatorlayout.widget.CoordinatorLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg">

    <androidx.core.widget.NestedScrollView
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:fillViewport="true">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:paddingStart="20dp"
            android:paddingEnd="20dp"
            android:paddingTop="36dp"
            android:paddingBottom="48dp">

            <!-- Top Header Bar -->
            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:layout_marginBottom="24dp">

                <ImageButton
                    android:id="@+id/btnBack"
                    android:layout_width="44dp"
                    android:layout_height="44dp"
                    android:background="@drawable/bg_jarvis_icon_square"
                    android:src="@drawable/ic_back"
                    app:tint="?attr/themeTextPrimary"
                    android:contentDescription="Back" />

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Hands-Free &amp; App Control"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="19sp"
                        android:textStyle="bold"
                        android:fontFamily="sans-serif-medium" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Autonomous Voice Automation Guide"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp" />
                </LinearLayout>
            </LinearLayout>

            <!-- Hero Branding Banner -->
            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:gravity="center_horizontal"
                android:background="@drawable/bg_jarvis_card"
                android:padding="22dp"
                android:layout_marginBottom="20dp">

                <ImageView
                    android:layout_width="140dp"
                    android:layout_height="48dp"
                    android:src="@drawable/ic_jarvis_logo"
                    android:scaleType="fitCenter"
                    android:contentDescription="Jarvis Logo" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="12dp"
                    android:text="Autonomous Device Control"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="16sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="3dp"
                    android:gravity="center"
                    android:text="Control WhatsApp, YouTube, and phone settings completely hands-free with your voice."
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12.5sp"
                    android:lineSpacingExtra="2dp" />

                <!-- Live Status Chip -->
                <LinearLayout
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:background="@drawable/bg_jarvis_status_badge"
                    android:paddingHorizontal="14dp"
                    android:paddingVertical="6dp"
                    android:layout_marginTop="14dp">

                    <View
                        android:id="@+id/dotAccessibilityStatus"
                        android:layout_width="8dp"
                        android:layout_height="8dp"
                        android:background="@drawable/bg_jarvis_mic_center"
                        android:backgroundTint="@color/status_green" />

                    <TextView
                        android:id="@+id/tvAccessibilityStatus"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="HANDS-FREE SERVICE: ACTIVE"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="11sp"
                        android:textStyle="bold"
                        android:letterSpacing="0.08"
                        android:layout_marginStart="8dp" />
                </LinearLayout>

                <!-- Direct Action Button -->
                <com.google.android.material.button.MaterialButton
                    android:id="@+id/btnToggleAccessibility"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:minHeight="48dp"
                    android:layout_marginTop="16dp"
                    android:text="Configure Accessibility Service"
                    android:textColor="#FFFFFF"
                    android:textStyle="bold"
                    android:textSize="14sp"
                    android:textAllCaps="false"
                    app:cornerRadius="14dp"
                    app:backgroundTint="?attr/themeAccent" />
            </LinearLayout>

            <!-- SECTION 1: HOW JARVIS WORKS (NON-DEVELOPER GUIDE) -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="HOW IT WORKS (EASY GUIDE)"
                android:textColor="?attr/themeAccent"
                android:textSize="11sp"
                android:letterSpacing="0.10"
                android:textStyle="bold"
                android:fontFamily="sans-serif-medium"
                android:layout_marginBottom="10dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="20dp"
                android:layout_marginBottom="20dp">

                <!-- Step 1: Hold the Mic Button -->
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="top"
                    android:layout_marginBottom="16dp">

                    <FrameLayout
                        android:layout_width="38dp"
                        android:layout_height="38dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="20dp"
                            android:layout_height="20dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_mic_jarvis"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Mic" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="1. Hold the Microphone Button"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginTop="2dp"
                            android:text="Hold the center mic button or tap the 3D Orb to speak. You don&apos;t need to type or navigate manually."
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12.5sp"
                            android:lineSpacingExtra="2dp" />
                    </LinearLayout>
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder"
                    android:layout_marginBottom="16dp" />

                <!-- Step 2: Ultra-Fast AI Neural Brain -->
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="top"
                    android:layout_marginBottom="16dp">

                    <FrameLayout
                        android:layout_width="38dp"
                        android:layout_height="38dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="20dp"
                            android:layout_height="20dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_stack_memory"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Brain" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="2. Gemini 3.8 Live Brain"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginTop="2dp"
                            android:text="Your speech is processed in real time using Google&apos;s latest Gemini 3.8 Live model. It understands context in Hindi, Urdu, English, Hinglish, and regional languages."
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12.5sp"
                            android:lineSpacingExtra="2dp" />
                    </LinearLayout>
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder"
                    android:layout_marginBottom="16dp" />

                <!-- Step 3: Autonomous Device Execution -->
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="top">

                    <FrameLayout
                        android:layout_width="38dp"
                        android:layout_height="38dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="20dp"
                            android:layout_height="20dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_apps"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Automation" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="3. Digital Hands on Your Mobile"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginTop="2dp"
                            android:text="Jarvis uses your phone&apos;s built-in Android accessibility service to type messages, tap send, search YouTube, and adjust settings just like your own hands."
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12.5sp"
                            android:lineSpacingExtra="2dp" />
                    </LinearLayout>
                </LinearLayout>

            </LinearLayout>

            <!-- SECTION 2: PERMISSIONS & ACCESSIBILITY INSTRUCTIONS -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="HOW TO ALLOW ALL PERMISSIONS"
                android:textColor="?attr/themeAccent"
                android:textSize="11sp"
                android:letterSpacing="0.10"
                android:textStyle="bold"
                android:fontFamily="sans-serif-medium"
                android:layout_marginBottom="10dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="20dp"
                android:layout_marginBottom="20dp">

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="Why does Jarvis need Accessibility Permission?"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="15sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium" />

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="6dp"
                    android:text="Android protects other apps from being controlled. For Jarvis to send WhatsApp messages or open YouTube videos on your command, you must grant the Jarvis Accessibility Service permission."
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="13sp"
                    android:lineSpacingExtra="3dp" />

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="vertical"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:padding="14dp"
                    android:layout_marginTop="14dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Quick Steps to Enable:"
                        android:textColor="?attr/themeAccent"
                        android:textSize="12.5sp"
                        android:textStyle="bold" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="6dp"
                        android:text="1. Tap the 'Open Accessibility Settings' button below.\n2. Tap 'Downloaded Apps' or 'Installed Services'.\n3. Tap 'Jarvis Accessibility Service'.\n4. Turn the switch ON and tap 'Allow'."
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="12.5sp"
                        android:lineSpacingExtra="4dp" />
                </LinearLayout>

                <com.google.android.material.button.MaterialButton
                    android:id="@+id/btnOpenAccessibilitySettings"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:minHeight="48dp"
                    android:layout_marginTop="14dp"
                    android:text="Open Accessibility Settings"
                    android:textColor="#FFFFFF"
                    android:textStyle="bold"
                    android:textSize="14sp"
                    android:textAllCaps="false"
                    app:cornerRadius="12dp"
                    app:backgroundTint="?attr/themeAccent" />

                <com.google.android.material.button.MaterialButton
                    android:id="@+id/btnOpenAllPermissions"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:minHeight="48dp"
                    android:layout_marginTop="8dp"
                    android:text="Grant All System Authorizations"
                    android:textColor="?attr/themeAccent"
                    android:textStyle="bold"
                    android:textSize="14sp"
                    android:textAllCaps="false"
                    style="@style/Widget.MaterialComponents.Button.OutlinedButton"
                    app:cornerRadius="12dp"
                    app:strokeColor="?attr/themeAccent" />

            </LinearLayout>

            <!-- SECTION 3: VOICE COMMANDS CATALOG -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="VOICE COMMANDS CATALOG"
                android:textColor="?attr/themeAccent"
                android:textSize="11sp"
                android:letterSpacing="0.10"
                android:textStyle="bold"
                android:fontFamily="sans-serif-medium"
                android:layout_marginBottom="10dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="18dp"
                android:layout_marginBottom="20dp">

                <!-- WhatsApp Commands -->
                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="💬 WhatsApp Hands-Free Commands"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="14sp"
                    android:textStyle="bold" />

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="4dp"
                    android:text="• &quot;Send WhatsApp to Rahul saying I will reach in 10 minutes&quot;\n• &quot;Call Mom on WhatsApp&quot;\n• &quot;Make a video call to Priya on WhatsApp&quot;\n• &quot;Delete last message for everyone&quot;"
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12.5sp"
                    android:lineSpacingExtra="3dp" />

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder"
                    android:layout_marginVertical="12dp" />

                <!-- YouTube Commands -->
                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="🎬 YouTube &amp; Music Commands"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="14sp"
                    android:textStyle="bold" />

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="4dp"
                    android:text="• &quot;Play Arijit Singh songs on YouTube&quot;\n• &quot;Search Iron Man highlights on YouTube&quot;\n• &quot;Pause YouTube video&quot; / &quot;Play next song&quot;\n• &quot;Make video fullscreen&quot;"
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12.5sp"
                    android:lineSpacingExtra="3dp" />

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder"
                    android:layout_marginVertical="12dp" />

                <!-- Phone Hardware Commands -->
                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="📱 Phone Hardware &amp; Settings"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="14sp"
                    android:textStyle="bold" />

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="4dp"
                    android:text="• &quot;Turn on flashlight / torch&quot;\n• &quot;Increase volume to 80%&quot; / &quot;Mute sound&quot;\n• &quot;Set brightness to 50%&quot;\n• &quot;Turn on Bluetooth&quot; / &quot;Open Instagram&quot;"
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12.5sp"
                    android:lineSpacingExtra="3dp" />

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder"
                    android:layout_marginVertical="12dp" />

                <!-- Intelligence & Memory Commands -->
                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="🧠 Neural Memory &amp; Daily Life"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="14sp"
                    android:textStyle="bold" />

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="4dp"
                    android:text="• &quot;Remember that my passport is in the blue bag&quot;\n• &quot;Where is my passport?&quot;\n• &quot;What is the weather outside?&quot;\n• &quot;Good morning Jarvis, what is my schedule today?&quot;"
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12.5sp"
                    android:lineSpacingExtra="3dp" />

            </LinearLayout>

            <!-- SECTION 4: ACTIVE AI MODEL & RELEASE API -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="AI MODEL &amp; RELEASE API"
                android:textColor="?attr/themeAccent"
                android:textSize="11sp"
                android:letterSpacing="0.10"
                android:textStyle="bold"
                android:fontFamily="sans-serif-medium"
                android:layout_marginBottom="10dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="20dp"
                android:layout_marginBottom="24dp">

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Best Selected Model: Gemini 3.8 Live"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="15sp"
                    android:textStyle="bold" />

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="4dp"
                    android:text="The app comes pre-configured with Google's gemini-3.8-live model and embedded release API key. Ultra-low latency voice streaming with immediate responses."
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12.5sp"
                    android:lineSpacingExtra="2dp" />

                <com.google.android.material.button.MaterialButton
                    android:id="@+id/btnConfigureApi"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:minHeight="48dp"
                    android:layout_marginTop="14dp"
                    android:text="Manage API Key &amp; Models"
                    android:textColor="?attr/themeAccent"
                    android:textStyle="bold"
                    android:textSize="14sp"
                    android:textAllCaps="false"
                    style="@style/Widget.MaterialComponents.Button.OutlinedButton"
                    app:cornerRadius="12dp"
                    app:strokeColor="?attr/themeAccent" />
            </LinearLayout>

            <!-- SECTION 5: COMMUNITY & SOURCE CODE -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="COMMUNITY &amp; DISCUSSION GROUPS"
                android:textColor="?attr/themeAccent"
                android:textSize="11sp"
                android:letterSpacing="0.10"
                android:textStyle="bold"
                android:fontFamily="sans-serif-medium"
                android:layout_marginBottom="10dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:paddingStart="16dp"
                android:paddingEnd="16dp"
                android:paddingTop="6dp"
                android:paddingBottom="6dp"
                android:layout_marginBottom="24dp">

                <!-- Official Telegram Channel -->
                <LinearLayout
                    android:id="@+id/btnHandsFreeOfficialTelegram"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingVertical="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <ImageView
                        android:layout_width="36dp"
                        android:layout_height="36dp"
                        android:src="@drawable/ic_social_telegram"
                        app:tint="?attr/themeAccent"
                        android:contentDescription="Official Telegram" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Official Telegram Channel"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Get announcements &amp; new release updates"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Discussion Group Telegram -->
                <LinearLayout
                    android:id="@+id/btnHandsFreeDiscussion"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingVertical="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <ImageView
                        android:layout_width="36dp"
                        android:layout_height="36dp"
                        android:src="@drawable/ic_social_telegram"
                        app:tint="?attr/themeAccent"
                        android:contentDescription="Discussion Group" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Telegram Discussion Group"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Source code talk &amp; community discussions"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Instagram -->
                <LinearLayout
                    android:id="@+id/btnHandsFreeInstagram"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingVertical="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <ImageView
                        android:layout_width="36dp"
                        android:layout_height="36dp"
                        android:src="@drawable/ic_social_instagram"
                        app:tint="?attr/themeAccent"
                        android:contentDescription="Instagram" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Follow on Instagram"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="@techgptx.ai"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>
            </LinearLayout>

            <!-- Community Links -->
            <TextView
                android:id="@+id/tvFooterHandsFree"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:gravity="center"
                android:text="JARVIS INTELLIGENCE OS • TECHGPT X\nAutonomous Hands-Free Architecture"
                android:textColor="?attr/themeTextMuted"
                android:textSize="11.5sp"
                android:lineSpacingExtra="3dp" />

        </LinearLayout>
    </androidx.core.widget.NestedScrollView>

</androidx.coordinatorlayout.widget.CoordinatorLayout>
```
=== END FILE: app/src/main/res/layout/activity_hands_free.xml ===


=== FILE: app/src/main/res/layout/activity_main.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:id="@+id/rootMainLayout"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:clipChildren="false"
    android:clipToPadding="false"
    android:background="?attr/themeBg">

    <!-- Fragment Container for Home, Chat, Settings, and Updates -->
    <FrameLayout
        android:id="@+id/fragmentContainer"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />

    <!-- Sleek Liquid Glass Floating Navigation Capsule -->
    <LinearLayout
        android:id="@+id/bottomDock"
        android:layout_width="match_parent"
        android:layout_height="64dp"
        android:layout_marginStart="14dp"
        android:layout_marginEnd="14dp"
        android:layout_marginBottom="16dp"
        android:background="@drawable/bg_jarvis_dock"
        android:elevation="12dp"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:orientation="horizontal"
        android:paddingStart="6dp"
        android:paddingEnd="6dp"
        android:paddingTop="3dp"
        android:paddingBottom="3dp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <!-- Tab 1: Home -->
        <FrameLayout
            android:id="@+id/tabHome"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:clickable="true"
            android:focusable="true">

            <LinearLayout
                android:id="@+id/pillTabHome"
                android:layout_width="wrap_content"
                android:layout_height="match_parent"
                android:layout_gravity="center"
                android:minWidth="52dp"
                android:orientation="vertical"
                android:gravity="center"
                android:paddingHorizontal="10dp"
                android:paddingVertical="3dp"
                android:background="@drawable/bg_dock_item_active">

                <ImageView
                    android:id="@+id/ivTabHome"
                    android:layout_width="22dp"
                    android:layout_height="22dp"
                    android:src="@drawable/ic_nav_home"
                    app:tint="?attr/themeTextPrimary"
                    android:contentDescription="Home" />

                <TextView
                    android:id="@+id/tvTabHome"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Home"
                    android:textSize="10sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium"
                    android:includeFontPadding="false"
                    android:layout_marginTop="2dp"
                    android:textColor="?attr/themeTextPrimary" />
            </LinearLayout>
        </FrameLayout>

        <!-- Tab 2: Chat -->
        <FrameLayout
            android:id="@+id/tabChat"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:clickable="true"
            android:focusable="true">

            <LinearLayout
                android:id="@+id/pillTabChat"
                android:layout_width="wrap_content"
                android:layout_height="match_parent"
                android:layout_gravity="center"
                android:minWidth="52dp"
                android:orientation="vertical"
                android:gravity="center"
                android:paddingHorizontal="10dp"
                android:paddingVertical="3dp">

                <ImageView
                    android:id="@+id/ivTabChat"
                    android:layout_width="22dp"
                    android:layout_height="22dp"
                    android:src="@drawable/ic_nav_chat"
                    app:tint="?attr/themeTextMuted"
                    android:contentDescription="Chat" />

                <TextView
                    android:id="@+id/tvTabChat"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Chat"
                    android:textSize="10sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium"
                    android:includeFontPadding="false"
                    android:layout_marginTop="2dp"
                    android:textColor="?attr/themeTextMuted" />
            </LinearLayout>
        </FrameLayout>

        <!-- Tab 3: Voice / Mic (Hero Highlighted Action) -->
        <FrameLayout
            android:id="@+id/tabMic"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:clipChildren="false"
            android:clipToPadding="false"
            android:clickable="true"
            android:focusable="true">

            <LinearLayout
                android:id="@+id/pillTabMic"
                android:layout_width="56dp"
                android:layout_height="56dp"
                android:layout_gravity="center"
                android:translationY="-8dp"
                android:orientation="vertical"
                android:gravity="center"
                android:background="@drawable/bg_dock_mic_highlight">

                <ImageView
                    android:id="@+id/ivTabMic"
                    android:layout_width="28dp"
                    android:layout_height="28dp"
                    android:src="@drawable/ic_mic_jarvis"
                    app:tint="#FFFFFF"
                    android:contentDescription="Voice" />

                <TextView
                    android:id="@+id/tvTabMic"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Voice"
                    android:textSize="10sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium"
                    android:includeFontPadding="false"
                    android:textColor="#FFFFFF"
                    android:visibility="gone" />
            </LinearLayout>
        </FrameLayout>

        <!-- Tab 4: Settings -->
        <FrameLayout
            android:id="@+id/tabSettings"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:clickable="true"
            android:focusable="true">

            <LinearLayout
                android:id="@+id/pillTabSettings"
                android:layout_width="wrap_content"
                android:layout_height="match_parent"
                android:layout_gravity="center"
                android:minWidth="52dp"
                android:orientation="vertical"
                android:gravity="center"
                android:paddingHorizontal="10dp"
                android:paddingVertical="3dp">

                <ImageView
                    android:id="@+id/ivTabSettings"
                    android:layout_width="22dp"
                    android:layout_height="22dp"
                    android:src="@drawable/ic_nav_settings"
                    app:tint="?attr/themeTextMuted"
                    android:contentDescription="Settings" />

                <TextView
                    android:id="@+id/tvTabSettings"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Settings"
                    android:textSize="10sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium"
                    android:includeFontPadding="false"
                    android:layout_marginTop="2dp"
                    android:textColor="?attr/themeTextMuted" />
            </LinearLayout>
        </FrameLayout>

        <!-- Tab 5: Updates -->
        <FrameLayout
            android:id="@+id/tabUpdates"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:clickable="true"
            android:focusable="true">

            <LinearLayout
                android:id="@+id/pillTabUpdates"
                android:layout_width="wrap_content"
                android:layout_height="match_parent"
                android:layout_gravity="center"
                android:minWidth="52dp"
                android:orientation="vertical"
                android:gravity="center"
                android:paddingHorizontal="10dp"
                android:paddingVertical="3dp">

                <FrameLayout
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content">

                    <ImageView
                        android:id="@+id/ivTabUpdates"
                        android:layout_width="22dp"
                        android:layout_height="22dp"
                        android:src="@drawable/ic_nav_bell"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Updates" />

                    <View
                        android:id="@+id/badgeUpdates"
                        android:layout_width="6dp"
                        android:layout_height="6dp"
                        android:layout_gravity="top|end"
                        android:background="@drawable/bg_jarvis_mic_center"
                        android:backgroundTint="@color/status_red" />
                </FrameLayout>

                <TextView
                    android:id="@+id/tvTabUpdates"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Updates"
                    android:textSize="10sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium"
                    android:includeFontPadding="false"
                    android:layout_marginTop="2dp"
                    android:textColor="?attr/themeTextMuted" />
            </LinearLayout>
        </FrameLayout>

    </LinearLayout>

    <!-- Glowing Liquid Glass Curved Line arching over the center Mic button -->
    <com.jarvis.assistant.ui.widget.CurvedDockLineView
        android:id="@+id/dockCurvedLine"
        android:layout_width="0dp"
        android:layout_height="24dp"
        android:elevation="14dp"
        app:layout_constraintStart_toStartOf="@id/bottomDock"
        app:layout_constraintEnd_toEndOf="@id/bottomDock"
        app:layout_constraintTop_toTopOf="@id/bottomDock"
        android:layout_marginTop="-21dp" />

</androidx.constraintlayout.widget.ConstraintLayout>
```
=== END FILE: app/src/main/res/layout/activity_main.xml ===


=== FILE: app/src/main/res/layout/activity_memory.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg"
    android:orientation="vertical">

    <!-- Top App Bar -->
    <androidx.constraintlayout.widget.ConstraintLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:paddingStart="16dp"
        android:paddingEnd="16dp"
        android:paddingTop="16dp"
        android:paddingBottom="14dp">

        <ImageButton
            android:id="@+id/btnBack"
            android:layout_width="40dp"
            android:layout_height="40dp"
            android:background="?attr/selectableItemBackgroundBorderless"
            android:src="@drawable/ic_back"
            android:contentDescription="@string/desc_back"
            app:tint="?attr/themeTextPrimary"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintBottom_toBottomOf="parent" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/memory_title"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="18sp"
            android:textStyle="bold"
            android:fontFamily="sans-serif-black"
            android:letterSpacing="0.15"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintBottom_toBottomOf="parent" />

        <Button
            android:id="@+id/btnAddMemory"
            style="@style/Widget.Material3.Button.TextButton"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="+ ADD"
            android:textColor="?attr/themeAccent"
            android:textStyle="bold"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintBottom_toBottomOf="parent" />
    </androidx.constraintlayout.widget.ConstraintLayout>

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical"
        android:paddingHorizontal="16dp">

        <!-- Search Input -->
        <com.google.android.material.textfield.TextInputLayout
            android:id="@+id/tilSearch"
            style="@style/Widget.Material3.TextInputLayout.OutlinedBox"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="4dp"
            app:boxBackgroundColor="?attr/themeInputBg"
            app:boxStrokeColor="?attr/themeAccent"
            app:boxCornerRadiusTopStart="12dp"
            app:boxCornerRadiusTopEnd="12dp"
            app:boxCornerRadiusBottomStart="12dp"
            app:boxCornerRadiusBottomEnd="12dp"
            app:hintEnabled="false">

            <com.google.android.material.textfield.TextInputEditText
                android:id="@+id/etSearch"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:hint="@string/search_memories"
                android:textColor="?attr/themeTextPrimary"
                android:textColorHint="?attr/themeTextMuted"
                android:singleLine="true"
                android:paddingVertical="12dp"
                android:textSize="14sp" />
        </com.google.android.material.textfield.TextInputLayout>

        <!-- Category Filter Chips -->
        <HorizontalScrollView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:scrollbars="none">

            <LinearLayout
                android:id="@+id/layoutCategories"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:orientation="horizontal">

                <TextView
                    android:id="@+id/chipCategoryAll"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:background="@drawable/bg_chip_selected"
                    android:paddingHorizontal="14dp"
                    android:paddingVertical="6dp"
                    android:text="@string/category_all"
                    android:textColor="?attr/themeAccent"
                    android:textSize="12sp"
                    android:textStyle="bold" />

                <TextView
                    android:id="@+id/chipCategoryPersonal"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_chip_unselected"
                    android:paddingHorizontal="14dp"
                    android:paddingVertical="6dp"
                    android:text="@string/category_personal"
                    android:textColor="?attr/themeTextSecondary"
                    android:textSize="12sp" />

                <TextView
                    android:id="@+id/chipCategoryPreferences"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_chip_unselected"
                    android:paddingHorizontal="14dp"
                    android:paddingVertical="6dp"
                    android:text="@string/category_preferences"
                    android:textColor="?attr/themeTextSecondary"
                    android:textSize="12sp" />

                <TextView
                    android:id="@+id/chipCategoryContacts"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_chip_unselected"
                    android:paddingHorizontal="14dp"
                    android:paddingVertical="6dp"
                    android:text="@string/category_contacts"
                    android:textColor="?attr/themeTextSecondary"
                    android:textSize="12sp" />

                <TextView
                    android:id="@+id/chipCategoryRoutines"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_chip_unselected"
                    android:paddingHorizontal="14dp"
                    android:paddingVertical="6dp"
                    android:text="@string/category_routines"
                    android:textColor="?attr/themeTextSecondary"
                    android:textSize="12sp" />

                <TextView
                    android:id="@+id/chipCategoryNotes"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:background="@drawable/bg_chip_unselected"
                    android:paddingHorizontal="14dp"
                    android:paddingVertical="6dp"
                    android:text="@string/category_notes"
                    android:textColor="?attr/themeTextSecondary"
                    android:textSize="12sp" />
            </LinearLayout>
        </HorizontalScrollView>

        <!-- Count header -->
        <TextView
            android:id="@+id/tvMemoryCount"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="16dp"
            android:layout_marginBottom="8dp"
            android:text="SAVED MEMORIES (0)"
            android:textColor="?attr/themeTextMuted"
            android:textSize="11sp"
            android:letterSpacing="0.05"
            android:textStyle="bold" />

        <!-- Memory List -->
        <FrameLayout
            android:layout_width="match_parent"
            android:layout_height="match_parent">

            <androidx.recyclerview.widget.RecyclerView
                android:id="@+id/rvMemories"
                android:layout_width="match_parent"
                android:layout_height="match_parent"
                android:clipToPadding="false"
                android:paddingBottom="24dp"
                tools:listitem="@layout/item_memory" />

            <TextView
                android:id="@+id/tvNoMemories"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_gravity="center"
                android:text="@string/no_memories"
                android:textColor="?attr/themeTextMuted"
                android:textSize="14sp"
                android:visibility="gone" />
        </FrameLayout>
    </LinearLayout>

</LinearLayout>
```
=== END FILE: app/src/main/res/layout/activity_memory.xml ===


=== FILE: app/src/main/res/layout/activity_overlay_avatar.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:id="@+id/overlayAvatarRoot"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:background="?attr/themeBg">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:gravity="center_vertical"
        android:orientation="horizontal"
        android:paddingStart="16dp"
        android:paddingEnd="20dp"
        android:paddingTop="16dp"
        android:paddingBottom="12dp">

        <ImageButton
            android:id="@+id/btnBack"
            android:layout_width="44dp"
            android:layout_height="44dp"
            android:background="@drawable/bg_jarvis_icon_square"
            android:src="@drawable/ic_back"
            android:contentDescription="Back"
            app:tint="?attr/themeTextPrimary" />

        <LinearLayout
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:orientation="vertical"
            android:layout_marginStart="14dp">

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Overlay Avatars"
                android:textColor="?attr/themeTextPrimary"
                android:textSize="20sp"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold" />

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Pick the companion shown while Jarvis works"
                android:textColor="?attr/themeTextMuted"
                android:textSize="12sp" />
        </LinearLayout>
    </LinearLayout>

    <com.google.android.material.card.MaterialCardView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginStart="20dp"
        android:layout_marginEnd="20dp"
        android:layout_marginTop="4dp"
        android:layout_marginBottom="14dp"
        app:cardBackgroundColor="?attr/themeCardBg"
        app:strokeColor="?attr/themeCardBorder"
        app:strokeWidth="1dp"
        app:cardCornerRadius="18dp">

        <androidx.appcompat.widget.SwitchCompat
            android:id="@+id/switchOverlayEnabled"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:minHeight="64dp"
            android:paddingStart="18dp"
            android:paddingEnd="18dp"
            android:text="Show floating overlay"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="15sp" />
    </com.google.android.material.card.MaterialCardView>

    <com.google.android.material.card.MaterialCardView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginStart="20dp"
        android:layout_marginEnd="20dp"
        android:layout_marginBottom="12dp"
        app:cardBackgroundColor="?attr/themeCardBg"
        app:strokeColor="?attr/themeCardBorder"
        app:strokeWidth="1dp"
        app:cardCornerRadius="16dp">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:padding="14dp">

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Avatar visibility"
                android:textColor="?attr/themeTextPrimary"
                android:textStyle="bold"
                android:textSize="14sp" />

            <RadioGroup
                android:id="@+id/radioOverlayMode"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal">

                <RadioButton
                    android:id="@+id/rbOverlayWorking"
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:text="While working"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="12sp" />

                <RadioButton
                    android:id="@+id/rbOverlayAlways"
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:text="Always on"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="12sp" />
            </RadioGroup>

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Dock the avatar to an edge; dragging it will choose the nearest edge."
                android:textColor="?attr/themeTextMuted"
                android:textSize="11sp" />

            <Spinner
                android:id="@+id/spinnerOverlayEdge"
                android:layout_width="match_parent"
                android:layout_height="44dp"
                android:entries="@array/overlay_edges"
                android:spinnerMode="dropdown" />
        </LinearLayout>
    </com.google.android.material.card.MaterialCardView>

    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:paddingStart="22dp"
        android:paddingEnd="22dp"
        android:paddingBottom="8dp"
        android:text="CHOOSE AN AVATAR"
        android:textColor="?attr/themeTextMuted"
        android:textSize="11sp"
        android:letterSpacing="0.08"
        android:fontFamily="sans-serif-medium"
        android:textStyle="bold" />

    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:paddingStart="22dp"
        android:paddingEnd="22dp"
        android:paddingBottom="10dp"
        android:text="Tap an avatar to select it. Double-tap the floating avatar to see task progress."
        android:textColor="?attr/themeTextMuted"
        android:textSize="12sp" />

    <WebView
        android:id="@+id/avatarGallery"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"
        android:background="@android:color/transparent"
        android:overScrollMode="never"
        android:scrollbars="none" />
</LinearLayout>
```
=== END FILE: app/src/main/res/layout/activity_overlay_avatar.xml ===


=== FILE: app/src/main/res/layout/activity_permission.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.coordinatorlayout.widget.CoordinatorLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg">

    <androidx.core.widget.NestedScrollView
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:fillViewport="true">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:paddingStart="20dp"
            android:paddingEnd="20dp"
            android:paddingTop="36dp"
            android:paddingBottom="40dp">

            <!-- Top Header Bar -->
            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:layout_marginBottom="24dp">

                <ImageButton
                    android:id="@+id/btnBack"
                    android:layout_width="44dp"
                    android:layout_height="44dp"
                    android:background="@drawable/bg_jarvis_icon_square"
                    android:src="@drawable/ic_back"
                    app:tint="?attr/themeTextPrimary"
                    android:contentDescription="Back" />

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="System Authorizations"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="19sp"
                        android:textStyle="bold"
                        android:fontFamily="sans-serif-medium" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Permissions &amp; Privacy Control"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp" />
                </LinearLayout>
            </LinearLayout>

            <!-- Hero Banner Card -->
            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:gravity="center_horizontal"
                android:background="@drawable/bg_jarvis_card"
                android:padding="22dp"
                android:layout_marginBottom="24dp">

                <ImageView
                    android:layout_width="140dp"
                    android:layout_height="48dp"
                    android:src="@drawable/ic_jarvis_logo"
                    android:scaleType="fitCenter"
                    android:contentDescription="Jarvis Logo" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="12dp"
                    android:text="TechGPT X • Neural Assistant"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="16sp"
                    android:textStyle="bold" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="4dp"
                    android:gravity="center"
                    android:text="Grant necessary authorizations so Jarvis can listen, speak, deliver accurate weather, and process your requests seamlessly."
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12.5sp"
                    android:lineSpacingExtra="2dp" />
            </LinearLayout>

            <!-- Card 1: Microphone -->
            <LinearLayout
                android:id="@+id/cardMicPermission"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="18dp"
                android:layout_marginBottom="14dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical">

                    <ImageView
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_avatar"
                        android:padding="8dp"
                        android:src="@drawable/ic_mic_jarvis"
                        app:tint="?attr/themeAccent" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Microphone Access"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvStatusMic"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Checking..."
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <Button
                        android:id="@+id/btnGrantMic"
                        android:layout_width="wrap_content"
                        android:layout_height="36dp"
                        android:text="Grant"
                        android:textSize="12sp"
                        android:textStyle="bold"
                        android:background="@drawable/bg_jarvis_pill_button"
                        android:textColor="#FFFFFF" />
                </LinearLayout>

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="10dp"
                    android:text="Required for voice conversations, voice recognition, and real-time audio interaction with Jarvis."
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12sp" />
            </LinearLayout>

            <!-- Card 2: Location -->
            <LinearLayout
                android:id="@+id/cardLocationPermission"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="18dp"
                android:layout_marginBottom="14dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical">

                    <ImageView
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_avatar"
                        android:padding="8dp"
                        android:src="@drawable/ic_weather_sun"
                        app:tint="?attr/themeAccent" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Precise Location"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvStatusLocation"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Checking..."
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <Button
                        android:id="@+id/btnGrantLocation"
                        android:layout_width="wrap_content"
                        android:layout_height="36dp"
                        android:text="Grant"
                        android:textSize="12sp"
                        android:textStyle="bold"
                        android:background="@drawable/bg_jarvis_pill_button"
                        android:textColor="#FFFFFF" />
                </LinearLayout>

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="10dp"
                    android:text="Required to detect your exact city/locality and provide accurate real-time weather and temperature reports on Home screen."
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12sp" />
            </LinearLayout>

            <!-- Card 3: Notification -->
            <LinearLayout
                android:id="@+id/cardNotificationPermission"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="18dp"
                android:layout_marginBottom="14dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical">

                    <ImageView
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_avatar"
                        android:padding="8dp"
                        android:src="@drawable/ic_nav_bell"
                        app:tint="?attr/themeAccent" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Notifications"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvStatusNotification"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Checking..."
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <Button
                        android:id="@+id/btnGrantNotification"
                        android:layout_width="wrap_content"
                        android:layout_height="36dp"
                        android:text="Grant"
                        android:textSize="12sp"
                        android:textStyle="bold"
                        android:background="@drawable/bg_jarvis_pill_button"
                        android:textColor="#FFFFFF" />
                </LinearLayout>

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="10dp"
                    android:text="Required for reminders, schedule alerts, and continuous background voice service notifications."
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12sp" />
            </LinearLayout>

            <!-- Card 4: System Overlay -->
            <LinearLayout
                android:id="@+id/cardOverlayPermission"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="18dp"
                android:layout_marginBottom="28dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical">

                    <ImageView
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_avatar"
                        android:padding="8dp"
                        android:src="@drawable/ic_nav_settings"
                        app:tint="?attr/themeAccent" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Display Over Other Apps"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvStatusOverlay"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Checking..."
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <Button
                        android:id="@+id/btnGrantOverlay"
                        android:layout_width="wrap_content"
                        android:layout_height="36dp"
                        android:text="Grant"
                        android:textSize="12sp"
                        android:textStyle="bold"
                        android:background="@drawable/bg_jarvis_pill_button"
                        android:textColor="#FFFFFF" />
                </LinearLayout>

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="10dp"
                    android:text="Optional: Allows Jarvis floating bubble to appear anywhere on your phone for quick one-tap voice commands."
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12sp" />
            </LinearLayout>

            <!-- Card 5: Accessibility Service -->
            <LinearLayout
                android:id="@+id/cardAccessibilityPermission"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="18dp"
                android:layout_marginBottom="28dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical">

                    <ImageView
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_avatar"
                        android:padding="8dp"
                        android:src="@drawable/ic_checklist_tasks"
                        app:tint="?attr/themeAccent" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Accessibility Service"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvStatusAccessibility"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Checking..."
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <Button
                        android:id="@+id/btnGrantAccessibility"
                        android:layout_width="wrap_content"
                        android:layout_height="36dp"
                        android:text="Grant"
                        android:textSize="12sp"
                        android:textStyle="bold"
                        android:background="@drawable/bg_jarvis_pill_button"
                        android:textColor="#FFFFFF" />
                </LinearLayout>

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="10dp"
                    android:text="Essential for autonomous AI actions: allows Jarvis to tap buttons, search apps, type messages, and scroll hands-free on your screen."
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="12sp" />
            </LinearLayout>

            <!-- Bottom Action Buttons -->
            <Button
                android:id="@+id/btnGrantAll"
                android:layout_width="match_parent"
                android:layout_height="52dp"
                android:text="GRANT ALL PERMISSIONS"
                android:textColor="#FFFFFF"
                android:textSize="14sp"
                android:textStyle="bold"
                android:background="@drawable/bg_jarvis_pill_button"
                android:layout_marginBottom="12dp" />

            <com.google.android.material.button.MaterialButton
                android:id="@+id/btnOpenSettings"
                style="@style/Widget.Material3.Button.OutlinedButton"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:minHeight="48dp"
                android:text="OPEN SYSTEM APP SETTINGS"
                android:textColor="?attr/themeAccent"
                android:textSize="13sp"
                android:textStyle="bold"
                app:strokeColor="?attr/themeAccent"
                app:cornerRadius="16dp" />

        </LinearLayout>
    </androidx.core.widget.NestedScrollView>
</androidx.coordinatorlayout.widget.CoordinatorLayout>
```
=== END FILE: app/src/main/res/layout/activity_permission.xml ===


=== FILE: app/src/main/res/layout/activity_persona.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg"
    android:focusable="true"
    android:focusableInTouchMode="true">

    <!-- Top App Bar -->
    <LinearLayout
        android:id="@+id/topBar"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:gravity="center_vertical"
        android:paddingStart="16dp"
        android:paddingEnd="16dp"
        android:paddingTop="16dp"
        android:paddingBottom="12dp"
        app:layout_constraintTop_toTopOf="parent">

        <ImageButton
            android:id="@+id/btnBack"
            android:layout_width="44dp"
            android:layout_height="44dp"
            android:background="@drawable/bg_jarvis_icon_square"
            android:src="@drawable/ic_back"
            app:tint="?attr/themeTextPrimary"
            android:contentDescription="Back" />

        <LinearLayout
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:orientation="vertical"
            android:layout_marginStart="14dp">

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="AI Persona"
                android:textColor="?attr/themeTextPrimary"
                android:textSize="20sp"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold" />

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Choose your companion personality"
                android:textColor="?attr/themeTextMuted"
                android:textSize="12sp"
                android:fontFamily="sans-serif" />
        </LinearLayout>
    </LinearLayout>

    <ScrollView
        android:id="@+id/scrollPersona"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:paddingStart="20dp"
        android:paddingEnd="20dp"
        android:scrollbars="none"
        android:descendantFocusability="beforeDescendants"
        app:layout_constraintTop_toBottomOf="@id/topBar"
        app:layout_constraintBottom_toTopOf="@id/layoutBottomBar">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:paddingTop="8dp"
            android:paddingBottom="24dp">

            <com.google.android.material.card.MaterialCardView
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginBottom="14dp"
                app:cardBackgroundColor="?attr/themeCardBg"
                app:strokeColor="?attr/themeCardBorder"
                app:strokeWidth="1dp"
                app:cardCornerRadius="18dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="vertical"
                    android:padding="16dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="YOUR OPERATOR PROFILE"
                        android:textColor="?attr/themeAccent"
                        android:textSize="10sp"
                        android:letterSpacing="0.08"
                        android:textStyle="bold" />

                    <TextView
                        android:id="@+id/tvPersonaPreview"
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="7dp"
                        android:text="Jarvis Pro · Charon"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="16sp"
                        android:textStyle="bold" />

                    <TextView
                        android:id="@+id/tvPersonaGreeting"
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="3dp"
                        android:text="Ready to help, TechGPT X."
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp" />
                </LinearLayout>
            </com.google.android.material.card.MaterialCardView>

            <!-- 1. Jarvis Pro (Default) -->
            <LinearLayout
                android:id="@+id/cardPersonaJarvis"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="16dp"
                android:clickable="true"
                android:focusable="true"
                android:layout_marginBottom="12dp">

                <FrameLayout
                    android:layout_width="48dp"
                    android:layout_height="48dp">
                    <ImageView
                        android:layout_width="match_parent"
                        android:layout_height="match_parent"
                        android:background="@drawable/bg_jarvis_avatar"
                        android:src="@drawable/ic_nav_home"
                        app:tint="@color/accent_sapphire"
                        android:padding="12dp"
                        android:contentDescription="Jarvis" />
                </FrameLayout>

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <LinearLayout
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:orientation="horizontal"
                        android:gravity="center_vertical">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Jarvis Pro"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="16sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="DEFAULT AI"
                            android:singleLine="true"
                            android:maxLines="1"
                            android:textColor="@color/accent_sapphire"
                            android:textSize="10sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium"
                            android:background="@drawable/bg_jarvis_chip"
                            android:paddingStart="6dp"
                            android:paddingEnd="6dp"
                            android:paddingTop="2dp"
                            android:paddingBottom="2dp"
                            android:layout_marginStart="8dp" />
                    </LinearLayout>

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Intelligent, witty &amp; strategic assistant by TechGPT X"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp"
                        android:fontFamily="sans-serif"
                        android:layout_marginTop="2dp" />
                </LinearLayout>

                <RadioButton
                    android:id="@+id/rbSelectJarvis"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:clickable="false"
                    android:focusable="false" />
            </LinearLayout>

            <!-- 2. Girlfriend Mode (Pari) -->
            <LinearLayout
                android:id="@+id/cardPersonaGirlfriend"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="16dp"
                android:clickable="true"
                android:focusable="true"
                android:layout_marginBottom="12dp">

                <FrameLayout
                    android:layout_width="48dp"
                    android:layout_height="48dp">
                    <ImageView
                        android:layout_width="match_parent"
                        android:layout_height="match_parent"
                        android:background="@drawable/bg_jarvis_avatar"
                        android:src="@drawable/ic_nav_chat"
                        app:tint="#EC4899"
                        android:padding="12dp"
                        android:contentDescription="Girlfriend" />
                </FrameLayout>

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <LinearLayout
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:orientation="horizontal"
                        android:gravity="center_vertical">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Girlfriend Mode (Pari)"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="16sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="SWEET"
                            android:singleLine="true"
                            android:maxLines="1"
                            android:textColor="#EC4899"
                            android:textSize="10sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium"
                            android:background="@drawable/bg_jarvis_chip"
                            android:paddingStart="6dp"
                            android:paddingEnd="6dp"
                            android:paddingTop="2dp"
                            android:paddingBottom="2dp"
                            android:layout_marginStart="8dp" />
                    </LinearLayout>

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Caring, warm, affectionate Hinglish companion"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp"
                        android:fontFamily="sans-serif"
                        android:layout_marginTop="2dp" />
                </LinearLayout>

                <RadioButton
                    android:id="@+id/rbSelectGirlfriend"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:clickable="false"
                    android:focusable="false" />
            </LinearLayout>

            <!-- 3. Boyfriend Mode (Kabir) -->
            <LinearLayout
                android:id="@+id/cardPersonaBoyfriend"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="16dp"
                android:clickable="true"
                android:focusable="true"
                android:layout_marginBottom="12dp">

                <FrameLayout
                    android:layout_width="48dp"
                    android:layout_height="48dp">
                    <ImageView
                        android:layout_width="match_parent"
                        android:layout_height="match_parent"
                        android:background="@drawable/bg_jarvis_avatar"
                        android:src="@drawable/ic_settings_shield"
                        app:tint="#3B82F6"
                        android:padding="12dp"
                        android:contentDescription="Boyfriend" />
                </FrameLayout>

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <LinearLayout
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:orientation="horizontal"
                        android:gravity="center_vertical">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Boyfriend Mode (Kabir)"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="16sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="CHARMING"
                            android:singleLine="true"
                            android:maxLines="1"
                            android:textColor="#3B82F6"
                            android:textSize="10sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium"
                            android:background="@drawable/bg_jarvis_chip"
                            android:paddingStart="6dp"
                            android:paddingEnd="6dp"
                            android:paddingTop="2dp"
                            android:paddingBottom="2dp"
                            android:layout_marginStart="8dp" />
                    </LinearLayout>

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Charismatic, protective &amp; supportive partner"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp"
                        android:fontFamily="sans-serif"
                        android:layout_marginTop="2dp" />
                </LinearLayout>

                <RadioButton
                    android:id="@+id/rbSelectBoyfriend"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:clickable="false"
                    android:focusable="false" />
            </LinearLayout>

            <!-- 4. TechGPT X Mode -->
            <LinearLayout
                android:id="@+id/cardPersonaTechGpt"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="16dp"
                android:clickable="true"
                android:focusable="true"
                android:layout_marginBottom="20dp">

                <FrameLayout
                    android:layout_width="48dp"
                    android:layout_height="48dp">
                    <ImageView
                        android:layout_width="match_parent"
                        android:layout_height="match_parent"
                        android:background="@drawable/bg_jarvis_avatar"
                        android:src="@drawable/ic_code_chip"
                        app:tint="#10B981"
                        android:padding="12dp"
                        android:contentDescription="TechGPT X" />
                </FrameLayout>

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <LinearLayout
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:orientation="horizontal"
                        android:gravity="center_vertical">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="TechGPT X Mode"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="16sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="NEURAL CORE"
                            android:singleLine="true"
                            android:maxLines="1"
                            android:textColor="#10B981"
                            android:textSize="10sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium"
                            android:background="@drawable/bg_jarvis_chip"
                            android:paddingStart="6dp"
                            android:paddingEnd="6dp"
                            android:paddingTop="2dp"
                            android:paddingBottom="2dp"
                            android:layout_marginStart="8dp" />
                    </LinearLayout>

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Ultra-fast code architecture, research &amp; deep reasoning"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp"
                        android:fontFamily="sans-serif"
                        android:layout_marginTop="2dp" />
                </LinearLayout>

                <RadioButton
                    android:id="@+id/rbSelectTechGpt"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:clickable="false"
                    android:focusable="false" />
            </LinearLayout>

            <!-- Configuration Section -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="User Name (Default: TechGPT X)"
                android:textColor="?attr/themeTextMuted"
                android:textSize="13sp"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold"
                android:layout_marginBottom="8dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="16dp"
                android:layout_marginBottom="16dp">

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="How should this persona address you?"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="14sp"
                    android:fontFamily="sans-serif-medium"
                    android:textStyle="bold" />

                <com.google.android.material.textfield.TextInputLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="10dp"
                    app:boxBackgroundMode="outline"
                    app:boxCornerRadiusTopStart="12dp"
                    app:boxCornerRadiusTopEnd="12dp"
                    app:boxCornerRadiusBottomStart="12dp"
                    app:boxCornerRadiusBottomEnd="12dp"
                    app:boxStrokeColor="@color/accent_sapphire">

                    <com.google.android.material.textfield.TextInputEditText
                        android:id="@+id/etUserName"
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:hint="TechGPT X"
                        android:text="TechGPT X"
                        android:inputType="textPersonName"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="14sp"
                        android:fontFamily="sans-serif" />
                </com.google.android.material.textfield.TextInputLayout>
            </LinearLayout>

            <!-- Voice Selection Card -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Voice Tone"
                android:textColor="?attr/themeTextMuted"
                android:textSize="13sp"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold"
                android:layout_marginBottom="8dp" />

            <RadioGroup
                android:id="@+id/rgVoiceGroup"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:background="@drawable/bg_jarvis_card"
                android:padding="14dp"
                android:layout_marginBottom="24dp">

                <RadioButton
                    android:id="@+id/rbVoiceAoede"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="Aoede (Warm, expressive female voice)"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="13sp"
                    android:fontFamily="sans-serif-medium"
                    android:paddingTop="6dp"
                    android:paddingBottom="6dp" />

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="@color/border_subtle" />

                <RadioButton
                    android:id="@+id/rbVoiceKore"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="Kore (Gentle, calm female voice)"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="13sp"
                    android:fontFamily="sans-serif-medium"
                    android:paddingTop="6dp"
                    android:paddingBottom="6dp" />

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="@color/border_subtle" />

                <RadioButton
                    android:id="@+id/rbVoiceFenrir"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="Fenrir (Deep, protective charismatic male voice)"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="13sp"
                    android:fontFamily="sans-serif-medium"
                    android:paddingTop="6dp"
                    android:paddingBottom="6dp" />

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="@color/border_subtle" />

                <RadioButton
                    android:id="@+id/rbVoicePuck"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="Puck (Crisp, modern dynamic male voice)"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="13sp"
                    android:fontFamily="sans-serif-medium"
                    android:paddingTop="6dp"
                    android:paddingBottom="6dp" />

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="@color/border_subtle" />

                <RadioButton
                    android:id="@+id/rbVoiceCharon"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="Charon (Distinguished butler male voice)"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="13sp"
                    android:fontFamily="sans-serif-medium"
                    android:paddingTop="6dp"
                    android:paddingBottom="6dp" />
            </RadioGroup>

        </LinearLayout>
    </ScrollView>

    <!-- Bottom Action Bar -->
    <LinearLayout
        android:id="@+id/layoutBottomBar"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:paddingStart="20dp"
        android:paddingEnd="20dp"
        android:paddingTop="12dp"
        android:paddingBottom="20dp"
        android:background="?attr/themeBg"
        app:layout_constraintBottom_toBottomOf="parent">

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btnActivatePersona"
            android:layout_width="match_parent"
            android:layout_height="54dp"
            android:background="@drawable/bg_jarvis_pill_button"
            app:backgroundTint="@null"
            android:text="Activate Persona"
            android:textColor="#FFFFFF"
            android:textSize="15sp"
            android:textStyle="bold"
            android:fontFamily="sans-serif-medium"
            android:textAllCaps="false" />
    </LinearLayout>

</androidx.constraintlayout.widget.ConstraintLayout>
```
=== END FILE: app/src/main/res/layout/activity_persona.xml ===


=== FILE: app/src/main/res/layout/activity_privacy_shield.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.coordinatorlayout.widget.CoordinatorLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg">

    <androidx.core.widget.NestedScrollView
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:fillViewport="true">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:paddingStart="20dp"
            android:paddingEnd="20dp"
            android:paddingTop="36dp"
            android:paddingBottom="40dp">

            <!-- Top Header Bar -->
            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:layout_marginBottom="24dp">

                <ImageButton
                    android:id="@+id/btnBack"
                    android:layout_width="44dp"
                    android:layout_height="44dp"
                    android:background="@drawable/bg_jarvis_icon_square"
                    android:src="@drawable/ic_back"
                    app:tint="?attr/themeTextPrimary"
                    android:contentDescription="Back" />

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Privacy &amp; Data Shield"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="19sp"
                        android:textStyle="bold"
                        android:fontFamily="sans-serif-medium" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Zero-Backend • 100% On-Device Security"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp" />
                </LinearLayout>
            </LinearLayout>

            <!-- Hero Branding Banner (Matching System Authorized Style) -->
            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:gravity="center_horizontal"
                android:background="@drawable/bg_jarvis_card"
                android:padding="22dp"
                android:layout_marginBottom="20dp">

                <ImageView
                    android:layout_width="140dp"
                    android:layout_height="48dp"
                    android:src="@drawable/ic_jarvis_logo"
                    android:scaleType="fitCenter"
                    android:contentDescription="Jarvis Logo" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="12dp"
                    android:text="System Authorized Jarvis TechGPT X"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="16sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="2dp"
                    android:text="Neural Assistant Architecture"
                    android:textColor="?attr/themeAccent"
                    android:textSize="12sp"
                    android:letterSpacing="0.08"
                    android:fontFamily="sans-serif-medium" />

                <LinearLayout
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:background="@drawable/bg_jarvis_status_badge"
                    android:paddingHorizontal="12dp"
                    android:paddingVertical="5dp"
                    android:layout_marginTop="12dp">

                    <View
                        android:layout_width="6dp"
                        android:layout_height="6dp"
                        android:background="@drawable/bg_jarvis_mic_center"
                        android:backgroundTint="@color/status_green" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="100% PRIVATE • ZERO TRACKING"
                        android:textColor="@color/status_green"
                        android:textSize="10.5sp"
                        android:textStyle="bold"
                        android:letterSpacing="0.08"
                        android:layout_marginStart="6dp" />
                </LinearLayout>
            </LinearLayout>

            <!-- Section 1: Your Data Is On Your Mobile -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="DATA OWNERSHIP &amp; STORAGE"
                android:textColor="?attr/themeAccent"
                android:textSize="11sp"
                android:letterSpacing="0.10"
                android:textStyle="bold"
                android:fontFamily="sans-serif-medium"
                android:layout_marginBottom="10dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="20dp"
                android:layout_marginBottom="20dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:layout_marginBottom="12dp">

                    <FrameLayout
                        android:layout_width="44dp"
                        android:layout_height="44dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="24dp"
                            android:layout_height="24dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_shield"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Shield" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Your data is on your mobile."
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="16sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Zero external server databases"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>
                </LinearLayout>

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="In this app there is no backend, nothing. This is a process, totally local on your mobile and Gemini for your conversation. That&apos;s all. No owner added his database or any sign-up pages."
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="14sp"
                    android:lineSpacingExtra="4dp"
                    android:fontFamily="sans-serif" />

                <!-- Bullet guarantees -->
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="vertical"
                    android:layout_marginTop="16dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="•  No Sign-Up, No Accounts, No Trackers"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12.5sp"
                        android:layout_marginBottom="6dp" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="•  Voice Biometrics run 100% locally on-device"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12.5sp"
                        android:layout_marginBottom="6dp" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="•  Direct encrypted TLS 1.3 socket to Gemini Live"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12.5sp" />
                </LinearLayout>
            </LinearLayout>

            <!-- Section 2: Open Source Release -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="TRANSPARENCY &amp; OPEN SOURCE"
                android:textColor="?attr/themeAccent"
                android:textSize="11sp"
                android:letterSpacing="0.10"
                android:textStyle="bold"
                android:fontFamily="sans-serif-medium"
                android:layout_marginBottom="10dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="20dp"
                android:layout_marginBottom="24dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:layout_marginBottom="12dp">

                    <FrameLayout
                        android:layout_width="44dp"
                        android:layout_height="44dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_stack_memory"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Code" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Open Source Coming Soon"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="16sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Full code transparency for the community"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>
                </LinearLayout>

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="And in fact, it will be open source soon. Join if you want source code, Telegram discussion group, Instagram, YouTube. You will get a notification soon that it is open sourced."
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="14sp"
                    android:lineSpacingExtra="4dp"
                    android:fontFamily="sans-serif" />
            </LinearLayout>

            <!-- Section 3: Community & Source Code Discussion -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="COMMUNITY &amp; DISCUSSION GROUPS"
                android:textColor="?attr/themeAccent"
                android:textSize="11sp"
                android:letterSpacing="0.10"
                android:textStyle="bold"
                android:fontFamily="sans-serif-medium"
                android:layout_marginBottom="10dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:paddingStart="16dp"
                android:paddingEnd="16dp"
                android:paddingTop="6dp"
                android:paddingBottom="6dp"
                android:layout_marginBottom="24dp">

                <!-- Official Telegram Channel -->
                <LinearLayout
                    android:id="@+id/btnJoinOfficialTelegram"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingVertical="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <ImageView
                        android:layout_width="36dp"
                        android:layout_height="36dp"
                        android:src="@drawable/ic_social_telegram"
                        android:contentDescription="Official Telegram" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Official Telegram Channel"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Official updates, release notes, and news"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Discussion Group Telegram -->
                <LinearLayout
                    android:id="@+id/btnJoinTelegram"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingVertical="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <ImageView
                        android:layout_width="36dp"
                        android:layout_height="36dp"
                        android:src="@drawable/ic_social_telegram"
                        android:contentDescription="Discussion Group" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Telegram Discussion Group"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Get source code updates &amp; developer chat"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Instagram -->
                <LinearLayout
                    android:id="@+id/btnJoinInstagram"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingVertical="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <ImageView
                        android:layout_width="36dp"
                        android:layout_height="36dp"
                        android:src="@drawable/ic_social_instagram"
                        android:contentDescription="Instagram" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Instagram Community"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Updates, demos, and behind-the-scenes"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- YouTube -->
                <LinearLayout
                    android:id="@+id/btnJoinYoutube"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingVertical="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <ImageView
                        android:layout_width="36dp"
                        android:layout_height="36dp"
                        android:src="@drawable/ic_social_youtube"
                        android:contentDescription="YouTube" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="YouTube Channel"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Watch tutorials, features, &amp; release demos"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

            </LinearLayout>

            <!-- Bottom Disclaimer / Footer -->
            <TextView
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:gravity="center"
                android:text="JARVIS INTELLIGENCE OS • TECHGPT X\nEngineered with complete local privacy &amp; transparency"
                android:textColor="?attr/themeTextMuted"
                android:textSize="11.5sp"
                android:lineSpacingExtra="3dp"
                android:layout_marginTop="8dp" />

        </LinearLayout>
    </androidx.core.widget.NestedScrollView>

</androidx.coordinatorlayout.widget.CoordinatorLayout>
```
=== END FILE: app/src/main/res/layout/activity_privacy_shield.xml ===


=== FILE: app/src/main/res/layout/activity_settings.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<FrameLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/settingsContainer"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg">

    <androidx.fragment.app.FragmentContainerView
        android:id="@+id/settingsFragmentView"
        android:name="com.jarvis.assistant.ui.settings.SettingsFragment"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

</FrameLayout>
```
=== END FILE: app/src/main/res/layout/activity_settings.xml ===


=== FILE: app/src/main/res/layout/activity_voice_enrollment.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg"
    android:orientation="vertical">

    <!-- Top App Bar -->
    <androidx.constraintlayout.widget.ConstraintLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:paddingStart="16dp"
        android:paddingEnd="16dp"
        android:paddingTop="16dp"
        android:paddingBottom="14dp">

        <ImageButton
            android:id="@+id/btnBack"
            android:layout_width="40dp"
            android:layout_height="40dp"
            android:background="?attr/selectableItemBackgroundBorderless"
            android:src="@drawable/ic_back"
            android:contentDescription="Back"
            app:tint="?attr/themeTextPrimary"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintBottom_toBottomOf="parent" />

        <TextView
            android:id="@+id/tvHeaderTitle"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="VOICE BIOMETRICS"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="17sp"
            android:textStyle="bold"
            android:fontFamily="sans-serif-black"
            android:letterSpacing="0.12"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintBottom_toBottomOf="parent" />

        <com.google.android.material.materialswitch.MaterialSwitch
            android:id="@+id/switchOwnerOnly"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintBottom_toBottomOf="parent" />
    </androidx.constraintlayout.widget.ConstraintLayout>

    <ScrollView
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:fillViewport="true"
        android:scrollbars="none">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:paddingHorizontal="16dp"
            android:paddingBottom="32dp">

            <!-- Status Banner Card -->
            <com.google.android.material.card.MaterialCardView
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="8dp"
                app:cardBackgroundColor="@color/bg_card"
                app:cardCornerRadius="16dp"
                app:strokeColor="@color/border_subtle"
                app:strokeWidth="1dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="vertical"
                    android:padding="16dp">

                    <LinearLayout
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:gravity="center_vertical"
                        android:orientation="horizontal">

                        <View
                            android:id="@+id/viewStatusDot"
                            android:layout_width="10dp"
                            android:layout_height="10dp"
                            android:background="@drawable/circle_cyan" />

                        <TextView
                            android:id="@+id/tvEnrollmentStatus"
                            android:layout_width="0dp"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="10dp"
                            android:layout_weight="1"
                            android:text="OWNER VOICE: ACTIVE"
                            android:textColor="?attr/themeAccent"
                            android:textSize="14sp"
                            android:textStyle="bold"
                            android:letterSpacing="0.08" />
                    </LinearLayout>

                    <TextView
                        android:id="@+id/tvStatusDescription"
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="8dp"
                        android:text="Jarvis is calibrated to your voice. Any speech or commands from strangers, family members, or TV are automatically blocked."
                        android:textColor="?attr/themeTextSecondary"
                        android:textSize="13sp"
                        android:lineSpacingExtra="3dp" />
                </LinearLayout>
            </com.google.android.material.card.MaterialCardView>

            <!-- Enrollment Card -->
            <com.google.android.material.card.MaterialCardView
                android:id="@+id/cardEnrollment"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="16dp"
                app:cardBackgroundColor="?attr/themeCardBg"
                app:cardCornerRadius="16dp"
                app:strokeColor="?attr/themeCardBorder"
                app:strokeWidth="1dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:gravity="center_horizontal"
                    android:orientation="vertical"
                    android:padding="20dp">

                    <TextView
                        android:id="@+id/tvStepIndicator"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="TRAIN STEP 1 OF 3"
                        android:textColor="?attr/themeAccent"
                        android:textSize="12sp"
                        android:textStyle="bold"
                        android:letterSpacing="0.15" />

                    <TextView
                        android:id="@+id/tvPromptInstruction"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="10dp"
                        android:text="Say clearly into your phone:"
                        android:textColor="?attr/themeTextSecondary"
                        android:textSize="13sp" />

                    <TextView
                        android:id="@+id/tvPromptPhrase"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="6dp"
                        android:gravity="center"
                        android:text="&quot;Hey Jarvis, wake up&quot;"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="18sp"
                        android:textStyle="bold" />

                    <!-- Big Glow Record Button -->
                    <com.google.android.material.button.MaterialButton
                        android:id="@+id/btnRecordSample"
                        android:layout_width="wrap_content"
                        android:layout_height="56dp"
                        android:layout_marginTop="20dp"
                        android:paddingHorizontal="28dp"
                        android:text="TAP &amp; SPEAK PHRASE"
                        android:textColor="#FFFFFF"
                        android:textStyle="bold"
                        android:textSize="14sp"
                        app:backgroundTint="?attr/themeAccent"
                        app:cornerRadius="28dp" />

                    <TextView
                        android:id="@+id/tvRecordFeedback"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="12dp"
                        android:text="Tap to start recording sample 1"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp" />

                    <!-- Step Checkmarks -->
                    <LinearLayout
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="18dp"
                        android:gravity="center"
                        android:orientation="horizontal">

                        <TextView
                            android:id="@+id/tvStep1Dot"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="① Sample 1"
                            android:textColor="?attr/themeAccent"
                            android:textSize="12sp"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvStep2Dot"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="16dp"
                            android:text="② Sample 2"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />

                        <TextView
                            android:id="@+id/tvStep3Dot"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginStart="16dp"
                            android:text="③ Sample 3"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp" />
                    </LinearLayout>
                </LinearLayout>
            </com.google.android.material.card.MaterialCardView>

            <!-- Live Test Card -->
            <com.google.android.material.card.MaterialCardView
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="16dp"
                app:cardBackgroundColor="?attr/themeCardBg"
                app:cardCornerRadius="16dp"
                app:strokeColor="?attr/themeCardBorder"
                app:strokeWidth="1dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="vertical"
                    android:padding="16dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="LIVE RECOGNITION TEST"
                        android:textColor="?attr/themeAccent"
                        android:textSize="13sp"
                        android:textStyle="bold"
                        android:letterSpacing="0.1" />

                    <TextView
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="4dp"
                        android:text="Test your voice or let a friend speak to verify that Jarvis accepts you and denies them."
                        android:textColor="?attr/themeTextSecondary"
                        android:textSize="12sp" />

                    <com.google.android.material.button.MaterialButton
                        android:id="@+id/btnTestVoice"
                        style="@style/Widget.Material3.Button.OutlinedButton"
                        android:layout_width="match_parent"
                        android:layout_height="48dp"
                        android:layout_marginTop="14dp"
                        android:text="TEST VOICE MATCH (SPEAK NOW)"
                        android:textColor="?attr/themeAccent"
                        app:strokeColor="?attr/themeAccent"
                        app:cornerRadius="12dp" />

                    <!-- Test Result Banner -->
                    <LinearLayout
                        android:id="@+id/layoutTestResult"
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="12dp"
                        android:background="@drawable/bg_test_result"
                        android:orientation="vertical"
                        android:padding="12dp"
                        android:visibility="gone">

                        <TextView
                            android:id="@+id/tvTestVerdict"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="VERIFIED: OWNER (94% MATCH)"
                            android:textColor="@color/status_green"
                            android:textSize="14sp"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvTestDetails"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:layout_marginTop="2dp"
                            android:text="Cosine distance: 0.28 (Threshold: 0.50)"
                            android:textColor="?attr/themeTextSecondary"
                            android:textSize="11sp" />
                    </LinearLayout>
                </LinearLayout>
            </com.google.android.material.card.MaterialCardView>

            <!-- Strictness / Sensitivity Card -->
            <com.google.android.material.card.MaterialCardView
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="16dp"
                app:cardBackgroundColor="?attr/themeCardBg"
                app:cardCornerRadius="16dp"
                app:strokeColor="?attr/themeCardBorder"
                app:strokeWidth="1dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="vertical"
                    android:padding="16dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="SENSITIVITY / STRICTNESS"
                        android:textColor="?attr/themeAccent"
                        android:textSize="13sp"
                        android:textStyle="bold"
                        android:letterSpacing="0.1" />

                    <RadioGroup
                        android:id="@+id/rgSensitivity"
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="10dp">

                        <RadioButton
                            android:id="@+id/rbStrict"
                            android:layout_width="match_parent"
                            android:layout_height="wrap_content"
                            android:text="Strict (High Security - Zero False Accepts)"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="13sp" />

                        <RadioButton
                            android:id="@+id/rbBalanced"
                            android:layout_width="match_parent"
                            android:layout_height="wrap_content"
                            android:checked="true"
                            android:text="Balanced (Recommended - Optimal Everyday)"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="13sp" />

                        <RadioButton
                            android:id="@+id/rbRelaxed"
                            android:layout_width="match_parent"
                            android:layout_height="wrap_content"
                            android:text="Relaxed (Forgiving - Best if you have a cold)"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="13sp" />
                    </RadioGroup>
                </LinearLayout>
            </com.google.android.material.card.MaterialCardView>

            <!-- Reset Button -->
            <com.google.android.material.button.MaterialButton
                android:id="@+id/btnClearProfile"
                style="@style/Widget.Material3.Button.OutlinedButton"
                android:layout_width="match_parent"
                android:layout_height="48dp"
                android:layout_marginTop="16dp"
                android:text="RESET / RE-ENROLL VOICE PROFILE"
                android:textColor="@color/status_red"
                app:strokeColor="@color/status_red"
                app:strokeWidth="1dp"
                android:textSize="13sp" />

        </LinearLayout>
    </ScrollView>
</LinearLayout>
```
=== END FILE: app/src/main/res/layout/activity_voice_enrollment.xml ===


=== FILE: app/src/main/res/layout/bottom_sheet_theme_selection.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    android:background="@drawable/bg_jarvis_dock"
    android:paddingStart="20dp"
    android:paddingEnd="20dp"
    android:paddingTop="20dp"
    android:paddingBottom="32dp">

    <!-- Handle Bar -->
    <View
        android:layout_width="40dp"
        android:layout_height="4dp"
        android:layout_gravity="center_horizontal"
        android:background="@drawable/bg_jarvis_chip"
        android:layout_marginBottom="16dp" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Select App Theme"
        android:textColor="?attr/themeTextPrimary"
        android:textSize="20sp"
        android:fontFamily="sans-serif-medium"
        android:textStyle="bold" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Restyles the entire app and the neural orb"
        android:textColor="?attr/themeTextMuted"
        android:textSize="12sp"
        android:fontFamily="sans-serif"
        android:layout_marginTop="2dp"
        android:layout_marginBottom="16dp" />

    <androidx.core.widget.NestedScrollView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:fillViewport="true">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical">

            <!-- Theme 1: Light -->
            <LinearLayout
                android:id="@+id/cardThemeLight"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="16dp"
                android:layout_marginBottom="10dp">

                <View
                    android:layout_width="28dp"
                    android:layout_height="28dp"
                    android:background="@drawable/bg_jarvis_chip"
                    android:backgroundTint="#F4F6FB" />

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Light"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="15sp"
                        android:fontFamily="sans-serif-medium"
                        android:textStyle="bold" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Crisp studio white • Blue &amp; Violet accents"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp"
                        android:fontFamily="sans-serif" />
                </LinearLayout>

                <ImageView
                    android:id="@+id/ivCheckLight"
                    android:layout_width="20dp"
                    android:layout_height="20dp"
                    android:src="@drawable/ic_checklist_tasks"
                    app:tint="?attr/themeAccent" />
            </LinearLayout>

            <!-- Theme 2: Dark -->
            <LinearLayout
                android:id="@+id/cardThemeDark"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="16dp"
                android:layout_marginBottom="10dp">

                <View
                    android:layout_width="28dp"
                    android:layout_height="28dp"
                    android:background="@drawable/bg_jarvis_chip"
                    android:backgroundTint="#0A0D1F" />

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Dark"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="15sp"
                        android:fontFamily="sans-serif-medium"
                        android:textStyle="bold" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Deep midnight cosmic • Neon cyan &amp; purple"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp"
                        android:fontFamily="sans-serif" />
                </LinearLayout>

                <ImageView
                    android:id="@+id/ivCheckDark"
                    android:layout_width="20dp"
                    android:layout_height="20dp"
                    android:src="@drawable/ic_checklist_tasks"
                    app:tint="?attr/themeAccent" />
            </LinearLayout>

            <!-- Theme 3: Red -->
            <LinearLayout
                android:id="@+id/cardThemeRed"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="16dp"
                android:layout_marginBottom="10dp">

                <View
                    android:layout_width="28dp"
                    android:layout_height="28dp"
                    android:background="@drawable/bg_jarvis_chip"
                    android:backgroundTint="#2A0A10" />

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Red"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="15sp"
                        android:fontFamily="sans-serif-medium"
                        android:textStyle="bold" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Obsidian crimson • Laser coral &amp; flame"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp"
                        android:fontFamily="sans-serif" />
                </LinearLayout>

                <ImageView
                    android:id="@+id/ivCheckRed"
                    android:layout_width="20dp"
                    android:layout_height="20dp"
                    android:src="@drawable/ic_checklist_tasks"
                    app:tint="?attr/themeAccent" />
            </LinearLayout>

            <!-- Theme 4: Sunset -->
            <LinearLayout
                android:id="@+id/cardThemeSunset"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="16dp"
                android:layout_marginBottom="10dp">

                <View
                    android:layout_width="28dp"
                    android:layout_height="28dp"
                    android:background="@drawable/bg_jarvis_chip"
                    android:backgroundTint="#FFE7E1" />

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:orientation="vertical"
                    android:layout_marginStart="14dp">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Sunset"
                        android:textColor="?attr/themeTextPrimary"
                        android:textSize="15sp"
                        android:fontFamily="sans-serif-medium"
                        android:textStyle="bold" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Warm pastel peach • Coral &amp; magenta twilight"
                        android:textColor="?attr/themeTextMuted"
                        android:textSize="12sp"
                        android:fontFamily="sans-serif" />
                </LinearLayout>

                <ImageView
                    android:id="@+id/ivCheckSunset"
                    android:layout_width="20dp"
                    android:layout_height="20dp"
                    android:src="@drawable/ic_checklist_tasks"
                    app:tint="?attr/themeAccent" />
            </LinearLayout>

            <!-- Theme 5: Custom Background Colour -->
            <LinearLayout
                android:id="@+id/cardThemeCustom"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:padding="16dp"
                android:layout_marginBottom="10dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical">

                    <View
                        android:id="@+id/viewCustomPreview"
                        android:layout_width="28dp"
                        android:layout_height="28dp"
                        android:background="@drawable/bg_jarvis_chip"
                        android:backgroundTint="#8B5CF6" />

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Custom Background"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvCustomSubtitle"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Choose any HEX colour (#RRGGBB)"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif" />
                    </LinearLayout>

                    <ImageView
                        android:id="@+id/ivCheckCustom"
                        android:layout_width="20dp"
                        android:layout_height="20dp"
                        android:src="@drawable/ic_checklist_tasks"
                        app:tint="?attr/themeAccent" />
                </LinearLayout>

                <!-- Custom Hex Input & Presets -->
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:layout_marginTop="12dp">

                    <EditText
                        android:id="@+id/etCustomHex"
                        android:layout_width="0dp"
                        android:layout_height="44dp"
                        android:layout_weight="1"
                        android:hint="#1E1B4B"
                        android:text="#1E1B4B"
                        android:textColor="?attr/themeTextPrimary"
                        android:textColorHint="?attr/themeTextMuted"
                        android:textSize="14sp"
                        android:paddingStart="12dp"
                        android:paddingEnd="12dp"
                        android:background="@drawable/bg_jarvis_card"
                        android:singleLine="true" />

                    <com.google.android.material.button.MaterialButton
                        android:id="@+id/btnApplyCustom"
                        android:layout_width="wrap_content"
                        android:layout_height="44dp"
                        android:text="Apply"
                        android:textColor="#FFFFFF"
                        app:backgroundTint="?attr/themeAccent"
                        app:cornerRadius="10dp"
                        android:layout_marginStart="10dp" />
                </LinearLayout>

                <!-- Quick Preset Swatches -->
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center"
                    android:layout_marginTop="12dp">

                    <View
                        android:id="@+id/swatch1"
                        android:layout_width="32dp"
                        android:layout_height="32dp"
                        android:layout_margin="4dp"
                        android:background="@drawable/bg_jarvis_chip"
                        android:backgroundTint="#000000" />

                    <View
                        android:id="@+id/swatch2"
                        android:layout_width="32dp"
                        android:layout_height="32dp"
                        android:layout_margin="4dp"
                        android:background="@drawable/bg_jarvis_chip"
                        android:backgroundTint="#1E1B4B" />

                    <View
                        android:id="@+id/swatch3"
                        android:layout_width="32dp"
                        android:layout_height="32dp"
                        android:layout_margin="4dp"
                        android:background="@drawable/bg_jarvis_chip"
                        android:backgroundTint="#042F2E" />

                    <View
                        android:id="@+id/swatch4"
                        android:layout_width="32dp"
                        android:layout_height="32dp"
                        android:layout_margin="4dp"
                        android:background="@drawable/bg_jarvis_chip"
                        android:backgroundTint="#451A03" />

                    <View
                        android:id="@+id/swatch5"
                        android:layout_width="32dp"
                        android:layout_height="32dp"
                        android:layout_margin="4dp"
                        android:background="@drawable/bg_jarvis_chip"
                        android:backgroundTint="#F0FDF4" />

                    <View
                        android:id="@+id/swatch6"
                        android:layout_width="32dp"
                        android:layout_height="32dp"
                        android:layout_margin="4dp"
                        android:background="@drawable/bg_jarvis_chip"
                        android:backgroundTint="#FAF5FF" />
                </LinearLayout>
            </LinearLayout>

        </LinearLayout>
    </androidx.core.widget.NestedScrollView>
</LinearLayout>
```
=== END FILE: app/src/main/res/layout/bottom_sheet_theme_selection.xml ===


=== FILE: app/src/main/res/layout/fragment_chat.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg"
    android:paddingStart="16dp"
    android:paddingEnd="16dp"
    android:paddingTop="16dp"
    android:paddingBottom="100dp">

    <!-- Top Navigation Header -->
    <ImageButton
        android:id="@+id/btnChatMenu"
        android:layout_width="44dp"
        android:layout_height="44dp"
        android:background="@drawable/bg_jarvis_icon_square"
        android:src="@drawable/ic_menu"
        app:tint="?attr/themeTextPrimary"
        android:contentDescription="Menu"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintStart_toStartOf="parent" />

    <LinearLayout
        android:id="@+id/layoutChatHeader"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:gravity="center"
        android:layout_marginStart="12dp"
        android:layout_marginEnd="12dp"
        app:layout_constraintTop_toTopOf="@id/btnChatMenu"
        app:layout_constraintBottom_toBottomOf="@id/btnChatMenu"
        app:layout_constraintStart_toEndOf="@id/btnChatMenu"
        app:layout_constraintEnd_toStartOf="@id/btnChatNew">

        <TextView
            android:id="@+id/tvChatTitle"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Hi"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="18sp"
            android:textStyle="bold"
            android:fontFamily="sans-serif-medium" />

        <TextView
            android:id="@+id/tvChatSubtitle"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Jarvis • Gemini Live • Active"
            android:textColor="?attr/themeTextMuted"
            android:textSize="12sp"
            android:fontFamily="sans-serif" />
    </LinearLayout>

    <ImageButton
        android:id="@+id/btnChatNew"
        android:layout_width="44dp"
        android:layout_height="44dp"
        android:background="@drawable/bg_jarvis_icon_square"
        android:src="@drawable/ic_plus"
        app:tint="?attr/themeTextPrimary"
        android:contentDescription="New Chat"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />

    <!-- Chat Messages List -->
    <androidx.recyclerview.widget.RecyclerView
        android:id="@+id/rvChatMessages"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:clipToPadding="false"
        android:paddingTop="12dp"
        android:paddingBottom="12dp"
        android:layout_marginTop="8dp"
        android:layout_marginBottom="12dp"
        app:layout_constraintTop_toBottomOf="@id/layoutChatHeader"
        app:layout_constraintBottom_toTopOf="@id/cardInputContainer" />

    <!-- Rich Bottom Message Input Container (Matching Image 3) -->
    <LinearLayout
        android:id="@+id/cardInputContainer"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:background="@drawable/bg_jarvis_card"
        android:padding="14dp"
        app:layout_constraintBottom_toBottomOf="parent">

        <EditText
            android:id="@+id/etMessageInput"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="Message Jarvis"
            android:textColorHint="?attr/themeTextMuted"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="15sp"
            android:fontFamily="sans-serif"
            android:background="@null"
            android:minLines="1"
            android:maxLines="4"
            android:inputType="textCapSentences|textMultiLine"
            android:paddingBottom="12dp" />

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center_vertical">

            <!-- Chip 1: Jarvis Persona -->
            <LinearLayout
                android:id="@+id/chipPersona"
                android:layout_width="wrap_content"
                android:layout_height="36dp"
                android:orientation="horizontal"
                android:gravity="center"
                android:background="@drawable/bg_jarvis_chip"
                android:paddingStart="12dp"
                android:paddingEnd="14dp"
                android:layout_marginEnd="8dp">

                <ImageView
                    android:layout_width="16dp"
                    android:layout_height="16dp"
                    android:src="@drawable/ic_nav_chat"
                    app:tint="?attr/themeTextSecondary"
                    android:layout_marginEnd="6dp" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Jarvis"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="12sp"
                    android:fontFamily="sans-serif-medium"
                    android:textStyle="bold" />
            </LinearLayout>

            <!-- Chip 2: Mode / Code -->
            <LinearLayout
                android:id="@+id/chipMode"
                android:layout_width="wrap_content"
                android:layout_height="36dp"
                android:orientation="horizontal"
                android:gravity="center"
                android:background="@drawable/bg_jarvis_chip"
                android:paddingStart="12dp"
                android:paddingEnd="14dp">

                <ImageView
                    android:layout_width="16dp"
                    android:layout_height="16dp"
                    android:src="@drawable/ic_code_chip"
                    app:tint="?attr/themeTextSecondary"
                    android:layout_marginEnd="6dp" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Code"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="12sp"
                    android:fontFamily="sans-serif-medium"
                    android:textStyle="bold" />
            </LinearLayout>

            <View
                android:layout_width="0dp"
                android:layout_height="1dp"
                android:layout_weight="1" />

            <!-- Plus attachment button -->
            <ImageButton
                android:id="@+id/btnAttach"
                android:layout_width="36dp"
                android:layout_height="36dp"
                android:background="@null"
                android:src="@drawable/ic_plus"
                app:tint="?attr/themeTextSecondary"
                android:layout_marginEnd="8dp"
                android:contentDescription="Attach" />

            <!-- Send Button -->
            <ImageButton
                android:id="@+id/btnSendMessage"
                android:layout_width="44dp"
                android:layout_height="44dp"
                android:background="@drawable/bg_jarvis_pill_button"
                android:src="@drawable/ic_send_up"
                app:tint="#FFFFFF"
                android:contentDescription="Send" />
        </LinearLayout>
    </LinearLayout>

</androidx.constraintlayout.widget.ConstraintLayout>
```
=== END FILE: app/src/main/res/layout/fragment_chat.xml ===


=== FILE: app/src/main/res/layout/fragment_home.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg"
    android:clipChildren="false"
    android:clipToPadding="false"
    android:paddingStart="20dp"
    android:paddingEnd="20dp"
    android:paddingTop="16dp"
    android:paddingBottom="96dp">

    <!-- Ambient Liquid Glass Glow Fields (Soft luminous refractions behind glass) -->
    <View
        android:id="@+id/glowOrbTopRight"
        android:layout_width="280dp"
        android:layout_height="280dp"
        android:layout_marginTop="-70dp"
        android:layout_marginEnd="-70dp"
        android:background="?attr/themeGlowBlob1"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />

    <View
        android:id="@+id/glowOrbCenterLeft"
        android:layout_width="260dp"
        android:layout_height="260dp"
        android:layout_marginStart="-80dp"
        android:background="?attr/themeGlowBlob2"
        app:layout_constraintTop_toTopOf="@id/orbContainer"
        app:layout_constraintBottom_toBottomOf="@id/orbContainer"
        app:layout_constraintStart_toStartOf="parent" />

    <View
        android:id="@+id/glowOrbBottom"
        android:layout_width="280dp"
        android:layout_height="280dp"
        android:layout_marginBottom="-60dp"
        android:layout_marginEnd="-40dp"
        android:background="?attr/themeGlowBlob3"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />

    <!-- Top Action Bar -->
    <ImageButton
        android:id="@+id/btnTopChat"
        android:layout_width="46dp"
        android:layout_height="46dp"
        android:background="@drawable/bg_jarvis_icon_square"
        android:src="@drawable/ic_chat_bubble"
        app:tint="?attr/themeTextPrimary"
        android:contentDescription="Chat"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintStart_toStartOf="parent" />

    <LinearLayout
        android:id="@+id/layoutTitle"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:gravity="center"
        app:layout_constraintTop_toTopOf="@id/btnTopChat"
        app:layout_constraintBottom_toBottomOf="@id/btnTopChat"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <ImageView
            android:id="@+id/ivHeaderJarvisLogo"
            android:layout_width="110dp"
            android:layout_height="34dp"
            android:src="@drawable/ic_jarvis_logo"
            android:scaleType="fitCenter"
            android:contentDescription="Jarvis Logo" />

        <TextView
            android:id="@+id/tvGreeting"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Welcome, Rehaan"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="14sp"
            android:textStyle="bold"
            android:fontFamily="sans-serif-medium"
            android:layout_marginTop="2dp" />
    </LinearLayout>

    <ImageButton
        android:id="@+id/btnTopSettings"
        android:layout_width="46dp"
        android:layout_height="46dp"
        android:background="@drawable/bg_jarvis_icon_square"
        android:src="@drawable/ic_nav_settings"
        app:tint="?attr/themeTextPrimary"
        android:contentDescription="Settings"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />

    <!-- Center 3D Glowing Particle Orb Stage -->
    <FrameLayout
        android:id="@+id/orbContainer"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:clipChildren="false"
        android:clipToPadding="false"
        app:layout_constraintHeight_percent="0.45"
        app:layout_constraintVertical_bias="0.45"
        app:layout_constraintTop_toBottomOf="@id/layoutTitle"
        app:layout_constraintBottom_toTopOf="@id/layoutStatusIndicator"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <View
            android:id="@+id/orbHaloRing"
            android:layout_width="260dp"
            android:layout_height="260dp"
            android:layout_gravity="center"
            android:background="@drawable/bg_jarvis_orb_halo" />

        <WebView
            android:id="@+id/orbWebView"
            android:layout_width="match_parent"
            android:layout_height="match_parent"
            android:layout_gravity="center"
            android:background="@android:color/transparent" />
    </FrameLayout>

    <!-- Sleek Futuristic Status Pill -->
    <LinearLayout
        android:id="@+id/layoutStatusIndicator"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:gravity="center"
        android:layout_marginBottom="22dp"
        app:layout_constraintBottom_toTopOf="@id/cardWeather"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <LinearLayout
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center_vertical"
            android:background="@drawable/bg_jarvis_status_badge"
            android:paddingHorizontal="16dp"
            android:paddingVertical="8dp">

            <View
                android:id="@+id/dotStatusGlow"
                android:layout_width="8dp"
                android:layout_height="8dp"
                android:background="@drawable/bg_jarvis_mic_center"
                android:backgroundTint="?attr/themeAccent" />

            <TextView
                android:id="@+id/tvListeningStatus"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="TAP ORB TO START"
                android:textColor="?attr/themeTextPrimary"
                android:textSize="12sp"
                android:letterSpacing="0.10"
                android:textStyle="bold"
                android:fontFamily="sans-serif-medium"
                android:layout_marginStart="8dp" />
        </LinearLayout>

        <TextView
            android:id="@+id/tvHoldHint"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Hold button or orb to power off"
            android:textColor="?attr/themeTextMuted"
            android:textSize="10sp"
            android:fontFamily="sans-serif"
            android:layout_marginTop="5dp" />
    </LinearLayout>

    <!-- Weather Widget Card -->
    <LinearLayout
        android:id="@+id/cardWeather"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:gravity="center_vertical"
        android:background="@drawable/bg_jarvis_action_card"
        android:paddingStart="20dp"
        android:paddingEnd="20dp"
        android:paddingTop="16dp"
        android:paddingBottom="16dp"
        android:clickable="true"
        android:focusable="true"
        android:layout_marginBottom="24dp"
        app:layout_constraintBottom_toTopOf="@id/layoutActionGrid"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <TextView
            android:id="@+id/tvTemperature"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="--°C"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="26sp"
            android:fontFamily="sans-serif-medium"
            android:textStyle="bold"
            android:includeFontPadding="false"
            android:layout_marginEnd="14dp" />

        <LinearLayout
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:orientation="vertical">

            <TextView
                android:id="@+id/tvWeatherCondition"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Detecting Location&#8230;"
                android:textColor="?attr/themeTextPrimary"
                android:textSize="14sp"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold"
                android:includeFontPadding="false" />

            <TextView
                android:id="@+id/tvWeatherDetails"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Tap to refresh live atmosphere"
                android:textColor="?attr/themeTextMuted"
                android:textSize="12sp"
                android:fontFamily="sans-serif"
                android:includeFontPadding="false"
                android:layout_marginTop="2dp" />
        </LinearLayout>

        <ImageView
            android:id="@+id/ivWeatherIcon"
            android:layout_width="30dp"
            android:layout_height="30dp"
            android:src="@drawable/ic_weather_sun"
            app:tint="?attr/themeAccent"
            android:contentDescription="Weather"
            android:layout_marginStart="8dp" />
    </LinearLayout>

    <!-- Quick Action Grid (3 Modern High-Tech Cards) -->
    <LinearLayout
        android:id="@+id/layoutActionGrid"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:layout_marginBottom="12dp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <!-- 1. Screen Share -->
        <LinearLayout
            android:id="@+id/btnScreenShareQuick"
            android:layout_width="0dp"
            android:layout_height="66dp"
            android:layout_weight="1"
            android:layout_marginEnd="6dp"
            android:background="@drawable/bg_jarvis_action_card"
            android:orientation="horizontal"
            android:gravity="center_vertical"
            android:paddingStart="10dp"
            android:paddingEnd="6dp"
            android:clickable="true"
            android:focusable="true"
            android:contentDescription="Start or stop screen sharing">

            <ImageView
                android:layout_width="24dp"
                android:layout_height="24dp"
                android:src="@drawable/ic_screen_share"
                app:tint="?attr/themeAccent"
                android:layout_marginEnd="8dp" />

            <LinearLayout
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:orientation="vertical">

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Screen"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="12sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium"
                    android:includeFontPadding="false" />

                <TextView
                    android:id="@+id/tvQuickScreenShareStatus"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Share"
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="10sp"
                    android:fontFamily="sans-serif"
                    android:includeFontPadding="false"
                    android:layout_marginTop="2dp" />
            </LinearLayout>
        </LinearLayout>

        <!-- 2. Saved Memories -->
        <LinearLayout
            android:id="@+id/btnSavedMemories"
            android:layout_width="0dp"
            android:layout_height="66dp"
            android:layout_weight="1"
            android:layout_marginStart="6dp"
            android:layout_marginEnd="6dp"
            android:background="@drawable/bg_jarvis_action_card"
            android:orientation="horizontal"
            android:gravity="center_vertical"
            android:paddingStart="10dp"
            android:paddingEnd="6dp"
            android:clickable="true"
            android:focusable="true">

            <ImageView
                android:layout_width="20dp"
                android:layout_height="20dp"
                android:src="@drawable/ic_stack_memory"
                app:tint="?attr/themeAccent"
                android:layout_marginEnd="6dp" />

            <LinearLayout
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:orientation="vertical">

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Memories"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="12sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium"
                    android:includeFontPadding="false" />

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Recall Core"
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="10sp"
                    android:fontFamily="sans-serif"
                    android:includeFontPadding="false"
                    android:layout_marginTop="2dp" />
            </LinearLayout>
        </LinearLayout>

        <!-- 3. Conversation Language -->
        <LinearLayout
            android:id="@+id/btnConversationLanguageQuick"
            android:layout_width="0dp"
            android:layout_height="66dp"
            android:layout_weight="1"
            android:layout_marginStart="6dp"
            android:background="@drawable/bg_jarvis_action_card"
            android:orientation="horizontal"
            android:gravity="center_vertical"
            android:paddingStart="10dp"
            android:paddingEnd="6dp"
            android:clickable="true"
            android:focusable="true">

            <ImageView
                android:layout_width="22dp"
                android:layout_height="22dp"
                android:src="@drawable/ic_settings_language"
                app:tint="?attr/themeAccent"
                android:layout_marginEnd="6dp" />

            <LinearLayout
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:orientation="vertical">

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Language"
                    android:textColor="?attr/themeTextPrimary"
                    android:textSize="12sp"
                    android:textStyle="bold"
                    android:fontFamily="sans-serif-medium"
                    android:includeFontPadding="false" />

                <TextView
                    android:id="@+id/tvQuickLanguageStatus"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Auto"
                    android:textColor="?attr/themeTextMuted"
                    android:textSize="10sp"
                    android:fontFamily="sans-serif"
                    android:singleLine="true"
                    android:maxLines="1"
                    android:ellipsize="end"
                    android:includeFontPadding="false"
                    android:layout_marginTop="2dp" />
            </LinearLayout>
        </LinearLayout>

    </LinearLayout>

    <!-- Prominent Actionable Error Card Overlay (Floats Upon Orb) -->
    <LinearLayout
        android:id="@+id/cardLiveError"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:background="@drawable/bg_jarvis_error_card"
        android:padding="20dp"
        android:layout_marginStart="24dp"
        android:layout_marginEnd="24dp"
        android:elevation="32dp"
        android:translationZ="32dp"
        android:clickable="true"
        android:focusable="true"
        android:visibility="gone"
        app:layout_constraintTop_toTopOf="@id/orbContainer"
        app:layout_constraintBottom_toBottomOf="@id/orbContainer"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center_vertical">

            <ImageView
                android:id="@+id/ivLiveErrorIcon"
                android:layout_width="24dp"
                android:layout_height="24dp"
                android:src="@drawable/ic_warning"
                app:tint="#EF4444" />

            <TextView
                android:id="@+id/tvLiveErrorTitle"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:layout_marginStart="10dp"
                android:text="API KEY ERROR"
                android:textColor="#EF4444"
                android:textSize="14sp"
                android:letterSpacing="0.08"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold" />

            <ImageButton
                android:id="@+id/btnDismissLiveError"
                android:layout_width="36dp"
                android:layout_height="36dp"
                android:background="?attr/selectableItemBackgroundBorderless"
                android:src="@drawable/ic_close"
                app:tint="?attr/themeTextMuted"
                android:contentDescription="Dismiss" />
        </LinearLayout>

        <TextView
            android:id="@+id/tvLiveErrorMessage"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="10dp"
            android:text="Google rejected the API key: 400 Bad Request. Please update your API key in Settings."
            android:textColor="?attr/themeTextPrimary"
            android:textSize="13sp"
            android:lineSpacingExtra="3dp" />

        <Button
            android:id="@+id/btnFixLiveError"
            android:layout_width="wrap_content"
            android:layout_height="40dp"
            android:layout_marginTop="14dp"
            android:paddingHorizontal="20dp"
            android:text="OPEN API SETTINGS"
            android:textSize="12sp"
            android:textStyle="bold"
            android:background="@drawable/bg_jarvis_pill_button"
            app:backgroundTint="@null"
            android:textColor="#FFFFFF" />
    </LinearLayout>

</androidx.constraintlayout.widget.ConstraintLayout>
```
=== END FILE: app/src/main/res/layout/fragment_home.xml ===


=== FILE: app/src/main/res/layout/fragment_settings.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg"
    android:paddingStart="20dp"
    android:paddingEnd="20dp"
    android:paddingTop="16dp"
    android:paddingBottom="100dp">

    <!-- Ambient Liquid Glass Glow Fields (Soft luminous refractions behind glass) -->
    <View
        android:id="@+id/glowOrbTopRight"
        android:layout_width="280dp"
        android:layout_height="280dp"
        android:layout_marginTop="-70dp"
        android:layout_marginEnd="-70dp"
        android:background="?attr/themeGlowBlob1"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />

    <View
        android:id="@+id/glowOrbCenterLeft"
        android:layout_width="260dp"
        android:layout_height="260dp"
        android:layout_marginStart="-80dp"
        android:background="?attr/themeGlowBlob2"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="parent" />

    <View
        android:id="@+id/glowOrbBottom"
        android:layout_width="280dp"
        android:layout_height="280dp"
        android:layout_marginBottom="-60dp"
        android:layout_marginEnd="-40dp"
        android:background="?attr/themeGlowBlob3"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />

    <!-- Top Header -->
    <LinearLayout
        android:id="@+id/layoutHeader"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:gravity="center_vertical"
        app:layout_constraintTop_toTopOf="parent">

        <LinearLayout
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:orientation="vertical">

            <TextView
                android:id="@+id/tvSettingsTitle"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Settings &amp; Intelligence"
                android:textColor="?attr/themeTextPrimary"
                android:textSize="22sp"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold" />

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="System preferences &amp; neural configuration"
                android:textColor="?attr/themeTextMuted"
                android:textSize="12sp"
                android:fontFamily="sans-serif"
                android:layout_marginTop="2dp" />
        </LinearLayout>

        <ImageView
            android:layout_width="28dp"
            android:layout_height="28dp"
            android:src="@drawable/ic_sparkle"
            app:tint="?attr/themeAccent"
            android:contentDescription="AI" />
    </LinearLayout>

    <ScrollView
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_marginTop="16dp"
        android:scrollbars="none"
        app:layout_constraintTop_toBottomOf="@id/layoutHeader"
        app:layout_constraintBottom_toBottomOf="parent">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:paddingBottom="32dp">

            <!-- Executive VIP Profile & Identity Card -->
            <LinearLayout
                android:id="@+id/cardProfile"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_action_card"
                android:padding="18dp"
                android:clickable="true"
                android:focusable="true"
                android:layout_marginBottom="22dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical">

                    <FrameLayout
                        android:layout_width="56dp"
                        android:layout_height="56dp">

                        <ImageView
                            android:layout_width="match_parent"
                            android:layout_height="match_parent"
                            android:background="@drawable/bg_jarvis_icon_square"
                            android:scaleType="centerInside"
                            android:src="@drawable/ic_user_profile"
                            app:tint="?attr/themeAccent"
                            android:padding="12dp"
                            android:contentDescription="Avatar" />

                        <!-- Online Status Dot -->
                        <View
                            android:layout_width="12dp"
                            android:layout_height="12dp"
                            android:layout_gravity="bottom|end"
                            android:background="@drawable/bg_jarvis_mic_center"
                            android:backgroundTint="@color/status_green" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:id="@+id/tvProfileName"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Rehaan"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="18sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvProfileSubtitle"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="JARVIS OPERATOR • PRIMARY USER"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="11sp"
                            android:letterSpacing="0.06"
                            android:fontFamily="sans-serif-medium"
                            android:layout_marginTop="3dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="20dp"
                        android:layout_height="20dp"
                        android:src="@drawable/ic_edit"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Edit" />
                </LinearLayout>

                <!-- Profile Quick Status Chips -->
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:layout_marginTop="14dp">

                    <!-- Voice Biometrics Chip -->
                    <LinearLayout
                        android:id="@+id/chipProfileVoiceStatus"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:orientation="horizontal"
                        android:gravity="center_vertical"
                        android:background="@drawable/bg_jarvis_status_badge_green"
                        android:paddingHorizontal="10dp"
                        android:paddingVertical="5dp"
                        android:layout_marginEnd="8dp">

                        <ImageView
                            android:id="@+id/ivProfileVoiceBadgeIcon"
                            android:layout_width="12dp"
                            android:layout_height="12dp"
                            android:src="@drawable/ic_verified_badge"
                            app:tint="@color/status_green" />

                        <TextView
                            android:id="@+id/tvProfileVoiceStatus"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="VOICE ENROLLED"
                            android:textColor="@color/status_green"
                            android:textSize="10sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium"
                            android:letterSpacing="0.05"
                            android:layout_marginStart="5dp" />
                    </LinearLayout>

                    <!-- Persona Chip -->
                    <LinearLayout
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:orientation="horizontal"
                        android:gravity="center_vertical"
                        android:background="@drawable/bg_jarvis_status_badge"
                        android:paddingHorizontal="10dp"
                        android:paddingVertical="5dp">

                        <ImageView
                            android:layout_width="12dp"
                            android:layout_height="12dp"
                            android:src="@drawable/ic_settings_voice"
                            app:tint="?attr/themeAccent" />

                        <TextView
                            android:id="@+id/tvProfilePersonaChip"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="JARVIS PRO"
                            android:textColor="?attr/themeAccent"
                            android:textSize="10sp"
                            android:textStyle="bold"
                            android:fontFamily="sans-serif-medium"
                            android:letterSpacing="0.05"
                            android:layout_marginStart="5dp" />
                    </LinearLayout>
                </LinearLayout>
            </LinearLayout>

            <!-- SECTION 1: VOICE & NEURAL INTELLIGENCE -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="VOICE &amp; NEURAL INTELLIGENCE"
                android:textColor="?attr/themeTextMuted"
                android:textSize="11sp"
                android:letterSpacing="0.08"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold"
                android:layout_marginBottom="8dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:paddingStart="16dp"
                android:paddingEnd="16dp"
                android:layout_marginBottom="22dp">

                <!-- Row 1: Owner Voice Biometrics (FEATURE RESTORED & PROMINENT) -->
                <LinearLayout
                    android:id="@+id/rowOwnerVoice"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_owner_voice"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Owner Voice" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Owner Voice Biometrics"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvOwnerVoiceSubtitle"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Voice Profile Active • Only you can speak"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <TextView
                        android:id="@+id/tvOwnerVoiceBadge"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="ACTIVE"
                        android:textSize="10sp"
                        android:textStyle="bold"
                        android:textColor="@color/status_green"
                        android:background="@drawable/bg_jarvis_status_badge_green"
                        android:paddingHorizontal="8dp"
                        android:paddingVertical="3dp"
                        android:layout_marginEnd="8dp" />

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Row 2: Conversation Language (FEATURE RESTORED) -->
                <LinearLayout
                    android:id="@+id/rowLanguage"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_language"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Language" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Conversation Language"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvCurrentLanguage"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Auto (All Indian Languages)"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Row 3: AI Persona & Voice -->
                <LinearLayout
                    android:id="@+id/rowPersonaVoice"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_voice"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Persona &amp; Voice" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="AI Persona &amp; Voice"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvCurrentPersona"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Jarvis Pro • Voice: Puck"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>



                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Row 5: Silent Execution Mode (FEATURE RESTORED) -->
                <LinearLayout
                    android:id="@+id/rowSilentMode"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_silent"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Silent Mode" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp"
                        android:layout_marginEnd="8dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Silent Execution Mode"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Execute device commands without vocal reply"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <com.google.android.material.materialswitch.MaterialSwitch
                        android:id="@+id/switchSilentMode"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content" />
                </LinearLayout>
            </LinearLayout>

            <!-- SECTION 2: SYSTEM & INTELLIGENCE DATA -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="SYSTEM &amp; DATA ENGINE"
                android:textColor="?attr/themeTextMuted"
                android:textSize="11sp"
                android:letterSpacing="0.08"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold"
                android:layout_marginBottom="8dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:paddingStart="16dp"
                android:paddingEnd="16dp"
                android:layout_marginBottom="22dp">

                <!-- Row 1: API & Connection -->
                <LinearLayout
                    android:id="@+id/rowApiConnection"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_plug"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="API" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Gemini Live API &amp; Model"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvCurrentModel"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Gemini 3.1 Flash Live • WebSocket Engine"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Row 2: Long-Term Memory -->
                <LinearLayout
                    android:id="@+id/rowMemory"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_db"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Memory" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Neural Memory Bank"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Search, review and back up learned facts"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Row 3: Permissions -->
                <LinearLayout
                    android:id="@+id/rowPermissions"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_shield"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Permissions" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="System Permissions"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Microphone, Accessibility, Notifications &amp; System"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Floating task overlay and avatar selection -->
                <LinearLayout
                    android:id="@+id/rowOverlayAvatars"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">
                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_palette"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Overlay avatars" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">
                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Overlay Avatars"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:textStyle="bold" />
                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Choose a floating avatar or turn the overlay off"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Row 4: Applications & Automation -->
                <LinearLayout
                    android:id="@+id/rowApplications"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_apps"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Apps" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="App Control &amp; Hands-Free"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="WhatsApp, YouTube, Media &amp; Phone Automation"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>
            </LinearLayout>

            <!-- SECTION 3: APPEARANCE & SECURITY -->
            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="APPEARANCE &amp; SECURITY"
                android:textColor="?attr/themeTextMuted"
                android:textSize="11sp"
                android:letterSpacing="0.08"
                android:fontFamily="sans-serif-medium"
                android:textStyle="bold"
                android:layout_marginBottom="8dp" />

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:background="@drawable/bg_jarvis_card"
                android:paddingStart="16dp"
                android:paddingEnd="16dp"
                android:layout_marginBottom="24dp">

                <!-- Row 1: App Theme -->
                <LinearLayout
                    android:id="@+id/rowAppTheme"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_palette"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Theme" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Theme &amp; 3D Orb Colors"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:id="@+id/tvCurrentTheme"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Light Theme"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <!-- Row 2: Privacy Policy -->
                <LinearLayout
                    android:id="@+id/rowPrivacyPolicy"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">

                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_lock"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="Privacy" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Privacy &amp; Data Shield"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="On-device biometric processing &amp; TLS encryption"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:fontFamily="sans-serif"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>

                <View
                    android:layout_width="match_parent"
                    android:layout_height="1dp"
                    android:background="?attr/themeCardBorder" />

                <LinearLayout
                    android:id="@+id/rowAppIdentity"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:paddingTop="14dp"
                    android:paddingBottom="14dp"
                    android:background="@drawable/bg_jarvis_row_item"
                    android:clickable="true"
                    android:focusable="true">

                    <FrameLayout
                        android:layout_width="40dp"
                        android:layout_height="40dp"
                        android:background="@drawable/bg_jarvis_icon_square">
                        <ImageView
                            android:layout_width="22dp"
                            android:layout_height="22dp"
                            android:layout_gravity="center"
                            android:src="@drawable/ic_settings_shield"
                            app:tint="?attr/themeAccent"
                            android:contentDescription="App identity and integrity" />
                    </FrameLayout>

                    <LinearLayout
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:orientation="vertical"
                        android:layout_marginStart="14dp">
                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="App Identity &amp; Integrity"
                            android:textColor="?attr/themeTextPrimary"
                            android:textSize="15sp"
                            android:fontFamily="sans-serif-medium"
                            android:textStyle="bold" />
                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Publisher, app ID and signing certificate status"
                            android:textColor="?attr/themeTextMuted"
                            android:textSize="12sp"
                            android:layout_marginTop="2dp" />
                    </LinearLayout>

                    <ImageView
                        android:layout_width="18dp"
                        android:layout_height="18dp"
                        android:src="@drawable/ic_arrow_right"
                        app:tint="?attr/themeTextMuted"
                        android:contentDescription="Open" />
                </LinearLayout>
            </LinearLayout>

            <!-- Social Community Buttons -->
            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center"
                android:layout_marginBottom="16dp">

                <ImageButton
                    android:id="@+id/btnSocialTelegram"
                    android:layout_width="48dp"
                    android:layout_height="48dp"
                    android:background="@drawable/bg_jarvis_icon_square"
                    android:src="@drawable/ic_social_telegram"
                    app:tint="?attr/themeAccent"
                    android:layout_marginEnd="12dp"
                    android:contentDescription="Telegram" />

                <ImageButton
                    android:id="@+id/btnSocialInstagram"
                    android:layout_width="48dp"
                    android:layout_height="48dp"
                    android:background="@drawable/bg_jarvis_icon_square"
                    android:src="@drawable/ic_social_instagram"
                    app:tint="?attr/themeAccent"
                    android:layout_marginEnd="12dp"
                    android:contentDescription="Instagram" />

                <ImageButton
                    android:id="@+id/btnSocialYoutube"
                    android:layout_width="48dp"
                    android:layout_height="48dp"
                    android:background="@drawable/bg_jarvis_icon_square"
                    android:src="@drawable/ic_social_youtube"
                    app:tint="?attr/themeAccent"
                    android:contentDescription="YouTube" />
            </LinearLayout>

            <!-- Footer: Executive Signature -->
            <TextView
                android:id="@+id/tvFooterCredit"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:text="JARVIS INTELLIGENCE OS • v3.1 PRO\nEngineered by TechGPT X"
                android:textColor="?attr/themeTextMuted"
                android:textSize="12sp"
                android:fontFamily="sans-serif-medium"
                android:lineSpacingExtra="4dp"
                android:gravity="center"
                android:clickable="true"
                android:focusable="true" />

        </LinearLayout>
    </ScrollView>

</androidx.constraintlayout.widget.ConstraintLayout>
```
=== END FILE: app/src/main/res/layout/fragment_settings.xml ===


=== FILE: app/src/main/res/layout/fragment_updates.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg"
    android:paddingStart="20dp"
    android:paddingEnd="20dp"
    android:paddingTop="20dp"
    android:paddingBottom="100dp">

    <!-- Header -->
    <LinearLayout
        android:id="@+id/layoutUpdatesHeader"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        app:layout_constraintTop_toTopOf="parent">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Updates"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="24sp"
            android:textStyle="bold"
            android:fontFamily="sans-serif-medium" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Jarvis updates &amp; announcements"
            android:textColor="?attr/themeTextMuted"
            android:textSize="13sp"
            android:fontFamily="sans-serif"
            android:layout_marginTop="4dp" />
    </LinearLayout>

    <ScrollView
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_marginTop="16dp"
        app:layout_constraintTop_toBottomOf="@id/layoutUpdatesHeader"
        app:layout_constraintBottom_toBottomOf="parent">

        <LinearLayout
            android:id="@+id/updatesList"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical" />
    </ScrollView>

</androidx.constraintlayout.widget.ConstraintLayout>
```
=== END FILE: app/src/main/res/layout/fragment_updates.xml ===


=== FILE: app/src/main/res/layout/item_chat_turn.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    android:layout_marginBottom="18dp">

    <TextView
        android:id="@+id/tvTimestamp"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="center_horizontal"
        android:textColor="@color/text_muted"
        android:textSize="11sp"
        android:layout_marginBottom="6dp"
        tools:text="19:45:10" />

    <LinearLayout
        android:id="@+id/boxUserMessage"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="end"
        android:layout_marginStart="48dp"
        android:background="@drawable/bg_user_bubble"
        android:orientation="vertical"
        android:paddingHorizontal="14dp"
        android:paddingVertical="10dp">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/chat_label_you"
            android:textColor="?attr/themeTextSecondary"
            android:textSize="11sp"
            android:textStyle="bold"
            android:letterSpacing="0.05" />

        <TextView
            android:id="@+id/tvUserTranscript"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="14sp"
            android:layout_marginTop="2dp"
            tools:text="Hello JARVIS, how are you?" />
    </LinearLayout>

    <LinearLayout
        android:id="@+id/boxJarvisMessage"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="start"
        android:layout_marginEnd="48dp"
        android:layout_marginTop="8dp"
        android:background="@drawable/bg_jarvis_bubble"
        android:orientation="vertical"
        android:paddingHorizontal="14dp"
        android:paddingVertical="10dp">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/chat_label_jarvis"
            android:textColor="?attr/themeAccent"
            android:textSize="11sp"
            android:textStyle="bold"
            android:letterSpacing="0.05" />

        <TextView
            android:id="@+id/tvJarvisResponse"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="14sp"
            android:layout_marginTop="2dp"
            tools:text="Online and ready. How can I assist you today, Boss?" />
    </LinearLayout>

</LinearLayout>
```
=== END FILE: app/src/main/res/layout/item_chat_turn.xml ===


=== FILE: app/src/main/res/layout/item_jarvis_chat_message.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    android:paddingTop="6dp"
    android:paddingBottom="6dp">

    <!-- User Message Bubble (Right Aligned) -->
    <LinearLayout
        android:id="@+id/layoutUserContainer"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:gravity="end"
        android:visibility="gone">

        <TextView
            android:id="@+id/tvUserMessage"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:maxWidth="280dp"
            android:background="@drawable/bg_jarvis_chat_user"
            android:paddingStart="16dp"
            android:paddingTop="10dp"
            android:paddingEnd="16dp"
            android:paddingBottom="10dp"
            android:text="Hi"
            android:textColor="#FFFFFF"
            android:fontFamily="sans-serif"
            android:textSize="15sp" />

        <LinearLayout
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center_vertical"
            android:layout_marginTop="4dp"
            android:layout_marginEnd="4dp">

            <ImageView
                android:id="@+id/btnUserEdit"
                android:layout_width="16dp"
                android:layout_height="16dp"
                android:src="@drawable/ic_edit"
                app:tint="?attr/themeTextMuted"
                android:layout_marginEnd="10dp" />

            <ImageView
                android:id="@+id/btnUserCopy"
                android:layout_width="16dp"
                android:layout_height="16dp"
                android:src="@drawable/ic_copy"
                app:tint="?attr/themeTextMuted" />
        </LinearLayout>
    </LinearLayout>

    <!-- Assistant Message Bubble (Left Aligned) -->
    <LinearLayout
        android:id="@+id/layoutAssistantContainer"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:gravity="start"
        android:layout_marginTop="6dp"
        android:visibility="gone">

        <TextView
            android:id="@+id/tvAssistantMessage"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:maxWidth="300dp"
            android:background="@drawable/bg_jarvis_chat_assistant"
            android:paddingStart="16dp"
            android:paddingTop="12dp"
            android:paddingEnd="16dp"
            android:paddingBottom="12dp"
            android:text="Hey! I'm doing great, aap. How are you feeling today? 😊"
            android:textColor="?attr/themeTextPrimary"
            android:fontFamily="sans-serif"
            android:textSize="15sp"
            android:lineSpacingExtra="3dp" />

        <LinearLayout
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center_vertical"
            android:layout_marginTop="4dp"
            android:layout_marginStart="4dp">

            <ImageView
                android:id="@+id/btnAssistantCopy"
                android:layout_width="16dp"
                android:layout_height="16dp"
                android:src="@drawable/ic_copy"
                app:tint="?attr/themeTextMuted"
                android:layout_marginEnd="12dp" />

            <ImageView
                android:id="@+id/btnAssistantPlay"
                android:layout_width="16dp"
                android:layout_height="16dp"
                android:src="@drawable/ic_tts_play"
                app:tint="?attr/themeTextMuted" />
        </LinearLayout>
    </LinearLayout>

</LinearLayout>
```
=== END FILE: app/src/main/res/layout/item_jarvis_chat_message.xml ===


=== FILE: app/src/main/res/layout/item_memory.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_marginBottom="12dp"
    android:background="@drawable/bg_card_futuristic"
    android:orientation="vertical"
    android:padding="16dp">

    <!-- Header: Category & Date & Actions -->
    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:gravity="center_vertical"
        android:orientation="horizontal">

        <TextView
            android:id="@+id/tvMemoryCategory"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:background="@drawable/bg_badge_action"
            android:paddingHorizontal="10dp"
            android:paddingVertical="4dp"
            android:text="PREFERENCES"
            android:textColor="?attr/themeAccent"
            android:textSize="10sp"
            android:textStyle="bold"
            android:letterSpacing="0.05" />

        <TextView
            android:id="@+id/tvMemoryDate"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_marginStart="10dp"
            android:layout_weight="1"
            android:text="Sep 12, 2026 • 15:30"
            android:textColor="?attr/themeTextMuted"
            android:textSize="11sp" />

        <ImageButton
            android:id="@+id/btnEditMemory"
            android:layout_width="32dp"
            android:layout_height="32dp"
            android:background="?attr/selectableItemBackgroundBorderless"
            android:src="@drawable/ic_edit"
            app:tint="?attr/themeTextSecondary"
            android:contentDescription="Edit" />

        <ImageButton
            android:id="@+id/btnDeleteMemory"
            android:layout_width="32dp"
            android:layout_height="32dp"
            android:layout_marginStart="4dp"
            android:background="?attr/selectableItemBackgroundBorderless"
            android:src="@drawable/ic_delete"
            app:tint="@color/status_red"
            android:contentDescription="Delete" />
    </LinearLayout>

    <!-- Content / Fact Text -->
    <TextView
        android:id="@+id/tvMemoryFact"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="10dp"
        android:text="Favorite song is Believer."
        android:textColor="?attr/themeTextPrimary"
        android:textSize="14sp"
        android:lineSpacingExtra="3dp" />

</LinearLayout>
```
=== END FILE: app/src/main/res/layout/item_memory.xml ===


=== FILE: app/src/main/res/layout/item_naira_chat_message.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    android:paddingTop="6dp"
    android:paddingBottom="6dp">

    <!-- User Message Bubble (Right Aligned) -->
    <LinearLayout
        android:id="@+id/layoutUserContainer"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:gravity="end"
        android:visibility="gone">

        <TextView
            android:id="@+id/tvUserMessage"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:maxWidth="280dp"
            android:background="@drawable/bg_jarvis_chat_user"
            android:paddingStart="16dp"
            android:paddingTop="10dp"
            android:paddingEnd="16dp"
            android:paddingBottom="10dp"
            android:text="Hi"
            android:textColor="#FFFFFF"
            android:fontFamily="sans-serif"
            android:textSize="15sp" />

        <LinearLayout
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center_vertical"
            android:layout_marginTop="4dp"
            android:layout_marginEnd="4dp">

            <ImageView
                android:id="@+id/btnUserEdit"
                android:layout_width="16dp"
                android:layout_height="16dp"
                android:src="@drawable/ic_edit"
                app:tint="?attr/themeTextMuted"
                android:layout_marginEnd="10dp" />

            <ImageView
                android:id="@+id/btnUserCopy"
                android:layout_width="16dp"
                android:layout_height="16dp"
                android:src="@drawable/ic_copy"
                app:tint="?attr/themeTextMuted" />
        </LinearLayout>
    </LinearLayout>

    <!-- Assistant Message Bubble (Left Aligned) -->
    <LinearLayout
        android:id="@+id/layoutAssistantContainer"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:gravity="start"
        android:layout_marginTop="6dp"
        android:visibility="gone">

        <TextView
            android:id="@+id/tvAssistantMessage"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:maxWidth="300dp"
            android:background="@drawable/bg_jarvis_chat_assistant"
            android:paddingStart="16dp"
            android:paddingTop="12dp"
            android:paddingEnd="16dp"
            android:paddingBottom="12dp"
            android:text="Hey! I'm doing great, aap. How are you feeling today? 😊"
            android:textColor="?attr/themeTextPrimary"
            android:fontFamily="sans-serif"
            android:textSize="15sp"
            android:lineSpacingExtra="3dp" />

        <LinearLayout
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center_vertical"
            android:layout_marginTop="4dp"
            android:layout_marginStart="4dp">

            <ImageView
                android:id="@+id/btnAssistantCopy"
                android:layout_width="16dp"
                android:layout_height="16dp"
                android:src="@drawable/ic_copy"
                app:tint="?attr/themeTextMuted"
                android:layout_marginEnd="12dp" />

            <ImageView
                android:id="@+id/btnAssistantPlay"
                android:layout_width="16dp"
                android:layout_height="16dp"
                android:src="@drawable/ic_tts_play"
                app:tint="?attr/themeTextMuted" />
        </LinearLayout>
    </LinearLayout>

</LinearLayout>
```
=== END FILE: app/src/main/res/layout/item_naira_chat_message.xml ===


=== FILE: app/src/main/res/layout/sheet_chat_history.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/themeBg"
    android:orientation="vertical"
    android:paddingTop="12dp">

    <View
        android:layout_width="40dp"
        android:layout_height="4dp"
        android:background="?attr/themeCardBorder"
        android:layout_gravity="center_horizontal"
        android:layout_marginBottom="12dp" />

    <androidx.constraintlayout.widget.ConstraintLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:paddingHorizontal="20dp"
        android:paddingBottom="12dp">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/chat_history_title"
            android:textColor="?attr/themeTextPrimary"
            android:textSize="17sp"
            android:textStyle="bold"
            android:letterSpacing="0.05"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintBottom_toBottomOf="parent" />

        <Button
            android:id="@+id/btnClearHistory"
            style="@style/Widget.Material3.Button.TextButton"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/clear_history"
            android:textColor="@color/status_red"
            android:textSize="12sp"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintBottom_toBottomOf="parent" />
    </androidx.constraintlayout.widget.ConstraintLayout>

    <View
        android:layout_width="match_parent"
        android:layout_height="1dp"
        android:background="?attr/themeCardBorder" />

    <TextView
        android:id="@+id/tvEmptyHistory"
        android:layout_width="match_parent"
        android:layout_height="240dp"
        android:gravity="center"
        android:text="@string/no_history"
        android:textColor="?attr/themeTextMuted"
        android:textSize="14sp"
        android:visibility="gone" />

    <androidx.recyclerview.widget.RecyclerView
        android:id="@+id/rvChatHistory"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"
        android:paddingHorizontal="16dp"
        android:paddingTop="12dp"
        android:clipToPadding="false"
        tools:listitem="@layout/item_chat_turn" />

</LinearLayout>
```
=== END FILE: app/src/main/res/layout/sheet_chat_history.xml ===


=== FILE: app/src/main/res/drawable/bg_badge_action.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="?attr/themeAccentLight" />
    <corners android:radius="8dp" />
    <stroke
        android:width="1dp"
        android:color="?attr/themeAccent" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_badge_action.xml ===


=== FILE: app/src/main/res/drawable/bg_card_futuristic.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="?attr/themeCardBg" />
    <stroke
        android:width="1dp"
        android:color="?attr/themeCardBorder" />
    <corners android:radius="14dp" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_card_futuristic.xml ===


=== FILE: app/src/main/res/drawable/bg_chip_selected.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="?attr/themeAccentLight" />
    <stroke
        android:width="1.5dp"
        android:color="?attr/themeAccent" />
    <corners android:radius="20dp" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_chip_selected.xml ===


=== FILE: app/src/main/res/drawable/bg_chip_unselected.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="?attr/themeChipBg" />
    <stroke
        android:width="1dp"
        android:color="?attr/themeCardBorder" />
    <corners android:radius="20dp" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_chip_unselected.xml ===


=== FILE: app/src/main/res/drawable/bg_dock_item_active.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="24dp" />
    <gradient
        android:type="linear"
        android:angle="135"
        android:startColor="?attr/themeChipBg"
        android:endColor="?attr/themeCardGlassEnd" />
    <stroke
        android:width="1.2dp"
        android:color="?attr/themeCardBorder" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_dock_item_active.xml ===


=== FILE: app/src/main/res/drawable/bg_dock_mic_highlight.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="28dp" />
            <gradient
                android:type="linear"
                android:angle="135"
                android:startColor="?attr/themeAccent1"
                android:endColor="?attr/themeAccent2" />
            <stroke
                android:width="2dp"
                android:color="#FFFFFF" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_dock_mic_highlight.xml ===


=== FILE: app/src/main/res/drawable/bg_dock_mic_muted.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="28dp" />
            <gradient
                android:type="linear"
                android:angle="135"
                android:startColor="#EF4444"
                android:endColor="#B91C1C" />
            <stroke
                android:width="2dp"
                android:color="#FFFFFF" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_dock_mic_muted.xml ===


=== FILE: app/src/main/res/drawable/bg_dock_mic_off.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#20FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="28dp" />
            <solid android:color="#261E293B" />
            <stroke
                android:width="1.5dp"
                android:color="#475569" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_dock_mic_off.xml ===


=== FILE: app/src/main/res/drawable/bg_input_field.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="12dp" />
    <solid android:color="?attr/themeCardBg" />
    <stroke
        android:width="1dp"
        android:color="?attr/themeCardBorder" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_input_field.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_action_card.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="?attr/themeAccentLight">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="22dp" />
            <gradient
                android:type="linear"
                android:angle="135"
                android:startColor="?attr/themeCardGlassStart"
                android:endColor="?attr/themeCardGlassEnd" />
            <stroke
                android:width="1.2dp"
                android:color="?attr/themeCardBorder" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_action_card.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_avatar.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="18dp" />
    <gradient
        android:type="linear"
        android:angle="135"
        android:startColor="?attr/themeAccentLight"
        android:endColor="?attr/themeChipBg" />
    <stroke
        android:width="1.5dp"
        android:color="?attr/themeAccent" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_avatar.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_bubble.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners
        android:topLeftRadius="16dp"
        android:topRightRadius="16dp"
        android:bottomLeftRadius="4dp"
        android:bottomRightRadius="16dp" />
    <solid android:color="#140508" />
    <stroke
        android:width="1dp"
        android:color="#FF1744" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_bubble.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_card.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="22dp" />
    <gradient
        android:type="linear"
        android:angle="135"
        android:startColor="?attr/themeCardGlassStart"
        android:endColor="?attr/themeCardGlassEnd" />
    <stroke
        android:width="1.2dp"
        android:color="?attr/themeCardBorder" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_card.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_chat_assistant.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners
        android:topLeftRadius="20dp"
        android:topRightRadius="20dp"
        android:bottomLeftRadius="6dp"
        android:bottomRightRadius="20dp" />
    <solid android:color="?attr/themeCardBg" />
    <stroke
        android:width="1dp"
        android:color="?attr/themeCardBorder" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_chat_assistant.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_chat_user.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners
        android:topLeftRadius="20dp"
        android:topRightRadius="20dp"
        android:bottomLeftRadius="20dp"
        android:bottomRightRadius="6dp" />
    <solid android:color="?attr/themeAccent" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_chat_user.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_chip.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#20000000">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="18dp" />
            <solid android:color="?attr/themeChipBg" />
            <stroke
                android:width="1dp"
                android:color="?attr/themeCardBorder" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_chip.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_dock.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="36dp" />
    <gradient
        android:type="linear"
        android:angle="135"
        android:startColor="?attr/themeDockGlassStart"
        android:endColor="?attr/themeDockGlassEnd" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_dock.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_error_card.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="24dp" />
    <gradient
        android:type="linear"
        android:angle="135"
        android:startColor="#F51A1014"
        android:endColor="#F50D080C" />
    <stroke
        android:width="1.5dp"
        android:color="#EF4444" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_error_card.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_icon_square.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="?attr/themeAccentLight">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="16dp" />
            <gradient
                android:type="linear"
                android:angle="135"
                android:startColor="?attr/themeCardGlassStart"
                android:endColor="?attr/themeCardGlassEnd" />
            <stroke
                android:width="1.2dp"
                android:color="?attr/themeCardBorder" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_icon_square.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_mic_center.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <layer-list>
            <!-- 1. Ambient Glow & Liquid Base Sphere -->
            <item>
                <shape android:shape="oval">
                    <gradient
                        android:type="radial"
                        android:gradientRadius="36dp"
                        android:startColor="#60A5FA"
                        android:centerColor="#2563EB"
                        android:endColor="#1E40AF" />
                    <stroke
                        android:width="2dp"
                        android:color="#E6FFFFFF" />
                </shape>
            </item>
            <!-- 2. Top Specular Glass Crescent / Lens Reflection -->
            <item
                android:top="3dp"
                android:left="12dp"
                android:right="12dp"
                android:height="14dp">
                <shape android:shape="oval">
                    <gradient
                        android:type="linear"
                        android:angle="270"
                        android:startColor="#B3FFFFFF"
                        android:endColor="#00FFFFFF" />
                </shape>
            </item>
        </layer-list>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_mic_center.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_mic_muted.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <layer-list>
            <item>
                <shape android:shape="oval">
                    <gradient
                        android:type="radial"
                        android:gradientRadius="36dp"
                        android:startColor="#F87171"
                        android:centerColor="#DC2626"
                        android:endColor="#991B1B" />
                    <stroke
                        android:width="2dp"
                        android:color="#E6FFFFFF" />
                </shape>
            </item>
            <item
                android:top="3dp"
                android:left="12dp"
                android:right="12dp"
                android:height="14dp">
                <shape android:shape="oval">
                    <gradient
                        android:type="linear"
                        android:angle="270"
                        android:startColor="#B3FFFFFF"
                        android:endColor="#00FFFFFF" />
                </shape>
            </item>
        </layer-list>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_mic_muted.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_orb_halo.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="160dp"
        android:startColor="#1F5B8CFF"
        android:centerColor="#0D8B5CF6"
        android:endColor="#00000000" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_orb_halo.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_pill_button.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="24dp" />
            <gradient
                android:type="linear"
                android:angle="135"
                android:startColor="?attr/themeAccent1"
                android:endColor="?attr/themeAccent2" />
            <stroke
                android:width="1.2dp"
                android:color="#40FFFFFF" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_pill_button.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_row_item.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="?attr/themeAccentLight">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="16dp" />
            <solid android:color="@android:color/transparent" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_row_item.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_social_btn.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="?attr/themeAccentLight">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="16dp" />
            <gradient
                android:type="linear"
                android:angle="135"
                android:startColor="?attr/themeCardGlassStart"
                android:endColor="?attr/themeCardGlassEnd" />
            <stroke
                android:width="1.2dp"
                android:color="?attr/themeCardBorder" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_social_btn.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_status_badge.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="14dp" />
    <gradient
        android:type="linear"
        android:angle="135"
        android:startColor="?attr/themeChipBg"
        android:endColor="?attr/themeCardGlassEnd" />
    <stroke
        android:width="1.2dp"
        android:color="?attr/themeCardBorder" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_status_badge.xml ===


=== FILE: app/src/main/res/drawable/bg_jarvis_status_badge_green.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="10dp" />
    <solid android:color="#1A10B981" />
    <stroke
        android:width="1dp"
        android:color="#4D10B981" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_jarvis_status_badge_green.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_dark_1.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="140dp"
        android:startColor="#335B8CFF"
        android:centerColor="#145B8CFF"
        android:endColor="#005B8CFF" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_dark_1.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_dark_2.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="130dp"
        android:startColor="#26A78BFA"
        android:centerColor="#0FA78BFA"
        android:endColor="#00A78BFA" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_dark_2.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_dark_3.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="140dp"
        android:startColor="#2022D3EE"
        android:centerColor="#0C22D3EE"
        android:endColor="#0022D3EE" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_dark_3.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_light_1.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="140dp"
        android:startColor="#262F6BFF"
        android:centerColor="#102F6BFF"
        android:endColor="#002F6BFF" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_light_1.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_light_2.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="130dp"
        android:startColor="#208B5CF6"
        android:centerColor="#0D8B5CF6"
        android:endColor="#008B5CF6" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_light_2.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_light_3.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="140dp"
        android:startColor="#1A06B6D4"
        android:centerColor="#0B06B6D4"
        android:endColor="#0006B6D4" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_light_3.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_red_1.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="140dp"
        android:startColor="#33FF4D5E"
        android:centerColor="#14FF4D5E"
        android:endColor="#00FF4D5E" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_red_1.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_red_2.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="130dp"
        android:startColor="#26FB7185"
        android:centerColor="#0FFB7185"
        android:endColor="#00FB7185" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_red_2.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_red_3.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="140dp"
        android:startColor="#20F97316"
        android:centerColor="#0CF97316"
        android:endColor="#00F97316" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_red_3.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_sunset_1.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="140dp"
        android:startColor="#26FF6A3D"
        android:centerColor="#10FF6A3D"
        android:endColor="#00FF6A3D" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_sunset_1.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_sunset_2.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="130dp"
        android:startColor="#20F43F5E"
        android:centerColor="#0DF43F5E"
        android:endColor="#00F43F5E" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_sunset_2.xml ===


=== FILE: app/src/main/res/drawable/bg_liquid_glow_sunset_3.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="140dp"
        android:startColor="#1A8B5CF6"
        android:centerColor="#0B8B5CF6"
        android:endColor="#008B5CF6" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_liquid_glow_sunset_3.xml ===


=== FILE: app/src/main/res/drawable/bg_naira_avatar.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="18dp" />
    <solid android:color="#EFF6FF" />
    <stroke
        android:width="1.5dp"
        android:color="#2563EB" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_naira_avatar.xml ===


=== FILE: app/src/main/res/drawable/bg_naira_card.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="20dp" />
    <solid android:color="?attr/themeCardBg" />
    <stroke
        android:width="1dp"
        android:color="?attr/themeCardBorder" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_naira_card.xml ===


=== FILE: app/src/main/res/drawable/bg_naira_chat_assistant.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners
        android:topLeftRadius="20dp"
        android:topRightRadius="20dp"
        android:bottomLeftRadius="6dp"
        android:bottomRightRadius="20dp" />
    <solid android:color="#FFFFFF" />
    <stroke
        android:width="1dp"
        android:color="#E2E8F0" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_naira_chat_assistant.xml ===


=== FILE: app/src/main/res/drawable/bg_naira_chat_user.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners
        android:topLeftRadius="20dp"
        android:topRightRadius="20dp"
        android:bottomLeftRadius="20dp"
        android:bottomRightRadius="6dp" />
    <solid android:color="#2563EB" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_naira_chat_user.xml ===


=== FILE: app/src/main/res/drawable/bg_naira_chip.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#20000000">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="18dp" />
            <solid android:color="?attr/themeChipBg" />
            <stroke
                android:width="1dp"
                android:color="?attr/themeCardBorder" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_naira_chip.xml ===


=== FILE: app/src/main/res/drawable/bg_naira_dock.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="36dp" />
    <solid android:color="?attr/themeDockBg" />
    <stroke
        android:width="1.2dp"
        android:color="?attr/themeDockBorder" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_naira_dock.xml ===


=== FILE: app/src/main/res/drawable/bg_naira_icon_square.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#20000000">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="14dp" />
            <solid android:color="?attr/themeCardBg" />
            <stroke
                android:width="1dp"
                android:color="?attr/themeCardBorder" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_naira_icon_square.xml ===


=== FILE: app/src/main/res/drawable/bg_naira_mic_center.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="oval">
            <gradient
                android:type="radial"
                android:gradientRadius="38dp"
                android:startColor="#3B82F6"
                android:endColor="#1D4ED8" />
            <stroke
                android:width="2dp"
                android:color="#FFFFFF" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_naira_mic_center.xml ===


=== FILE: app/src/main/res/drawable/bg_naira_pill_button.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#33FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="24dp" />
            <solid android:color="#0F172A" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_naira_pill_button.xml ===


=== FILE: app/src/main/res/drawable/bg_naira_social_btn.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#20000000">
    <item>
        <shape android:shape="rectangle">
            <corners android:radius="16dp" />
            <solid android:color="#FFFFFF" />
            <stroke
                android:width="1dp"
                android:color="#E2E8F0" />
        </shape>
    </item>
</ripple>
```
=== END FILE: app/src/main/res/drawable/bg_naira_social_btn.xml ===


=== FILE: app/src/main/res/drawable/bg_test_result.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="@color/bg_input" />
    <corners android:radius="12dp" />
    <stroke
        android:width="1dp"
        android:color="@color/border_subtle" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_test_result.xml ===


=== FILE: app/src/main/res/drawable/bg_user_bubble.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners
        android:topLeftRadius="16dp"
        android:topRightRadius="16dp"
        android:bottomLeftRadius="16dp"
        android:bottomRightRadius="4dp" />
    <solid android:color="#2B0A11" />
    <stroke
        android:width="1dp"
        android:color="#591422" />
</shape>
```
=== END FILE: app/src/main/res/drawable/bg_user_bubble.xml ===


=== FILE: app/src/main/res/drawable/circle_cyan.xml ===
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="@color/primary_cyan" />
</shape>
```
=== END FILE: app/src/main/res/drawable/circle_cyan.xml ===


=== FILE: app/src/main/res/drawable/ic_arrow_right.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="20dp"
    android:height="20dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/text_subtle"
        android:pathData="M8.59,16.59L13.17,12 8.59,7.41 10,6l6,6 -6,6 -1.41,-1.41z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_arrow_right.xml ===


=== FILE: app/src/main/res/drawable/ic_back.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
  <path
      android:fillColor="#F4F4F6"
      android:pathData="M20,11H7.83l5.59,-5.59L12,4l-8,8 8,8 1.41,-1.41L7.83,13H20v-2z"/>
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_back.xml ===


=== FILE: app/src/main/res/drawable/ic_chat_bubble.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M20,2H4C2.9,2 2,2.9 2,4v18l4,-4h14c1.1,0 2,-0.9 2,-2V4C22,2.9 21.1,2 20,2zM7,9h2v2H7V9zm4,0h2v2h-2V9zm4,0h2v2h-2V9z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_chat_bubble.xml ===


=== FILE: app/src/main/res/drawable/ic_checklist_tasks.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="20dp"
    android:height="20dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M19,3H5C3.89,3 3,3.9 3,5v14c0,1.1 0.89,2 2,2h14c1.1,0 2,-0.9 2,-2V5C21,3.9 20.1,3 19,3zM10,17l-5,-5 1.41,-1.41L10,14.17l7.59,-7.59L19,8l-9,9z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_checklist_tasks.xml ===


=== FILE: app/src/main/res/drawable/ic_close.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
  <path
      android:fillColor="#FFFFFFFF"
      android:pathData="M19,6.41L17.59,5 12,10.59 6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 12,13.41 17.59,19 19,17.59 13.41,12z"/>
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_close.xml ===


=== FILE: app/src/main/res/drawable/ic_code_chip.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="20dp"
    android:height="20dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_text_pink"
        android:pathData="M9.4,16.6L4.8,12l4.6,-4.6L8,6l-6,6 6,6 1.4,-1.4zM14.6,16.6l4.6,-4.6 -4.6,-4.6L16,6l6,6 -6,6 -1.4,-1.4z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_code_chip.xml ===


=== FILE: app/src/main/res/drawable/ic_copy.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="18dp"
    android:height="18dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_text_muted"
        android:pathData="M16,1H4C2.9,1 2,1.9 2,3v14h2V3h12V1zm3,4H8C6.9,5 6,5.9 6,7v14c0,1.1 0.9,2 2,2h11c1.1,0 2,-0.9 2,-2V7c0,-1.1 -0.9,-2 -2,-2zm0,16H8V7h11v14z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_copy.xml ===


=== FILE: app/src/main/res/drawable/ic_delete.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
  <path
      android:fillColor="#FF1744"
      android:pathData="M6,19c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V7H6v12zM19,4h-3.5l-1,-1h-5l-1,1H5v2h14V4z"/>
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_delete.xml ===


=== FILE: app/src/main/res/drawable/ic_edit.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="18dp"
    android:height="18dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_text_muted"
        android:pathData="M3,17.25V21h3.75L17.81,9.94l-3.75,-3.75L3,17.25zM20.71,7.04c0.39,-0.39 0.39,-1.02 0,-1.41l-2.34,-2.34c-0.39,-0.39 -1.02,-0.39 -1.41,0l-1.83,1.83 3.75,3.75 1.83,-1.83z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_edit.xml ===


=== FILE: app/src/main/res/drawable/ic_menu.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_text_pink"
        android:pathData="M3,18h18v-2H3v2zm0,-5h18v-2H3v2zm0,-7v2h18V6H3z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_menu.xml ===


=== FILE: app/src/main/res/drawable/ic_mic_jarvis.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M12,14c1.66,0 3,-1.34 3,-3V5c0,-1.66 -1.34,-3 -3,-3S9,3.34 9,5v6c0,1.66 1.34,3 3,3zM17.3,11c0,3 -2.54,5.1 -5.3,5.1S6.7,14 6.7,11H5c0,3.41 2.72,6.23 6,6.72V21h2v-3.28c3.28,-0.48 6,-3.3 6,-6.72h-1.7z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_mic_jarvis.xml ===


=== FILE: app/src/main/res/drawable/ic_mic_mute_jarvis.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M19,11h-1.7c0,0.74 -0.16,1.43 -0.43,2.05l1.23,1.23c0.56,-0.98 0.9,-2.09 0.9,-3.28zM14.28,14.28l1.43,1.43c0.82,-0.51 1.49,-1.24 1.95,-2.11L16.2,12.5c-0.34,0.67 -0.84,1.24 -1.45,1.65l-0.47,0.13zM12,4c0.55,0 1,0.45 1,1v5.17l1.9,1.9c0.06,-0.34 0.1,-0.7 0.1,-1.07V5c0,-1.66 -1.34,-3 -3,-3c-1.54,0 -2.81,1.16 -2.98,2.65l2.1,2.1C11.18,4.27 11.56,4 12,4zM4.41,2.86L3,4.27l5.68,5.68V11c0,1.66 1.34,3 3,3c0.41,0 0.8,-0.08 1.15,-0.23l1.86,1.86C13.79,15.89 12.93,16 12,16c-3.28,0 -6,-2.46 -6,-5.5H4.3c0,3.34 2.51,6.09 5.7,6.46V21h4v-4.04c1.17,-0.14 2.27,-0.57 3.22,-1.24l2.81,2.81 1.41,-1.41L4.41,2.86z"/>
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_mic_mute_jarvis.xml ===


=== FILE: app/src/main/res/drawable/ic_mic_mute_naira.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M19,11h-1.7c0,0.74 -0.16,1.43 -0.43,2.05l1.23,1.23c0.56,-0.98 0.9,-2.09 0.9,-3.28zM14.28,14.28l1.43,1.43c0.82,-0.51 1.49,-1.24 1.95,-2.11L16.2,12.5c-0.34,0.67 -0.84,1.24 -1.45,1.65l-0.47,0.13zM12,4c0.55,0 1,0.45 1,1v5.17l1.9,1.9c0.06,-0.34 0.1,-0.7 0.1,-1.07V5c0,-1.66 -1.34,-3 -3,-3c-1.54,0 -2.81,1.16 -2.98,2.65l2.1,2.1C11.18,4.27 11.56,4 12,4zM4.41,2.86L3,4.27l5.68,5.68V11c0,1.66 1.34,3 3,3c0.41,0 0.8,-0.08 1.15,-0.23l1.86,1.86C13.79,15.89 12.93,16 12,16c-3.28,0 -6,-2.46 -6,-5.5H4.3c0,3.34 2.51,6.09 5.7,6.46V21h4v-4.04c1.17,-0.14 2.27,-0.57 3.22,-1.24l2.81,2.81 1.41,-1.41L4.41,2.86z"/>
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_mic_mute_naira.xml ===


=== FILE: app/src/main/res/drawable/ic_mic_naira.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M12,14c1.66,0 3,-1.34 3,-3V5c0,-1.66 -1.34,-3 -3,-3S9,3.34 9,5v6c0,1.66 1.34,3 3,3zM17.3,11c0,3 -2.54,5.1 -5.3,5.1S6.7,14 6.7,11H5c0,3.41 2.72,6.23 6,6.72V21h2v-3.28c3.28,-0.48 6,-3.3 6,-6.72h-1.7z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_mic_naira.xml ===


=== FILE: app/src/main/res/drawable/ic_nav_bell.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_text_pink"
        android:pathData="M12,22c1.1,0 2,-0.9 2,-2h-4c0,1.1 0.9,2 2,2zM18,16v-5c0,-3.07 -1.63,-5.64 -4.5,-6.32V4c0,-0.83 -0.67,-1.5 -1.5,-1.5s-1.5,0.67 -1.5,1.5v0.68C7.64,5.36 6,7.92 6,11v5l-2,2v1h16v-1l-2,-2zM16,17H8v-6c0,-2.48 1.51,-4.5 4,-4.5s4,2.02 4,4.5v6z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_nav_bell.xml ===


=== FILE: app/src/main/res/drawable/ic_nav_chat.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/text_subtle"
        android:pathData="M20,2H4C2.9,2 2,2.9 2,4v18l4,-4h14c1.1,0 2,-0.9 2,-2V4C22,2.9 21.1,2 20,2zM6,9h12v2H6V9zm0,4h8v2H6v-2z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_nav_chat.xml ===


=== FILE: app/src/main/res/drawable/ic_nav_home.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M10,20v-6h4v6h5v-8h3L12,3 2,12h3v8z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_nav_home.xml ===


=== FILE: app/src/main/res/drawable/ic_nav_settings.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_text_pink"
        android:pathData="M19.14,12.94c0.04,-0.3 0.06,-0.61 0.06,-0.94 0,-0.32 -0.02,-0.64 -0.07,-0.94l2.03,-1.58c0.18,-0.14 0.23,-0.41 0.12,-0.61l-1.92,-3.32c-0.12,-0.22 -0.37,-0.29 -0.59,-0.22l-2.39,0.96c-0.5,-0.38 -1.03,-0.7 -1.62,-0.94L14.4,2.81c-0.04,-0.24 -0.24,-0.41 -0.48,-0.41h-3.84c-0.24,0 -0.43,0.17 -0.47,0.41L9.25,5.35C8.66,5.59 8.12,5.92 7.63,6.29L5.24,5.33c-0.22,-0.08 -0.47,0 -0.59,0.22L2.74,8.87c-0.12,0.21 -0.08,0.47 0.12,0.61l2.03,1.58C4.84,11.36 4.8,11.69 4.8,12s0.02,0.64 0.07,0.94l-2.03,1.58c-0.18,0.14 -0.23,0.41 -0.12,0.61l1.92,3.32c0.12,0.22 0.37,0.29 0.59,0.22l2.39,-0.96c0.5,0.38 1.03,0.7 1.62,0.94l0.36,2.54c0.05,0.24 0.24,0.41 0.48,0.41h3.84c0.24,0 0.44,-0.17 0.47,-0.41l0.36,-2.54c0.59,-0.24 1.13,-0.56 1.62,-0.94l2.39,0.96c0.22,0.08 0.47,0 0.59,-0.22l1.92,-3.32c0.12,-0.22 0.07,-0.47 -0.12,-0.61L19.14,12.94zM12,15.6c-1.98,0 -3.6,-1.62 -3.6,-3.6s1.62,-3.6 3.6,-3.6 3.6,1.62 3.6,3.6 -1.62,3.6 -3.6,3.6z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_nav_settings.xml ===


=== FILE: app/src/main/res/drawable/ic_plus.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="22dp"
    android:height="22dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_text_pink"
        android:pathData="M19,13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_plus.xml ===


=== FILE: app/src/main/res/drawable/ic_screen_share.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M21,3H3c-1.1,0 -2,0.9 -2,2v12c0,1.1 0.9,2 2,2h7v2H8v2h8v-2h-2v-2h7c1.1,0 2,-0.9 2,-2V5c0,-1.1 -0.9,-2 -2,-2zM21,17H3V5h18v12zM8,8v6l5,-3zM14,8v6l5,-3z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_screen_share.xml ===


=== FILE: app/src/main/res/drawable/ic_send_up.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M4,12l1.41,1.41L11,7.83V20h2V7.83l5.58,5.59L20,12l-8,-8 -8,8z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_send_up.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_apps.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M4,11h5V4H4v7zM4,20h5v-7H4v7zM13,20h7v-7h-7v7zM13,4v7h7V4h-7z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_apps.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_book.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M21,5c-1.11,-0.35 -2.33,-0.5 -3.5,-0.5 -1.95,0 -4.05,0.4 -5.5,1.5 -1.45,-1.1 -3.55,-1.5 -5.5,-1.5 -1.95,0 -4.05,0.4 -5.5,1.5v14.65c0,0.25 0.25,0.5 0.5,0.5 0.1,0 0.15,-0.05 0.25,-0.05C3.2,20.4 5.05,20 6.5,20c1.95,0 4.05,0.4 5.5,1.5 1.35,-0.85 3.8,-1.5 5.5,-1.5 1.65,0 3.35,0.3 4.75,1.05 0.1,0.05 0.15,0.05 0.25,0.05 0.25,0 0.5,-0.25 0.5,-0.5V6c-0.6,-0.45 -1.25,-0.75 -2,-1zM19,18.5c-1.1,-0.35 -2.3,-0.5 -3.5,-0.5 -1.7,0 -4.15,0.65 -5.5,1.5V8c1.35,-0.85 3.8,-1.5 5.5,-1.5 1.2,0 2.4,0.15 3.5,0.5v11.5z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_book.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_db.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M12,2C6.48,2 2,3.34 2,5v14c0,1.66 4.48,3 10,3s10,-1.34 10,-3V5c0,-1.66 -4.48,-3 -10,-3zM12,4c4.42,0 8,0.89 8,2s-3.58,2 -8,2 -8,-0.89 -8,-2 3.58,-2 8,-2zM20,19c0,1.11 -3.58,2 -8,2s-8,-0.89 -8,-2v-2.35c1.99,0.86 4.86,1.35 8,1.35s6.01,-0.49 8,-1.35V19zM20,14.35c-1.99,0.86 -4.86,1.35 -8,1.35s-6.01,-0.49 -8,-1.35V12c1.99,0.86 4.86,1.35 8,1.35s6.01,-0.49 8,-1.35v2.35zM20,9.35c-1.99,0.86 -4.86,1.35 -8,1.35s-6.01,-0.49 -8,-1.35V7c1.99,0.86 4.86,1.35 8,1.35s6.01,-0.49 8,-1.35v2.35z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_db.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_language.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
  <path
      android:fillColor="@android:color/white"
      android:pathData="M11.99,2C6.47,2 2,6.48 2,12s4.47,10 9.99,10C17.52,22 22,17.52 22,12S17.52,2 11.99,2zM17.92,7h-2.54c-0.28,-1.2 -0.71,-2.32 -1.26,-3.28C15.82,4.42 17.15,5.55 17.92,7zM12,4.04c0.83,1.2 1.48,2.53 1.91,3.96h-3.82c0.43,-1.43 1.08,-2.76 1.91,-3.96zM4.26,14C4.1,13.36 4,12.69 4,12s0.1,-1.36 0.26,-2h3.38c-0.08,0.66 -0.14,1.32 -0.14,2s0.06,1.34 0.14,2H4.26zM5.58,16h2.88c0.28,1.2 0.71,2.32 1.26,3.28C7.99,18.77 6.64,17.54 5.58,16zM8.46,7H5.58C6.64,5.46 7.99,4.23 9.72,3.72C9.17,4.68 8.74,5.8 8.46,7zM12,19.96c-0.83,-1.2 -1.48,-2.53 -1.91,-3.96h3.82c-0.43,1.43 -1.08,2.76 -1.91,3.96zM14.34,14H9.66c-0.09,-0.66 -0.16,-1.32 -0.16,-2s0.07,-1.34 0.16,-2h4.68c0.09,0.66 0.16,1.32 0.16,2s-0.07,1.34 -0.16,2zM14.28,19.28c0.55,-0.96 0.98,-2.08 1.26,-3.28h2.88c-1.06,1.54 -2.41,2.77 -4.14,3.28zM16.36,14c0.08,-0.66 0.14,-1.32 0.14,-2s-0.06,-1.34 -0.14,-2h3.38c0.16,0.64 0.26,1.31 0.26,2s-0.1,1.36 -0.26,2h-3.38z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_language.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_lock.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M18,8h-1V6c0,-2.76 -2.24,-5 -5,-5S7,3.24 7,6v2H6c-1.1,0 -2,0.9 -2,2v10c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V10c0,-1.1 -0.9,-2 -2,-2zM9,6c0,-1.66 1.34,-3 3,-3s3,1.34 3,3v2H9V6zm9,14H6V10h12v10zm-6,-3c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_lock.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_orb.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM12,20c-4.41,0 -8,-3.59 -8,-8s3.59,-8 8,-8 8,3.59 8,8 -3.59,8 -8,8z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_orb.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_owner_voice.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
  <path
      android:fillColor="@android:color/white"
      android:pathData="M12,1c-2.76,0 -5,2.24 -5,5v6c0,2.76 2.24,5 5,5s5,-2.24 5,-5V6c0,-2.76 -2.24,-5 -5,-5zM10,6c0,-1.1 0.9,-2 2,-2s2,0.9 2,2v6c0,1.1 -0.9,2 -2,2s-2,-0.9 -2,-2V6zM19,11c0,3.53 -2.61,6.43 -6,6.92V21h4c0.55,0 1,0.45 1,1s-0.45,1 -1,1H7c-0.55,0 -1,-0.45 -1,-1s0.45,-1 1,-1h4v-3.08C7.61,17.43 5,14.53 5,11c0,-0.55 0.45,-1 1,-1s1,0.45 1,1c0,2.76 2.24,5 5,5s5,-2.24 5,-5c0,-0.55 0.45,-1 1,-1s1,0.45 1,1z" />
  <path
      android:fillColor="@android:color/white"
      android:pathData="M2,11c0,-0.55 0.45,-1 1,-1s1,0.45 1,1c0,4.41 3.59,8 8,8s8,-3.59 8,-8c0,-0.55 0.45,-1 1,-1s1,0.45 1,1c0,5.19 -3.95,9.48 -9,9.95V21h-2v-0.05C4.95,20.48 2,16.19 2,11z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_owner_voice.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_palette.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M12,3c-4.97,0 -9,4.03 -9,9 0,2.12 0.74,4.07 1.97,5.61L4.35,18.23c-0.39,0.39 -0.39,1.02 0,1.41 0.39,0.39 1.02,0.39 1.41,0l0.72,-0.72C8.01,19.64 9.92,20.2 12,20.2c4.97,0 9,-4.03 9,-9 0,-4.97 -4.03,-9 -9,-9zM6.5,12c-0.83,0 -1.5,-0.67 -1.5,-1.5S5.67,9 6.5,9 8,9.67 8,10.5 7.33,12 6.5,12zM9.5,8C8.67,8 8,7.33 8,6.5S8.67,5 9.5,5s1.5,0.67 1.5,1.5S10.33,8 9.5,8zM14.5,8c-0.83,0 -1.5,-0.67 -1.5,-1.5S13.67,5 14.5,5s1.5,0.67 1.5,1.5S15.33,8 14.5,8zM17.5,12c-0.83,0 -1.5,-0.67 -1.5,-1.5s0.67,-1.5 1.5,-1.5 1.5,0.67 1.5,1.5 -0.67,1.5 -1.5,1.5z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_palette.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_plug.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M16,9V4l-1,0V1h-2v3h-2V1H9v3l-1,0v5c0,1.66 1.34,3 3,3v3H7v2h4v7h2v-7h4v-2h-4v-3c1.66,0 3,-1.34 3,-3z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_plug.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_shield.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M12,1L3,5v6c0,5.55 3.84,10.74 9,12 5.16,-1.26 9,-6.45 9,-12V5l-9,-4zM10,17l-4,-4 1.41,-1.41L10,14.17l6.59,-6.59L18,9l-8,8z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_shield.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_silent.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
  <path
      android:fillColor="@android:color/white"
      android:pathData="M16.5,12c0,-1.77 -1.02,-3.29 -2.5,-4.03v2.21l2.45,2.45c0.03,-0.2 0.05,-0.41 0.05,-0.63zM19,12c0,0.94 -0.2,1.82 -0.54,2.64l1.51,1.51C20.63,14.91 21,13.5 21,12c0,-4.28 -2.99,-7.86 -7,-8.77v2.06c2.89,0.86 5,3.54 5,6.71zM4.27,3L3,4.27l4.73,4.73H3v6h4l5,5v-6.73l4.25,4.25c-0.67,0.52 -1.42,0.93 -2.25,1.18v2.06c1.38,-0.31 2.63,-0.95 3.69,-1.81L19.73,21 21,19.73l-9,-9L4.27,3zM12,4L9.91,6.09 12,8.18V4z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_silent.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_voice.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M11.99,2C6.47,2 2,6.48 2,12s4.47,10 9.99,10C17.52,22 22,17.52 22,12S17.52,2 11.99,2zM12,20c-4.42,0 -8,-3.58 -8,-8s3.58,-8 8,-8 8,3.58 8,8 -3.58,8 -8,8zM15.5,11c0.83,0 1.5,-0.67 1.5,-1.5S16.33,8 15.5,8 14,8.67 14,9.5s0.67,1.5 1.5,1.5zM8.5,11c0.83,0 1.5,-0.67 1.5,-1.5S9.33,8 8.5,8 7,8.67 7,9.5 7.67,11 8.5,11zM12,17.5c2.33,0 4.31,-1.46 5.11,-3.5H6.89c0.8,2.04 2.78,3.5 5.11,3.5z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_voice.xml ===


=== FILE: app/src/main/res/drawable/ic_settings_wave.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M12,3v18h2V3h-2zM8,6v12h2V6H8zM4,9v6h2V9H4zM16,6v12h2V6h-2zM20,9v6h2V9h-2z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_settings_wave.xml ===


=== FILE: app/src/main/res/drawable/ic_social_instagram.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="22dp"
    android:height="22dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M12,2.163c3.204,0 3.584,0.012 4.85,0.07 3.252,0.148 4.771,1.691 4.919,4.919 0.058,1.265 0.069,1.645 0.069,4.849 0,3.205 -0.012,3.584 -0.069,4.849 -0.149,3.225 -1.664,4.771 -4.919,4.919 -1.266,0.058 -1.644,0.07 -4.85,0.07 -3.204,0 -3.584,-0.012 -4.849,-0.07 -3.26,-0.149 -4.771,-1.699 -4.919,-4.92 -0.058,-1.265 -0.07,-1.644 -0.07,-4.849 0,-3.204 0.013,-3.583 0.07,-4.849 0.149,-3.227 1.664,-4.771 4.919,-4.919 1.266,-0.057 1.645,-0.069 4.849,-0.069M12,0C8.741,0 8.333,0.014 7.053,0.072 2.695,0.272 0.273,2.69 0.073,7.052 0.014,8.333 0,8.741 0,12c0,3.259 0.014,3.668 0.072,4.948 0.2,4.358 2.618,6.78 6.98,6.98 1.281,0.058 1.689,0.072 4.948,0.072 3.259,0 3.668,-0.014 4.948,-0.072 4.354,-0.2 6.782,-2.618 6.979,-6.98 0.059,-1.28 0.073,-1.689 0.073,-4.948 0,-3.259 -0.014,-3.667 -0.072,-4.947 -0.196,-4.354 -2.617,-6.78 -6.979,-6.98C15.668,0.014 15.259,0 12,0zm0,5.838a6.162,6.162 0,1 0,0 12.324,6.162 6.162 0,0 0,0 -12.324zM12,16a4,4 0,1 1,0 -8,4 4,0 0 1,0 8zm6.406,-11.845a1.44,1.44 0,1 0,0 2.881,1.44 1.44 0,0 0,0 -2.881z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_social_instagram.xml ===


=== FILE: app/src/main/res/drawable/ic_social_pinterest.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="22dp"
    android:height="22dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M12,0C5.37,0 0,5.37 0,12c0,5.08 3.16,9.43 7.63,11.18 -0.1,-0.95 -0.2,-2.4 0.04,-3.44l1.46,-6.18s-0.37,-0.75 -0.37,-1.85c0,-1.73 1,-3.03 2.26,-3.03 1.06,0 1.58,0.8 1.58,1.76 0,1.07 -0.68,2.67 -1.04,4.15 -0.3,1.25 0.63,2.27 1.86,2.27 2.23,0 3.95,-2.35 3.95,-5.75 0,-3.01 -2.16,-5.11 -5.25,-5.11 -3.58,0 -5.68,2.68 -5.68,5.45 0,1.08 0.42,2.24 0.94,2.87 0.1,0.13 0.12,0.24 0.09,0.37l-0.35,1.43c-0.06,0.23 -0.19,0.28 -0.44,0.17 -1.64,-0.76 -2.66,-3.16 -2.66,-5.08 0,-4.14 3.01,-7.94 8.67,-7.94 4.55,0 8.09,3.24 8.09,7.58 0,4.52 -2.85,8.16 -6.81,8.16 -1.33,0 -2.58,-0.69 -3.01,-1.5l-0.82,3.13c-0.3,1.15 -1.1,2.59 -1.64,3.46 1.25,0.39 2.58,0.6 3.96,0.6 6.63,0 12,-5.37 12,-12S18.63,0 12,0z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_social_pinterest.xml ===


=== FILE: app/src/main/res/drawable/ic_social_telegram.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="22dp"
    android:height="22dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M2.01,21L23,12 2.01,3 2,10l15,2 -15,2z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_social_telegram.xml ===


=== FILE: app/src/main/res/drawable/ic_social_youtube.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="22dp"
    android:height="22dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M21.58,7.19c-0.23,-0.86 -0.91,-1.54 -1.77,-1.77C18.25,5 12,5 12,5s-6.25,0 -7.81,0.42c-0.86,0.23 -1.54,0.91 -1.77,1.77C2,8.75 2,12 2,12s0,3.25 0.42,4.81c0.23,0.86 0.91,1.54 1.77,1.77C5.75,19 12,19 12,19s6.25,0 7.81,-0.42c0.86,-0.23 1.54,-0.91 1.77,-1.77C22,15.25 22,12 22,12s0,-3.25 -0.42,-4.81zM10,15V9l5.2,3 -5.2,3z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_social_youtube.xml ===


=== FILE: app/src/main/res/drawable/ic_sparkle.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
  <path
      android:fillColor="@android:color/white"
      android:pathData="M19,9l1.25,-2.75L23,5l-2.75,-1.25L19,1l-1.25,2.75L15,5l2.75,1.25L19,9zM9,11l2.5,-5.5L14,11l5.5,2.5L14,16l-2.5,5.5L9,16l-5.5,-2.5L9,11zM19,15l-1.25,2.75L15,19l2.75,1.25L19,23l1.25,-2.75L23,19l-2.75,-1.25L19,15z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_sparkle.xml ===


=== FILE: app/src/main/res/drawable/ic_stack_memory.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="20dp"
    android:height="20dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M11.99,18.54l-7.37,-5.73L3,14.07l9,7 9,-7 -1.63,-1.27zM12,16l7.36,-5.73L21,9.07l-9,-7 -9,7 1.63,1.27z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_stack_memory.xml ===


=== FILE: app/src/main/res/drawable/ic_tts_play.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="18dp"
    android:height="18dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_text_muted"
        android:pathData="M8,5v14l11,-7z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_tts_play.xml ===


=== FILE: app/src/main/res/drawable/ic_user_profile.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M12,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM12,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_user_profile.xml ===


=== FILE: app/src/main/res/drawable/ic_verified_badge.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
  <path
      android:fillColor="@android:color/white"
      android:pathData="M12,1L3,5v6c0,5.55 3.84,10.74 9,12 5.16,-1.26 9,-6.45 9,-12V5l-9,-4zM10,17l-4,-4 1.41,-1.41L10,14.17l6.59,-6.59L18,9l-8,8z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_verified_badge.xml ===


=== FILE: app/src/main/res/drawable/ic_warning.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
  <path
      android:fillColor="#FFFFFFFF"
      android:pathData="M1,21h22L12,2 1,21zM13,18h-2v-2h2v2zM13,14h-2v-4h2v4z"/>
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_warning.xml ===


=== FILE: app/src/main/res/drawable/ic_weather_cloud.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#60A5FA"
        android:pathData="M19.35,10.04C18.67,6.59 15.64,4 12,4 9.11,4 6.6,5.64 5.35,8.04 2.34,8.36 0,10.91 0,14c0,3.31 2.69,6 6,6h13c2.76,0 5,-2.24 5,-5 0,-2.64 -2.05,-4.78 -4.65,-4.96z"/>
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_weather_cloud.xml ===


=== FILE: app/src/main/res/drawable/ic_weather_moon.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="26dp"
    android:height="26dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="@color/naira_red_bright"
        android:pathData="M12.3,2a10,10 0,0 0,-1.9 0.18,10 10,0 1,1 11.42,11.42A10,10 0,0 1,12.3 2z" />
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_weather_moon.xml ===


=== FILE: app/src/main/res/drawable/ic_weather_rain.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#38BDF8"
        android:pathData="M19.35,10.04C18.67,6.59 15.64,4 12,4 9.11,4 6.6,5.64 5.35,8.04 2.34,8.36 0,10.91 0,14c0,3.31 2.69,6 6,6h13c2.76,0 5,-2.24 5,-5 0,-2.64 -2.05,-4.78 -4.65,-4.96zM10,21l-2,3h2l2,-3h-2zM14,21l-2,3h2l2,-3h-2zM6,21l-2,3h2l2,-3H6z"/>
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_weather_rain.xml ===


=== FILE: app/src/main/res/drawable/ic_weather_sun.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#F59E0B"
        android:pathData="M12,7c-2.76,0 -5,2.24 -5,5s2.24,5 5,5 5,-2.24 5,-5 -2.24,-5 -5,-5zM2,13h2c0.55,0 1,-0.45 1,-1s-0.45,-1 -1,-1H2c-0.55,0 -1,0.45 -1,1s0.45,1 1,1zM20,13h2c0.55,0 1,-0.45 1,-1s-0.45,-1 -1,-1h-2c-0.55,0 -1,0.45 -1,1s0.45,1 1,1zM11,2v2c0,0.55 0.45,1 1,1s1,-0.45 1,-1V2c0,-0.55 -0.45,-1 -1,-1s-1,0.45 -1,1zM11,20v2c0,0.55 0.45,1 1,1s1,-0.45 1,-1v-2c0,-0.55 -0.45,-1 -1,-1s-1,0.45 -1,1zM5.99,4.58c-0.39,-0.39 -1.03,-0.39 -1.41,0s-0.39,1.03 0,1.41l1.06,1.06c0.39,0.39 1.03,0.39 1.41,0s0.39,-1.03 0,-1.41L5.99,4.58zM18.36,16.95c-0.39,-0.39 -1.03,-0.39 -1.41,0s-0.39,1.03 0,1.41l1.06,1.06c0.39,0.39 1.03,0.39 1.41,0s0.39,-1.03 0,-1.41l-1.06,-1.06zM7.05,18.36l-1.06,1.06c-0.39,0.39 -0.39,1.03 0,1.41s1.03,0.39 1.41,0l1.06,-1.06c0.39,-0.39 0.39,-1.03 0,-1.41s-1.02,-0.39 -1.41,0zM16.95,5.99l1.06,-1.06c0.39,-0.39 1.03,-0.39 1.41,0s0.39,1.03 0,1.41l-1.06,1.06c-0.39,0.39 -1.03,0.39 -1.41,0s-0.39,-1.02 0,-1.41z"/>
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_weather_sun.xml ===


=== FILE: app/src/main/res/drawable/ic_weather_thunder.xml ===
```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FBBF24"
        android:pathData="M19.35,10.04C18.67,6.59 15.64,4 12,4 9.11,4 6.6,5.64 5.35,8.04 2.34,8.36 0,10.91 0,14c0,3.31 2.69,6 6,6h13c2.76,0 5,-2.24 5,-5 0,-2.64 -2.05,-4.78 -4.65,-4.96zM11,19v-4h-2l4,-6v4h2l-4,6z"/>
</vector>
```
=== END FILE: app/src/main/res/drawable/ic_weather_thunder.xml ===


=== FILE: app/src/test/java/com/jarvis/assistant/automation/agent/AgentTaskEngineTest.kt ===
```kotlin
package com.jarvis.assistant.automation.agent

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentTaskEngineTest {

    @Test
    fun instagramPlanHasOrderedDependenciesAndOnlyVerifiedStepsAdvance() {
        val context = AgentTaskEngine.begin("Instagram unlike all my liked reels", "unit-test-plan")
        val initial = AgentTaskEngine.taskState.value
        assertNotNull(initial)
        assertEquals("Understand goal", initial!!.steps.first().title)
        assertEquals(TaskStepStatus.COMPLETED, initial.steps.first().status)
        assertEquals("Open Instagram", initial.steps.first { it.stepId == initial.currentStepId }.title)

        assertFalse(AgentTaskEngine.completeStepByTitle("Navigate to liked content", "page seen", verified = true))
        assertTrue(AgentTaskEngine.completeStepByTitle("Open Instagram", "foreground verified", verified = true))
        assertTrue(AgentTaskEngine.completeStepByTitle("Navigate to liked content", "liked list identified", verified = true))
        assertEquals("Observe and process matching items", AgentTaskEngine.taskState.value?.steps
            ?.first { it.stepId == AgentTaskEngine.taskState.value?.currentStepId }?.title)
        assertEquals(context.steps.size, AgentTaskEngine.taskState.value?.steps?.size)
    }

    @Test
    fun completionRequiresEvidenceAndBulkIdentitiesAreDeduplicated() {
        val context = AgentTaskEngine.begin("Instagram unlike all liked reels", "unit-test-completion")
        assertFalse(AgentTaskEngine.finish(AgentTaskEngine.State.COMPLETED))
        assertTrue(AgentTaskEngine.markItemProcessed("reel:one", verified = true))
        assertFalse(AgentTaskEngine.markItemProcessed("reel:one", verified = true))
        assertFalse(AgentTaskEngine.markItemProcessed("reel:two", verified = false))
        assertTrue(AgentTaskEngine.completeStepByTitle("Open Instagram", "foreground verified", verified = true))
        assertTrue(AgentTaskEngine.completeStepByTitle("Navigate to liked content", "liked list identified", verified = true))
        assertTrue(AgentTaskEngine.completeStepByTitle("Observe and process matching items", "one item verified", verified = true))
        assertTrue(AgentTaskEngine.completeStepByTitle("Scroll and wait for more items", "stable end observed", verified = true))
        assertTrue(AgentTaskEngine.completeStepByTitle("Verify list end and results", "final evidence recorded", verified = true))
        AgentTaskEngine.recordCompletionEvidence(AgentTaskEngine.CompletionEvidence.END_REACHED, "stable end evidence")
        assertTrue(AgentTaskEngine.finish(AgentTaskEngine.State.COMPLETED))
        val state = AgentTaskEngine.taskState.value
        assertEquals(100, state?.progressPercentage)
        assertEquals(1, state?.processedItems?.size)
        assertEquals("stable end evidence", state?.finalVerificationResult)
        assertEquals(AgentTaskEngine.State.COMPLETED.name, state?.currentStatus)
        assertEquals(context.taskId, state?.taskId)
    }

    @Test
    fun spotifyPlanTracksRealStepProgressRatherThanFakeTime() {
        AgentTaskEngine.begin("Spotify play Midnight City", "unit-test-spotify")
        var state = AgentTaskEngine.taskState.value!!
        assertEquals("Open Spotify", state.steps.first { it.stepId == state.currentStepId }.title)
        assertEquals(20, state.progressPercentage)
        assertTrue(AgentTaskEngine.completeStepByTitle("Open Spotify", "foreground verified", verified = true))
        state = AgentTaskEngine.taskState.value!!
        assertEquals("Search for the requested track", state.steps.first { it.stepId == state.currentStepId }.title)
        assertTrue(AgentTaskEngine.completeStepByTitle("Search for the requested track", "unique match found", verified = true))
        assertTrue(AgentTaskEngine.completeStepByTitle("Select one unique match", "selected", verified = true))
        assertTrue(AgentTaskEngine.completeStepByTitle("Verify playback", "playing state visible", verified = true))
        AgentTaskEngine.recordCompletionEvidence(AgentTaskEngine.CompletionEvidence.VERIFIED_GOAL, "track and playback confirmed")
        assertTrue(AgentTaskEngine.finish(AgentTaskEngine.State.COMPLETED))
        assertEquals(100, AgentTaskEngine.taskState.value?.progressPercentage)
    }

    @Test
    fun pauseAndResumeAreReflectedInTheAuthoritativeSnapshot() {
        AgentTaskEngine.begin("Open Spotify", "unit-test-pause")
        assertTrue(AgentTaskEngine.pauseTask())
        assertTrue(AgentTaskEngine.isPaused.value)
        assertEquals(AgentTaskEngine.State.PAUSED.name, AgentTaskEngine.taskState.value?.currentStatus)
        assertTrue(AgentTaskEngine.resumeTask())
        assertFalse(AgentTaskEngine.isPaused.value)
        assertEquals(AgentTaskEngine.State.OBSERVING.name, AgentTaskEngine.taskState.value?.currentStatus)
    }
}
```
=== END FILE: app/src/test/java/com/jarvis/assistant/automation/agent/AgentTaskEngineTest.kt ===


=== FILE: app/src/main/assets/ghost-avatar-v2.html ===
```html
<!DOCTYPE html>
<html lang="en" style="background:transparent">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ghost Avatar</title>
<style>
  html, body { height:100%; margin:0; }
  body { display:flex; align-items:center; justify-content:center; background:transparent; font-family:system-ui,-apple-system,"Segoe UI",sans-serif; touch-action:manipulation; }
  #root { display:flex; flex-direction:column; align-items:center; gap:16px; }
</style>
</head>
<body>
<div id="root"></div>

<script type="module">
  for (const t of ["pointermove", "mousemove", "mouseover", "touchmove"])
    window.addEventListener(t, e => { if (e.isTrusted) e.stopImmediatePropagation(); }, true);

  window.addEventListener("pointerdown", e => {
    if (!e.isTrusted) return;
    window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el) el.dispatchEvent(new PointerEvent("pointermove", {
      clientX: e.clientX, clientY: e.clientY,
      pointerId: e.pointerId, pointerType: e.pointerType, isPrimary: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  try {
    const React = (await import("https://esm.sh/react@18.3.1")).default;
    const { createRoot } = await import("https://esm.sh/react-dom@18.3.1/client?deps=react@18.3.1");
    const { BotAvatar } = await import("https://esm.sh/bot-avatars?deps=react@18.3.1,react-dom@18.3.1");
    const { createElement: h } = React;

    createRoot(document.getElementById("root")).render(
      h(BotAvatar, { type: "ghost", face: "mouth", size: 64, shading: "fabric", interactive: true })
    );
  } catch (e) {
    document.getElementById("root").textContent = "Load failed: " + e.message + " (internet check karo)";
  }
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/ghost-avatar-v2.html ===


=== FILE: app/src/main/assets/hud/index.html ===
```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" name="viewport"/>
<title>JARVIS — Mark 85 Arc Core</title>
<style>
  :root {
    --bg-void: #050102;
    --red-core: #ff1744;
    --red-glow: #ff2a4b;
    --red-deep: #7a000d;
    --red-ember: #ff5252;
    --red-bright: #ff7582;
    --gold-accent: #ffb300;
    --gold-bright: #ffe082;
    --hud-border: rgba(255, 23, 68, 0.25);
    --hud-border-bright: rgba(255, 42, 75, 0.75);
    --hud-glass: rgba(14, 3, 6, 0.82);
    --text-white: #ffffff;
    --text-muted: #c99ea6;
    --text-faint: #6e444c;
    /* Use monospace and system-ui fallback to prevent cursive system themes */
    --font-mono: "Roboto Mono", "SF Mono", "Droid Sans Mono", "Consolas", monospace;
    --font-ui: system-ui, "Roboto", -apple-system, sans-serif;
  }

  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    background-color: var(--bg-void);
    color: var(--text-white);
    font-family: var(--font-ui);
    -webkit-font-smoothing: antialiased;
    overflow: hidden;
    user-select: none;
    -webkit-user-select: none;
  }

  body {
    background: radial-gradient(circle at 50% 48%, #220207 0%, #0c0104 55%, #050102 100%);
    overscroll-behavior: none;
  }

  .gpu { transform: translateZ(0); will-change: transform; }

  /* Holographic background grid */
  .grid-bg {
    position: fixed;
    inset: 0;
    background-image:
      linear-gradient(rgba(255, 23, 68, 0.035) 1px, transparent 1px),
      linear-gradient(90deg, rgba(255, 23, 68, 0.035) 1px, transparent 1px);
    background-size: 30px 30px;
    mask-image: radial-gradient(ellipse 95% 75% at 50% 50%, black 25%, transparent 85%);
    pointer-events: none;
    z-index: 1;
  }

  /* HUD Viewport */
  #hud {
    position: relative;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    z-index: 2;
    padding: calc(44px + env(safe-area-inset-top, 0px)) 16px calc(16px + env(safe-area-inset-bottom, 0px));
  }

  /* ============================================================
     1. REDESIGNED STARK CYBER HUD HEADER
     ============================================================ */
  .header-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    height: 52px;
    padding: 0 14px;
    background: linear-gradient(180deg, rgba(22, 4, 8, 0.90) 0%, rgba(11, 2, 4, 0.75) 100%);
    border: 1px solid rgba(255, 23, 68, 0.32);
    border-radius: 16px;
    backdrop-filter: blur(24px);
    -webkit-backdrop-filter: blur(24px);
    box-shadow: 0 4px 24px rgba(0, 0, 0, 0.65), inset 0 1px 0 rgba(255, 255, 255, 0.08), inset 0 0 14px rgba(255, 23, 68, 0.10);
    position: relative;
    box-sizing: border-box;
  }

  .brand-area {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
  }

  .reactor-mini-glyph {
    position: relative;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    background: radial-gradient(circle, #ffffff 0%, #ff5252 40%, #ff1744 75%, #6a000a 100%);
    box-shadow: 0 0 10px #ff1744, 0 0 18px rgba(255, 23, 68, 0.6);
    animation: miniCorePulse 2.4s ease-in-out infinite;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  }

  .reactor-mini-glyph::after {
    content: "";
    position: absolute;
    inset: -3px;
    border-radius: 50%;
    border: 1px dashed rgba(255, 82, 82, 0.5);
  }

  @keyframes miniCorePulse {
    0%, 100% { transform: scale(1); filter: drop-shadow(0 0 4px #ff1744); }
    50% { transform: scale(1.1); filter: drop-shadow(0 0 10px #ff5252); }
  }

  .brand-text-col {
    display: flex;
    flex-direction: column;
    gap: 1px;
    line-height: 1;
  }

  .brand-title {
    font-family: var(--font-mono);
    font-size: 0.95rem;
    font-weight: 900;
    letter-spacing: 0.16em;
    color: #ffffff;
    text-shadow: 0 0 8px rgba(255, 23, 68, 0.7);
    line-height: 1;
  }

  .brand-sub {
    font-family: var(--font-mono);
    font-size: 0.52rem;
    font-weight: 800;
    letter-spacing: 0.14em;
    color: #ff8a9e;
    opacity: 0.85;
    line-height: 1;
  }

  .status-pill {
    display: flex;
    align-items: center;
    gap: 7px;
    padding: 6px 14px;
    background: rgba(255, 23, 68, 0.10);
    border: 1px solid rgba(255, 23, 68, 0.4);
    border-radius: 20px;
    font-family: var(--font-mono);
    font-size: 0.68rem;
    font-weight: 800;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    color: #ff8a9e;
    box-shadow: inset 0 0 10px rgba(255, 23, 68, 0.15), 0 0 10px rgba(255, 23, 68, 0.1);
  }

  .status-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--red-core);
    box-shadow: 0 0 8px var(--red-core);
    transition: background 0.3s, box-shadow 0.3s;
    flex-shrink: 0;
  }

  .header-actions {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .hdr-btn {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    background: rgba(255, 23, 68, 0.12);
    border: 1px solid rgba(255, 23, 68, 0.35);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ff8a9e;
    cursor: pointer;
    transition: transform 0.15s, background-color 0.2s, box-shadow 0.2s;
  }

  .hdr-btn:active {
    transform: scale(0.90);
    background: rgba(255, 23, 68, 0.3);
    box-shadow: 0 0 14px rgba(255, 23, 68, 0.6);
  }

  .hdr-btn svg {
    width: 17px;
    height: 17px;
    fill: currentColor;
  }

  /* ============================================================
     2. MASSIVE UPGRADED STARK ARC REACTOR CORE (340px)
     ============================================================ */
  .orb-center-stage {
    position: relative;
    width: 100%;
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    pointer-events: auto;
  }

  .reactor-housing {
    position: relative;
    width: 330px;
    height: 330px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
  }

  /* Full Vector Arc Reactor SVG Elements */
  .reactor-svg-rings {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
  }

  /* Ring 1: Caliper Ring */
  .ring-calipers {
    transform-origin: 165px 165px;
    animation: rotateClockwise 36s linear infinite;
  }

  /* Ring 2: 10 Palladium / Energy Coils */
  .ring-coils {
    transform-origin: 165px 165px;
    animation: rotateCounterClockwise 24s linear infinite;
  }

  /* Ring 3: Fine Inner Dashed Track */
  .ring-inner-track {
    transform-origin: 165px 165px;
    animation: rotateClockwise 14s linear infinite;
  }

  @keyframes rotateClockwise {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }

  @keyframes rotateCounterClockwise {
    from { transform: rotate(360deg); }
    to { transform: rotate(0deg); }
  }

  /* Outer Energy Plasma Flare (Diffuse Bloom) */
  .arc-plasma-bloom {
    position: absolute;
    width: 250px;
    height: 250px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(255, 23, 68, 0.45) 0%, rgba(255, 23, 68, 0.15) 55%, transparent 75%);
    filter: blur(28px);
    pointer-events: none;
    transition: transform 0.2s, opacity 0.3s;
  }

  /* The Multi-Layer Fusion Core */
  .arc-fusion-core {
    position: relative;
    width: 172px;
    height: 172px;
    border-radius: 50%;
    background: radial-gradient(circle at 45% 45%, #ff5252 0%, #ff1744 38%, #b71c1c 72%, #320005 100%);
    box-shadow:
      0 0 35px rgba(255, 23, 68, 0.95),
      0 0 85px rgba(255, 23, 68, 0.55),
      inset 0 0 30px rgba(255, 255, 255, 0.55);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: transform 0.15s ease-out, box-shadow 0.15s ease-out;
    z-index: 10;
  }

  /* Palladium Segment Bevel Ring */
  .arc-fusion-core::before {
    content: "";
    position: absolute;
    inset: 10px;
    border-radius: 50%;
    border: 2.5px solid rgba(255, 255, 255, 0.7);
    background: radial-gradient(circle, rgba(255, 255, 255, 0.85) 0%, rgba(255, 138, 158, 0.4) 30%, transparent 68%);
    filter: blur(1.5px);
  }

  /* Central Fusion Star Nucleus */
  .arc-nucleus {
    position: relative;
    width: 68px;
    height: 68px;
    border-radius: 50%;
    background: radial-gradient(circle, #ffffff 0%, #fff59d 30%, #ff8a9e 65%, #ff1744 100%);
    box-shadow:
      0 0 25px #ffffff,
      0 0 50px #ff5252,
      0 0 90px rgba(255, 23, 68, 0.85);
    z-index: 15;
    transition: transform 0.15s ease-out;
  }

  /* 8 Radial Magnetic Caliper Vents inside Core */
  .caliper-vent {
    position: absolute;
    width: 4px;
    height: 18px;
    background: linear-gradient(180deg, #ffffff 0%, #ff1744 100%);
    border-radius: 2px;
    box-shadow: 0 0 8px #ff1744;
    z-index: 12;
  }
  .cv-1 { transform: rotate(0deg) translateY(-60px); }
  .cv-2 { transform: rotate(45deg) translateY(-60px); }
  .cv-3 { transform: rotate(90deg) translateY(-60px); }
  .cv-4 { transform: rotate(135deg) translateY(-60px); }
  .cv-5 { transform: rotate(180deg) translateY(-60px); }
  .cv-6 { transform: rotate(225deg) translateY(-60px); }
  .cv-7 { transform: rotate(270deg) translateY(-60px); }
  .cv-8 { transform: rotate(315deg) translateY(-60px); }

  /* Subtitle text under the orb in clean monospace */
  .orb-caption {
    margin-top: 26px;
    font-family: var(--font-mono);
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.22em;
    text-transform: uppercase;
    color: var(--text-muted);
    text-shadow: 0 0 10px rgba(255, 23, 68, 0.4);
    transition: color 0.3s;
  }

  /* ============================================================
     3. DYNAMIC STATE ANIMATIONS
     ============================================================ */
  #hud[data-state="idle"] .arc-fusion-core {
    animation: idlePulse 3.4s ease-in-out infinite;
  }

  @keyframes idlePulse {
    0%, 100% {
      transform: scale(1);
      box-shadow: 0 0 30px rgba(255, 23, 68, 0.8), 0 0 65px rgba(255, 23, 68, 0.4);
    }
    50% {
      transform: scale(1.06);
      box-shadow: 0 0 45px rgba(255, 23, 68, 1), 0 0 95px rgba(255, 42, 75, 0.65);
    }
  }

  #hud[data-state="listening"] .arc-fusion-core {
    box-shadow: 0 0 55px rgba(255, 23, 68, 1), 0 0 115px rgba(255, 42, 75, 0.85);
    filter: brightness(1.15);
  }

  #hud[data-state="listening"] .status-dot {
    background: #ff1744;
    box-shadow: 0 0 14px #ff1744;
  }

  #hud[data-state="listening"] .ring-coils {
    animation-duration: 6s;
  }

  #hud[data-state="thinking"] .arc-fusion-core {
    animation: thinkingVortex 1.3s ease-in-out infinite;
  }

  @keyframes thinkingVortex {
    0%, 100% {
      transform: scale(1);
      box-shadow: 0 0 35px rgba(255, 145, 0, 0.9), 0 0 80px rgba(255, 23, 68, 0.6);
    }
    50% {
      transform: scale(1.1);
      box-shadow: 0 0 60px rgba(255, 87, 34, 1), 0 0 115px rgba(255, 23, 68, 0.9);
      filter: brightness(1.25);
    }
  }

  #hud[data-state="thinking"] .arc-nucleus {
    background: radial-gradient(circle, #ffffff 0%, #ffe082 40%, #ff9100 80%, #ff1744 100%);
    box-shadow: 0 0 35px #ffe082, 0 0 65px #ff9100;
  }

  #hud[data-state="thinking"] .status-dot {
    background: #ff9100;
    box-shadow: 0 0 14px #ff9100;
  }

  #hud[data-state="speaking"] .status-dot {
    background: #ff5252;
    box-shadow: 0 0 16px #ff5252;
  }

  /* ============================================================
     4. CONTROL DOCK (REDESIGNED)
     ============================================================ */
  .control-dock {
    display: flex;
    align-items: center;
    justify-content: space-around;
    padding: 9px 12px;
    background: var(--hud-glass);
    border: 1px solid var(--hud-border);
    border-radius: 26px;
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.75), inset 0 0 15px rgba(255, 23, 68, 0.12);
  }

  .dock-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 4px;
    background: transparent;
    border: none;
    color: var(--text-muted);
    cursor: pointer;
    padding: 7px 14px;
    border-radius: 16px;
    transition: transform 0.12s, color 0.2s, background-color 0.2s;
  }

  .dock-btn:active {
    transform: scale(0.88);
    background: rgba(255, 23, 68, 0.2);
  }

  .dock-btn svg {
    width: 22px;
    height: 22px;
    fill: currentColor;
    transition: transform 0.2s, filter 0.2s;
  }

  .dock-label {
    font-family: var(--font-mono);
    font-size: 0.62rem;
    font-weight: 800;
    letter-spacing: 0.12em;
    text-transform: uppercase;
  }

  /* Center Elevated Mic Button */
  .center-mic-btn {
    position: relative;
    width: 66px;
    height: 66px;
    border-radius: 50%;
    background: radial-gradient(circle at 40% 40%, #ff5252 0%, #ff1744 55%, #990013 100%);
    border: 2.5px solid rgba(255, 255, 255, 0.7);
    box-shadow: 0 0 26px rgba(255, 23, 68, 0.9), 0 6px 18px rgba(0, 0, 0, 0.6);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    margin: -16px 4px 0 4px;
    transition: transform 0.12s, box-shadow 0.2s;
    color: #ffffff;
  }

  .center-mic-btn:active {
    transform: scale(0.90);
    box-shadow: 0 0 38px #ff1744;
  }

  .center-mic-btn svg {
    width: 30px;
    height: 30px;
    fill: #ffffff;
  }

  .btn-active {
    color: #ff5252 !important;
  }

  .btn-active svg {
    filter: drop-shadow(0 0 8px #ff1744);
  }
</style>
</head>
<body>
<div class="grid-bg"></div>

<div id="hud" data-state="idle">
  <!-- 1. Sleek Redesigned HUD Header -->
  <header class="header-bar gpu">
    <div class="brand-area" id="core-mark-btn" title="View Chat History">
      <div class="reactor-mini-glyph"></div>
      <div class="brand-text-col">
        <span class="brand-title">JARVIS</span>
        <span class="brand-sub">MARK 85</span>
      </div>
    </div>

    <div class="status-pill" id="status-chip">
      <div class="status-dot" id="status-dot"></div>
      <span id="status-text">ONLINE</span>
    </div>

    <div class="header-actions">
      <!-- Hidden clock element preserves JS timer callbacks without visual clutter -->
      <div id="live-clock" style="display: none;"></div>
      <button class="hdr-btn" id="hdr-settings-btn" title="Settings">
        <svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
      </button>
    </div>
  </header>

  <!-- 2. Massive Upgraded Stark Arc Reactor Core (Center Stage) -->
  <main class="orb-center-stage">
    <div class="reactor-housing gpu" id="reactor-assembly">
      <!-- High-Precision SVG Mechanical Rings -->
      <svg class="reactor-svg-rings" viewBox="0 0 330 330">
        <!-- Ring 1: Caliper Brackets -->
        <g class="ring-calipers">
          <circle cx="165" cy="165" r="158" fill="none" stroke="#ff1744" stroke-width="1.5" stroke-dasharray="2 10" opacity="0.45"/>
          <circle cx="165" cy="165" r="150" fill="none" stroke="#ff5252" stroke-width="1" stroke-dasharray="24 14 6 14" opacity="0.55"/>
          <!-- Cardinal Tick Marks -->
          <line x1="165" y1="5" x2="165" y2="18" stroke="#ff1744" stroke-width="2.5"/>
          <line x1="165" y1="312" x2="165" y2="325" stroke="#ff1744" stroke-width="2.5"/>
          <line x1="5" y1="165" x2="18" y2="165" stroke="#ff1744" stroke-width="2.5"/>
          <line x1="312" y1="165" x2="325" y2="165" stroke="#ff1744" stroke-width="2.5"/>
        </g>

        <!-- Ring 2: 10 Palladium Energy Coils -->
        <g class="ring-coils">
          <circle cx="165" cy="165" r="132" fill="none" stroke="#ffb300" stroke-width="1.5" stroke-dasharray="16 12" opacity="0.4"/>
          <rect x="160" y="36" width="10" height="14" rx="2" fill="#ff1744" opacity="0.9"/>
          <rect x="238" y="62" width="10" height="14" rx="2" fill="#ff5252" opacity="0.8" transform="rotate(36 243 69)"/>
          <rect x="282" y="132" width="10" height="14" rx="2" fill="#ff1744" opacity="0.9" transform="rotate(72 287 139)"/>
          <rect x="268" y="212" width="10" height="14" rx="2" fill="#ff5252" opacity="0.8" transform="rotate(108 273 219)"/>
          <rect x="202" y="270" width="10" height="14" rx="2" fill="#ff1744" opacity="0.9" transform="rotate(144 207 277)"/>
          <rect x="120" y="270" width="10" height="14" rx="2" fill="#ff5252" opacity="0.8" transform="rotate(180 125 277)"/>
          <rect x="54" y="212" width="10" height="14" rx="2" fill="#ff1744" opacity="0.9" transform="rotate(216 59 219)"/>
          <rect x="40" y="132" width="10" height="14" rx="2" fill="#ff5252" opacity="0.8" transform="rotate(252 45 139)"/>
          <rect x="84" y="62" width="10" height="14" rx="2" fill="#ff1744" opacity="0.9" transform="rotate(288 89 69)"/>
        </g>

        <!-- Ring 3: Fine Inner Dashed Track -->
        <g class="ring-inner-track">
          <circle cx="165" cy="165" r="108" fill="none" stroke="#ff1744" stroke-width="2" stroke-dasharray="4 6" opacity="0.75"/>
          <circle cx="165" cy="165" r="100" fill="none" stroke="#ffb300" stroke-width="1" stroke-dasharray="1 8" opacity="0.5"/>
        </g>
      </svg>

      <!-- Outer Plasma Bloom -->
      <div class="arc-plasma-bloom" id="arc-plasma-bloom"></div>

      <!-- Multi-Layer Fusion Core -->
      <div class="arc-fusion-core gpu" id="arc-core">
        <!-- 8 Radial Caliper Magnetic Vents -->
        <div class="caliper-vent cv-1"></div>
        <div class="caliper-vent cv-2"></div>
        <div class="caliper-vent cv-3"></div>
        <div class="caliper-vent cv-4"></div>
        <div class="caliper-vent cv-5"></div>
        <div class="caliper-vent cv-6"></div>
        <div class="caliper-vent cv-7"></div>
        <div class="caliper-vent cv-8"></div>

        <!-- Central Hyper-Dense Plasma Star -->
        <div class="arc-nucleus" id="arc-nucleus"></div>
      </div>
    </div>

    <!-- Dynamic Status Subtitle in Monospace -->
    <div class="orb-caption" id="orb-caption">SYSTEM ONLINE • TAP TO SPEAK</div>
  </main>

  <!-- 3. Redesigned Control Dock (No Chat Section) -->
  <footer style="width: 100%;">
    <nav class="control-dock gpu">
      <!-- Active / Sleep Toggle -->
      <button class="dock-btn" id="btn-power" title="Sleep / Wake">
        <svg viewBox="0 0 24 24"><path d="M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42A7.92 7.92 0 0 1 20 12c0 4.42-3.58 8-8 8s-8-3.58-8-8c0-2.45 1.12-4.64 2.89-6.09L5.47 4.49A9.957 9.957 0 0 0 2 12c0 5.52 4.48 10 10 10s10-4.48 10-10c0-2.76-1.12-5.26-2.93-7.07l-.24-.76z"/></svg>
        <span class="dock-label" id="label-power">Active</span>
      </button>

      <!-- Vision Toggle -->
      <button class="dock-btn" id="btn-vision" title="Screen Vision">
        <svg viewBox="0 0 24 24"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
        <span class="dock-label" id="label-vision">Vision</span>
      </button>

      <!-- Central Elevated Mic Button -->
      <button class="center-mic-btn gpu" id="btn-mic" title="Voice Input">
        <svg id="mic-icon" viewBox="0 0 24 24"><path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5-3c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/></svg>
      </button>

      <!-- Logs / History -->
      <button class="dock-btn" id="btn-history" title="Chat History">
        <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-2-4H7v-2h10v2zm0-4H7V9h10v2z"/></svg>
        <span class="dock-label">History</span>
      </button>

      <!-- Settings / Config -->
      <button class="dock-btn" id="btn-settings-bottom" title="Settings">
        <svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
        <span class="dock-label">Config</span>
      </button>
    </nav>
  </footer>
</div>

<script>
(function() {
  'use strict';

  const hud = document.getElementById('hud');
  const arcCore = document.getElementById('arc-core');
  const arcNucleus = document.getElementById('arc-nucleus');
  const reactorAssembly = document.getElementById('reactor-assembly');
  const statusText = document.getElementById('status-text');
  const liveClock = document.getElementById('live-clock');
  const orbCaption = document.getElementById('orb-caption');

  const btnMic = document.getElementById('btn-mic');
  const btnPower = document.getElementById('btn-power');
  const labelPower = document.getElementById('label-power');
  const btnVision = document.getElementById('btn-vision');
  const labelVision = document.getElementById('label-vision');
  const btnHistory = document.getElementById('btn-history');
  const btnSettings = document.getElementById('settings-trigger-btn');
  const btnSettingsBottom = document.getElementById('btn-settings-bottom');

  let currentState = 'idle';

  function updateClock() {
    const d = new Date();
    if (liveClock) liveClock.textContent = d.toTimeString().split(' ')[0];
  }
  setInterval(updateClock, 1000);
  updateClock();

  // State Handler (OrbHelper calls window.setOrbState)
  window.setOrbState = function(state, audioLevel) {
    if (!state) return;
    const s = state.toLowerCase();
    currentState = s;
    hud.dataset.state = s;

    switch(s) {
      case 'listening':
        statusText.textContent = "LISTENING";
        orbCaption.textContent = "TRANSCRIBING VOICE INPUT...";
        orbCaption.style.color = "#ff8a9e";
        setMicPulse(audioLevel || 0.3);
        break;
      case 'thinking':
        statusText.textContent = "ANALYZING";
        orbCaption.textContent = "PROCESSING REQUEST...";
        orbCaption.style.color = "#ffb300";
        if (arcCore) arcCore.style.transform = '';
        break;
      case 'speaking':
        statusText.textContent = "TRANSMITTING";
        orbCaption.textContent = "JARVIS TRANSMITTING AUDIO";
        orbCaption.style.color = "#ff5252";
        setSpeechPulse(audioLevel || 0.4);
        break;
      case 'idle':
      default:
        statusText.textContent = "ONLINE";
        orbCaption.textContent = "SYSTEM ONLINE • TAP TO SPEAK";
        orbCaption.style.color = "var(--text-muted)";
        if (arcCore) arcCore.style.transform = '';
        if (arcNucleus) arcNucleus.style.transform = '';
        break;
    }
  };
  window.updateState = window.setOrbState;

  function setMicPulse(level) {
    if (!arcCore) return;
    const scale = 1.0 + Math.min(level * 0.42, 0.38);
    arcCore.style.transform = `scale(${scale})`;
    if (arcNucleus) {
      const nScale = 1.0 + Math.min(level * 0.5, 0.45);
      arcNucleus.style.transform = `scale(${nScale})`;
    }
    const glow = Math.min(30 + level * 75, 95);
    arcCore.style.boxShadow = `0 0 ${glow}px rgba(255, 23, 68, 0.98), 0 0 ${glow * 2}px rgba(255, 42, 75, 0.6)`;
  }

  function setSpeechPulse(level) {
    if (!arcCore) return;
    const scale = 1.0 + Math.min(level * 0.38, 0.32);
    arcCore.style.transform = `scale(${scale})`;
    if (arcNucleus) {
      const nScale = 1.0 + Math.min(level * 0.4, 0.35);
      arcNucleus.style.transform = `scale(${nScale})`;
    }
    const glow = Math.min(25 + level * 65, 85);
    arcCore.style.boxShadow = `0 0 ${glow}px rgba(255, 82, 82, 0.98), 0 0 ${glow * 1.8}px rgba(255, 23, 68, 0.55)`;
  }

  window.setAudioLevel = function(level) {
    if (currentState === 'listening') {
      setMicPulse(level);
    } else if (currentState === 'speaking') {
      setSpeechPulse(level);
    }
  };

  window.setAudioFrequency = function(amp, pitchHz, bass, mid, high) {
    if (currentState === 'speaking' && arcCore) {
      const scale = 1.0 + Math.min(bass * 0.28 + mid * 0.16, 0.35);
      arcCore.style.transform = `scale(${scale})`;
    }
  };

  window.setConnectionStatus = function(status) {
    if (!status) return;
    statusText.textContent = status.toUpperCase();
  };
  window.updateConnectionStatus = window.setConnectionStatus;

  function renderLocalClock() {
    if (!liveClock) return;
    const now = new Date();
    let hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    liveClock.textContent = `${hours}:${minutes} ${ampm}`;
  }
  renderLocalClock();
  setInterval(renderLocalClock, 1000);

  window.setLiveTime = function(t) {
    renderLocalClock();
  };
  window.updateLiveTime = window.setLiveTime;

  window.setPowerState = function(isOn) {
    if (isOn) {
      btnPower.classList.add('btn-active');
      labelPower.textContent = "Active";
      labelPower.style.color = "#ff8a9e";
    } else {
      btnPower.classList.remove('btn-active');
      labelPower.textContent = "Sleep";
      labelPower.style.color = "var(--text-muted)";
    }
  };
  window.updatePowerState = window.setPowerState;

  window.setMicMuted = function(isMuted) {
    if (isMuted) {
      btnMic.style.background = "#550a14";
      btnMic.style.boxShadow = "0 0 10px rgba(255,23,68,0.3)";
    } else {
      btnMic.style.background = "radial-gradient(circle at 40% 40%, #ff5252 0%, #ff1744 55%, #990013 100%)";
      btnMic.style.boxShadow = "0 0 26px rgba(255, 23, 68, 0.9), 0 6px 18px rgba(0, 0, 0, 0.6)";
    }
  };
  window.updateMicMuted = window.setMicMuted;

  window.setScreenShareState = function(isSharing) {
    if (isSharing) {
      btnVision.classList.add('btn-active');
      labelVision.textContent = "Vision On";
      labelVision.style.color = "#ff1744";
    } else {
      btnVision.classList.remove('btn-active');
      labelVision.textContent = "Vision";
      labelVision.style.color = "var(--text-muted)";
    }
  };
  window.updateScreenShareState = window.setScreenShareState;

  // Stubs for OrbHelper chat methods so no errors are thrown while chat section is removed
  window.updateLiveUserTranscript = function() {};
  window.updateLiveAssistantResponse = function() {};
  window.finalizeLiveTurn = function() {};
  window.syncChatTurns = function() {};

  // Interactive Click Handlers (Connecting to Native Android Bridge)
  reactorAssembly.addEventListener('click', function() {
    if (window.JarvisBridge && window.JarvisBridge.onOrbClicked) {
      window.JarvisBridge.onOrbClicked();
    }
  });

  btnMic.addEventListener('click', function() {
    if (window.JarvisBridge && window.JarvisBridge.onMicClicked) {
      window.JarvisBridge.onMicClicked();
    }
  });

  btnPower.addEventListener('click', function() {
    if (window.JarvisBridge && window.JarvisBridge.onPowerClicked) {
      window.JarvisBridge.onPowerClicked();
    }
  });

  btnVision.addEventListener('click', function() {
    if (window.JarvisBridge && window.JarvisBridge.onScreenShareClicked) {
      window.JarvisBridge.onScreenShareClicked();
    }
  });

  btnHistory.addEventListener('click', function() {
    if (window.JarvisBridge && window.JarvisBridge.onHistoryClicked) {
      window.JarvisBridge.onHistoryClicked();
    }
  });

  const coreMark = document.getElementById('core-mark-btn');
  if (coreMark) {
    coreMark.addEventListener('click', function() {
      if (window.JarvisBridge && window.JarvisBridge.onHistoryClicked) {
        window.JarvisBridge.onHistoryClicked();
      }
    });
  }

  function openSettings() {
    if (window.JarvisBridge && window.JarvisBridge.onSettingsClicked) {
      window.JarvisBridge.onSettingsClicked();
    }
  }

  const hdrSettings = document.getElementById('hdr-settings-btn');
  if (hdrSettings) hdrSettings.addEventListener('click', openSettings);
  if (btnSettings) btnSettings.addEventListener('click', openSettings);
  if (btnSettingsBottom) btnSettingsBottom.addEventListener('click', openSettings);

  window.setOrbState('idle', 0);
})();
</script>
</body>
</html>
```
=== END FILE: app/src/main/assets/hud/index.html ===


=== FILE: app/src/main/assets/model-en-us/README ===
```
US English model for mobile Vosk applications

Copyright 2020 Alpha Cephei Inc

Accuracy: 10.38 (tedlium test) 9.85 (librispeech test-clean)
Speed: 0.11xRT (desktop)
Latency: 0.15s (right context)
```
=== END FILE: app/src/main/assets/model-en-us/README ===
