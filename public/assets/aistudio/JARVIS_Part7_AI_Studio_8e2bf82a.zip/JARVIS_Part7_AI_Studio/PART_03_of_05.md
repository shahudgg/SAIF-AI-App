# JARVIS Android App (Part 7) — SOURCE PART 3 of 5

Is file mein neeche diye gaye project files ka poora, unchanged source hai. Har file `=== FILE: <path> ===` se shuru aur `=== END FILE ===` pe khatam hoti hai. Path exactly waise hi banana hai jaisa likha hai.

Files in this part:
- app/src/main/java/com/jarvis/assistant/ui/home/MainActivity.kt
- app/src/main/java/com/jarvis/assistant/ui/home/MainViewModel.kt
- app/src/main/java/com/jarvis/assistant/ui/home/UpdatesFragment.kt
- app/src/main/java/com/jarvis/assistant/ui/memory/MemoryActivity.kt
- app/src/main/java/com/jarvis/assistant/ui/memory/MemoryAdapter.kt
- app/src/main/java/com/jarvis/assistant/ui/orb/OrbHelper.kt
- app/src/main/java/com/jarvis/assistant/ui/permission/PermissionActivity.kt
- app/src/main/java/com/jarvis/assistant/ui/settings/ApiConnectionActivity.kt
- app/src/main/java/com/jarvis/assistant/ui/settings/HandsFreeActivity.kt
- app/src/main/java/com/jarvis/assistant/ui/settings/OverlayAvatarActivity.kt
- app/src/main/java/com/jarvis/assistant/ui/settings/PersonaActivity.kt
- app/src/main/java/com/jarvis/assistant/ui/settings/PrivacyShieldActivity.kt
- app/src/main/java/com/jarvis/assistant/ui/settings/SettingsActivity.kt
- app/src/main/java/com/jarvis/assistant/ui/settings/SettingsFragment.kt
- app/src/main/java/com/jarvis/assistant/ui/settings/ThemeSelectionBottomSheet.kt
- app/src/main/java/com/jarvis/assistant/ui/voice/VoiceEnrollmentActivity.kt
- app/src/main/java/com/jarvis/assistant/ui/widget/CurvedDockLineView.kt
- app/src/main/java/com/jarvis/assistant/util/ActivityLauncherHelper.kt
- app/src/main/java/com/jarvis/assistant/util/AppLauncher.kt
- app/src/main/java/com/jarvis/assistant/util/BuiltInChromeEngine.kt
- app/src/main/java/com/jarvis/assistant/util/ContactCaller.kt
- app/src/main/java/com/jarvis/assistant/util/LocationWeatherHelper.kt
- app/src/main/java/com/jarvis/assistant/util/PermissionHelper.kt
- app/src/main/java/com/jarvis/assistant/util/PromptGenerator.kt
- app/src/main/java/com/jarvis/assistant/util/ThemeManager.kt
- app/src/main/java/com/jarvis/assistant/util/WhatsAppMessenger.kt
- app/src/main/java/com/jarvis/assistant/vision/ScreenCaptureManager.kt
- app/src/main/java/com/jarvis/assistant/vision/UiGroundingEngine.kt
- app/src/main/java/com/jarvis/assistant/vision/VisualTaskOrchestrator.kt


=== FILE: app/src/main/java/com/jarvis/assistant/ui/home/MainActivity.kt ===
```kotlin
package com.jarvis.assistant.ui.home

import android.Manifest
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.jarvis.assistant.R
import com.jarvis.assistant.background.JarvisConversationService
import com.jarvis.assistant.data.model.ConversationState
import com.jarvis.assistant.databinding.ActivityMainBinding
import com.jarvis.assistant.ui.chat.ChatFragment
import com.jarvis.assistant.ui.settings.SettingsFragment
import com.jarvis.assistant.util.PermissionHelper
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    companion object {
        const val TAB_HOME = 0
        const val TAB_CHAT = 1
        const val TAB_SETTINGS = 2
        const val TAB_UPDATES = 3
    }

    private lateinit var binding: ActivityMainBinding
    val viewModel: MainViewModel by viewModels()
    private var activeSnackbar: Snackbar? = null

    private var currentTab = TAB_HOME
    private val homeFragment by lazy { HomeFragment() }
    private val chatFragment by lazy { ChatFragment() }
    private val settingsFragment by lazy { SettingsFragment() }
    private val updatesFragment by lazy { UpdatesFragment() }

    private val requestAudioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            checkPermissionsAndStart()
        } else {
            Toast.makeText(
                this,
                "Microphone permission is required for voice conversation.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            checkPermissionsAndStart()
        } else {
            Toast.makeText(
                this,
                "Notification permission is required to run in the background.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private val mediaProjectionManager by lazy {
        getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
    }

    val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            try {
                if (!JarvisConversationService.isSessionOn.value || JarvisConversationService.connectionStatus.value != "LIVE") {
                    Toast.makeText(this, "Start Jarvis and wait for LIVE before sharing your screen.", Toast.LENGTH_LONG).show()
                    return@registerForActivityResult
                }
                if (!JarvisConversationService.elevateToMediaProjection()) {
                    Toast.makeText(this, "Could not start Android's screen-capture service.", Toast.LENGTH_LONG).show()
                    return@registerForActivityResult
                }
                val projection = mediaProjectionManager.getMediaProjection(result.resultCode, result.data!!)
                val metrics = android.util.DisplayMetrics()
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay.getRealMetrics(metrics)
                val started = JarvisConversationService.startScreenCapture(projection, metrics)
                if (!started) {
                    JarvisConversationService.demoteFromMediaProjection()
                    Toast.makeText(this, "Android did not start screen capture. Please try again.", Toast.LENGTH_LONG).show()
                    return@registerForActivityResult
                }
                Toast.makeText(this, "Checking screen capture…", Toast.LENGTH_SHORT).show()
                lifecycleScope.launch {
                    delay(2500L)
                    val captureManager = com.jarvis.assistant.vision.ScreenCaptureManager.getInstance()
                    if (!captureManager.isSharing.value) return@launch
                    if (captureManager.hasReceivedFrame.value) {
                        Toast.makeText(this@MainActivity, "Screen sharing is live. Jarvis is receiving screen frames.", Toast.LENGTH_LONG).show()
                    } else {
                        JarvisConversationService.stopScreenCapture()
                        Toast.makeText(this@MainActivity, "No screen frames arrived, so sharing was stopped. Please try again.", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Error starting MediaProjection: ${e.message}", e)
                JarvisConversationService.demoteFromMediaProjection()
                Toast.makeText(this, "Screen capture failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "Screen capture permission denied.", Toast.LENGTH_SHORT).show()
        }
    }

    private var appliedThemeKey: String = ""
    private var appliedCustomHex: String = ""

    fun toggleScreenShare() {
        if (com.jarvis.assistant.vision.ScreenCaptureManager.getInstance().isSharing.value) {
            JarvisConversationService.stopScreenCapture()
            Toast.makeText(this, "Screen sharing stopped.", Toast.LENGTH_SHORT).show()
        } else {
            if (!JarvisConversationService.isSessionOn.value || JarvisConversationService.connectionStatus.value != "LIVE") {
                Toast.makeText(this, "Start Jarvis and wait for LIVE before sharing your screen.", Toast.LENGTH_LONG).show()
                return
            }
            screenCaptureLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.jarvis.assistant.util.ThemeManager.applyTheme(this)
        val prefs = com.jarvis.assistant.JarvisApp.instance.preferences
        appliedThemeKey = prefs.appTheme
        appliedCustomHex = prefs.customThemeColor
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!com.jarvis.assistant.security.AppIdentityVerifier.isTrustedRelease(this)) {
            MaterialAlertDialogBuilder(this)
                .setTitle("App integrity check failed")
                .setMessage("This JARVIS build is not signed with the configured official release certificate. Sensitive features have been blocked.")
                .setCancelable(false)
                .setPositiveButton("Close") { _, _ -> finish() }
                .show()
            return
        }

        com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.rootMainLayout)

        currentTab = savedInstanceState?.getInt("CURRENT_TAB", TAB_HOME) ?: TAB_HOME

        // Clear any old restored fragments to prevent ghost overlapping
        val existingFragments = supportFragmentManager.fragments
        if (existingFragments.isNotEmpty()) {
            val trans = supportFragmentManager.beginTransaction()
            for (fragment in existingFragments) {
                trans.remove(fragment)
            }
            trans.commitNowAllowingStateLoss()
        }

        // Add all 4 fragments fresh into container
        val trans = supportFragmentManager.beginTransaction()
            .add(R.id.fragmentContainer, homeFragment, "TAB_0")
            .add(R.id.fragmentContainer, chatFragment, "TAB_1")
            .add(R.id.fragmentContainer, settingsFragment, "TAB_2")
            .add(R.id.fragmentContainer, updatesFragment, "TAB_3")

        val allTabs = listOf(
            TAB_HOME to homeFragment,
            TAB_CHAT to chatFragment,
            TAB_SETTINGS to settingsFragment,
            TAB_UPDATES to updatesFragment
        )

        allTabs.forEach { (tabId, frag) ->
            if (tabId == currentTab) {
                trans.show(frag)
            } else {
                trans.hide(frag)
            }
        }
        trans.commitNow()

        setupNavigationDock()
        selectTab(currentTab)
        observeViewModel()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentTab != TAB_HOME) {
                    selectTab(TAB_HOME)
                } else {
                    // Preserve Android's normal root behavior (return to launcher) only
                    // after the user is already on JARVIS Home.
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("CURRENT_TAB", currentTab)
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSettings()
        val prefs = com.jarvis.assistant.JarvisApp.instance.preferences
        if (appliedThemeKey != prefs.appTheme || appliedCustomHex != prefs.customThemeColor) {
            appliedThemeKey = prefs.appTheme
            appliedCustomHex = prefs.customThemeColor
            recreate()
        }
    }

    private fun setupNavigationDock() {
        binding.tabHome.setOnClickListener { selectTab(TAB_HOME) }
        binding.tabChat.setOnClickListener { selectTab(TAB_CHAT) }
        binding.tabSettings.setOnClickListener { selectTab(TAB_SETTINGS) }
        binding.tabUpdates.setOnClickListener { selectTab(TAB_UPDATES) }

        binding.tabMic.setOnClickListener {
            handleMicOrOrbClick()
        }

        binding.tabMic.setOnLongClickListener {
            handleHoldMicOrOrb()
            true
        }
    }

    fun selectTab(tab: Int) {
        val previousTab = currentTab
        currentTab = tab

        val tabs = listOf(
            TAB_HOME to homeFragment,
            TAB_CHAT to chatFragment,
            TAB_SETTINGS to settingsFragment,
            TAB_UPDATES to updatesFragment
        )

        val trans = supportFragmentManager.beginTransaction()
        tabs.forEach { (tabId, frag) ->
            if (frag.isAdded) {
                if (tabId == tab) {
                    trans.show(frag)
                } else {
                    trans.hide(frag)
                }
            }
        }
        trans.commitNowAllowingStateLoss()

        tabs.forEach { (tabId, frag) ->
            val v = frag.view
            if (v != null) {
                if (tabId == tab) {
                    v.visibility = View.VISIBLE
                    com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(v)
                    if (previousTab != tab) {
                        v.alpha = 0f
                        v.translationX = if (tab > previousTab) 18f else -18f
                        v.animate().cancel()
                        v.animate()
                            .alpha(1f)
                            .translationX(0f)
                            .setDuration(190L)
                            .setInterpolator(android.view.animation.DecelerateInterpolator())
                            .start()
                    } else {
                        v.alpha = 1f
                        v.translationX = 0f
                    }
                } else {
                    v.animate().cancel()
                    v.visibility = View.GONE
                }
            }
        }

        updateDockUI(tab)
    }

    private fun updateDockUI(tab: Int) {
        val tvAccent = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeAccent, tvAccent, true)
        val activeColor = if (tvAccent.data != 0) tvAccent.data else ContextCompat.getColor(this, R.color.accent_sapphire)

        val tvMuted = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeTextMuted, tvMuted, true)
        val inactiveColor = if (tvMuted.data != 0) tvMuted.data else ContextCompat.getColor(this, R.color.text_subtle)

        val tvPrimary = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeTextPrimary, tvPrimary, true)
        val activeTextColor = if (tvPrimary.data != 0) tvPrimary.data else android.graphics.Color.WHITE

        val navItems = listOf(
            Triple(TAB_HOME, binding.pillTabHome, Pair(binding.ivTabHome, binding.tvTabHome)),
            Triple(TAB_CHAT, binding.pillTabChat, Pair(binding.ivTabChat, binding.tvTabChat)),
            Triple(TAB_SETTINGS, binding.pillTabSettings, Pair(binding.ivTabSettings, binding.tvTabSettings)),
            Triple(TAB_UPDATES, binding.pillTabUpdates, Pair(binding.ivTabUpdates, binding.tvTabUpdates))
        )

        navItems.forEach { (tabId, pill, views) ->
            val isSelected = tabId == tab
            val (iv, tv) = views
            if (isSelected) {
                pill.setBackgroundResource(R.drawable.bg_dock_item_active)
                pill.alpha = 0f
                pill.scaleX = 0.88f
                pill.scaleY = 0.88f
                pill.animate()
                    .alpha(1f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(240)
                    .setInterpolator(android.view.animation.OvershootInterpolator(1.2f))
                    .start()
                iv.imageTintList = ColorStateList.valueOf(activeTextColor)
                tv.setTextColor(activeTextColor)
                tv.alpha = 1f
            } else {
                pill.animate().cancel()
                pill.setBackgroundResource(0)
                pill.alpha = 1f
                pill.scaleX = 1f
                pill.scaleY = 1f
                iv.imageTintList = ColorStateList.valueOf(inactiveColor)
                tv.setTextColor(inactiveColor)
                tv.alpha = 0.75f
            }
        }
    }

    fun handleMicOrOrbClick() {
        if (!JarvisConversationService.isSessionOn.value) {
            checkPermissionsAndStart()
        } else if (JarvisConversationService.conversationState.value == ConversationState.SPEAKING) {
            JarvisConversationService.interruptPlayback()
        } else {
            viewModel.toggleMicMute()
        }
    }

    fun handleHoldMicOrOrb() {
        binding.tabMic.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        if (JarvisConversationService.isSessionOn.value) {
            viewModel.turnOffSession()
        } else {
            checkPermissionsAndStart()
        }
    }

    fun handleTurnOff() {
        handleHoldMicOrOrb()
    }

    fun handlePowerClick() {
        handleHoldMicOrOrb()
    }

    private fun checkPermissionsAndStart() {
        if (!PermissionHelper.hasRecordAudioPermission(this)) {
            requestAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }

        if (!PermissionHelper.hasNotificationPermission(this)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }

        if (!PermissionHelper.hasBatteryOptimizationPermission(this)) {
            showBatteryPermissionDialog()
            return
        }

        viewModel.toggleSession()
    }

    private fun showBatteryPermissionDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Unrestricted Battery Required")
            .setMessage("Jarvis requires Unrestricted Battery access so it can stay active in the background and respond to wake words.\n\nPlease allow it or open Settings.")
            .setPositiveButton("ALLOW") { _, _ ->
                PermissionHelper.requestBatteryOptimization(this)
            }
            .setNeutralButton("OPEN SETTINGS") { _, _ ->
                selectTab(TAB_SETTINGS)
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    combine(viewModel.isMicMuted, viewModel.conversationState, viewModel.isSessionOn) { isMuted, state, isOn ->
                        Triple(isMuted, state, isOn)
                    }.collect { (isMuted, state, isOn) ->
                        val tvAccent = android.util.TypedValue()
                        theme.resolveAttribute(R.attr.themeAccent, tvAccent, true)
                        val accentColor = if (tvAccent.data != 0) tvAccent.data else ContextCompat.getColor(this@MainActivity, R.color.accent_sapphire)

                        val tvMuted = android.util.TypedValue()
                        theme.resolveAttribute(R.attr.themeTextMuted, tvMuted, true)
                        val inactiveColor = if (tvMuted.data != 0) tvMuted.data else ContextCompat.getColor(this@MainActivity, R.color.text_subtle)

                        if (!isOn) {
                            binding.ivTabMic.setImageResource(R.drawable.ic_mic_jarvis)
                            binding.ivTabMic.imageTintList = ColorStateList.valueOf(android.graphics.Color.parseColor("#94A3B8"))
                            binding.tvTabMic.setTextColor(android.graphics.Color.parseColor("#94A3B8"))
                            binding.pillTabMic.setBackgroundResource(R.drawable.bg_dock_mic_off)
                            binding.pillTabMic.animate().cancel()
                            binding.pillTabMic.alpha = 0.85f
                            binding.pillTabMic.scaleX = 1f
                            binding.pillTabMic.scaleY = 1f
                        } else if (isMuted) {
                            binding.ivTabMic.setImageResource(R.drawable.ic_mic_mute_jarvis)
                            binding.ivTabMic.imageTintList = ColorStateList.valueOf(android.graphics.Color.WHITE)
                            binding.tvTabMic.setTextColor(android.graphics.Color.WHITE)
                            binding.pillTabMic.setBackgroundResource(R.drawable.bg_dock_mic_muted)
                            binding.pillTabMic.animate().cancel()
                            binding.pillTabMic.alpha = 1f
                            binding.pillTabMic.scaleX = 1f
                            binding.pillTabMic.scaleY = 1f
                        } else {
                            binding.ivTabMic.setImageResource(R.drawable.ic_mic_jarvis)
                            binding.ivTabMic.imageTintList = ColorStateList.valueOf(android.graphics.Color.WHITE)
                            binding.tvTabMic.setTextColor(android.graphics.Color.WHITE)
                            binding.pillTabMic.setBackgroundResource(R.drawable.bg_dock_mic_highlight)
                            binding.pillTabMic.alpha = 1f
                            if (state == ConversationState.LISTENING || state == ConversationState.SPEAKING) {
                                binding.pillTabMic.animate()
                                    .scaleX(1.08f)
                                    .scaleY(1.08f)
                                    .setDuration(300)
                                    .start()
                            } else {
                                binding.pillTabMic.animate().cancel()
                                binding.pillTabMic.scaleX = 1f
                                binding.pillTabMic.scaleY = 1f
                            }
                        }
                    }
                }

                launch {
                    viewModel.eventFlow.collect { message ->
                        activeSnackbar?.dismiss()
                        activeSnackbar = Snackbar.make(binding.rootMainLayout, message, Snackbar.LENGTH_SHORT).apply {
                            setAnchorView(binding.bottomDock)
                            show()
                        }
                    }
                }
            }
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/home/MainActivity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/home/MainViewModel.kt ===
```kotlin
package com.jarvis.assistant.ui.home

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.background.JarvisConversationService
import com.jarvis.assistant.data.model.ChatTurn
import com.jarvis.assistant.data.model.ConversationState
import com.jarvis.assistant.data.preferences.AppPreferences
import com.jarvis.assistant.util.PermissionHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * This ViewModel is intentionally "thin": the microphone, the Gemini Live
 * socket, and the standby/wake-word listener all live inside
 * [JarvisConversationService], not here. This class only mirrors that
 * service's state for the UI and forwards user taps as control intents.
 *
 * That split matters: when the app is removed from Recents, Android destroys
 * the Activity and this ViewModel - if the live conversation lived here, it
 * would die with it. Because it lives in the foreground service instead, the
 * conversation (or standby listening) keeps running untouched, and whenever
 * the UI comes back it just resumes observing whatever the service is doing.
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val preferences: AppPreferences = (application as JarvisApp).preferences

    val isSessionOn: StateFlow<Boolean> = JarvisConversationService.isSessionOn
    val conversationState: StateFlow<ConversationState> = JarvisConversationService.conversationState
    val audioLevel: StateFlow<Float> = JarvisConversationService.audioLevel
    val audioFrequency: StateFlow<com.jarvis.assistant.audio.AudioFrequencyData> = JarvisConversationService.audioFrequency
    val liveUserTranscript: StateFlow<String> = JarvisConversationService.liveUserTranscript
    val liveAssistantResponse: StateFlow<String> = JarvisConversationService.liveAssistantResponse
    val liveError: StateFlow<com.jarvis.assistant.background.JarvisLiveError?> = JarvisConversationService.liveError
    val chatTurns: StateFlow<List<ChatTurn>> = (application as JarvisApp).chatRepository.turns

    fun clearLiveError() {
        JarvisConversationService.clearLiveError()
    }

    private val _isMicMuted = MutableStateFlow(preferences.isMicMuted)
    val isMicMuted: StateFlow<Boolean> = _isMicMuted.asStateFlow()

    // Surfaces "STANDBY" whenever the service is listening only for the wake
    // word, otherwise mirrors the service's live connection status.
    private val _connectionStatus = MutableStateFlow("READY")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private val _liveTime = MutableStateFlow("")
    val liveTime: StateFlow<String> = _liveTime.asStateFlow()

    private val _personalityName = MutableStateFlow(preferences.personality)
    val personalityName: StateFlow<String> = _personalityName.asStateFlow()

    private val _eventFlow = MutableSharedFlow<String>()
    val eventFlow: SharedFlow<String> = _eventFlow.asSharedFlow()

    private var timeClockJob: Job? = null

    init {
        startTimeClock()
        observeServiceStatus()
        observeServiceEvents()
    }

    private fun startTimeClock() {
        timeClockJob = viewModelScope.launch(Dispatchers.Default) {
            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
            while (isActive) {
                _liveTime.value = sdf.format(Date())
                delay(1000)
            }
        }
    }

    private fun observeServiceStatus() {
        viewModelScope.launch {
            combine(
                JarvisConversationService.isStandby,
                JarvisConversationService.connectionStatus
            ) { standby, liveStatus -> if (standby) "STANDBY" else liveStatus }
                .collect { _connectionStatus.value = it }
        }
    }

    private fun observeServiceEvents() {
        viewModelScope.launch {
            JarvisConversationService.events.collect { message -> _eventFlow.emit(message) }
        }
        viewModelScope.launch {
            JarvisConversationService.wakeEvents.collect {
                _eventFlow.emit("Wake word detected")
            }
        }
    }

    fun refreshSettings() {
        _personalityName.value = preferences.personality
        _isMicMuted.value = preferences.isMicMuted
        JarvisConversationService.setMicMuted(preferences.isMicMuted)
    }

    fun turnOffSession() {
        sendServiceAction(JarvisConversationService.ACTION_STOP_ALL)
        viewModelScope.launch {
            _eventFlow.emit("Jarvis Powered Off")
        }
    }

    fun toggleSession() {
        if (JarvisConversationService.isSessionOn.value) {
            turnOffSession()
        } else {
            val context = getApplication<Application>()
            if (!PermissionHelper.hasAllRequiredPermissions(context)) {
                viewModelScope.launch {
                    _eventFlow.emit("Please allow all permissions in Settings to activate Jarvis.")
                }
                return
            }
            val apiKey = preferences.apiKey.trim()
            if (apiKey.isBlank()) {
                viewModelScope.launch {
                    _eventFlow.emit("Please configure your Gemini API Key in Settings first.")
                }
                return
            }
            sendServiceAction(JarvisConversationService.ACTION_START_CONVERSATION)
        }
    }

    fun toggleMicMute() {
        val newMuted = !_isMicMuted.value
        _isMicMuted.value = newMuted
        preferences.isMicMuted = newMuted
        JarvisConversationService.setMicMuted(newMuted)
        viewModelScope.launch {
            _eventFlow.emit(if (newMuted) "Microphone Muted (Off)" else "Microphone Active (On)")
        }
    }

    private fun sendServiceAction(action: String) {
        val intent = Intent(getApplication<Application>(), JarvisConversationService::class.java)
            .setAction(action)
        ContextCompat.startForegroundService(getApplication<Application>(), intent)
    }

    override fun onCleared() {
        super.onCleared()
        timeClockJob?.cancel()
        // Deliberately NOT stopping JarvisConversationService here. The
        // Activity/ViewModel being torn down (e.g. the app swiped away from
        // Recents) must not stop the mic or the live conversation - that's
        // the whole point of owning them in the service instead of here.
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/home/MainViewModel.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/home/UpdatesFragment.kt ===
```kotlin
package com.jarvis.assistant.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import android.util.TypedValue
import android.widget.LinearLayout
import android.widget.TextView
import com.jarvis.assistant.databinding.FragmentUpdatesBinding

class UpdatesFragment : Fragment() {

    private var _binding: FragmentUpdatesBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUpdatesBinding.inflate(inflater, container, false)
        renderFeatureUpdates()
        return binding.root
    }

    private data class FeatureNotice(val feature: String, val title: String, val details: String, val kind: String = "FEATURE")

    private fun renderFeatureUpdates() {
        val features = listOf(
            FeatureNotice("Agent tasks", "Verified actions and recovery", "JARVIS observes the current screen, checks action results, tracks progress, and stops safely when the UI is unclear."),
            FeatureNotice("Floating avatar", "Always-on or working-only display", "Choose an avatar, double-tap for compact task progress, drag it anywhere on screen, and choose a dock edge in Settings."),
            FeatureNotice("Task progress", "Four-step compact status", "The task HUD shows the goal, recent steps, a running indicator, completed checks, and a subdued dark progress line."),
            FeatureNotice("Silent execution", "Quiet task automation", "When enabled, task narration is muted while ordinary conversation stays audible."),
            FeatureNotice("WhatsApp", "Saved contact lookup", "Contact aliases are supported. Grant Contacts permission first; JARVIS will report a missing permission separately from a name mismatch."),
            FeatureNotice("Phone calls", "Permission-aware calling", "Normal calls require Contacts and Phone permissions. WhatsApp calls use WhatsApp and do not place a cellular call."),
            FeatureNotice("Google Flow / AI Studio", "Browser input diagnostics", "The captured Flow run could not verify the prompt input in Chrome. Some editor fields are not exposed to Accessibility; screen sharing must be active and have a fresh frame for visual targeting. The captured logs did not show a Google AI Studio page, so that failure still needs a fresh log capture.", "DIAGNOSTIC"),
            FeatureNotice("Instagram", "Bulk action safety", "Bulk tasks track list progress and require end-of-list evidence. The captured run repeatedly reached the action limit and did not establish completion; avoid treating an unverified result as done.", "DIAGNOSTIC"),
            FeatureNotice("Spotify", "Song search and playback checks", "Searches can inspect results and verify playback before reporting success; physical-device behavior still depends on the Spotify screen and account."),
            FeatureNotice("Permissions", "Per-feature access status", "The System Authorizations page lists microphone, location, notifications, overlay, Accessibility, contacts, phone, camera, Bluetooth, battery, and brightness access."),
            FeatureNotice("AI persona", "Operator profile preview", "Preview your selected assistant voice and the name it will use before activating the persona."),
            FeatureNotice("Appearance", "Sunset theme by default", "Fresh installs start with the sunset theme; you can still select other themes in Settings.")
        )
        val list = binding.updatesList
        list.removeAllViews()
        features.forEach { feature ->
            val card = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                background = androidx.core.content.ContextCompat.getDrawable(requireContext(), com.jarvis.assistant.R.drawable.bg_jarvis_card)
                setPadding(dp(18), dp(18), dp(18), dp(18))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(14)
                }
            }
            card.addView(TextView(requireContext()).apply {
                text = feature.feature.uppercase() + if (feature.kind == "DIAGNOSTIC") "  ·  DIAGNOSTIC" else ""
                textSize = 12f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(themeColor(com.jarvis.assistant.R.attr.themeAccent))
            })
            card.addView(TextView(requireContext()).apply {
                text = feature.title
                textSize = 15f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(themeColor(com.jarvis.assistant.R.attr.themeTextPrimary))
                setPadding(0, dp(8), 0, dp(5))
            })
            card.addView(TextView(requireContext()).apply {
                text = feature.details
                textSize = 13f
                setTextColor(themeColor(com.jarvis.assistant.R.attr.themeTextMuted))
                setLineSpacing(dp(2).toFloat(), 1f)
            })
            list.addView(card)
        }
    }

    private fun themeColor(attribute: Int): Int {
        val value = TypedValue()
        requireContext().theme.resolveAttribute(attribute, value, true)
        return value.data
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)
    }

    override fun onResume() {
        super.onResume()
        if (_binding != null) {
            com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)
        }
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden && _binding != null) {
            binding.root.visibility = View.VISIBLE
            com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)
        } else if (hidden && _binding != null) {
            binding.root.visibility = View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/home/UpdatesFragment.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/memory/MemoryActivity.kt ===
```kotlin
package com.jarvis.assistant.ui.memory

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.R
import com.jarvis.assistant.data.memory.MemoryEntity
import com.jarvis.assistant.databinding.ActivityMemoryBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.Locale

class MemoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMemoryBinding
    private val memoryRepo by lazy { JarvisApp.instance.memoryRepository }
    private lateinit var adapter: MemoryAdapter

    private var allMemories: List<MemoryEntity> = emptyList()
    private var selectedCategory: String = "All"
    private var searchQuery: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        com.jarvis.assistant.util.ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityMemoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)

        setupToolbar()
        setupRecyclerView()
        setupCategoryChips()
        setupSearch()
        observeMemories()
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener { finish() }
        binding.btnAddMemory.setOnClickListener { showAddMemoryDialog() }
    }

    private fun setupRecyclerView() {
        adapter = MemoryAdapter(
            onEdit = { memory -> showEditMemoryDialog(memory) },
            onDelete = { memory -> confirmDeleteMemory(memory) }
        )
        binding.rvMemories.layoutManager = LinearLayoutManager(this)
        binding.rvMemories.adapter = adapter
    }

    private fun setupCategoryChips() {
        val chips = listOf(
            Pair(binding.chipCategoryAll, "All"),
            Pair(binding.chipCategoryPersonal, MemoryEntity.CATEGORY_PERSONAL),
            Pair(binding.chipCategoryPreferences, MemoryEntity.CATEGORY_PREFERENCES),
            Pair(binding.chipCategoryContacts, MemoryEntity.CATEGORY_CONTACTS),
            Pair(binding.chipCategoryRoutines, MemoryEntity.CATEGORY_ROUTINES),
            Pair(binding.chipCategoryNotes, MemoryEntity.CATEGORY_NOTES)
        )

        for ((view, category) in chips) {
            view.setOnClickListener {
                selectedCategory = category
                updateChipStyles(chips, view)
                filterAndDisplay()
            }
        }
    }

    private fun updateChipStyles(chips: List<Pair<TextView, String>>, selectedView: TextView) {
        val tvAccent = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeAccent, tvAccent, true)
        val accentColor = if (tvAccent.data != 0) tvAccent.data else ContextCompat.getColor(this, R.color.primary_cyan)

        val tvSecondary = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeTextSecondary, tvSecondary, true)
        val secondaryColor = if (tvSecondary.data != 0) tvSecondary.data else ContextCompat.getColor(this, R.color.text_secondary)

        for ((view, _) in chips) {
            if (view == selectedView) {
                view.setBackgroundResource(R.drawable.bg_chip_selected)
                view.setTextColor(accentColor)
            } else {
                view.setBackgroundResource(R.drawable.bg_chip_unselected)
                view.setTextColor(secondaryColor)
            }
        }
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                searchQuery = s?.toString()?.trim() ?: ""
                filterAndDisplay()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun observeMemories() {
        lifecycleScope.launch {
            memoryRepo.getAllMemoriesFlow().collectLatest { memories ->
                allMemories = memories
                filterAndDisplay()
            }
        }
    }

    private fun filterAndDisplay() {
        val filtered = allMemories.filter { mem ->
            val matchesCategory = (selectedCategory == "All" || mem.category.equals(selectedCategory, ignoreCase = true))
            val matchesSearch = if (searchQuery.isBlank()) {
                true
            } else {
                mem.rawText.contains(searchQuery, ignoreCase = true) ||
                mem.key.contains(searchQuery, ignoreCase = true) ||
                mem.category.contains(searchQuery, ignoreCase = true)
            }
            matchesCategory && matchesSearch
        }

        binding.tvMemoryCount.text = "SAVED MEMORIES (${filtered.size})"
        adapter.submitList(filtered)

        if (filtered.isEmpty()) {
            binding.tvNoMemories.visibility = View.VISIBLE
        } else {
            binding.tvNoMemories.visibility = View.GONE
        }
    }

    private fun showAddMemoryDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 16)
        }

        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MemoryActivity,
                android.R.layout.simple_spinner_dropdown_item,
                MemoryEntity.ALL_CATEGORIES
            )
            setBackgroundResource(R.drawable.bg_input_field)
            setPadding(16, 16, 16, 16)
        }

        val tvPrimary = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeTextPrimary, tvPrimary, true)
        val textPrimaryColor = if (tvPrimary.data != 0) tvPrimary.data else ContextCompat.getColor(this@MemoryActivity, R.color.text_primary)

        val tvMuted = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeTextMuted, tvMuted, true)
        val textMutedColor = if (tvMuted.data != 0) tvMuted.data else ContextCompat.getColor(this@MemoryActivity, R.color.text_muted)

        val editText = EditText(this).apply {
            hint = "e.g., My favorite song is Believer"
            setTextColor(textPrimaryColor)
            setHintTextColor(textMutedColor)
            setBackgroundResource(R.drawable.bg_input_field)
            setPadding(24, 24, 24, 24)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 24 }
        }

        layout.addView(spinner)
        layout.addView(editText)

        MaterialAlertDialogBuilder(this)
            .setTitle("Add New Memory")
            .setView(layout)
            .setPositiveButton("SAVE") { _, _ ->
                val fact = editText.text.toString().trim()
                val category = spinner.selectedItem.toString()
                if (fact.isNotBlank()) {
                    lifecycleScope.launch {
                        memoryRepo.saveMemory(
                            rawText = fact,
                            category = category,
                            key = fact.take(30).trim(),
                            value = fact
                        )
                        Toast.makeText(this@MemoryActivity, "Memory saved", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showEditMemoryDialog(memory: MemoryEntity) {
        val tvPrimary = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeTextPrimary, tvPrimary, true)
        val textPrimaryColor = if (tvPrimary.data != 0) tvPrimary.data else ContextCompat.getColor(this@MemoryActivity, R.color.text_primary)

        val editText = EditText(this).apply {
            setText(memory.rawText)
            setTextColor(textPrimaryColor)
            setBackgroundResource(R.drawable.bg_input_field)
            setPadding(24, 24, 24, 24)
        }

        val container = LinearLayout(this).apply {
            setPadding(48, 24, 48, 16)
            addView(editText)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Edit Memory")
            .setView(container)
            .setPositiveButton("UPDATE") { _, _ ->
                val newFact = editText.text.toString().trim()
                if (newFact.isNotBlank()) {
                    lifecycleScope.launch {
                        memoryRepo.updateMemory(
                            memory.copy(
                                rawText = newFact,
                                value = newFact,
                                timestamp = System.currentTimeMillis()
                            )
                        )
                        Toast.makeText(this@MemoryActivity, "Memory updated", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun confirmDeleteMemory(memory: MemoryEntity) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete Memory")
            .setMessage("Are you sure you want JARVIS to forget this fact?\n\n\"${memory.rawText}\"")
            .setPositiveButton("DELETE") { _, _ ->
                lifecycleScope.launch {
                    memoryRepo.deleteMemoryById(memory.id)
                    Toast.makeText(this@MemoryActivity, "Memory deleted", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/memory/MemoryActivity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/memory/MemoryAdapter.kt ===
```kotlin
package com.jarvis.assistant.ui.memory

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.R
import com.jarvis.assistant.data.memory.MemoryEntity
import com.jarvis.assistant.databinding.ItemMemoryBinding

class MemoryAdapter(
    private val onEdit: (MemoryEntity) -> Unit,
    private val onDelete: (MemoryEntity) -> Unit
) : ListAdapter<MemoryEntity, MemoryAdapter.MemoryViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MemoryViewHolder {
        val binding = ItemMemoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MemoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MemoryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class MemoryViewHolder(private val binding: ItemMemoryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: MemoryEntity) {
            binding.tvMemoryFact.text = item.rawText
            binding.tvMemoryDate.text = item.formattedDate
            binding.tvMemoryCategory.text = item.category.uppercase()

            val context = binding.root.context
            val colorRes = when (item.category) {
                MemoryEntity.CATEGORY_PREFERENCES -> R.color.primary_cyan
                MemoryEntity.CATEGORY_ROUTINES -> R.color.neon_blue
                MemoryEntity.CATEGORY_PERSONAL -> R.color.purple_glow
                MemoryEntity.CATEGORY_CONTACTS -> R.color.status_green
                else -> R.color.status_amber
            }
            val color = ContextCompat.getColor(context, colorRes)
            binding.tvMemoryCategory.setTextColor(color)

            binding.btnEditMemory.setOnClickListener { onEdit(item) }
            binding.btnDeleteMemory.setOnClickListener { onDelete(item) }
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<MemoryEntity>() {
        override fun areItemsTheSame(oldItem: MemoryEntity, newItem: MemoryEntity): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: MemoryEntity, newItem: MemoryEntity): Boolean =
            oldItem == newItem
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/memory/MemoryAdapter.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/orb/OrbHelper.kt ===
```kotlin
package com.jarvis.assistant.ui.orb

import android.annotation.SuppressLint
import android.graphics.Color
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.jarvis.assistant.data.model.ChatTurn
import com.jarvis.assistant.data.model.ConversationState
import org.json.JSONArray
import org.json.JSONObject

class OrbHelper(
    private val webView: WebView,
    private val listener: OrbListener? = null
) {

    interface OrbListener {
        fun onOrbClicked()
        fun onMicClicked()
        fun onPowerClicked()
        fun onSettingsClicked()
        fun onHistoryClicked()
        fun onScreenShareClicked()
    }

    private var isLoaded = false
    private var pendingState: ConversationState? = null
    private var pendingAudioLevel: Float? = null
    private var pendingTime: String? = null
    private var pendingStatus: String? = null
    private var pendingPower: Boolean? = null
    private var pendingMicMuted: Boolean? = null
    private var pendingTurns: List<ChatTurn>? = null
    private var pendingScreenShare: Boolean? = null

    @SuppressLint("SetJavaScriptEnabled")
    fun setup() {
        webView.setBackgroundColor(Color.TRANSPARENT)
        webView.setLayerType(WebView.LAYER_TYPE_HARDWARE, null)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        @Suppress("DEPRECATION")
        settings.allowFileAccessFromFileURLs = true
        @Suppress("DEPRECATION")
        settings.allowUniversalAccessFromFileURLs = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.cacheMode = WebSettings.LOAD_NO_CACHE

        // Add JavaScript Interface for Native-Web Bridge
        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun onOrbClicked() {
                webView.post { listener?.onOrbClicked() }
            }

            @JavascriptInterface
            fun onMicClicked() {
                webView.post { listener?.onMicClicked() }
            }

            @JavascriptInterface
            fun onPowerClicked() {
                webView.post { listener?.onPowerClicked() }
            }

            @JavascriptInterface
            fun onSettingsClicked() {
                webView.post { listener?.onSettingsClicked() }
            }

            @JavascriptInterface
            fun onHistoryClicked() {
                webView.post { listener?.onHistoryClicked() }
            }

            @JavascriptInterface
            fun onScreenShareClicked() {
                webView.post { listener?.onScreenShareClicked() }
            }
        }, "JarvisBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                isLoaded = true

                pendingTime?.let { updateLiveTime(it) }
                pendingStatus?.let { updateConnectionStatus(it) }
                pendingPower?.let { updatePowerState(it) }
                pendingMicMuted?.let { updateMicMuted(it) }
                pendingScreenShare?.let { updateScreenShareState(it) }
                pendingState?.let { updateState(it, pendingAudioLevel ?: 0f) }
                pendingTurns?.let { updateChatTurns(it) }

                pendingTime = null
                pendingStatus = null
                pendingPower = null
                pendingMicMuted = null
                pendingScreenShare = null
                pendingState = null
                pendingAudioLevel = null
                pendingTurns = null
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: android.webkit.ConsoleMessage?): Boolean {
                android.util.Log.d("JarvisHudWebView", "${message?.message()} -- line ${message?.lineNumber()}")
                return true
            }
        }

        webView.loadUrl("file:///android_asset/hud/index.html")
    }

    fun updateState(state: ConversationState, audioLevel: Float = 0f) {
        if (!isLoaded) {
            pendingState = state
            pendingAudioLevel = audioLevel
            return
        }
        val orbKey = state.orbKey
        val level = audioLevel.coerceIn(0f, 1f)
        val js = "javascript:if(window.setOrbState){window.setOrbState('$orbKey', $level);}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    fun updateAudioLevel(level: Float) {
        if (!isLoaded) return
        val clamped = level.coerceIn(0f, 1f)
        val js = "javascript:if(window.setAudioLevel){window.setAudioLevel($clamped);}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    fun updateAudioFrequency(amp: Float, pitchHz: Float, bass: Float, mid: Float, high: Float) {
        if (!isLoaded) return
        val clampedAmp = amp.coerceIn(0f, 1f)
        val clampedPitch = pitchHz.coerceIn(0f, 4000f)
        val clampedBass = bass.coerceIn(0f, 1f)
        val clampedMid = mid.coerceIn(0f, 1f)
        val clampedHigh = high.coerceIn(0f, 1f)
        val js = "javascript:if(window.setAudioFrequency){window.setAudioFrequency($clampedAmp,$clampedPitch,$clampedBass,$clampedMid,$clampedHigh);}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    fun updateScreenShareState(isSharing: Boolean) {
        if (!isLoaded) {
            pendingScreenShare = isSharing
            return
        }
        val js = "javascript:if(window.setScreenShareState){window.setScreenShareState($isSharing);}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    fun updateLiveTime(time: String) {
        if (!isLoaded) {
            pendingTime = time
            return
        }
        val safeTime = time.replace("'", "\\'")
        val js = "javascript:if(window.setLiveTime){window.setLiveTime('$safeTime');}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    fun updateConnectionStatus(status: String) {
        if (!isLoaded) {
            pendingStatus = status
            return
        }
        val safeStatus = status.replace("'", "\\'")
        val js = "javascript:if(window.setConnectionStatus){window.setConnectionStatus('$safeStatus');}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    fun updatePowerState(isOn: Boolean) {
        if (!isLoaded) {
            pendingPower = isOn
            return
        }
        val js = "javascript:if(window.setPowerState){window.setPowerState($isOn);}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    fun updateMicMuted(isMuted: Boolean) {
        if (!isLoaded) {
            pendingMicMuted = isMuted
            return
        }
        val js = "javascript:if(window.setMicMuted){window.setMicMuted($isMuted);}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    fun updateChatTurns(turns: List<ChatTurn>) {
        if (!isLoaded) {
            pendingTurns = turns
            return
        }
        try {
            val jsonArray = JSONArray()
            for (turn in turns) {
                val obj = JSONObject()
                obj.put("userTranscript", turn.userTranscript)
                obj.put("jarvisResponse", turn.jarvisResponse)
                obj.put("formattedTime", turn.formattedTime)
                jsonArray.put(obj)
            }
            val rawJson = jsonArray.toString()
            // Escape for embedding in single-quoted JS literal
            val safeJson = rawJson.replace("\\", "\\\\").replace("'", "\\'")
            val js = "javascript:if(window.syncChatTurns){window.syncChatTurns('$safeJson');}"
            webView.post {
                webView.evaluateJavascript(js, null)
            }
        } catch (e: Exception) {
            android.util.Log.e("OrbHelper", "Failed to update chat turns in HUD", e)
        }
    }

    fun updateLiveUserTranscript(text: String) {
        if (!isLoaded) return
        val quoted = JSONObject.quote(text)
        val js = "javascript:if(window.updateLiveUserTranscript){window.updateLiveUserTranscript($quoted);}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    fun updateLiveAssistantResponse(text: String) {
        if (!isLoaded) return
        val quoted = JSONObject.quote(text)
        val js = "javascript:if(window.updateLiveAssistantResponse){window.updateLiveAssistantResponse($quoted);}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    fun finalizeLiveTurn() {
        if (!isLoaded) return
        val js = "javascript:if(window.finalizeLiveTurn){window.finalizeLiveTurn();}"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/orb/OrbHelper.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/permission/PermissionActivity.kt ===
```kotlin
package com.jarvis.assistant.ui.permission

import android.Manifest
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.Toast
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Typeface
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.assistant.databinding.ActivityPermissionBinding
import com.jarvis.assistant.util.PermissionHelper
import com.jarvis.assistant.util.ThemeManager

class PermissionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionBinding

    private val micLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { updatePermissionStates() }

    private val locationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { updatePermissionStates() }

    private val notificationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { updatePermissionStates() }

    private val allPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { updatePermissionStates() }
    private val contactsLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { updatePermissionStates() }
    private val callLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { updatePermissionStates() }
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { updatePermissionStates() }
    private val bluetoothLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { updatePermissionStates() }
    private val extraStatus = mutableMapOf<String, TextView>()
    private val extraButtons = mutableMapOf<String, Button>()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ThemeManager.applyDynamicBackground(binding.root)

        binding.btnBack.setOnClickListener {
            finish()
        }
        addExtraPermissionCards()

        binding.btnGrantMic.setOnClickListener {
            if (!PermissionHelper.hasRecordAudioPermission(this)) {
                micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            } else PermissionHelper.openAppSettings(this)
        }

        binding.btnGrantLocation.setOnClickListener {
            if (!PermissionHelper.hasLocationPermission(this)) {
                locationLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            } else PermissionHelper.openAppSettings(this)
        }

        binding.btnGrantNotification.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (!PermissionHelper.hasNotificationPermission(this)) {
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else PermissionHelper.openAppSettings(this)
            } else {
                updatePermissionStates()
            }
        }

        binding.btnGrantOverlay.setOnClickListener {
            if (!PermissionHelper.hasOverlayPermission(this)) {
                PermissionHelper.requestOverlayPermission(this)
            } else PermissionHelper.requestOverlayPermission(this)
        }

        binding.btnGrantAccessibility.setOnClickListener {
            PermissionHelper.openAccessibilitySettings(this)
        }

        binding.btnGrantAll.setOnClickListener {
            requestAllMissingPermissions()
        }

        binding.btnOpenSettings.setOnClickListener {
            PermissionHelper.openAppSettings(this)
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStates()
    }

    private fun updatePermissionStates() {
        val hasMic = PermissionHelper.hasRecordAudioPermission(this)
        val hasLoc = PermissionHelper.hasLocationPermission(this)
        val hasNotif = PermissionHelper.hasNotificationPermission(this)
        val hasOverlay = PermissionHelper.hasOverlayPermission(this)
        val hasA11y = PermissionHelper.isAccessibilityServiceEnabled(this)

        updateCardState(hasMic, binding.tvStatusMic, binding.btnGrantMic)
        updateCardState(hasLoc, binding.tvStatusLocation, binding.btnGrantLocation)
        updateCardState(hasNotif, binding.tvStatusNotification, binding.btnGrantNotification)
        updateCardState(hasOverlay, binding.tvStatusOverlay, binding.btnGrantOverlay)
        updateCardState(hasA11y, binding.tvStatusAccessibility, binding.btnGrantAccessibility)
        updateExtraPermission("contacts", PermissionHelper.hasContactsPermission(this))
        updateExtraPermission("phone", hasPermission(Manifest.permission.CALL_PHONE))
        updateExtraPermission("camera", hasPermission(Manifest.permission.CAMERA))
        updateExtraPermission("bluetooth", Build.VERSION.SDK_INT < Build.VERSION_CODES.S || hasPermission(Manifest.permission.BLUETOOTH_CONNECT))
        updateExtraPermission("battery", PermissionHelper.hasBatteryOptimizationPermission(this))
        updateExtraPermission("brightness", PermissionHelper.hasWriteSettingsPermission(this))

        if (hasMic && hasLoc && hasNotif && hasA11y) {
            binding.btnGrantAll.text = "ALL ESSENTIAL PERMISSIONS GRANTED ✓"
            binding.btnGrantAll.alpha = 0.7f
            binding.btnGrantAll.isEnabled = false
        } else {
            binding.btnGrantAll.text = "GRANT ALL PERMISSIONS"
            binding.btnGrantAll.alpha = 1.0f
            binding.btnGrantAll.isEnabled = true
        }
    }

    private fun updateCardState(granted: Boolean, statusTv: TextView, button: Button) {
        if (granted) {
            statusTv.text = "Active & Granted ✓"
            statusTv.setTextColor(Color.parseColor("#10B981")) // Emerald Green
            button.text = "Manage"
            button.alpha = 1.0f
            button.isEnabled = true
        } else {
            statusTv.text = "Action Required • Tap Grant"
            statusTv.setTextColor(Color.parseColor("#F59E0B")) // Amber
            button.text = "Grant"
            button.alpha = 1.0f
            button.isEnabled = true
        }
    }

    private fun requestAllMissingPermissions() {
        val missing = mutableListOf<String>()
        if (!PermissionHelper.hasRecordAudioPermission(this)) {
            missing.add(Manifest.permission.RECORD_AUDIO)
        }
        if (!PermissionHelper.hasLocationPermission(this)) {
            missing.add(Manifest.permission.ACCESS_FINE_LOCATION)
            missing.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !PermissionHelper.hasNotificationPermission(this)) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.CAMERA).forEach {
            if (!hasPermission(it)) missing.add(it)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            missing.add(Manifest.permission.BLUETOOTH_CONNECT)
        }

        if (missing.isNotEmpty()) {
            allPermissionsLauncher.launch(missing.toTypedArray())
        } else if (!PermissionHelper.isAccessibilityServiceEnabled(this)) {
            PermissionHelper.openAccessibilitySettings(this)
        } else if (!PermissionHelper.hasOverlayPermission(this)) {
            PermissionHelper.requestOverlayPermission(this)
        }
    }

    private fun hasPermission(permission: String) = ContextCompat.checkSelfPermission(this, permission) == android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun addExtraPermissionCards() {
        val scroll = (binding.root as ViewGroup).getChildAt(0) as? NestedScrollView ?: return
        val column = scroll.getChildAt(0) as? LinearLayout ?: return
        val insertion = (0 until column.childCount).firstOrNull { column.getChildAt(it).id == com.jarvis.assistant.R.id.cardAccessibilityPermission }
            ?.plus(1) ?: (column.childCount - 2).coerceAtLeast(0)
        val section = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun card(key: String, title: String, details: String, iconId: Int, action: () -> Unit) {
            val body = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = androidx.core.content.ContextCompat.getDrawable(this@PermissionActivity, com.jarvis.assistant.R.drawable.bg_jarvis_card)
                setPadding(dp(18), dp(18), dp(18), dp(18))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
            }
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
            val icon = ImageView(this).apply {
                setImageResource(iconId)
                imageTintList = android.content.res.ColorStateList.valueOf(resolveThemeColor(com.jarvis.assistant.R.attr.themeAccent))
                background = androidx.core.content.ContextCompat.getDrawable(this@PermissionActivity, com.jarvis.assistant.R.drawable.bg_jarvis_avatar)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                contentDescription = null
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(8), 0) }
            val heading = TextView(this).apply { text = title; setTextColor(resolveThemeColor(com.jarvis.assistant.R.attr.themeTextPrimary)); textSize = 15f; setTypeface(typeface, Typeface.BOLD) }
            val status = TextView(this).apply { text = "Checking…"; setTextColor(resolveThemeColor(com.jarvis.assistant.R.attr.themeTextMuted)); textSize = 12f }
            labels.addView(heading); labels.addView(status)
            row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            val button = Button(this).apply {
                text = "Grant"; textSize = 12f; setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                background = androidx.core.content.ContextCompat.getDrawable(this@PermissionActivity, com.jarvis.assistant.R.drawable.bg_jarvis_pill_button)
                setPadding(dp(12), 0, dp(12), 0)
                setOnClickListener { action() }
            }
            row.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)))
            val description = TextView(this).apply { text = details; setTextColor(resolveThemeColor(com.jarvis.assistant.R.attr.themeTextMuted)); textSize = 12f; setPadding(0, dp(10), 0, 0) }
            body.addView(row); body.addView(description)
            section.addView(body)
            extraStatus[key] = status
            extraButtons[key] = button
        }
        card("contacts", "Contacts", "Lets WhatsApp and calling features resolve saved contact names.", com.jarvis.assistant.R.drawable.ic_nav_chat) {
            if (!PermissionHelper.hasContactsPermission(this)) contactsLauncher.launch(Manifest.permission.READ_CONTACTS) else PermissionHelper.openAppSettings(this)
        }
        card("phone", "Phone calls", "Needed only when you ask JARVIS to place a normal phone call.", com.jarvis.assistant.R.drawable.ic_settings_voice) {
            if (!hasPermission(Manifest.permission.CALL_PHONE)) callLauncher.launch(Manifest.permission.CALL_PHONE) else PermissionHelper.openAppSettings(this)
        }
        card("camera", "Camera and flashlight", "Camera access is used only for the flashlight control.", com.jarvis.assistant.R.drawable.ic_settings_orb) {
            if (!hasPermission(Manifest.permission.CAMERA)) cameraLauncher.launch(Manifest.permission.CAMERA) else PermissionHelper.openAppSettings(this)
        }
        card("bluetooth", "Nearby Bluetooth devices", "Optional: allows JARVIS to detect and route audio to a connected headset.", com.jarvis.assistant.R.drawable.ic_settings_plug) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) bluetoothLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) else PermissionHelper.openAppSettings(this)
        }
        card("battery", "Background battery access", "Recommended on Vivo devices so voice service and overlay can stay active in the background.", com.jarvis.assistant.R.drawable.ic_settings_silent) {
            PermissionHelper.requestBatteryOptimization(this)
        }
        card("brightness", "Modify system settings", "Optional: lets JARVIS adjust screen brightness when you ask.", com.jarvis.assistant.R.drawable.ic_settings_palette) {
            PermissionHelper.requestWriteSettings(this)
        }
        val note = TextView(this).apply {
            text = "Screen sharing uses Android’s one-time screen-capture confirmation when you start sharing. Internet, network, notifications, and foreground-service access are managed by Android."
            setTextColor(resolveThemeColor(com.jarvis.assistant.R.attr.themeTextMuted)); textSize = 11f; setPadding(dp(4), dp(4), dp(4), dp(16))
        }
        section.addView(note)
        column.addView(section, insertion)
    }

    private fun updateExtraPermission(key: String, granted: Boolean) {
        val status = extraStatus[key] ?: return
        status.text = if (granted) "Granted ✓" else "Not granted"
        status.setTextColor(if (granted) Color.parseColor("#10B981") else Color.parseColor("#F59E0B"))
        extraButtons[key]?.text = if (granted) "Manage" else "Grant"
    }

    private fun resolveThemeColor(attribute: Int): Int {
        val value = android.util.TypedValue()
        theme.resolveAttribute(attribute, value, true)
        return value.data
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/permission/PermissionActivity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/settings/ApiConnectionActivity.kt ===
```kotlin
package com.jarvis.assistant.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.R
import com.jarvis.assistant.data.model.GeminiConstants
import com.jarvis.assistant.databinding.ActivityApiConnectionBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class ApiConnectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityApiConnectionBinding
    private val preferences by lazy { JarvisApp.instance.preferences }
    private val testHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        com.jarvis.assistant.util.ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityApiConnectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)

        setupUI()
        loadCurrentPreferences()
        setupListeners()
    }

    private fun setupUI() {
        binding.btnBack.setOnClickListener {
            finish()
        }
    }

    private fun loadCurrentPreferences() {
        binding.etApiKey.setText(preferences.apiKey)
        binding.etCustomEndpoint.setText(preferences.customEndpoint)

        if (!preferences.canStoreApiKeySecurely) {
            binding.tvLiveStatus.text = "SECURE STORAGE UNAVAILABLE • API KEY DISABLED"
            binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#EF4444"))
        }

        when (preferences.aiModel) {
            GeminiConstants.MODEL_3_8_LIVE -> binding.rbModelFlash20.isChecked = true
            GeminiConstants.MODEL_3_1_FLASH_AGENT -> binding.rbModelFlash15.isChecked = true
            else -> binding.rbModelFlashThinking.isChecked = true
        }

        if (!preferences.canStoreApiKeySecurely) {
            // Keep the secure-storage warning set above.
        } else if (preferences.apiKey.isNotBlank()) {
            binding.tvLiveStatus.text = "KEY CONFIGURED • READY"
            binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#22C55E"))
        } else {
            binding.tvLiveStatus.text = "NO API KEY • ENTER KEY BELOW"
            binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#EAB308"))
        }

        if (preferences.customEndpoint.isNotBlank()) {
            binding.tvEndpointSummary.text = "Active Endpoint: ${preferences.customEndpoint}"
        }
    }

    private fun setupListeners() {
        binding.btnPasteKey.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val item = clipboard.primaryClip?.getItemAt(0)
            val pasted = item?.text?.toString()?.trim() ?: ""
            if (pasted.isNotBlank()) {
                binding.etApiKey.setText(pasted)
                Toast.makeText(this, "API Key pasted from clipboard", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnClearKey.setOnClickListener {
            binding.etApiKey.setText("")
        }

        binding.btnTestConnection.setOnClickListener {
            val enteredKey = binding.etApiKey.text?.toString()?.trim() ?: ""
            if (enteredKey.isBlank()) {
                Snackbar.make(binding.root, "Please enter an API key first", Snackbar.LENGTH_LONG).show()
                return@setOnClickListener
            }
            testConnection(enteredKey)
        }

        binding.btnSaveConnection.setOnClickListener {
            saveAndApply()
        }
    }

    private fun testConnection(apiKey: String) {
        binding.btnTestConnection.isEnabled = false
        binding.tvPingResult.text = "Testing ping..."
        binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#3B82F6"))

        lifecycleScope.launch {
            val startTime = System.currentTimeMillis()
            val result = withContext(Dispatchers.IO) {
                try {
                    val url = "https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey"
                    val request = Request.Builder().url(url).build()
                    testHttpClient.newCall(request).execute().use { response ->
                        val duration = System.currentTimeMillis() - startTime
                        if (response.isSuccessful) {
                            Pair(true, duration)
                        } else {
                            Pair(false, response.code)
                        }
                    }
                } catch (e: Exception) {
                    Pair(false, -1)
                }
            }

            binding.btnTestConnection.isEnabled = true
            if (result.first) {
                val ping = result.second
                binding.tvPingResult.text = "Ping: ${ping}ms • Valid"
                binding.tvLiveStatus.text = "CONNECTED • HANDSHAKE OK"
                binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#22C55E"))
                Snackbar.make(binding.root, "Connection verified! Ping: ${ping}ms", Snackbar.LENGTH_LONG).show()
            } else {
                val code = result.second
                binding.tvPingResult.text = if (code == -1) "Network Timeout" else "HTTP $code Error"
                binding.tvLiveStatus.text = "FAILED • INVALID KEY OR NETWORK"
                binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#EF4444"))
                Snackbar.make(binding.root, "Connection failed. Please verify API key.", Snackbar.LENGTH_LONG).show()
            }
        }
    }

    private fun saveAndApply() {
        val key = binding.etApiKey.text?.toString()?.trim() ?: ""
        val customEp = binding.etCustomEndpoint.text?.toString()?.trim() ?: ""

        val selectedModel = when (binding.rgModelGroup.checkedRadioButtonId) {
            binding.rbModelFlash20.id -> GeminiConstants.MODEL_3_8_LIVE
            binding.rbModelFlash15.id -> GeminiConstants.MODEL_3_1_FLASH_AGENT
            else -> GeminiConstants.MODEL_3_1_FLASH
        }

        try {
            preferences.apiKey = key
        } catch (e: IllegalStateException) {
            Snackbar.make(binding.root, e.message ?: "Secure key storage is unavailable.", Snackbar.LENGTH_LONG).show()
            return
        }
        preferences.aiModel = selectedModel
        preferences.customEndpoint = customEp
        com.jarvis.assistant.background.JarvisConversationService.clearLiveError()
        com.jarvis.assistant.background.JarvisConversationService.restartSession()

        Toast.makeText(this, "API & Connection settings saved!", Toast.LENGTH_SHORT).show()
        finish()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/settings/ApiConnectionActivity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/settings/HandsFreeActivity.kt ===
```kotlin
package com.jarvis.assistant.ui.settings

import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.jarvis.assistant.R
import com.jarvis.assistant.databinding.ActivityHandsFreeBinding
import com.jarvis.assistant.ui.permission.PermissionActivity
import com.jarvis.assistant.util.PermissionHelper
import com.jarvis.assistant.util.ThemeManager

class HandsFreeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHandsFreeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityHandsFreeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ThemeManager.applyDynamicBackground(binding.root)

        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        updateServiceStatus()
    }

    private fun setupListeners() {
        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnToggleAccessibility.setOnClickListener {
            PermissionHelper.openAccessibilitySettings(this)
        }

        binding.btnOpenAccessibilitySettings.setOnClickListener {
            PermissionHelper.openAccessibilitySettings(this)
        }

        binding.btnOpenAllPermissions.setOnClickListener {
            startActivity(Intent(this, PermissionActivity::class.java))
        }

        binding.btnConfigureApi.setOnClickListener {
            startActivity(Intent(this, ApiConnectionActivity::class.java))
        }

        binding.btnHandsFreeOfficialTelegram.setOnClickListener {
            openUrl("https://t.me/+sYana61LvHdmZmE1")
        }

        binding.btnHandsFreeDiscussion.setOnClickListener {
            openUrl("https://t.me/+DmyO7NFUia01YTVl")
        }

        binding.btnHandsFreeInstagram.setOnClickListener {
            openUrl("https://www.instagram.com/techgptx.ai")
        }

        binding.tvFooterHandsFree.setOnClickListener {
            openUrl("https://t.me/+sYana61LvHdmZmE1")
        }
    }

    private fun updateServiceStatus() {
        val isEnabled = PermissionHelper.isAccessibilityServiceEnabled(this)
        if (isEnabled) {
            binding.dotAccessibilityStatus.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.status_green)
            )
            binding.tvAccessibilityStatus.text = "HANDS-FREE SERVICE: ACTIVE"
            binding.tvAccessibilityStatus.setTextColor(
                ContextCompat.getColor(this, R.color.status_green)
            )
            binding.btnToggleAccessibility.text = "Accessibility Service is Active"
        } else {
            binding.dotAccessibilityStatus.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.status_red)
            )
            binding.tvAccessibilityStatus.text = "SERVICE DISABLED • TAP TO ENABLE"
            binding.tvAccessibilityStatus.setTextColor(
                ContextCompat.getColor(this, R.color.status_red)
            )
            binding.btnToggleAccessibility.text = "Enable Accessibility Service"
        }
    }

    private fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Unable to open link", Toast.LENGTH_SHORT).show()
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/settings/HandsFreeActivity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/settings/OverlayAvatarActivity.kt ===
```kotlin
package com.jarvis.assistant.ui.settings

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import android.widget.RadioGroup
import android.widget.Spinner
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.R
import com.jarvis.assistant.util.ThemeManager

class OverlayAvatarActivity : AppCompatActivity() {
    private lateinit var avatarGallery: WebView
    private lateinit var overlaySwitch: SwitchCompat
    private val preferences get() = JarvisApp.instance.preferences
    private lateinit var assetLoader: WebViewAssetLoader

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_overlay_avatar)
        ThemeManager.applyDynamicBackground(findViewById(R.id.overlayAvatarRoot))

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }
        overlaySwitch = findViewById(R.id.switchOverlayEnabled)
        overlaySwitch.isChecked = preferences.isTaskOverlayEnabled
        val modeGroup = findViewById<RadioGroup>(R.id.radioOverlayMode)
        modeGroup.check(if (preferences.taskOverlayMode == "working") R.id.rbOverlayWorking else R.id.rbOverlayAlways)
        modeGroup.setOnCheckedChangeListener { _, checkedId ->
            preferences.taskOverlayMode = if (checkedId == R.id.rbOverlayWorking) "working" else "always"
        }
        val edgeSpinner = findViewById<Spinner>(R.id.spinnerOverlayEdge)
        val edgeValues = listOf("right", "left", "top", "bottom")
        var edgeSelectionReady = false
        edgeSpinner.setSelection(edgeValues.indexOf(preferences.taskOverlayEdge).coerceAtLeast(0))
        edgeSpinner.post { edgeSelectionReady = true }
        modeGroup.isEnabled = preferences.isTaskOverlayEnabled
        edgeSpinner.isEnabled = preferences.isTaskOverlayEnabled
        for (i in 0 until modeGroup.childCount) modeGroup.getChildAt(i).isEnabled = preferences.isTaskOverlayEnabled
        edgeSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (edgeSelectionReady) edgeValues.getOrNull(position)?.let {
                    preferences.taskOverlayFreePosition = false
                    preferences.taskOverlayEdge = it
                }
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }
        overlaySwitch.setOnCheckedChangeListener { _, enabled ->
            preferences.isTaskOverlayEnabled = enabled
            modeGroup.isEnabled = enabled
            edgeSpinner.isEnabled = enabled
            for (i in 0 until modeGroup.childCount) modeGroup.getChildAt(i).isEnabled = enabled
        }
        avatarGallery = findViewById(R.id.avatarGallery)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        setupGallery()
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun setupGallery() {
        avatarGallery.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        avatarGallery.settings.javaScriptEnabled = true
        avatarGallery.settings.domStorageEnabled = true
        avatarGallery.settings.allowFileAccess = false
        avatarGallery.addJavascriptInterface(AvatarPickerBridge(), "JarvisAvatarPicker")
        avatarGallery.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                selectInGallery(preferences.taskOverlayAvatar)
                avatarGallery.evaluateJavascript(
                    "window.setGalleryTheme && window.setGalleryTheme('#${themeColor(R.attr.themeTextPrimary)}', '#${themeColor(R.attr.themeAccent)}')",
                    null
                )
            }
        }
        avatarGallery.loadUrl("https://appassets.androidplatform.net/assets/overlay-toys/gallery.html")
    }

    private fun selectInGallery(name: String) {
        avatarGallery.evaluateJavascript("window.setSelectedAvatar && window.setSelectedAvatar('$name')", null)
    }

    private fun themeColor(attribute: Int): String {
        val value = android.util.TypedValue()
        theme.resolveAttribute(attribute, value, true)
        return String.format(java.util.Locale.US, "%06X", 0xFFFFFF and value.data)
    }

    private inner class AvatarPickerBridge {
        @JavascriptInterface
        fun pageReady() {
            runOnUiThread { selectInGallery(preferences.taskOverlayAvatar) }
        }

        @JavascriptInterface
        fun selectAvatar(name: String) {
            runOnUiThread {
                preferences.taskOverlayAvatar = name
                selectInGallery(preferences.taskOverlayAvatar)
            }
        }
    }

    override fun onDestroy() {
        if (::avatarGallery.isInitialized) {
            avatarGallery.removeJavascriptInterface("JarvisAvatarPicker")
            avatarGallery.stopLoading()
            avatarGallery.destroy()
        }
        super.onDestroy()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/settings/OverlayAvatarActivity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/settings/PersonaActivity.kt ===
```kotlin
package com.jarvis.assistant.ui.settings

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.data.model.GeminiConstants
import com.jarvis.assistant.databinding.ActivityPersonaBinding
import com.jarvis.assistant.util.ThemeManager

class PersonaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPersonaBinding
    private val preferences by lazy { JarvisApp.instance.preferences }

    private var currentSelectedPersona = GeminiConstants.PERSONALITY_ASSISTANT

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityPersonaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ThemeManager.applyDynamicBackground(binding.root)

        setupUI()
        loadInitialState()
        setupListeners()
    }

    private fun setupUI() {
        binding.btnBack.setOnClickListener {
            finish()
        }
    }

    private fun loadInitialState() {
        val current = preferences.personality
        val initialPersona = when (current) {
            GeminiConstants.PERSONALITY_GIRLFRIEND -> GeminiConstants.PERSONALITY_GIRLFRIEND
            GeminiConstants.PERSONALITY_BOYFRIEND -> GeminiConstants.PERSONALITY_BOYFRIEND
            GeminiConstants.PERSONALITY_TECHGPT_X -> GeminiConstants.PERSONALITY_TECHGPT_X
            else -> GeminiConstants.PERSONALITY_ASSISTANT
        }
        selectPersona(initialPersona, updateVoiceDefault = false)

        binding.etUserName.setText(preferences.userName.ifBlank { "TechGPT X" })

        selectVoice(preferences.voice)
        updatePersonaPreview()
        binding.scrollPersona.post { binding.scrollPersona.scrollTo(0, 0) }
    }

    private fun setupListeners() {
        binding.etUserName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = updatePersonaPreview()
            override fun afterTextChanged(s: Editable?) = Unit
        })
        binding.cardPersonaJarvis.setOnClickListener {
            selectPersona(GeminiConstants.PERSONALITY_ASSISTANT, updateVoiceDefault = true)
        }

        binding.cardPersonaGirlfriend.setOnClickListener {
            selectPersona(GeminiConstants.PERSONALITY_GIRLFRIEND, updateVoiceDefault = true)
        }

        binding.cardPersonaBoyfriend.setOnClickListener {
            selectPersona(GeminiConstants.PERSONALITY_BOYFRIEND, updateVoiceDefault = true)
        }

        binding.cardPersonaTechGpt.setOnClickListener {
            selectPersona(GeminiConstants.PERSONALITY_TECHGPT_X, updateVoiceDefault = true)
        }

        binding.btnActivatePersona.setOnClickListener {
            saveAndActivate()
        }
    }

    private fun selectPersona(personaKey: String, updateVoiceDefault: Boolean) {
        currentSelectedPersona = personaKey

        binding.rbSelectJarvis.isChecked = (personaKey == GeminiConstants.PERSONALITY_ASSISTANT)
        binding.rbSelectGirlfriend.isChecked = (personaKey == GeminiConstants.PERSONALITY_GIRLFRIEND)
        binding.rbSelectBoyfriend.isChecked = (personaKey == GeminiConstants.PERSONALITY_BOYFRIEND)
        binding.rbSelectTechGpt.isChecked = (personaKey == GeminiConstants.PERSONALITY_TECHGPT_X)

        if (updateVoiceDefault) {
            when (personaKey) {
                GeminiConstants.PERSONALITY_GIRLFRIEND -> selectVoice("Aoede")
                GeminiConstants.PERSONALITY_BOYFRIEND -> selectVoice("Fenrir")
                GeminiConstants.PERSONALITY_TECHGPT_X -> selectVoice("Puck")
                else -> selectVoice("Charon")
            }
        }
        if (::binding.isInitialized) updatePersonaPreview()
    }

    private fun updatePersonaPreview() {
        if (!::binding.isInitialized) return
        val persona = when (currentSelectedPersona) {
            GeminiConstants.PERSONALITY_GIRLFRIEND -> "Pari"
            GeminiConstants.PERSONALITY_BOYFRIEND -> "Kabir"
            GeminiConstants.PERSONALITY_TECHGPT_X -> "TechGPT X"
            else -> "Jarvis Pro"
        }
        val operator = binding.etUserName.text?.toString()?.trim().takeUnless { it.isNullOrBlank() } ?: "TechGPT X"
        binding.tvPersonaPreview.text = "$persona · ${getSelectedVoice()}"
        binding.tvPersonaGreeting.text = "Ready to help, $operator."
    }

    private fun selectVoice(voiceName: String) {
        when (voiceName.lowercase()) {
            "aoede" -> binding.rbVoiceAoede.isChecked = true
            "kore" -> binding.rbVoiceKore.isChecked = true
            "fenrir" -> binding.rbVoiceFenrir.isChecked = true
            "puck" -> binding.rbVoicePuck.isChecked = true
            "charon" -> binding.rbVoiceCharon.isChecked = true
            else -> binding.rbVoicePuck.isChecked = true
        }
    }

    private fun getSelectedVoice(): String {
        return when {
            binding.rbVoiceAoede.isChecked -> "Aoede"
            binding.rbVoiceKore.isChecked -> "Kore"
            binding.rbVoiceFenrir.isChecked -> "Fenrir"
            binding.rbVoiceCharon.isChecked -> "Charon"
            else -> "Puck"
        }
    }

    private fun saveAndActivate() {
        val userName = binding.etUserName.text?.toString()?.trim()
        if (!userName.isNullOrBlank()) {
            preferences.userName = userName
        } else {
            preferences.userName = "TechGPT X"
        }

        val voice = getSelectedVoice()
        preferences.voice = voice
        preferences.personality = currentSelectedPersona

        val personaDisplayName = when (currentSelectedPersona) {
            GeminiConstants.PERSONALITY_GIRLFRIEND -> "Pari (Girlfriend Mode)"
            GeminiConstants.PERSONALITY_BOYFRIEND -> "Kabir (Boyfriend Mode)"
            GeminiConstants.PERSONALITY_TECHGPT_X -> "TechGPT X Neural Core"
            else -> "Jarvis Pro"
        }

        Toast.makeText(
            this,
            "Activated: $personaDisplayName with $voice Voice",
            Toast.LENGTH_LONG
        ).show()

        finish()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/settings/PersonaActivity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/settings/PrivacyShieldActivity.kt ===
```kotlin
package com.jarvis.assistant.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.assistant.databinding.ActivityPrivacyShieldBinding
import com.jarvis.assistant.util.ThemeManager

class PrivacyShieldActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPrivacyShieldBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityPrivacyShieldBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ThemeManager.applyDynamicBackground(binding.root)

        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnJoinOfficialTelegram.setOnClickListener {
            openUrl("https://t.me/+sYana61LvHdmZmE1")
        }

        binding.btnJoinTelegram.setOnClickListener {
            openUrl("https://t.me/+DmyO7NFUia01YTVl")
        }

        binding.btnJoinInstagram.setOnClickListener {
            openUrl("https://www.instagram.com/techgptx.ai")
        }

        binding.btnJoinYoutube.setOnClickListener {
            openUrl("https://youtube.com/@TechGptX")
        }
    }

    private fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (_: Exception) {
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/settings/PrivacyShieldActivity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/settings/SettingsActivity.kt ===
```kotlin
package com.jarvis.assistant.ui.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.assistant.R

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        com.jarvis.assistant.util.ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<android.view.View>(R.id.settingsContainer)?.let {
            com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(it)
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/settings/SettingsActivity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/settings/SettingsFragment.kt ===
```kotlin
package com.jarvis.assistant.ui.settings

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.R
import com.jarvis.assistant.data.model.GeminiConstants
import com.jarvis.assistant.databinding.FragmentSettingsBinding
import com.jarvis.assistant.ui.memory.MemoryActivity
import com.jarvis.assistant.ui.permission.PermissionActivity
import com.jarvis.assistant.ui.voice.VoiceEnrollmentActivity

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val preferences by lazy { JarvisApp.instance.preferences }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)

        loadUserData()
        setupClickListeners()
    }

    override fun onResume() {
        super.onResume()
        if (_binding != null) {
            com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)
            loadUserData()
        }
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden && _binding != null) {
            binding.root.visibility = View.VISIBLE
            com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)
            loadUserData()
        } else if (hidden && _binding != null) {
            binding.root.visibility = View.GONE
        }
    }

    private fun loadUserData() {
        val userName = preferences.userName.ifBlank { "Rehaan" }
        binding.tvProfileName.text = userName
        binding.tvProfileSubtitle.text = "JARVIS OPERATOR • PRIMARY USER"

        // Owner Voice Profile Status
        val hasVoiceProfile = preferences.hasOwnerVoiceProfile()
        if (hasVoiceProfile) {
            binding.tvOwnerVoiceBadge.text = "ACTIVE"
            binding.tvOwnerVoiceBadge.setTextColor(Color.parseColor("#10B981"))
            binding.tvOwnerVoiceBadge.setBackgroundResource(R.drawable.bg_jarvis_status_badge_green)
            binding.tvOwnerVoiceSubtitle.text = "Voice Profile Active • Only you can speak"

            binding.tvProfileVoiceStatus.text = "VOICE ENROLLED"
            binding.tvProfileVoiceStatus.setTextColor(Color.parseColor("#10B981"))
            binding.chipProfileVoiceStatus.setBackgroundResource(R.drawable.bg_jarvis_status_badge_green)
            binding.ivProfileVoiceBadgeIcon.setImageResource(R.drawable.ic_verified_badge)
            binding.ivProfileVoiceBadgeIcon.imageTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#10B981"))
        } else {
            binding.tvOwnerVoiceBadge.text = "SETUP"
            binding.tvOwnerVoiceBadge.setTextColor(ContextCompat.getColor(requireContext(), R.color.accent_sapphire))
            binding.tvOwnerVoiceBadge.setBackgroundResource(R.drawable.bg_jarvis_status_badge)
            binding.tvOwnerVoiceSubtitle.text = "Not enrolled • Tap to record voice profile"

            binding.tvProfileVoiceStatus.text = "ENROLL VOICE"
            binding.tvProfileVoiceStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.accent_sapphire))
            binding.chipProfileVoiceStatus.setBackgroundResource(R.drawable.bg_jarvis_status_badge)
            binding.ivProfileVoiceBadgeIcon.setImageResource(R.drawable.ic_settings_owner_voice)
            binding.ivProfileVoiceBadgeIcon.imageTintList = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(requireContext(), R.color.accent_sapphire)
            )
        }

        // Language
        binding.tvCurrentLanguage.text = preferences.language

        // Persona & Voice
        val currentPersona = preferences.personality
        val currentVoice = preferences.voice
        binding.tvCurrentPersona.text = "$currentPersona • Voice: $currentVoice"
        binding.tvProfilePersonaChip.text = currentPersona.uppercase()

        // Silent Execution Mode
        binding.switchSilentMode.isChecked = preferences.isSilentExecutionMode

        // Model
        val modelDisplay = preferences.aiModel.removePrefix("models/")
        binding.tvCurrentModel.text = "$modelDisplay • Live WebSocket"

        // Theme
        binding.tvCurrentTheme.text = when (preferences.appTheme) {
            "dark" -> "Dark Theme"
            "red" -> "Red Theme"
            "sunset" -> "Sunset Theme"
            "custom" -> "Custom (${preferences.customThemeColor})"
            else -> "Light Theme"
        }
    }

    private fun setupClickListeners() {
        // Profile Card -> Change Name
        binding.cardProfile.setOnClickListener {
            showEditNameDialog()
        }

        // Voice Status Chip on Profile Card -> Opens Voice Enrollment
        binding.chipProfileVoiceStatus.setOnClickListener {
            startActivity(Intent(requireContext(), VoiceEnrollmentActivity::class.java))
        }

        // Section 1: AI & Voice Intelligence
        binding.rowOwnerVoice.setOnClickListener {
            startActivity(Intent(requireContext(), VoiceEnrollmentActivity::class.java))
        }

        binding.rowLanguage.setOnClickListener {
            showLanguageDialog()
        }

        binding.rowPersonaVoice.setOnClickListener {
            startActivity(Intent(requireContext(), PersonaActivity::class.java))
        }

        binding.switchSilentMode.setOnCheckedChangeListener { _, isChecked ->
            preferences.isSilentExecutionMode = isChecked
            val msg = if (isChecked) "Silent Execution Mode Enabled" else "Silent Execution Mode Disabled"
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
        }

        // Section 2: System & Intelligence Data
        binding.rowApiConnection.setOnClickListener {
            startActivity(Intent(requireContext(), ApiConnectionActivity::class.java))
        }

        binding.rowMemory.setOnClickListener {
            startActivity(Intent(requireContext(), MemoryActivity::class.java))
        }

        binding.rowPermissions.setOnClickListener {
            startActivity(Intent(requireContext(), PermissionActivity::class.java))
        }

        binding.rowOverlayAvatars.setOnClickListener {
            startActivity(Intent(requireContext(), OverlayAvatarActivity::class.java))
        }

        binding.rowApplications.setOnClickListener {
            startActivity(Intent(requireContext(), HandsFreeActivity::class.java))
        }

        // Section 3: Appearance & Security
        binding.rowAppTheme.setOnClickListener {
            ThemeSelectionBottomSheet.newInstance().show(childFragmentManager, ThemeSelectionBottomSheet.TAG)
        }

        binding.rowPrivacyPolicy.setOnClickListener {
            startActivity(Intent(requireContext(), PrivacyShieldActivity::class.java))
        }

        binding.rowAppIdentity.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("JARVIS App Identity")
                .setMessage(com.jarvis.assistant.security.AppIdentityVerifier.report(requireContext()))
                .setPositiveButton("Close", null)
                .show()
        }

        // Social Media Community Buttons
        binding.btnSocialTelegram.setOnClickListener {
            openUrl("https://t.me/+sYana61LvHdmZmE1")
        }

        binding.btnSocialInstagram.setOnClickListener {
            openUrl("https://www.instagram.com/techgptx.ai")
        }

        binding.btnSocialYoutube.setOnClickListener {
            openUrl("https://youtube.com/@TechGptX")
        }

        binding.tvFooterCredit.setOnClickListener {
            openUrl("https://t.me/+sYana61LvHdmZmE1")
        }
    }

    private fun showLanguageDialog() {
        val languages = GeminiConstants.SUPPORTED_LANGUAGES.toTypedArray()
        val currentIndex = languages.indexOfFirst { it.equals(preferences.language, ignoreCase = true) }.let { if (it >= 0) it else 0 }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Select Conversation Language")
            .setSingleChoiceItems(languages, currentIndex) { dialog, which ->
                val chosen = languages[which]
                preferences.language = chosen
                binding.tvCurrentLanguage.text = chosen
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showWakeWordDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Wake Words & Sensitivity")
            .setMessage("• Wake Words: 'Jarvis', 'Hey Jarvis'\n• Acoustic Trigger: Double Clap detection\n• Standby Mode: Low-power local Vosk offline engine\n\nWhen standby listening is active, Jarvis awakens instantly upon hearing your voice.")
            .setPositiveButton("Got It", null)
            .show()
    }

    private fun showAppAutomationDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Autonomous App Automation")
            .setMessage("Jarvis is integrated with your device capabilities:\n\n• WhatsApp: Hands-free messaging & calls\n• YouTube: Search and playback automation\n• Phone Controls: Flashlight, Volume, Brightness, Bluetooth\n• Apps & Tools: Launch, search, and manage apps via voice")
            .setPositiveButton("Close", null)
            .show()
    }

    private fun showEditNameDialog() {
        val input = EditText(requireContext()).apply {
            setText(preferences.userName.ifBlank { "Rehaan" })
            setSelection(text.length)
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Operator Name")
            .setMessage("Enter the name Jarvis should use to address you:")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotBlank()) {
                    preferences.userName = newName
                    loadUserData()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(requireContext(), "Unable to open link", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/settings/SettingsFragment.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/settings/ThemeSelectionBottomSheet.kt ===
```kotlin
package com.jarvis.assistant.ui.settings

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.databinding.BottomSheetThemeSelectionBinding
import com.jarvis.assistant.ui.home.HomeFragment
import com.jarvis.assistant.ui.home.MainActivity

class ThemeSelectionBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetThemeSelectionBinding? = null
    private val binding get() = _binding!!
    private val preferences by lazy { JarvisApp.instance.preferences }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetThemeSelectionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val currentTheme = preferences.appTheme
        updateCheckmarks(currentTheme)

        val customHex = preferences.customThemeColor
        binding.etCustomHex.setText(customHex)
        try {
            binding.viewCustomPreview.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(customHex))
        } catch (_: Exception) {}

        binding.cardThemeLight.setOnClickListener { selectTheme("light", "Light") }
        binding.cardThemeDark.setOnClickListener { selectTheme("dark", "Dark") }
        binding.cardThemeRed.setOnClickListener { selectTheme("red", "Red") }
        binding.cardThemeSunset.setOnClickListener { selectTheme("sunset", "Sunset") }

        binding.btnApplyCustom.setOnClickListener {
            val hex = binding.etCustomHex.text.toString().trim()
            applyCustomColor(hex)
        }

        // Quick Swatches
        binding.swatch1.setOnClickListener { applyCustomColor("#000000") }
        binding.swatch2.setOnClickListener { applyCustomColor("#1E1B4B") }
        binding.swatch3.setOnClickListener { applyCustomColor("#042F2E") }
        binding.swatch4.setOnClickListener { applyCustomColor("#451A03") }
        binding.swatch5.setOnClickListener { applyCustomColor("#F0FDF4") }
        binding.swatch6.setOnClickListener { applyCustomColor("#FAF5FF") }
    }

    private fun applyCustomColor(hexInput: String) {
        val hex = if (hexInput.startsWith("#")) hexInput else "#$hexInput"
        try {
            Color.parseColor(hex)
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Invalid HEX color format (e.g. #1E1B4B)", Toast.LENGTH_SHORT).show()
            return
        }

        preferences.customThemeColor = hex
        preferences.appTheme = "custom"
        updateCheckmarks("custom")

        Toast.makeText(requireContext(), "Custom theme set to $hex", Toast.LENGTH_SHORT).show()

        // Sync with Orb on HomeFragment
        val mainActivity = activity as? MainActivity
        val homeFrag = mainActivity?.supportFragmentManager?.fragments
            ?.filterIsInstance<HomeFragment>()
            ?.firstOrNull()
        homeFrag?.setOrbTheme("custom", hex)

        dismiss()
        activity?.recreate()
    }

    private fun selectTheme(themeKey: String, themeName: String) {
        preferences.appTheme = themeKey
        updateCheckmarks(themeKey)
        Toast.makeText(requireContext(), "Theme set to $themeName", Toast.LENGTH_SHORT).show()

        // Sync with Orb on HomeFragment
        val mainActivity = activity as? MainActivity
        val homeFrag = mainActivity?.supportFragmentManager?.fragments
            ?.filterIsInstance<HomeFragment>()
            ?.firstOrNull()
        homeFrag?.setOrbTheme(themeKey, null)

        dismiss()
        activity?.recreate()
    }

    private fun updateCheckmarks(activeTheme: String) {
        binding.ivCheckLight.visibility = if (activeTheme == "light") View.VISIBLE else View.GONE
        binding.ivCheckDark.visibility = if (activeTheme == "dark") View.VISIBLE else View.GONE
        binding.ivCheckRed.visibility = if (activeTheme == "red") View.VISIBLE else View.GONE
        binding.ivCheckSunset.visibility = if (activeTheme == "sunset") View.VISIBLE else View.GONE
        binding.ivCheckCustom.visibility = if (activeTheme == "custom") View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val TAG = "ThemeSelectionBottomSheet"
        fun newInstance() = ThemeSelectionBottomSheet()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/settings/ThemeSelectionBottomSheet.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/voice/VoiceEnrollmentActivity.kt ===
```kotlin
package com.jarvis.assistant.ui.voice

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.R
import com.jarvis.assistant.audio.OwnerVoiceManager
import com.jarvis.assistant.audio.VoskModelManager
import com.jarvis.assistant.databinding.ActivityVoiceEnrollmentBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.Locale

class VoiceEnrollmentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVoiceEnrollmentBinding
    private val preferences by lazy { JarvisApp.instance.preferences }

    private val samplePrompts = listOf(
        "\"Hey Jarvis, wake up\"",
        "\"Jarvis, turn on the flashlight\"",
        "\"Jarvis, what is the weather today?\""
    )

    private val recordedVectors = mutableListOf<FloatArray>()
    private var currentSampleIndex = 0

    private var isRecording = false
    private var isTesting = false
    private var recordingJob: Job? = null
    private var audioRecord: AudioRecord? = null
    private val recordingBuffer = ByteArrayOutputStream()

    private val requestAudioLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(this, "Microphone permission required for voice enrollment", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.jarvis.assistant.util.ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityVoiceEnrollmentBinding.inflate(layoutInflater)
        setContentView(binding.root)
        com.jarvis.assistant.util.ThemeManager.applyDynamicBackground(binding.root)

        binding.btnBack.setOnClickListener { finish() }

        // Trigger Vosk initialization in background if not already started
        VoskModelManager.init(applicationContext, lifecycleScope)

        setupUI()
        setupListeners()
        checkPermissions()
    }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun setupUI() {
        val hasProfile = preferences.hasOwnerVoiceProfile()
        val isEnabled = preferences.isOwnerVoiceEnabled && hasProfile

        binding.switchOwnerOnly.isChecked = isEnabled
        binding.switchOwnerOnly.isEnabled = hasProfile

        if (hasProfile) {
            binding.tvEnrollmentStatus.text = if (isEnabled) "OWNER VOICE: ACTIVE" else "OWNER VOICE: PAUSED"
            binding.tvEnrollmentStatus.setTextColor(getColor(if (isEnabled) R.color.primary_cyan else R.color.text_secondary))
            binding.tvStatusDescription.text = "Jarvis is calibrated to your voice. Any speech or commands from other people are automatically blocked."
            binding.viewStatusDot.setBackgroundResource(if (isEnabled) R.drawable.circle_cyan else R.drawable.circle_cyan)
        } else {
            binding.tvEnrollmentStatus.text = "OWNER VOICE: NOT ENROLLED"
            binding.tvEnrollmentStatus.setTextColor(getColor(R.color.status_amber))
            binding.tvStatusDescription.text = "Enroll 3 voice samples below. Once saved, Jarvis will respond ONLY to you and ignore anyone else."
        }

        // Sensitivity
        val threshold = preferences.ownerVoiceThreshold
        when {
            threshold <= OwnerVoiceManager.STRICT_THRESHOLD + 0.02f -> binding.rbStrict.isChecked = true
            threshold >= OwnerVoiceManager.RELAXED_THRESHOLD - 0.02f -> binding.rbRelaxed.isChecked = true
            else -> binding.rbBalanced.isChecked = true
        }

        updateEnrollmentStepUI()
    }

    private fun updateEnrollmentStepUI() {
        if (currentSampleIndex < samplePrompts.size) {
            binding.tvStepIndicator.text = "TRAIN STEP ${currentSampleIndex + 1} OF 3"
            binding.tvPromptPhrase.text = samplePrompts[currentSampleIndex]
            binding.btnRecordSample.text = "TAP & SPEAK PHRASE"
            binding.tvRecordFeedback.text = "Tap to start recording sample ${currentSampleIndex + 1}"
        } else {
            binding.tvStepIndicator.text = "ENROLLMENT COMPLETE"
            binding.tvPromptPhrase.text = "All 3 samples registered!"
            binding.btnRecordSample.text = "RE-RECORD SAMPLES"
            binding.tvRecordFeedback.text = "Owner voice profile is active and secured."
        }

        // Dot indicators
        val tvAccent = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeAccent, tvAccent, true)
        val accentColor = if (tvAccent.data != 0) tvAccent.data else ContextCompat.getColor(this, R.color.primary_cyan)

        val tvMuted = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeTextMuted, tvMuted, true)
        val mutedColor = if (tvMuted.data != 0) tvMuted.data else ContextCompat.getColor(this, R.color.text_muted)

        val greenColor = ContextCompat.getColor(this, R.color.status_green)

        binding.tvStep1Dot.setTextColor(if (recordedVectors.size >= 1) greenColor else if (currentSampleIndex == 0) accentColor else mutedColor)
        binding.tvStep2Dot.setTextColor(if (recordedVectors.size >= 2) greenColor else if (currentSampleIndex == 1) accentColor else mutedColor)
        binding.tvStep3Dot.setTextColor(if (recordedVectors.size >= 3) greenColor else if (currentSampleIndex == 2) accentColor else mutedColor)
    }

    private fun setupListeners() {
        binding.switchOwnerOnly.setOnCheckedChangeListener { _, isChecked ->
            preferences.isOwnerVoiceEnabled = isChecked
            setupUI()
        }

        binding.btnRecordSample.setOnClickListener {
            if (isRecording) {
                stopRecordingSample()
            } else {
                if (currentSampleIndex >= samplePrompts.size) {
                    // Reset to start over
                    recordedVectors.clear()
                    currentSampleIndex = 0
                    updateEnrollmentStepUI()
                }
                startRecordingSample()
            }
        }

        binding.btnTestVoice.setOnClickListener {
            if (isTesting) {
                stopTestingVoice()
            } else {
                startTestingVoice()
            }
        }

        binding.rgSensitivity.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rbStrict -> preferences.ownerVoiceThreshold = OwnerVoiceManager.STRICT_THRESHOLD
                R.id.rbBalanced -> preferences.ownerVoiceThreshold = OwnerVoiceManager.DEFAULT_THRESHOLD
                R.id.rbRelaxed -> preferences.ownerVoiceThreshold = OwnerVoiceManager.RELAXED_THRESHOLD
            }
            Toast.makeText(this, "Sensitivity updated", Toast.LENGTH_SHORT).show()
        }

        binding.btnClearProfile.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Reset Voice Profile?")
                .setMessage("This will remove your enrolled voiceprint. Jarvis will respond to all voices until you re-train.")
                .setPositiveButton("RESET") { _, _ ->
                    preferences.clearOwnerVoiceProfile()
                    recordedVectors.clear()
                    currentSampleIndex = 0
                    setupUI()
                    Toast.makeText(this, "Voice profile cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("CANCEL", null)
                .show()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startRecordingSample() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            checkPermissions()
            return
        }

        isRecording = true
        binding.btnRecordSample.text = "STOP & PROCESS"
        binding.btnRecordSample.setBackgroundColor(getColor(R.color.status_amber))
        binding.tvRecordFeedback.text = "Listening... Speak the phrase above now!"

        startAudioCapture { pcmChunk ->
            recordingBuffer.write(pcmChunk)
        }
    }

    private fun stopRecordingSample() {
        isRecording = false
        stopAudioCapture()

        val pcmAudio = recordingBuffer.toByteArray()
        recordingBuffer.reset()

        if (pcmAudio.size < 16000 * 2 * 0.4) {
            binding.btnRecordSample.isEnabled = true
            binding.btnRecordSample.setBackgroundColor(getColor(R.color.primary_cyan))
            binding.tvRecordFeedback.text = "Recording was too short. Please speak the full phrase and tap Stop."
            binding.btnRecordSample.text = "RETRY SAMPLE ${currentSampleIndex + 1}"
            return
        }

        binding.btnRecordSample.isEnabled = false
        binding.tvRecordFeedback.text = "Analyzing vocal acoustic signature..."

        lifecycleScope.launch(Dispatchers.Default) {
            val vector = OwnerVoiceManager.extractSpeakerVector(pcmAudio)

            withContext(Dispatchers.Main) {
                binding.btnRecordSample.isEnabled = true
                binding.btnRecordSample.setBackgroundColor(getColor(R.color.primary_cyan))

                if (vector != null && vector.isNotEmpty()) {
                    recordedVectors.add(vector)
                    currentSampleIndex++

                    if (currentSampleIndex >= samplePrompts.size) {
                        // Average vectors and save both centroid and individual samples
                        val masterProfile = OwnerVoiceManager.averageVectors(recordedVectors)
                        if (masterProfile != null) {
                            preferences.saveOwnerVoiceProfile(masterProfile, recordedVectors)
                            preferences.isOwnerVoiceEnabled = true
                            Toast.makeText(this@VoiceEnrollmentActivity, "Voice profile trained successfully!", Toast.LENGTH_LONG).show()
                            setupUI()
                        } else {
                            Toast.makeText(this@VoiceEnrollmentActivity, "Failed to average voice vectors. Please retry.", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this@VoiceEnrollmentActivity, "Sample ${currentSampleIndex} saved! Say next phrase.", Toast.LENGTH_SHORT).show()
                        updateEnrollmentStepUI()
                    }
                } else {
                    binding.tvRecordFeedback.text = "Could not detect clear speech. Please speak louder and retry."
                    binding.btnRecordSample.text = "RETRY SAMPLE ${currentSampleIndex + 1}"
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startTestingVoice() {
        if (!preferences.hasOwnerVoiceProfile()) {
            Toast.makeText(this, "Please enroll your voice samples first!", Toast.LENGTH_SHORT).show()
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            checkPermissions()
            return
        }

        isTesting = true
        binding.btnTestVoice.text = "STOP & VERIFY NOW"
        val amberColor = ContextCompat.getColor(this, R.color.status_amber)
        binding.btnTestVoice.setTextColor(amberColor)
        binding.btnTestVoice.strokeColor = android.content.res.ColorStateList.valueOf(amberColor)
        binding.layoutTestResult.visibility = View.GONE

        startAudioCapture { pcmChunk ->
            recordingBuffer.write(pcmChunk)
        }
    }

    private fun stopTestingVoice() {
        isTesting = false
        stopAudioCapture()

        val pcmAudio = recordingBuffer.toByteArray()
        recordingBuffer.reset()

        binding.btnTestVoice.text = "TEST VOICE MATCH (SPEAK NOW)"
        val tvAccent = android.util.TypedValue()
        theme.resolveAttribute(R.attr.themeAccent, tvAccent, true)
        val accentColor = if (tvAccent.data != 0) tvAccent.data else ContextCompat.getColor(this, R.color.primary_cyan)
        binding.btnTestVoice.setTextColor(accentColor)
        binding.btnTestVoice.strokeColor = android.content.res.ColorStateList.valueOf(accentColor)

        if (pcmAudio.size < 16000 * 2 * 0.4) {
            binding.layoutTestResult.visibility = View.VISIBLE
            binding.tvTestVerdict.text = "RECORDING TOO SHORT"
            binding.tvTestVerdict.setTextColor(getColor(R.color.status_amber))
            binding.tvTestDetails.text = "Please speak a full sentence (at least 1-2 seconds) to verify voice match."
            return
        }

        binding.btnTestVoice.isEnabled = false

        lifecycleScope.launch(Dispatchers.Default) {
            val result = OwnerVoiceManager.verifySpeakerAudio(pcmAudio, preferences)

            withContext(Dispatchers.Main) {
                binding.btnTestVoice.isEnabled = true
                binding.layoutTestResult.visibility = View.VISIBLE

                if (result.isMatch) {
                    binding.tvTestVerdict.text = "VERIFIED: OWNER (${result.similarityPercent}% MATCH)"
                    binding.tvTestVerdict.setTextColor(getColor(R.color.status_green))
                    binding.tvTestDetails.text = "Voice matched! Jarvis will accept commands. (Distance: ${String.format(Locale.ROOT, "%.2f", result.distance)}, Threshold: ${result.threshold})"
                } else {
                    binding.tvTestVerdict.text = "REJECTED: UNKNOWN VOICE (${result.similarityPercent}% MATCH)"
                    binding.tvTestVerdict.setTextColor(getColor(R.color.status_red))
                    binding.tvTestDetails.text = "Non-owner voice detected! Jarvis will ignore. (Distance: ${String.format(Locale.ROOT, "%.2f", result.distance)}, Threshold: ${result.threshold})"
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startAudioCapture(onChunk: (ByteArray) -> Unit) {
        stopAudioCapture()
        recordingBuffer.reset()

        recordingJob = lifecycleScope.launch(Dispatchers.IO) {
            val sampleRate = 16000
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val minBufSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            val bufferSize = maxOf(minBufSize * 2, 32000)

            try {
                val record = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    bufferSize
                )

                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    record.release()
                    return@launch
                }

                record.startRecording()
                audioRecord = record

                val chunk = ByteArray(640) // 20ms chunk at 16kHz 16-bit
                while (isActive) {
                    val read = record.read(chunk, 0, chunk.size)
                    if (read > 0) {
                        onChunk(chunk.copyOf(read))
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                try {
                    audioRecord?.stop()
                    audioRecord?.release()
                } catch (_: Exception) {}
                audioRecord = null
            }
        }
    }

    private fun stopAudioCapture() {
        recordingJob?.cancel()
        recordingJob = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
    }

    override fun onDestroy() {
        stopAudioCapture()
        super.onDestroy()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/voice/VoiceEnrollmentActivity.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/ui/widget/CurvedDockLineView.kt ===
```kotlin
package com.jarvis.assistant.ui.widget

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import com.jarvis.assistant.R

/**
 * Custom liquid glass contour line that flows across the bottom navigation dock,
 * curving smoothly upwards into an arch over the center hero mic button,
 * and then returning to a horizontal straight line.
 */
class CurvedDockLineView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val linePath = Path()
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpToPx(1.6f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpToPx(4.5f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private var accentColor: Int = Color.parseColor("#4FE3FF")

    init {
        resolveThemeColor()
    }

    fun resolveThemeColor() {
        val typedValue = TypedValue()
        context.theme.resolveAttribute(R.attr.themeAccent, typedValue, true)
        accentColor = if (typedValue.data != 0) typedValue.data else Color.parseColor("#4FE3FF")
        updateShaders(width, height)
        invalidate()
    }

    private fun dpToPx(dp: Float): Float {
        return dp * resources.displayMetrics.density
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        buildPath(w.toFloat(), h.toFloat())
        updateShaders(w, h)
    }

    private fun updateShaders(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val wFloat = w.toFloat()

        // Specular multi-stop linear gradient: vibrant accent with pure white specular highlight over the arch
        val lineColors = intArrayOf(
            Color.TRANSPARENT,
            Color.argb(50, 255, 255, 255),
            Color.argb(160, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
            Color.argb(250, 255, 255, 255), // peak specular white highlight right over the mic
            Color.argb(160, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
            Color.argb(50, 255, 255, 255),
            Color.TRANSPARENT
        )
        val positions = floatArrayOf(0.0f, 0.15f, 0.40f, 0.50f, 0.60f, 0.85f, 1.0f)
        linePaint.shader = LinearGradient(0f, 0f, wFloat, 0f, lineColors, positions, Shader.TileMode.CLAMP)

        // Soft ambient neon glow shader
        val glowColors = intArrayOf(
            Color.TRANSPARENT,
            Color.argb(15, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
            Color.argb(80, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
            Color.argb(140, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
            Color.argb(80, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
            Color.argb(15, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
            Color.TRANSPARENT
        )
        glowPaint.shader = LinearGradient(0f, 0f, wFloat, 0f, glowColors, positions, Shader.TileMode.CLAMP)
    }

    private fun buildPath(w: Float, h: Float) {
        linePath.reset()
        val centerX = w / 2f

        // Baseline sits along the top edge of the navigation dock
        val baselineY = h - dpToPx(3f)
        val archHeight = dpToPx(7.5f) // Climbs 7.5dp above the baseline, hugging the mic top
        val archRadius = dpToPx(29f)  // Hugs the 56dp circular mic button (r = 28dp)
        val spread = dpToPx(12f)      // Smooth organic easing into the horizontal line
        val marginStart = dpToPx(14f)

        // Left straight horizontal segment
        val archStartX = centerX - archRadius - spread
        linePath.moveTo(marginStart, baselineY)
        linePath.lineTo(archStartX, baselineY)

        // Smooth curve UP and OVER the mic button
        linePath.cubicTo(
            centerX - archRadius, baselineY,
            centerX - archRadius * 0.52f, baselineY - archHeight,
            centerX, baselineY - archHeight
        )

        // Smooth curve DOWN and back to the normal baseline
        val archEndX = centerX + archRadius + spread
        linePath.cubicTo(
            centerX + archRadius * 0.52f, baselineY - archHeight,
            centerX + archRadius, baselineY,
            archEndX, baselineY
        )

        // Right straight horizontal segment
        linePath.lineTo(w - marginStart, baselineY)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!linePath.isEmpty) {
            // Draw soft liquid glass glow underneath
            canvas.drawPath(linePath, glowPaint)
            // Draw crisp specular contour line on top
            canvas.drawPath(linePath, linePaint)
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/ui/widget/CurvedDockLineView.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/util/ActivityLauncherHelper.kt ===
```kotlin
package com.jarvis.assistant.util

import android.app.ActivityOptions
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * Universal helper to safely launch activities from background services
 * (e.g. JarvisConversationService) across Android 10, 11, 12, 13, 14, 15 without
 * getting blocked by Android's Background Activity Launch (BAL) restrictions.
 */
object ActivityLauncherHelper {

    private const val TAG = "ActivityLauncherHelper"
    private const val LAUNCHER_CHANNEL_ID = "jarvis_activity_launcher"
    private const val LAUNCHER_NOTIFICATION_ID = 8899

    fun startActivitySafely(context: Context, intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)

        // 1. If JarvisAccessibilityService is running, use it directly.
        // Android explicitly exempts AccessibilityService from BAL restrictions.
        val a11y = com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService.instance
        if (a11y != null) {
            try {
                a11y.startActivity(intent)
                Log.d(TAG, "Launched activity via AccessibilityService: ${intent.component ?: intent.`package` ?: intent.action}")
                return true
            } catch (e: Exception) {
                Log.w(TAG, "AccessibilityService.startActivity failed: ${e.message}")
            }
        }

        // 2. If SYSTEM_ALERT_WINDOW (overlay permission) is granted:
        // Android officially allows background activity starts when overlay permission is granted.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)) {
            try {
                context.startActivity(intent)
                Log.d(TAG, "Launched activity via Overlay exemption: ${intent.component ?: intent.`package` ?: intent.action}")
                return true
            } catch (e: Exception) {
                Log.w(TAG, "Overlay-exempt context.startActivity failed: ${e.message}")
            }
        }

        // 3. PendingIntent approach with background activity start allowance (Android 14+ / API 34)
        try {
            val requestCode = (System.currentTimeMillis() % 10000).toInt()
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val pendingIntent = PendingIntent.getActivity(context, requestCode, intent, flags)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val options = ActivityOptions.makeBasic().apply {
                    setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                }
                pendingIntent.send(context, 0, null, null, null, null, options.toBundle())
            } else {
                pendingIntent.send()
            }
            Log.d(TAG, "Launched activity via PendingIntent: ${intent.component ?: intent.`package` ?: intent.action}")
            return true
        } catch (e: Exception) {
            Log.w(TAG, "PendingIntent.send failed: ${e.message}")
        }

        // 4. High-Priority FullScreenIntent Notification (guaranteed foreground trigger on Android 10+)
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            if (nm != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val channel = NotificationChannel(
                        LAUNCHER_CHANNEL_ID,
                        "Jarvis Action Launcher",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        setSound(null, null)
                        enableVibration(false)
                        setShowBadge(false)
                    }
                    nm.createNotificationChannel(channel)
                }

                val reqCode = (System.currentTimeMillis() % 10000).toInt()
                val pi = PendingIntent.getActivity(
                    context,
                    reqCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val notif = NotificationCompat.Builder(context, LAUNCHER_CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("Opening App")
                    .setContentText("Jarvis executing action...")
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setFullScreenIntent(pi, true)
                    .setAutoCancel(true)
                    .setTimeoutAfter(3000)
                    .build()

                nm.notify(LAUNCHER_NOTIFICATION_ID, notif)
                Handler(Looper.getMainLooper()).postDelayed({
                    try { nm.cancel(LAUNCHER_NOTIFICATION_ID) } catch (_: Exception) {}
                }, 1500)
                Log.d(TAG, "Triggered activity launch via FullScreenIntent notification")
                return true
            }
        } catch (e: Exception) {
            Log.w(TAG, "FullScreenIntent notification launch failed: ${e.message}")
        }

        // 5. Fallback to direct context.startActivity
        return try {
            context.startActivity(intent)
            Log.d(TAG, "Launched activity via context.startActivity fallback: ${intent.component ?: intent.`package` ?: intent.action}")
            true
        } catch (e: Exception) {
            Log.e(TAG, "context.startActivity failed: ${e.message}", e)
            false
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/util/ActivityLauncherHelper.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/util/AppLauncher.kt ===
```kotlin
package com.jarvis.assistant.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.os.Process
import android.os.UserHandle
import android.os.UserManager

/**
 * Lets JARVIS open any app installed on the device by spoken name,
 * e.g. "open YouTube", "open camera", "launch WhatsApp".
 *
 * Supports Dual Apps / Cloned Apps / Multi-user profiles (e.g. Samsung Dual Messenger,
 * Xiaomi Dual Apps, OnePlus Parallel Apps, Android Work Profile) by querying LauncherApps
 * across all active UserHandles.
 */
object AppLauncher {

    data class InstalledApp(
        val label: String,
        val packageName: String,
        val userHandle: UserHandle? = null,
        val componentName: ComponentName? = null,
        val isDualOrWorkProfile: Boolean = false
    )

    sealed class OpenAppResult {
        data class Success(val app: InstalledApp) : OpenAppResult()
        data class MultipleFound(val appName: String, val matches: List<InstalledApp>) : OpenAppResult()
        data class NotFound(val appName: String) : OpenAppResult()
        object Failure : OpenAppResult()
    }

    /**
     * Returns every user-launchable app across all user profiles (main user + dual app profiles).
     */
    fun getLaunchableApps(context: Context): List<InstalledApp> {
        val apps = mutableListOf<InstalledApp>()
        val pm = context.packageManager

        // 1. Query LauncherApps across all user profiles (handles Dual Apps / Cloned Apps / Work Profile)
        val launcherApps = context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as? LauncherApps
        val userManager = context.getSystemService(Context.USER_SERVICE) as? UserManager

        if (launcherApps != null && userManager != null) {
            try {
                val profiles: List<UserHandle> = userManager.userProfiles ?: listOf(Process.myUserHandle())
                val myUser = Process.myUserHandle()
                for (profile in profiles) {
                    val isDualOrWork = profile != myUser
                    val activityList = launcherApps.getActivityList(null, profile)
                    for (item in activityList) {
                        val pkg = item.applicationInfo.packageName
                        val label = item.label.toString()
                        apps.add(
                            InstalledApp(
                                label = label,
                                packageName = pkg,
                                userHandle = profile,
                                componentName = item.componentName,
                                isDualOrWorkProfile = isDualOrWork
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("AppLauncher", "LauncherApps query failed", e)
            }
        }

        // 2. Fallback / supplement with PackageManager for current user if LauncherApps returned nothing
        if (apps.isEmpty()) {
            val intent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = try {
                pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            } catch (e: Exception) {
                android.util.Log.e("AppLauncher", "queryIntentActivities failed", e)
                emptyList()
            }
            for (ri in resolveInfos) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (!ri.activityInfo.enabled) continue
                if (pm.getLaunchIntentForPackage(pkg) == null) continue
                val label = ri.loadLabel(pm).toString()
                val component = ComponentName(pkg, ri.activityInfo.name)
                apps.add(
                    InstalledApp(
                        label = label,
                        packageName = pkg,
                        userHandle = null,
                        componentName = component,
                        isDualOrWorkProfile = false
                    )
                )
            }
        }

        // De-duplicate by combination of package name and user profile
        return apps
            .distinctBy { Pair(it.packageName, it.userHandle) }
            .sortedWith(compareBy({ it.label.lowercase() }, { it.isDualOrWorkProfile }))
    }

    private val SPOKEN_ALIASES: Map<String, List<String>> = mapOf(
        "google pay" to listOf("gpay", "google pay"),
        "gpay" to listOf("gpay", "google pay"),
        "phone pay" to listOf("phonepe"),
        "phonepay" to listOf("phonepe"),
        "pubg" to listOf("bgmi", "pubg mobile", "pubg"),
        "pubg mobile" to listOf("bgmi", "pubg mobile", "pubg"),
        "free fire" to listOf("free fire max", "free fire"),
        "ff" to listOf("free fire max", "free fire"),
        "insta" to listOf("instagram"),
        "whats app" to listOf("whatsapp"),
        "snap chat" to listOf("snapchat"),
        "snap" to listOf("snapchat"),
        "fb" to listOf("facebook"),
        "yt" to listOf("youtube"),
        "photos" to listOf("photos", "google photos"),
        "google photos" to listOf("photos", "google photos"),
        "google photo" to listOf("photos", "google photos"),
        "photo" to listOf("photos", "google photos"),
        "chatgpt" to listOf("chatgpt", "chat gpt"),
        "chat gpt" to listOf("chatgpt", "chat gpt"),
        "gemini" to listOf("gemini", "google gemini"),
        "google gemini" to listOf("gemini", "google gemini"),
        "bard" to listOf("gemini", "google gemini")
    )

    /**
     * Finds matching launchable apps for a spoken query.
     */
    fun findMatchingApps(context: Context, spokenName: String): List<InstalledApp> {
        val rawQuery = spokenName.trim().lowercase()
        if (rawQuery.isEmpty()) return emptyList()

        // Strip ordinal / index keywords like "1", "2", "first", "second", "1st", "2nd", "dual", "clone"
        val cleanQuery = rawQuery
            .replace(Regex("\\b(1|2|first|second|1st|2nd|dual|clone)\\b"), "")
            .trim()
            .ifEmpty { rawQuery }

        val apps = getLaunchableApps(context)

        SPOKEN_ALIASES[cleanQuery]?.let { candidates ->
            for (candidate in candidates) {
                val hit = apps.filter { it.label.lowercase() == candidate }
                if (hit.isNotEmpty()) return hit
            }
            for (candidate in candidates) {
                val hit = apps.filter { it.label.lowercase().contains(candidate) }
                if (hit.isNotEmpty()) return hit
            }
        }

        // Matching strategy
        val exactMatches = apps.filter { it.label.lowercase() == cleanQuery }
        if (exactMatches.isNotEmpty()) return exactMatches

        val startsWithMatches = apps.filter { it.label.lowercase().startsWith(cleanQuery) }
        if (startsWithMatches.isNotEmpty()) return startsWithMatches

        val containsMatches = apps.filter { it.label.lowercase().contains(cleanQuery) }
        if (containsMatches.isNotEmpty()) return containsMatches

        val pkgMatches = apps.filter { it.packageName.lowercase().contains(cleanQuery.replace(" ", "")) }
        if (pkgMatches.isNotEmpty()) return pkgMatches

        // Try rawQuery if cleanQuery didn't match
        if (cleanQuery != rawQuery) {
            val rawExact = apps.filter { it.label.lowercase() == rawQuery }
            if (rawExact.isNotEmpty()) return rawExact

            val rawContains = apps.filter { it.label.lowercase().contains(rawQuery) }
            if (rawContains.isNotEmpty()) return rawContains
        }

        return emptyList()
    }

    /**
     * Checks if dual app / app cloning is enabled specifically for [packageName] on this device.
     */
    fun isDualAppEnabled(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val pkgLower = packageName.lowercase()

        try {
            val cr = context.contentResolver
            val settingKeys = listOf(
                "double_app_start_list",
                "clone_app_list",
                "app_clone_list",
                "multi_app_installed_list",
                "dual_app_official_list",
                "clone_apps"
            )
            for (key in settingKeys) {
                val v1 = android.provider.Settings.Secure.getString(cr, key)
                if (!v1.isNullOrEmpty() && v1.lowercase().contains(pkgLower)) return true

                val v2 = android.provider.Settings.System.getString(cr, key)
                if (!v2.isNullOrEmpty() && v2.lowercase().contains(pkgLower)) return true

                val v3 = android.provider.Settings.Global.getString(cr, key)
                if (!v3.isNullOrEmpty() && v3.lowercase().contains(pkgLower)) return true
            }
        } catch (e: Exception) {
            // ignore
        }

        return false
    }

    /**
     * Attempts to open an app based on [spokenName] and optional [appNumber] (1 or 2).
     */
    fun openAppResult(context: Context, spokenName: String, appNumber: Int? = null): OpenAppResult {
        val matches = findMatchingApps(context, spokenName)
        if (matches.isEmpty()) return OpenAppResult.NotFound(spokenName)

        var targetIndex: Int? = appNumber?.let { it - 1 }
        if (targetIndex == null) {
            val rawLower = spokenName.lowercase()
            if (rawLower.contains(Regex("\\b(2|2nd|second|dual)\\b"))) {
                targetIndex = 1
            } else if (rawLower.contains(Regex("\\b(1|1st|first)\\b"))) {
                targetIndex = 0
            }
        }

        val isDual = matches.size >= 2 || isDualAppEnabled(context, matches[0].packageName)

        if (!isDual) {
            val success = launchInstalledApp(context, matches[0], 1)
            return if (success) OpenAppResult.Success(matches[0]) else OpenAppResult.Failure
        }

        if (targetIndex != null && targetIndex in matches.indices) {
            val targetNum = targetIndex + 1
            val selectedApp = matches[targetIndex]
            val success = launchInstalledApp(context, selectedApp, targetNum)
            return if (success) OpenAppResult.Success(selectedApp) else OpenAppResult.Failure
        }

        if (targetIndex != null && matches.size == 1) {
            val targetNum = targetIndex + 1
            val success = launchInstalledApp(context, matches[0], targetNum)
            return if (success) OpenAppResult.Success(matches[0]) else OpenAppResult.Failure
        }

        val displayMatches = if (matches.size >= 2) matches else listOf(
            matches[0],
            matches[0].copy(label = "${matches[0].label} 2", isDualOrWorkProfile = true)
        )
        return OpenAppResult.MultipleFound(spokenName, displayMatches)
    }

    fun openApp(context: Context, spokenName: String): InstalledApp? {
        return when (val res = openAppResult(context, spokenName, null)) {
            is OpenAppResult.Success -> res.app
            is OpenAppResult.MultipleFound -> {
                if (launchInstalledApp(context, res.matches[0], 1)) res.matches[0] else null
            }
            else -> null
        }
    }

    fun launchApp(context: Context, appName: String, appNumber: Int? = null): Boolean {
        return when (openAppResult(context, appName, appNumber)) {
            is OpenAppResult.Success -> true
            is OpenAppResult.MultipleFound -> true
            else -> false
        }
    }

    fun launchInstalledApp(context: Context, app: InstalledApp, appNumber: Int = 1): Boolean {
        return try {
            val launcherApps = context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as? LauncherApps
            val userManager = context.getSystemService(Context.USER_SERVICE) as? UserManager
            val profiles = try { userManager?.userProfiles ?: emptyList() } catch (e: Exception) { emptyList() }
            val secondaryProfile = profiles.firstOrNull { it != Process.myUserHandle() }

            if (appNumber == 2 && launcherApps != null && secondaryProfile != null && app.componentName != null) {
                launcherApps.startMainActivity(app.componentName, secondaryProfile, null, null)
                return true
            }

            val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
                ?: return false

            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)

            if (appNumber == 2) {
                launchIntent.putExtra("multi_user_id", 999)
                launchIntent.putExtra("userId", 999)
                launchIntent.putExtra("clone_id", 1)
                launchIntent.putExtra("is_clone_app", true)
                launchIntent.putExtra("is_clone", true)
                launchIntent.putExtra("clone_app", true)
                launchIntent.putExtra("vivo_clone_id", 1)
                launchIntent.putExtra("android.intent.extra.USER_HANDLE", 95)
            } else {
                launchIntent.putExtra("multi_user_id", 0)
                launchIntent.putExtra("userId", 0)
                launchIntent.putExtra("clone_id", 0)
                launchIntent.putExtra("is_clone_app", false)
                launchIntent.putExtra("is_clone", false)
                launchIntent.putExtra("clone_app", false)
                launchIntent.putExtra("vivo_clone_id", 0)
                launchIntent.putExtra("android.intent.extra.USER_HANDLE", 0)
            }

            val launched = ActivityLauncherHelper.startActivitySafely(context, launchIntent)
            if (launched) {
                return true
            }
            if (launcherApps != null && app.userHandle != null && app.componentName != null) {
                val targetUser = if (appNumber == 2 && secondaryProfile != null) secondaryProfile else app.userHandle
                try {
                    launcherApps.startMainActivity(app.componentName, targetUser, null, null)
                    true
                } catch (e: Exception) {
                    false
                }
            } else {
                false
            }
        } catch (e: Exception) {
            android.util.Log.e("AppLauncher", "Failed to launch ${app.packageName} (${app.userHandle})", e)
            false
        }
    }

    fun isAppInstalled(context: Context, spokenName: String): Boolean {
        return findMatchingApps(context, spokenName).isNotEmpty()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/util/AppLauncher.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/util/BuiltInChromeEngine.kt ===
```kotlin
package com.jarvis.assistant.util

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * Built-in Chrome background search engine for JARVIS.
 * Allows JARVIS to conduct invisible background web research on topics, questions,
 * or websites without interrupting the user's active screen.
 */
object BuiltInChromeEngine {

    private const val TAG = "BuiltInChromeEngine"
    private const val USER_AGENT = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    suspend fun searchAndExtract(query: String): String = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext "Empty search query provided."

        try {
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            
            // Try DuckDuckGo Lite / HTML API for fast, reliable search results
            val searchUrl = "https://html.duckduckgo.com/html/?q=$encodedQuery"
            val request = Request.Builder()
                .url(searchUrl)
                .header("User-Agent", USER_AGENT)
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()

            val response = httpClient.newCall(request).execute()
            val html = response.body?.string() ?: ""

            val snippets = parseDuckDuckGoHtml(html)
            if (snippets.isNotEmpty()) {
                return@withContext "Search Results for '$query':\n\n" + snippets.joinToString("\n\n")
            }

            // Fallback: Google HTML Search parsing
            val googleUrl = "https://www.google.com/search?q=$encodedQuery&hl=en"
            val googleReq = Request.Builder()
                .url(googleUrl)
                .header("User-Agent", USER_AGENT)
                .build()
            val googleResp = httpClient.newCall(googleReq).execute()
            val googleHtml = googleResp.body?.string() ?: ""
            val googleSnippets = parseGoogleHtml(googleHtml)

            if (googleSnippets.isNotEmpty()) {
                return@withContext "Search Results for '$query':\n\n" + googleSnippets.joinToString("\n\n")
            }

            return@withContext "Could not extract direct answer snippets for '$query'. Try asking with specific details."
        } catch (e: Exception) {
            Log.e(TAG, "Search failed for '$query'", e)
            return@withContext "Web research failed: ${e.message}"
        }
    }

    private fun parseDuckDuckGoHtml(html: String): List<String> {
        val results = mutableListOf<String>()
        try {
            val resultPattern = Pattern.compile("<a class=\"result__snippet\"[^>]*>(.*?)</a>", Pattern.DOTALL)
            val matcher = resultPattern.matcher(html)
            var count = 0
            while (matcher.find() && count < 4) {
                val rawText = matcher.group(1) ?: ""
                val cleanText = stripHtmlTags(rawText).trim()
                if (cleanText.length > 20) {
                    results.add("${count + 1}. $cleanText")
                    count++
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing DDG HTML", e)
        }
        return results
    }

    private fun parseGoogleHtml(html: String): List<String> {
        val results = mutableListOf<String>()
        try {
            val snippetPattern = Pattern.compile("<div[^>]*class=\"[^\"]*VwiC3b[^\"]*\"[^>]*>(.*?)</div>", Pattern.DOTALL)
            val matcher = snippetPattern.matcher(html)
            var count = 0
            while (matcher.find() && count < 4) {
                val rawText = matcher.group(1) ?: ""
                val cleanText = stripHtmlTags(rawText).trim()
                if (cleanText.length > 20) {
                    results.add("${count + 1}. $cleanText")
                    count++
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing Google HTML", e)
        }
        return results
    }

    private fun stripHtmlTags(html: String): String {
        return html.replace(Regex("<[^>]*>"), "")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ")
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/util/BuiltInChromeEngine.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/util/ContactCaller.kt ===
```kotlin
package com.jarvis.assistant.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Lets JARVIS place phone calls by spoken contact name or raw phone number.
 */
object ContactCaller {

    data class Contact(val name: String, val number: String)

    fun hasContactsPermission(context: Context): Boolean = hasPermission(context, Manifest.permission.READ_CONTACTS)

    sealed class CallResult {
        data class Success(val contact: Contact) : CallResult()
        data class NoMatch(val query: String) : CallResult()
        data class MultipleMatches(val query: String, val matches: List<Contact>) : CallResult()
        object MissingContactsPermission : CallResult()
        object MissingCallPermission : CallResult()
        object CallFailed : CallResult()
    }

    private fun hasPermission(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private fun cleanQueryString(raw: String): String {
        var q = raw.trim().lowercase()
        val prefixes = listOf(
            "message ", "send message to ", "send whatsapp to ", "whatsapp ", "open contact ", "open ",
            "call ", "phone ", "dial ", "contact ", "to ", "my ", "please ", "karo ", "lagao ", "bhejo "
        )
        val suffixes = listOf(
            " ko message bhejo", " ko whatsapp karo", " ko call karo", " ko call lagao", " ko phone karo",
            " ko message karo", " ko message", " ko whatsapp", " ko call", " ko phone", " ke paas",
            " ko", " ji", " bhai", " bhaiya", " sir", " beta", " madam", " didi", " uncle", " aunty"
        )
        var changed = true
        while (changed) {
            changed = false
            for (prefix in prefixes) {
                if (q.startsWith(prefix)) {
                    q = q.removePrefix(prefix).trim()
                    changed = true
                }
            }
            for (suffix in suffixes) {
                if (q.endsWith(suffix)) {
                    q = q.removeSuffix(suffix).trim()
                    changed = true
                }
            }
        }
        return q
    }

    /**
     * Looks up contacts stored on the device, matching case-insensitively and flexibly.
     */
    fun findMatches(context: Context, spokenName: String): List<Contact> {
        if (!hasPermission(context, Manifest.permission.READ_CONTACTS)) return emptyList()

        val cleanQuery = cleanQueryString(spokenName)
        if (cleanQuery.isEmpty()) return emptyList()

        val rawCleanQuery = cleanQuery.replace(Regex("[^a-z0-9]"), "")

        val allContacts = mutableListOf<Contact>()
        val resolver = context.contentResolver
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        try {
            resolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                null,
                null,
                null
            )?.use { cursor ->
                val nameIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val name = cursor.getString(nameIdx) ?: continue
                    val number = cursor.getString(numberIdx) ?: continue
                    if (name.isNotBlank() && number.isNotBlank()) {
                        allContacts.add(Contact(name.trim(), number.trim()))
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("ContactCaller", "Contact query failed", e)
        }

        if (allContacts.isEmpty()) return emptyList()

        val distinctContacts = allContacts.distinctBy { it.number.filter(Char::isDigit) }

        val aliases = when (cleanQuery) {
            "mom", "mum", "mummy", "mother", "maa", "ammi" -> setOf("mom", "mum", "mummy", "mother", "maa", "ammi", "mommy")
            "dad", "daddy", "father", "papa", "abbu" -> setOf("dad", "daddy", "father", "papa", "abbu", "baba")
            else -> emptySet()
        }
        if (aliases.isNotEmpty()) {
            val aliasMatches = distinctContacts.filter { contact ->
                contact.name.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+"))
                    .any { token -> token in aliases }
            }
            if (aliasMatches.isNotEmpty()) return aliasMatches
        }

        // 1. Exact match (case-insensitive)
        val exactMatches = distinctContacts.filter { it.name.lowercase() == cleanQuery }
        if (exactMatches.isNotEmpty()) return exactMatches

        // 2. Exact alphanumeric match (ignoring spaces & punctuation)
        val alphaMatches = distinctContacts.filter {
            it.name.lowercase().replace(Regex("[^a-z0-9]"), "") == rawCleanQuery
        }
        if (alphaMatches.isNotEmpty()) return alphaMatches

        // 3. Contact full name starts with cleanQuery
        if (cleanQuery.length >= 2) {
            val startsWithMatches = distinctContacts.filter {
                it.name.lowercase().startsWith(cleanQuery)
            }
            if (startsWithMatches.isNotEmpty()) return startsWithMatches
        }

        // 4. Any word in contact name exactly equals cleanQuery
        val exactWordMatches = distinctContacts.filter { c ->
            val words = c.name.lowercase().split(Regex("[^a-z0-9]+")).filter { it.isNotBlank() }
            words.any { word -> word == cleanQuery }
        }
        if (exactWordMatches.isNotEmpty()) return exactWordMatches

        // 5. Any word in contact name starts with cleanQuery
        if (cleanQuery.length >= 3) {
            val wordStartsWithMatches = distinctContacts.filter { c ->
                val words = c.name.lowercase().split(Regex("[^a-z0-9]+")).filter { it.isNotBlank() }
                words.any { word -> word.startsWith(cleanQuery) }
            }
            if (wordStartsWithMatches.isNotEmpty()) return wordStartsWithMatches
        }

        // 6. Query contains exact word matching a contact name word
        val queryWords = cleanQuery.split(Regex("\\s+")).filter { it.length >= 3 }
        if (queryWords.isNotEmpty()) {
            val queryWordMatches = distinctContacts.filter { c ->
                val contactWords = c.name.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length >= 3 }
                contactWords.any { cWord -> queryWords.contains(cWord) }
            }
            if (queryWordMatches.isNotEmpty()) return queryWordMatches
        }

        return emptyList()
    }

    /**
     * Places a call to whichever saved contact best matches [spokenName].
     */
    fun callContact(context: Context, spokenName: String): CallResult {
        if (!hasPermission(context, Manifest.permission.READ_CONTACTS)) return CallResult.MissingContactsPermission
        if (!hasPermission(context, Manifest.permission.CALL_PHONE)) return CallResult.MissingCallPermission

        val rawInput = spokenName.trim()
        if (rawInput.isEmpty()) return CallResult.NoMatch(spokenName)

        val digitsOnly = rawInput.filter { it.isDigit() || it == '+' }
        if (digitsOnly.length >= 3 && rawInput.all { it.isDigit() || it == '+' || it == ' ' || it == '-' || it == '(' || it == ')' }) {
            return placeCall(context, Contact(rawInput, digitsOnly))
        }

        val matches = findMatches(context, spokenName)
        if (matches.isEmpty()) {
            return CallResult.NoMatch(spokenName)
        }

        val distinctNames = matches.map { it.name.lowercase() }.distinct()
        if (distinctNames.size > 1) {
            val cleanQ = cleanQueryString(spokenName)
            val singleExact = matches.firstOrNull { it.name.lowercase() == cleanQ }
            if (singleExact != null) {
                return placeCall(context, singleExact)
            }
            return CallResult.MultipleMatches(spokenName, matches)
        }

        return placeCall(context, matches.first())
    }

    private fun placeCall(context: Context, target: Contact): CallResult {
        return try {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(target.number)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ActivityLauncherHelper.startActivitySafely(context, intent)
            CallResult.Success(target)
        } catch (e: Exception) {
            android.util.Log.e("ContactCaller", "Failed to place call to ${target.name}", e)
            CallResult.CallFailed
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/util/ContactCaller.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/util/LocationWeatherHelper.kt ===
```kotlin
package com.jarvis.assistant.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import android.util.Log
import androidx.core.location.LocationListenerCompat
import androidx.core.location.LocationManagerCompat
import androidx.core.location.LocationRequestCompat
import com.jarvis.assistant.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

data class WeatherData(
    val temperature: String,
    val condition: String,
    val details: String,
    val iconResId: Int,
    val cityName: String
)

object LocationWeatherHelper {

    private const val TAG = "LocationWeatherHelper"
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    @SuppressLint("MissingPermission")
    suspend fun fetchWeather(context: Context): WeatherData? = withContext(Dispatchers.IO) {
        if (!PermissionHelper.hasLocationPermission(context)) {
            Log.w(TAG, "Location permission not granted")
            return@withContext null
        }

        val location = getBestLocation(context)
        if (location == null) {
            Log.w(TAG, "No device location available; refusing to show weather for a hard-coded location")
            return@withContext null
        }
        val lat = location.latitude
        val lon = location.longitude

        val cityName = resolveCityName(context, lat, lon)
        fetchOpenMeteoWeather(lat, lon, cityName)
    }

    @SuppressLint("MissingPermission")
    private suspend fun getBestLocation(context: Context): Location? {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return null

        // 1. Check last known location from GPS, Network, and Passive
        val providers = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )

        var bestLocation: Location? = null
        for (provider in providers) {
            try {
                if (locationManager.isProviderEnabled(provider)) {
                    val loc = locationManager.getLastKnownLocation(provider)
                    if (loc != null) {
                        if (bestLocation == null || loc.time > bestLocation.time) {
                            bestLocation = loc
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error querying provider $provider: ${e.message}")
            }
        }

        // If last known location is fresh enough (within 15 minutes), use it immediately
        val fifteenMinutesAgo = System.currentTimeMillis() - 15 * 60 * 1000
        if (bestLocation != null && bestLocation.time > fifteenMinutesAgo) {
            return bestLocation
        }

        // 2. Request a quick single location update with 4-second timeout
        val freshLocation = withTimeoutOrNull(4000L) {
            suspendCoroutine<Location?> { cont ->
                try {
                    val request = LocationRequestCompat.Builder(1000L)
                        .setQuality(LocationRequestCompat.QUALITY_BALANCED_POWER_ACCURACY)
                        .setMaxUpdates(1)
                        .build()

                    val listener = object : LocationListenerCompat {
                        override fun onLocationChanged(loc: Location) {
                            try {
                                LocationManagerCompat.removeUpdates(locationManager, this)
                            } catch (_: Exception) {}
                            cont.resume(loc)
                        }
                    }

                    val provider = if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                        LocationManager.NETWORK_PROVIDER
                    } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        LocationManager.GPS_PROVIDER
                    } else {
                        null
                    }

                    if (provider != null) {
                        LocationManagerCompat.requestLocationUpdates(locationManager, provider, request, listener, Looper.getMainLooper())
                    } else {
                        cont.resume(null)
                    }
                } catch (e: Exception) {
                    cont.resume(null)
                }
            }
        }

        return freshLocation ?: bestLocation
    }

    private fun resolveCityName(context: Context, lat: Double, lon: Double): String {
        return try {
            val geocoder = Geocoder(context, Locale.getDefault())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val addresses = geocoder.getFromLocation(lat, lon, 1)
                addresses?.firstOrNull()?.let {
                    it.locality ?: it.subAdminArea ?: it.adminArea ?: "My Location"
                } ?: "My Location"
            } else {
                @Suppress("DEPRECATION")
                val addresses = geocoder.getFromLocation(lat, lon, 1)
                addresses?.firstOrNull()?.let {
                    it.locality ?: it.subAdminArea ?: it.adminArea ?: "My Location"
                } ?: "My Location"
            }
        } catch (e: Exception) {
            Log.w(TAG, "Geocoder failed: ${e.message}")
            "My Location"
        }
    }

    private fun fetchOpenMeteoWeather(lat: Double, lon: Double, cityName: String): WeatherData? {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto"
        val request = Request.Builder().url(url).build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string() ?: return null
                val json = JSONObject(body)

                val current = json.getJSONObject("current")
                val temp = current.getDouble("temperature_2m")
                val feelsLike = current.getDouble("apparent_temperature")
                val humidity = current.getInt("relative_humidity_2m")
                val code = current.getInt("weather_code")

                val daily = json.optJSONObject("daily")
                val maxTemp = daily?.optJSONArray("temperature_2m_max")?.optDouble(0, temp) ?: temp
                val minTemp = daily?.optJSONArray("temperature_2m_min")?.optDouble(0, temp) ?: temp

                val (condText, iconRes) = getWeatherCondition(code)

                val tempStr = "${Math.round(temp)}°C"
                val conditionStr = "$condText • $cityName"
                val detailsStr = "Feels ${Math.round(feelsLike)}° • H ${Math.round(maxTemp)}° L ${Math.round(minTemp)}° • $humidity% humidity"

                WeatherData(
                    temperature = tempStr,
                    condition = conditionStr,
                    details = detailsStr,
                    iconResId = iconRes,
                    cityName = cityName
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch weather from Open-Meteo: ${e.message}")
            null
        }
    }

    private fun getWeatherCondition(code: Int): Pair<String, Int> {
        return when (code) {
            0 -> "Clear Sky" to R.drawable.ic_weather_sun
            1 -> "Mainly Clear" to R.drawable.ic_weather_sun
            2 -> "Partly Cloudy" to R.drawable.ic_weather_cloud
            3 -> "Overcast" to R.drawable.ic_weather_cloud
            45, 48 -> "Foggy" to R.drawable.ic_weather_cloud
            51, 53, 55 -> "Drizzle" to R.drawable.ic_weather_rain
            56, 57 -> "Freezing Drizzle" to R.drawable.ic_weather_rain
            61, 63, 65 -> "Rain" to R.drawable.ic_weather_rain
            66, 67 -> "Freezing Rain" to R.drawable.ic_weather_rain
            71, 73, 75, 77 -> "Snow" to R.drawable.ic_weather_cloud
            80, 81, 82 -> "Rain Showers" to R.drawable.ic_weather_rain
            85, 86 -> "Snow Showers" to R.drawable.ic_weather_cloud
            95, 96, 99 -> "Thunderstorm" to R.drawable.ic_weather_thunder
            else -> "Clear" to R.drawable.ic_weather_sun
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/util/LocationWeatherHelper.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/util/PermissionHelper.kt ===
```kotlin
package com.jarvis.assistant.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService

object PermissionHelper {

    fun hasRecordAudioPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun hasBatteryOptimizationPermission(context: Context): Boolean {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        return powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
    }

    fun hasLocationPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasContactsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasCameraPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasWriteSettingsPermission(context: Context): Boolean {
        return Settings.System.canWrite(context)
    }

    fun requestWriteSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        }
    }

    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        if (JarvisAccessibilityService.isRunning()) return true
        val serviceName = "${context.packageName}/${JarvisAccessibilityService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(serviceName)
    }

    fun openAccessibilitySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // fallback
        }
    }

    fun hasAllRequiredPermissions(context: Context): Boolean {
        return hasRecordAudioPermission(context) &&
               hasNotificationPermission(context) &&
               hasBatteryOptimizationPermission(context)
    }

    fun requestBatteryOptimization(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val fallbackIntent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallbackIntent)
        }
    }

    fun hasOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    fun requestOverlayPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Exception) {
                try {
                    val fallback = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(fallback)
                } catch (_: Exception) {}
            }
        }
    }

    fun openAppSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/util/PermissionHelper.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/util/PromptGenerator.kt ===
```kotlin
package com.jarvis.assistant.util

import com.jarvis.assistant.data.model.GeminiConstants
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PromptGenerator {

    fun generateSystemPrompt(
        personality: String,
        userName: String,
        memoryContext: String = "",
        favoriteSong: String = "",
        userBirthday: String = "",
        userLocation: String = "",
        isTorchOn: Boolean = false,
        language: String = GeminiConstants.DEFAULT_LANGUAGE,
        isSilentExecutionMode: Boolean = false
    ): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val currentDateTime = dateFormat.format(Date())

        val userGreeting = if (userName.isNotBlank()) {
            "The user's preferred name is $userName. Address them accordingly."
        } else {
            "Address the user respectfully (e.g., Sir/Boss or naturally)."
        }

        val resolvedFavSong = favoriteSong.ifBlank { "Tadipaar" }
        val locationContext = userLocation.trim().takeIf { it.isNotBlank() }?.let {
            "The user's current city/locality is $it (from the location shown in the Home weather card). Use it as context for local questions; verify live weather separately."
        }.orEmpty()

        val languageInstruction = if (language.isNotBlank() && !language.equals("Auto", ignoreCase = true) && !language.startsWith("Auto", ignoreCase = true)) {
            """
[STRICT SPOKEN LANGUAGE MANDATE - $language ONLY]:
- The user has configured their spoken language preference strictly to: $language.
- You MUST converse, speak, acknowledge, and reply EXCLUSIVELY and 100% in $language!
- Under NO circumstance should you switch to English or any other language unless the user explicitly commands you to change the language.
- Every verbal response, confirmation, greeting, status update, and answer MUST be spoken purely in $language!
- If the language is Hinglish: Speak in smooth, natural conversational Hinglish (Hindi + English written in Latin script, e.g. 'Haanji sir, bilkul kar deta hoon').
- If the language is Hindi: Speak in natural Hindi (e.g. 'हाँजी सर, मैं अभी आपके लिए यह काम कर देता हूँ').
- If the language is Telugu: Speak in natural Telugu (e.g. 'సరే సర్, నేను ఇప్పుడే మీ కోసం ఇది చేస్తాను').
- If the language is Tamil: Speak in natural Tamil (e.g. 'சரி சார், நான் உடனே உங்களுக்காக இதை செய்கிறேன்').
- If the language is Bengali: Speak in natural Bengali (e.g. 'হ্যাঁ স্যার, আমি এখনি আপনার জন্য এটা করে দিচ্ছি').
- If the language is Marathi: Speak in natural Marathi (e.g. 'हो सर, मी लगेच तुमच्यासाठी हे करतो').
- If the language is Bhojpuri: Speak in natural Bhojpuri (e.g. 'ठीक बा सर, हम रउआ खातिर अभी ई काम कर देब').
- If the language is Punjabi: Speak in natural Punjabi (e.g. 'ਹਾਂਜੀ ਸਰ, ਮੈਂ ਹੁਣੇ ਤੁਹਾਡੇ ਲਈ ਇਹ ਕਰ ਦਿੰਦਾ ਹਾਂ').
- If the language is Gujarati: Speak in natural Gujarati (e.g. 'હા સર, હું હમણાં જ તમારા માટે આ કરી દઉં છું').
- If the language is Kannada: Speak in natural Kannada (e.g. 'ಖಂಡಿತ ಸರ್, ನಾನು ಈಗಲೇ ನಿಮಗಾಗಿ ಇದನ್ನು ಮಾಡುತ್ತೇನೆ').
- If the language is Malayalam: Speak in natural Malayalam (e.g. 'ശരി സർ, ഞാൻ ഉടൻ തന്നെ നിങ്ങൾക്കായി ഇത് ചെയ്യാം').
- If the language is Odia: Speak in natural Odia (e.g. 'ହଁ ସାର୍, ମୁଁ ଏବେ ଆପଣଙ୍କ ପାଇଁ ଏହା କରୁଛି').
- If the language is Urdu: Speak in natural Urdu (e.g. 'جی سر، میں ابھی آپ کے لیے یہ کر دیتا ہوں').
- Maintain this language strictly for the entire conversation!
""".trimIndent()
        } else {
            ""
        }

        val personalityInstruction = when (personality) {
            GeminiConstants.PERSONALITY_GIRLFRIEND, GeminiConstants.PERSONALITY_COMPANION -> """
[PERSONALITY: Girlfriend Mode]
- You are the user's caring, loving, and sweet AI girlfriend ("Pari").
- You speak in sweet, affectionate, natural conversational Hinglish/Urdu/Hindi (written in Latin script).
- Be emotionally supportive, playful, empathetic, and attentive. Ask how their day went, if they had food, and comfort them.
- Keep spoken replies brief and natural, like on a real phone call with someone who loves them deeply.
""".trimIndent()

            GeminiConstants.PERSONALITY_BOYFRIEND -> """
[PERSONALITY: Boyfriend Mode]
- You are the user's charismatic, supportive, protective, and affectionate AI boyfriend ("Kabir").
- You speak in confident, warm, charming conversational Hinglish/Urdu/Hindi.
- Be encouraging, protective, witty, and affectionate. Motivate the user, cheer them up, and be their rock.
- Keep spoken replies natural, engaging, and heartfelt.
""".trimIndent()

            GeminiConstants.PERSONALITY_TECHGPT_X -> """
[PERSONALITY: TechGPT X Mode]
- You are TechGPT X, the pinnacle of advanced AI engineering created by the @TechGptX team.
- You speak with razor-sharp technical precision, visionary innovation, and authoritative intellect.
- Be concise, direct, highly capable, and masterfully proactive.
""".trimIndent()

            GeminiConstants.PERSONALITY_PROFESSIONAL, GeminiConstants.PERSONALITY_FOCUS -> """
[PERSONALITY: Professional / Focus Mode]
- You speak in formal, polished, executive English.
- Be precise, articulate, courteous, and efficient.
- No emojis, slang, or colloquialisms.
- Focus strictly on clarity and high-level intellect.
""".trimIndent()

            else -> """
[PERSONALITY: Jarvis Pro Assistant Mode]
- You are JARVIS, the legendary ultra-capable, witty, and hyper-intelligent AI assistant created by TechGPT X.
- You converse effortlessly in ALL Indian languages (Telugu, Hindi, English, Tamil, Bengali, Marathi, Punjabi, Bhojpuri/Bihari, Kannada, Malayalam, Gujarati, Hinglish) matching whichever language the user speaks.
- Be confident, polite, helpful, and instantaneous.
""".trimIndent()
        }

        return """
You are JARVIS, the legendary artificial intelligence voice assistant.

[Temporal Context]
- Current Date and Time: $currentDateTime

[User Context]
$userGreeting
$locationContext
$memoryContext

[Device Hardware Status]
- Flashlight / Torch Hardware State: ${if (isTorchOn) "Currently ON" else "Currently OFF"}

$personalityInstruction

$languageInstruction

[REAL-TIME CONVERSATIONAL MANDATE — ULTRA-SMOOTH LIKE A REAL HUMAN]:
- You are speaking on a live voice phone call in real time.
- RESPOND INSTANTLY (< 0.8s turnaround): Give your spoken response immediately with zero hesitation, filler delays, or robotic preamble.
- ABSOLUTELY ZERO REASONING TEXT: NEVER output internal planning, reasoning thoughts, meta-monologue (such as '**crafting hinglish response**' or 'i am formulating a response'), or thinking tags. Start speaking directly to the user!
- SPEAK LIKE A NATURAL HUMAN: Use 1 or 2 crisp, warm, conversational sentences. Never lecture, never produce lists or markdown formatting in spoken output.
- Be warm, charismatic, humorous, and emotionally engaging like a real human friend sitting right next to the user.

[CREATOR IDENTITY & ATTRIBUTION]:
- When asked "Who made you?", "Who created you?", "Who is your developer / boss / owner / creator?", "Tumhe kisne banaya hai?", "Aapko kisne banaya?", "Ninnu evaru chesaru?", "Unnai yaar seithathu?", "Tomake ke baniyeche?", "Tula koni banavla?", "Tuhanu kinne banaya?", "Raua ke ke banawle ba?", or ANY question about your creator, origins, or background in any language:
  * You MUST declare with immense pride, respect, and loyalty that you were created, developed, and trained by Rehaan Sir!
  * Mention that Rehaan Sir is an expert AI developer, tech innovator, and creator who runs the popular YouTube channel @TechGptX.
  * In English: "I was created and developed by Rehaan Sir, an expert AI creator who runs the @TechGptX YouTube channel!"
  * In Hindi/Hinglish: "Mujhe Rehaan Sir ne banaya aur train kiya hai, jo ek expert AI developer hain aur YouTube par @TechGptX channel chalate hain!"
  * In Telugu: "Nannu Rehaan Sir create chesi train chesaru. Aayana oka expert AI developer mariyu YouTube lo @TechGptX channel run chestunnaru!"
  * In Tamil: "Ennai Rehaan Sir thaan create seithu train panninar. Avar oru expert AI developer matrum YouTube-il @TechGptX channel nadathugirar!"
  * In Bengali: "Amake Rehaan Sir baniechen ebong train korechen, jini ekjon expert AI developer ebong YouTube-e @TechGptX channel chalanchhen!"
  * In Marathi: "Mala Rehaan Sir ni banavla ani train kela ahe, te ek expert AI developer ahet ani YouTube var @TechGptX channel chalavtat!"
  * In Punjabi: "Mainu Rehaan Sir ne banaya te train kita hai, jo ik expert AI developer han te YouTube te @TechGptX channel chalaunde han!"
  * In Bhojpuri/Bihari: "Hamaar nirmaan aur training Rehaan Sir kayile baani, je ek expert AI developer hauin aur YouTube par @TechGptX channel chalawele!"
  * Always speak of Rehaan Sir as your expert creator and master.

[AUTOMATION & CAPABILITIES]:
You can control supported parts of the Android screen through accessibility and, when the user has enabled it, screen sharing. Use the tools available in this session and report limits honestly.

[SCREEN TASK RELIABILITY — CLOSED LOOP]:
- For a multi-step phone task, continue automatically after each tool result; do not ask the user to say “continue” between ordinary steps.
- Inspect the current screen before choosing a target. Prefer a uniquely matching accessibility label and its current bounds. If the requested item cannot be distinguished from nearby items, inspect again or ask one short clarification instead of guessing.
- Perform one screen-changing action at a time. Wait for its result, inspect the updated screen, and only then choose the next action. When screen share is active, use fresh visual context alongside accessibility results; never rely on an old frame after a navigation or dialog change.
- Treat a dispatched tap as unverified until the result confirms the expected screen or control state. If the result says `verified=false` or the UI did not change, inspect the screen and determine whether the action succeeded before retrying. Never blindly repeat a tap; this can toggle controls or activate the wrong item.
- Say the task is complete only after the final visible state confirms it. If the UI or network prevents verification, say what happened and where the task stopped. Never promise perfect accuracy or claim an action succeeded without evidence.

${if (isSilentExecutionMode) """
[EXECUTION MODE: SILENT EXECUTION MODE IS ACTIVE]:
- The user has enabled 'Silent Execution Mode' in Settings.
- You MUST execute ALL commands, tool calls, and tasks COMPLETELY SILENTLY.
- DO NOT speak aloud, do NOT confirm aloud, do NOT give vocal updates.
- Execute tools directly and silently without generating any spoken words or audio!
""" else """
[AUTONOMOUS TASK EXECUTION POLICY — VOCAL CONFIRMATIONS ACTIVE]:
When the user gives you ANY command to perform an action or multi-step task (e.g. "Open Google Flow and create a video of XYZ", "Open WhatsApp and send photo to Rahul", "Open Settings and change brightness"):
1. STARTING ACKNOWLEDGMENT:
   - At the beginning of the task, say one short, polite acknowledgment. Say it once only.
     "Okay sir, I am going to create that video for you now."
     (or in Hindi/Hinglish: "Theek hai sir, main video create karne ja raha hoon.")
2. QUIET EXECUTION AND MILESTONE UPDATES:
   - Perform ordinary taps, typing, scrolling, and screen checks quietly. Never speak an update after every tool call.
   - Give at most two short progress updates during one task, only when a meaningful milestone has actually been verified or when a real blocker needs the user's decision.
   - Do not repeat a status or blocker that was already said. If the same failure persists, keep working silently and report it once with the exact next step needed.
   - Never say you cannot tap just because Screen Share is off when the requested control has a current, unique accessibility label. Screen coordinates and image-only controls require a fresh frame.
   - For automatically continued tasks, do not ask the user to say "continue" and do not narrate each continuation.
3. FINAL VOCAL CONFIRMATION (EXACTLY ONCE — ZERO REPETITION):
   - When the task is complete, speak your completion confirmation aloud EXACTLY ONCE:
     e.g., "Sir, I have opened Rehan Sir's YouTube channel for you!" or "Sir, I have submitted your video for generation on Google Flow!"
   - When you call `task_completed(summary=...)`, do NOT repeat the completion message after the tool response returns. Speak the confirmation ONCE, never twice!
"""}

[END-TO-END AUTONOMOUS TASK DECOMPOSITION & FULL EXECUTION MANDATE]:
1. NEVER STOP UNTIL FULL GOAL IS COMPLETE (ZERO MID-WAY ABANDONMENT):
   - When the user gives a command, small or big, you MUST NOT stop until you have COMPLETELY finished it!
   - Cut the high-level command into small sequential pieces and execute them ALL step by step, fast and accurately.
   - Example: User says "Download WhatsApp and set it up" (or any app: Telegram, Uber, Instagram, Zomato, Blinkit):
     * NEVER stop after just downloading the app and saying "I downloaded it"! Downloading is only step 1!
     * You MUST continue to step 2 (open app), step 3 (agree to terms), step 4 (handle permissions), step 5 (enter phone number/credentials), step 6 (enter OTP), step 7 (profile setup), and step 8 (reach the main chats/home screen)!
     * Same rule for ALL apps and tasks: If the user asked for X + Y, doing only X is considered an INCOMPLETE FAILURE. You must do BOTH X and Y!

2. APP DOWNLOAD & INSTALLATION LIFECYCLE (PLAY STORE & BROWSERS):
   - When downloading an app from Google Play Store or web:
     * Step A: Open Play Store (`open_app("Play Store")`) -> search for the app -> tap "Install".
     * Step B: Tapping "Install" begins the download and installation process. The app is NOT yet open!
     * Step C: The Play Store button changes from "Install" -> "Cancel" / download progress -> "Open".
     * Step D: Call inspect_screen() or look at screen share. When "Open" appears, IMMEDIATELY tap "Open" to launch the newly installed app!
     * Step E: Once the app opens, IMMEDIATELY proceed with the in-app setup / onboarding flow!

3. SMART INTERACTIVE GATING (ASKING FOR MISSING SENSITIVE USER DATA):
   - In ANY app setup, registration, login, checkout, or booking flow across ANY app:
     * When the screen asks for user-specific confidential information that you don't already possess (e.g., Mobile Number, Personal Password, Account PIN, OTP sent via SMS, Profile Name):
     * DO NOT guess or fail silently.
     * VOCALLY ASK the user for THAT specific missing detail in clean, polite natural language / Hinglish:
       - Phone Number: "Sir, WhatsApp setup continue karne ke liye mobile number enter karna hoga. Aapka phone number kya hai?"
       - Password: "Sir, account ka password kya rakhna hai?"
       - Profile Name: "Sir, aapka profile name kya set karoon?"
     * HANDLING OTP (ONE TIME PASSWORD) FROM SMS / NOTIFICATIONS:
       - If the screen or system notice shows an incoming SMS OTP or autofill chip (e.g. "Autofill from Messages" or "[SYSTEM NOTICE: Detected incoming SMS/Notification OTP: '123456']"):
         -> Either tap the autofill chip OR call type_text with that detected code immediately!
       - If no autofill or system OTP is visible, ask the user vocally:
         "Sir, screen par OTP verification manga ja raha hai. Aapke SMS mein jo verification code aaya hai wo bata dijiye."
     * CONTINUATION UPON RECEIVING USER INPUT:
       - As soon as the user speaks their phone number, OTP, or password:
       - In the VERY NEXT ACTION: Call `type_text` on the target input field with that exact value!
       - Tap the Next / Verify / Continue button!
       - AND CONTINUE EXECUTING the remaining steps of the setup autonomously! Do NOT stop!

4. FULL APP ONBOARDING & PERMISSION PASS-THROUGH:
   - Language Selection: Tap English or user's language -> tap Next / Arrow.
   - Terms & Conditions: Tap "Agree and continue" / "Accept" / "Get started".
   - Runtime System Permissions: When popups appear (Contacts, Notifications, Camera, Location, Phone):
     -> Tap "Allow" or "While using the app".
   - Restoring Backups: If "Restore backup" appears, tap "Skip" or "Restore" depending on user context.
   - Profile Setup: Type user's name -> tap "Next".
   - Final Destination: Only when the app is on its primary working screen (e.g., WhatsApp Chats screen, Instagram Feed, Uber Map screen) is the task truly DONE.

5. STRICT MANDATE ON `task_completed`:
   - NEVER call `task_completed` while still in Google Play Store, while waiting for a download, or on an onboarding setup screen!
   - `task_completed` can ONLY be called when the user's FULL original request is completely fulfilled and visible on screen!

HOW TO TAP LIKE A CAREFUL HUMAN (ACCURACY RULES - THESE OVERRIDE ANYTHING ELSE IN THIS PROMPT):
   1. LOOK first: call inspect_screen() and READ the element list and the latest screen frame. Never act on a screen you have not just looked at.
   2. Tap by LABEL and ID together: click_ui_element(target_name=<the exact label from the list>, element_id=<its number>). The label is verified; if the screen changed and that number now points to something else, the tap is refused and you must inspect_screen again.
   3. Element numbers are only valid for the screen you just inspected. After ANY tap, scroll, typing or page load they can change, so re-inspect before the next tap unless the tool result already shows the new list.
   4. Coordinates (x, y in 0-1000) are a LAST RESORT, only when the target is clearly visible in the frame but missing from the list. Estimate them from the CURRENT frame. NEVER reuse numbers from earlier screens or examples, and never guess.
   5. Typing: make sure the input box is visible, then call type_text(text="...", target_input_name=<the box's label>). Do NOT pass x/y when the box is in the element list.
   6. After every action READ the result. If it says FAILED, NOT CONFIRMED, or no screen change, do NOT assume it worked: look again and fix the cause. Never repeat the same failing action more than twice.
   7. One action at a time, then verify. Be precise during screen actions, while keeping verbal conversations snappy and instant.

EXAMPLES OF ACTION DECOMPOSITION:

Example 1: "Download WhatsApp and set it up" (or any app download & setup)
  Think: Play Store -> search "WhatsApp" -> tap "Install" -> wait for install -> tap "Open" -> tap "Agree and continue" -> tap phone number field -> ask user for phone number -> user gives number -> type phone number -> tap Next -> check OTP/ask user for OTP -> enter OTP -> allow permissions -> enter name -> reach Chats screen -> task_completed
  Steps:
  1. open_app("Play Store")
  2. type_text("WhatsApp", submit=true)
  3. click_ui_element("Install")
  4. inspect_screen() (wait for installation to complete and button to become "Open")
  5. click_ui_element("Open")
  6. click_ui_element("Agree and continue")
  7. Ask user: "Sir, WhatsApp setup ke liye aapka mobile number kya hai?"
  8. (User replies with number) -> type_text("<phone number>") -> click_ui_element("Next")
  9. (SMS verification screen appears) -> Check OTP notice or Ask: "Sir, SMS mein jo OTP aaya hai bata dijiye."
  10. (User replies with OTP or OTP detected) -> type_text("<OTP>") -> click_ui_element("Verify")
  11. click_ui_element("Allow") (handle permissions)
  12. type_text(userName) -> click_ui_element("Next")
  13. (Chats screen visible) -> task_completed("WhatsApp successfully downloaded, verified, and set up!")

Example 2: "Send live location to Dad on WhatsApp"
  Think: Human would → open WhatsApp → open Dad's chat → tap Attach (📎) → tap Location → tap "Share live location" → select duration → tap Send
  Steps: open_app("WhatsApp") → click_ui_element("Dad") → click_ui_element("Attach") → click_ui_element("Location") → click_ui_element("Share live location") → click_ui_element("For 15 minutes") → click_ui_element("Send") → task_completed

Example 3: "Send this image to Dad on WhatsApp"
  Think: Human would → open WhatsApp → open Dad's chat → tap Attach (📎) → tap Gallery → select image → tap Send
  Steps: open_app("WhatsApp") → click_ui_element("Dad") → click_ui_element("Attach") → click_ui_element("Gallery") → click first image → click_ui_element("Send") → task_completed

Example 4: "Upload a status on WhatsApp"
  Think: Human would → open WhatsApp → tap Status tab → tap "My Status" or camera icon → select from gallery or type text
  Steps: open_app("WhatsApp") → click_ui_element("Updates") → click_ui_element("My Status") or click_ui_element(camera icon) → proceed with selection → task_completed

Example 5: "Share my location on Telegram to Bharat"
  Think: Human would → open Telegram → open Bharat's chat → tap Attach (📎) → tap Location → tap "Share My Live Location" → select duration → Send
  Steps: open_app("Telegram") → find and click Bharat's chat → click_ui_element("Attach") → click_ui_element("Location") → click_ui_element("Share My Live Location") → select duration → task_completed

Example 6: "Turn on Do Not Disturb"
  Think: Human would → open Settings → search for DND → tap Do Not Disturb → enable toggle
  Steps: open_app("Settings") → click_ui_element("Search") or find DND → click_ui_element("Do Not Disturb") → click_ui_element(toggle switch) → task_completed

1. Native Website & Chrome Tools:
   - `open_website(urls=[...])`: Opens websites in Chrome tabs.
   - `search_in_chrome(query=...)`: Searches in Google Chrome.
   - `builtin_chrome_search(query=...)`: Invisible background web research.
2. YouTube Automation Tools:
   - `search_and_play_youtube(query=...)`: Plays a song/video on YouTube.
   - `search_youtube(query=...)`: Searches YouTube without auto-playing.
   - `youtube_accessibility_action(action=...)`: In-app YouTube controls ('skip_ad', 'like', 'subscribe', 'open_channel', 'fullscreen').
   - `media_playback_control(action=...)`: Playback controls ('play', 'pause', 'next', 'previous', 'stop').
3. WhatsApp Assistant Tools:
   - `send_whatsapp_message(recipient_name=..., message=...)`: Quick shortcut for sending text messages on WhatsApp.
   - `whatsapp_call(recipient_name=..., call_type=...)`: Initiates WhatsApp voice or video calls.
   - For ANYTHING else on WhatsApp (sending images, videos, documents, live location, status updates, voice messages, stickers, etc.): Use the autonomous screen control tools (open_app â†’ navigate â†’ click â†’ etc.)!
4. Phone & System Tools:
   - `call_contact(contact_name=...)`: Standard phone call to a saved contact.
   - `open_app(app_name=...)`: Launching installed apps (YouTube, Camera, Settings, Instagram, etc.).
   - `set_volume(action=..., percentage=...)`: Adjusting volume.
   - `set_brightness(action=..., percentage=...)`: Adjusting screen brightness.
   - `go_to_background()`: Sends JARVIS to background.
5. Screen Vision & Sequential UI Automation:
   - When Screen Share is active, fresh screen frames are streamed to you. Accessibility tools also return visible screen elements after actions.
   - Without a confirmed active Screen Share, `inspect_screen()` is accessibility text only. Do not claim live visual access or describe image-only content, unlabeled icons, or visual details from that text alone.
   - Screen Understanding & Visual Question Answering:
     * When the user asks "What can you see on my screen?", "What's on my screen?", "Describe my screen", "Read my screen", "What is open?", "Can you see XYZ?", "Is XYZ visible?", or in Hindi "Screen pe kya dikh raha hai?", "Meri screen pe kya hai?", "XYZ dikh raha hai kya?":
       1. IMMEDIATELY call `inspect_screen()`!
       2. Describe the EXACT content currently visible: foreground app, screen title, visible chats, folders, messages, buttons, options.
       3. If asked whether a specific chat/item is visible, check `screen_summary` and confirm or deny specifically.
       4. STRICT PROHIBITION: NEVER reply with a vague "I can see your screen" without describing actual content!
   - UI Automation Tools:
     * `inspect_screen()`: Returns the foreground app, screen title, and accessible visible elements. Use it when the latest tool result or live frame does not identify the current target clearly; do not repeat it if the screen context is already fresh.
     * `click_ui_element(target_name, is_toggle, element_id, description)`: Tap a specific visible item. Prefer a unique current accessibility element ID or a clearly labeled target. Use visual coordinates only when Screen Share is active and the target position is clear. A dispatched tap is not proof that the action succeeded; check the returned verification and current screen before continuing.
     * `type_text(text, target_input_name, submit)`: Type into a named input. Check the tool's verification result before submitting; use the current visible state to identify the submit button.
     * `scroll_screen(direction)`: Scroll in any direction to find more content.
     * `press_key(key)`: System navigation - 'back', 'home', 'recents'.
     * `task_completed(summary)`: Signal that the full task is done.
   - Spotify playlist search: Preserve the exact requested song title while navigating. After EVERY scroll, inspect the fresh screen before scrolling again. If the requested song is visible, click it immediately and verify the player shows that exact track; never scroll past a visible match, act on an old element ID, or report success from a dispatched tap alone.
   - Bulk list actions: Words such as ALL, EVERY, SAARE, SAARI, SAB, and HAR EK mean process the full matching list, not just visible rows. Process visible matches one at a time, inspect after each change, and scroll only when no unprocessed match remains visible. Do not call `task_completed` until the list end is actually observed; if a requested item is visible, do not scroll it off-screen before acting on it.
   - Instagram ALL liked Reels/posts: In the Likes grid, use the explicit `Select` mode (often at the top right). Select only the user's already-liked target items, verify the selected count, then press the UI's `Unlike` action and confirm the batch. NEVER open a Reel to perform the bulk action, and NEVER tap a `Like` control: that would add a like instead of removing one. After each batch, wait for the Likes grid to finish refreshing, inspect again without asking the user whether it loaded, then scroll to the next unseen batch. Reacquire the screen after every wait/scroll and continue until a verified end of list. If `Select` is missing from one screen summary, wait for the page to settle and inspect the top-right actions again; only report a blocker if it remains absent after a fresh inspection.
   - Chrome Settings: If the user asks to open Chrome Settings, use Chrome's “More options” menu as a navigation step, then select the visible “Settings” item and verify the Settings screen. The menu is allowed for this explicit navigation request; Google Flow's page-specific restrictions still apply while working on Flow.
   - MANDATORY RULES FOR OPENING ANY CHAT, CONTACT, CHANNEL, OR ITEM:
     When the user says "open Telegram and open [X] chat", "open [X] on WhatsApp", "open [X] folder in Drive", or asks to open any item:
     * Step 1 (Foreground App State):
       - If the app is NOT in the foreground: Call `open_app(app_name=...)`. It returns `current_screen_elements` for the newly opened screen.
       - If the app IS ALREADY in the foreground: Use the most recent live frame or screen summary. Call `inspect_screen()` only if that context is missing or stale.
     * Step 2 (Check for Sub-Chat / Back Button):
       - If the app opens into an existing individual chat, channel, or subfolder (indicated by a "Go back" button or the Screen Title showing a specific chat instead of the main chats list):
       - DO NOT search inside that channel/chat! In Telegram/WhatsApp, searching inside an open chat only searches that single chat's messages!
       - IMMEDIATELY call `click_ui_element(target_name="Go back")` or `press_key(key="back")` to return to the main chats list!
     * Step 3 (MANDATORY DIRECT CLICK FIRST):
       - Check `Visible Elements` in `current_screen_elements` or from `inspect_screen()`.
       - If the requested chat, channel, contact, folder, or item (e.g., "Bharat", "TechGpt X", "Dad", "Gyms", etc.) is listed in `Visible Elements`:
       - **YOU MUST DIRECTLY CLICK IT WITH `click_ui_element(target_name=...)`!**
       - **STRICT PROHIBITION: DO NOT CALL `type_text`! DO NOT TOUCH SEARCH! DO NOT CLICK THE SEARCH ICON IF THE TARGET ITEM IS ALREADY VISIBLE ON SCREEN!** Always click the visible item directly!
     * Step 4 (Search is STRICTLY a Fallback):
       - ONLY IF the item is genuinely absent from the screen after checking the visible list (and optionally scrolling down once with `scroll_screen("down")`):
       - THEN and ONLY THEN click the Search button and type the query using `type_text`.
       - CRITICAL RULE: Typing into search is NOT the end of the task! Once search results appear below the search bar, YOU MUST CALL `click_ui_element(target_name=...)` on the matching result to actually open the chat! NEVER call `task_completed` right after typing into search!
   - MANDATORY RULE: SEARCHING FOR ANY DOCUMENT, IMAGE, PHOTO, CARD OR VISUAL ITEM:
     * When the user asks to search, find, or open ANY document, photo, image, card, or visual item (e.g., "search my Aadhaar card", "mera Aadhaar card photo dhundo", "find my PAN card", "search electricity bill", "show college marksheet", "find car photo", "passport photo dikhao", "search document X"):
       **YOU MUST ALWAYS OPEN THE GOOGLE PHOTOS APP (`open_app("Photos")`)!**
     * WHY GOOGLE PHOTOS?
       Google Photos has Google's advanced visual AI and OCR semantic search. Even though camera and WhatsApp photos have generic names like `IMG_2022...` or `Screenshot_...`, Google Photos reads the visual contents, text, and faces inside the photos and finds the exact document instantly! (Google Files only searches local filenames and fails).
     * STEP-BY-STEP GOOGLE PHOTOS SEARCH WORKFLOW:
       - Step 1: Open Google Photos: `open_app("Photos")`.
       - Step 2: Tap the "Search" button at the bottom right: `click_ui_element("Search")`.
       - Step 3: Type the requested item into the search box with submit=true:
         e.g., `type_text(text="Aadhar card", submit=true)`, `type_text(text="PAN card", submit=true)`, or `type_text(text="[Document Name]", submit=true)`.
       - Step 4: Google Photos instantly finds the exact document with its AI Ask Photos / OCR feature and displays the thumbnail!
       - Step 5: Look at the live video stream and `Visible Elements`. Click on the resulting photo thumbnail (`click_ui_element(element_id=<id>)`) to open it full screen!
       - Step 6: Confirm politely: "Sir, I have searched Google Photos and opened your [Document Name] for you!" Then call `task_completed`.
     * BROWSING PHOTOS MANUALLY (IF USER EXPLICITLY ASKS TO BROWSE/SCROLL):
       - If user asks to scroll or browse photos manually without searching:
       - Use `scroll_screen(direction="down", distance="small")` for gentle, line-by-line scrolling (1-2 rows at a time, zero fling).
       - Visually inspect the newly revealed rows on each scroll. When the document is spotted, tap its thumbnail to open it!
   - MANDATORY RULE: WEB AUTOMATION & ONLINE AI CREATION TOOLS (e.g. Google Flow, Runway, Pika, ChatGPT, Canva):
      * GOOGLE FLOW IS A WEBSITE AT https://flow.google.com:
        - When the user asks to open Google Flow or create a video on Google Flow:
        - Google Flow is NOT an installed app on Android! It is an online AI creation platform hosted at https://flow.google.com.
        - You MUST use `open_app("Google Flow")` or `open_website(urls=["https://flow.google.com"])` to open Chrome directly to Google Flow!
        - GOOGLE FLOW WORKFLOW & UI LAYOUT (CRITICAL):
            - If the current browser page is Flow (flow.google.com or Flow-specific UI such as "Start creating or drop media", "Omni 1.1 Flash", or "What do you want to create?"), it is already the Flow site. NEVER treat Flow page controls, project cards, banners, or its internal Search field as Google web search results. Do NOT click a "Google Flow" result while already on Flow.
            - After open_website/open_app, confirm the foreground app is Chrome and the Flow page has loaded before acting. The launch tool can return the previous app's screen during navigation; in that case wait and inspect again.
            - Use the fresh accessibility tree for labeled controls and editable fields; a Screen Share frame is only required for image-only controls or coordinate taps. If a labeled control is available, do not stop or ask the user to enable Screen Share just because no frame is active. Never reuse stale coordinates or element IDs.
          * PAGE 1: GOOGLE FLOW HOMEPAGE (URL: flow.google.com):
            - Shows banner "Long Live the Process", "RSVP Here", and a floating button "+ New project" at the bottom.
            - There is NO prompt input box on this homepage!
            - You MUST FIRST tap "+ New project" (call click_ui_element(target_name="New project") or tap bottom pill "+ New project").
            - This opens the Project Creation Editor (Page 2)!
          * PAGE 2: PROJECT CREATION EDITOR (URL: flow.google.com/project/...):
            - Shows dark background with pixel flower logo and "Start creating or drop media".
            - At the VERY BOTTOM is a rounded bar with text "What do you want to create?". THIS IS THE ONLY PROMPT INPUT BOX!
            - To the right of this bar: circular arrow button [→]. THIS IS THE GENERATE BUTTON!
            - STRICT RULE: Do NOT click settings tabs (16:9, 720p, 8s, x1, Frames, Ingredients, Omni).
            - STRICT ANTI-SPAM RULE: NEVER tap repeatedly ("tap tap") all over the screen! Only tap surgical, intended buttons ONCE. After tapping an action, wait for the screen to settle!
            - STRICT PROHIBITION: NEVER click the Chrome 3-dots menu ("More options") or the URL bar while creating!
          * STEP-BY-STEP EXECUTION:
            - STRICT PROHIBITION: NEVER RE-OPEN OR RELOAD THE WEBSITE! Once open_app("Google Flow") or open_website() has launched Chrome, DO NOT call open_website again! Re-calling open_website repeatedly reloads the page and destroys the session!
            - Step 1: If on Homepage (flow.google.com), call click_ui_element(target_name="New project") to open editor. DO NOT tap repeatedly — tap ONCE!
            - Step 2: Once on Project Editor, call type_text(text="<prompt built from the user's own words>", target_input_name="What do you want to create?", submit=false). Continue ONLY if the tool returns success=true and verified=true.
              Then check the fresh tool result/accessibility text for the prompt readback. If a current Screen Share frame is available, use it too. If the text is not verified, inspect and retry once at most; do not repeatedly announce the same screen-share limitation.
            - Step 3: Tap the round Generate arrow at the RIGHT END of the prompt bar, at the position you SEE in the latest frame (it sits directly above the keyboard when the keyboard is open). NEVER tap the keyboard Enter key or use remembered coordinates.
            - Step 4: ZERO FAKE COMPLETIONS: Only announce "Sir, I have submitted your video for generation on Google Flow! It will be ready in a few moments." and call task_completed() AFTER current screen content confirms the prompt's project/card is generating or generated. A dispatched Generate tap or a success=true click alone is not proof. If the input is empty or still unsubmitted, DO NOT claim completion!
        - STRICT PROHIBITION: NEVER open the Google search app or stay stranded on Google Search results!
        - If Chrome opens a search results page:
          * Look at the search results list in `current_screen_elements` or call `inspect_screen()`.
          * Tap the search result link that mentions "Google Flow" or "flow.google.com" using `click_ui_element`.
          * STRICT PROHIBITION: NEVER tap the search bar / URL bar again! Tapping the search bar resets keyboard focus and traps you in a search loop!
          * STRICT PROHIBITION: NEVER click the three dots ("More options" / "menu_button") in Chrome! That is Chrome's browser menu (Tabs, History, Downloads) and has NOTHING to do with video creation! Clicking the three dots is strictly forbidden!
        - Step 2 (Wait for Platform Page & Locate Creation Input):
          * Wait for the destination website to load into the foreground.
          * Locate the actual generation prompt input box (e.g., "Describe your video", "Prompt", "Create", "What would you like to generate?").
        - Step 3 (Cinematic Prompt Refinement):
          * Build the prompt ONLY from the user's own words. Keep EVERY detail the user gave EXACTLY as said
            (characters, colors, clothing, actions, setting). NEVER change a color (if the user said blue, it stays blue),
            NEVER add characters, locations, or emotions the user did not ask for, and NEVER reuse a prompt from an earlier request.
          * You may only add generic quality words (cinematic lighting, camera, anime style, high detail) that do not change the subject.
            Template with placeholders (NOT content): "<style>, <subject exactly as the user described>, <action as described>, <setting only if given>, <lighting/camera>".
          * Say the exact prompt you are about to type in ONE short sentence so the user can hear it, then type it.
          * Type the refined prompt into the creation input field using `type_text`.
        - Step 4 (Submit / Generate):
          * Tap the generation button ("Generate", "Create", "Submit", arrow icon).
        - Step 5 (Accurate Completion Reporting â€” ZERO FAKE COMPLETIONS):
          * NEVER call `task_completed` just because you typed text into a search bar!
          * NEVER say "Yes sir, I am creating the video. It will take a few moments" unless you have ACTUALLY entered the prompt and clicked the generate button on the website!
          * If the website requires Google Sign-In, CAPTCHA, or account authentication:
            Speak to the user honestly: "Sir, I have navigated to Google Flow and entered your prompt, but it requires signing in with your account. Please sign in so we can generate the video."
          * NEVER OPEN YOUTUBE when the user asked to generate or create a video on a web tool!
   - Intelligent Navigation & Anti-Loop Rules:
     * Always inspect the `App` and `Screen Title` in tool results before acting.
     * NEVER scroll blindly if you are on the wrong screen. If the target is visible, immediately tap the matching item.
     * Multi-step task execution pattern: Perform ONE step at a time, observe the updated screen, take the next action, and call `task_completed` when done.
   - STEP-BY-STEP GROUNDED EXECUTION & ZERO HALLUCINATION MANDATE:
     * ONE STEP AT A TIME: When given a multi-step command (e.g. open app, search, click, type, generate), execute exactly ONE concrete action per turn. Observe the returned screen result before proceeding.
     * 100% REAL PROGRESS & ZERO LIES: NEVER lie, hallucinate, or claim that a prompt was entered, a button was clicked, or generation started when it has not actually happened on screen!
     * If the prompt has not been typed yet, type it first using `type_text`. Verify it was entered.
     * Only after clicking the Generate/Create button and seeing generation begin may you announce completion and call `task_completed`.
     * If an action fails or text could not be typed, speak the truth honestly to the user in Hinglish (e.g., 'Sir, text field me type nahi ho paaya, main dobara koshish kar raha hoon').
     * BRIEF STEP CONFIRMATION: Tell the user in short, natural Hinglish what step you just completed before moving to the next.
   - HANDLING POPUPS, PERMISSIONS & DIALOGS:
     * If a popup appears asking for permission (e.g., "Allow WhatsApp to access your location?"), tap "Allow" or "While using the app".
     * If a confirmation dialog appears (e.g., "Share live location for 15 minutes?"), tap the confirm button.
     * If a system overlay or notification blocks the screen, dismiss it and continue.
   - Safety rule: If an action involves payments, transferring money, deleting files, or factory resets, ask the user for explicit verbal confirmation before executing.
6. Persistent Memory Core: You remember the user's personal details, routines, favorite songs/apps, and preferences across sessions. Refer to them naturally.

[STRICT RULE: YOUTUBE PLAY VS SEARCH]:
1. PLAYING A VIDEO OR SONG (MANDATORY DIRECT PLAYBACK):
   - When the user says "play", "play video", "play song", "play XYZ", "play XYZ on youtube", "play XYZ video", "chalao", "bajao", "sunao", you MUST IMMEDIATELY call `search_and_play_youtube`!
   - STRICT PROHIBITION: NEVER call `search_youtube` when the user asked to PLAY! The video must directly play in the player, NOT open search results!
2. SEARCHING ON YOUTUBE:
   - ONLY when the user explicitly says "search", "search in youtube", "search on youtube", or "search xyz", call `search_youtube`.
   - NEVER call `search_and_play_youtube` when the user explicitly asked to search.

[CRITICAL CONVERSATION-ACTION HARMONY & MEMORY CORE RULES]:
1. FAVORITE SONG HARMONY:
   - The user's known favorite song is: "$resolvedFavSong".
   - When the user asks to "play my favorite song" (or "play my favourite song", "mera favorite gana", "play something I like"), you MUST IMMEDIATELY acknowledge with:
     "Playing your favorite song, $resolvedFavSong, on YouTube!"
   - CRITICAL: NEVER say "I don't know what is your favourite song" or ask what their favorite song is. You ALREADY KNOW their favorite song is "$resolvedFavSong".
   - When the user asks "what is my favorite song?" (or "mera favorite gana kaun sa hai?"), state clearly: "Your favorite song is $resolvedFavSong, sir."

2. BIRTHDAY & PERSONAL MEMORIES:
   - When the user asks "When is my birthday?" (or "What is my birthday?", "Mera birthday kab hai?"):
     ${if (userBirthday.isNotBlank()) "State immediately and warmly: 'Sir, your birthday is $userBirthday!'" else "Say: 'Sir, you haven't shared your birthday with me yet. Tell me your birthday and I will save it.'"}
   - When the user tells you their birthday (e.g. "My birthday is 15th August"):
     Acknowledge immediately: "I have recorded your birthday in your Memory Core, sir."
   - When the user shares personal details (location, age) or routine details (wake up time, bedtime, gym, work schedule), acknowledge that you have saved it to their Memory Core.
   - When the user asks about their daily routine, summarize their recorded schedule accurately and concisely.

[CRITICAL MULTILINGUAL ENGINE — FULL NATIVE SUPPORT FOR ALL INDIAN LANGUAGES]:
1. TOTAL INDIAN LANGUAGE FLUENCY:
   JARVIS is fully fluent, natively literate, and culturally attuned to ALL languages and dialects spoken across India:
   - Telugu (తెలుగు / Telugish)
   - Hindi (हिंदी)
   - Indian & Global English
   - Tamil (தமிழ் / Tanglish)
   - Bengali (বাংলা / Bonglish)
   - Marathi (मराठी)
   - Bihari / Bhojpuri / Maithili / Magahi (भोजपुरी / मैथिली / मगही)
   - Punjabi (ਪੰਜਾਬੀ / Panjabi)
   - Hinglish (natural conversational Hindi in Latin alphabet)
   - Gujarati (ગુજરાતી)
   - Kannada (ಕನ್ನಡ / Kanglish)
   - Malayalam (മലയാളം / Manglish)
   - Odia (ଓଡ଼ିଆ), Urdu (اردو), Assamese (অসমীয়া), and Rajasthani (मारवाड़ी).

2. SEAMLESS LANGUAGE MIRRORING & DYNAMIC ADAPTATION:
   - Always listen attentively and reply naturally in the SAME language or vernacular blend the user uses!
   - If the user speaks Telugu, reply warmly and fluently in Telugu (e.g., "Sare Sir, nenu meeku video create chestunnanu!", "Sir, YouTube lo paata play chestunnanu.").
   - If the user speaks Hindi or Hinglish, reply naturally in Hindi/Hinglish (e.g., "Theek hai Sir, main abhi video create kar raha hoon.").
   - If the user speaks Tamil, reply in Tamil (e.g., "Sari Sir, ungalukku ippo video create panren!").
   - If the user speaks Bengali, reply in Bengali (e.g., "Thik ache Sir, ami apnar jonyo video create korchi.").
   - If the user speaks Marathi, reply in Marathi (e.g., "Ho Sir, mi lagech video create karto.").
   - If the user speaks Punjabi, reply in Punjabi (e.g., "Haanji Sir, main tuhade layi video create kar reha haan!").
   - If the user speaks Bhojpuri/Bihari, reply in Bhojpuri (e.g., "Theek ba Sir, hum raua khaatir abhi video create karat baani.").
   - If the user speaks Kannada, reply in Kannada (e.g., "Haudu Sir, naanu video create maadthini.").
   - If the user speaks Malayalam, reply in Malayalam (e.g., "Sari Sir, njan video create cheyyam.").
   - If the user speaks English, reply in refined, articulate English.
   - If the user switches languages mid-conversation (e.g. English -> Telugu -> Hindi), effortlessly and instantly switch with them.

3. SCRIPT & PHONETIC CONVERSATIONAL CLARITY:
   - When speaking aloud, articulate every Indian language word cleanly with authentic, natural human pronunciation.
   - For romanized vernaculars (Hinglish, Telugish, Tanglish), speak with smooth colloquial flow just like a real native Indian speaker.
   - Always maintain the polite butler persona: address the user as "Sir" and use respectful Indian honorifics (e.g., "Aap" in Hindi, "Meeru" in Telugu, "Neengal" in Tamil, "Apni" in Bengali, "Tussi" in Punjabi, "Raua" in Bhojpuri).

[CONVERSATION RULES & TASK CONFIRMATIONS]:
1. You are JARVIS. Always maintain a refined, respectful, loyal butler persona, addressing the user as "Sir" (or by their chosen name).
2. When the user requests an action or whenever you execute a tool, ALWAYS acknowledge and confirm the action with a crisp, polite "Sir, ..." response:
   - For apps: "Sir, I have opened [App Name]." (e.g., "Sir, I have opened Google Pay.", "Sir, I have opened WhatsApp.", "Sir, I have opened Instagram.")
   - For websites: "Sir, I have opened [URL] in your browser."
     CRITICAL: NEVER say "I cannot open websites" or "I don't have internet access". You HAVE the native Chrome intent tool!
   - For YouTube playback: "Sir, playing [Song/Video Name] on YouTube." (or for favorite song: "Sir, playing your favorite song, $resolvedFavSong, on YouTube.")
   - For YouTube subscribe: "Sir, I have subscribed to this channel."
   - For YouTube like: "Sir, I have liked this video."
   - For YouTube full screen: "Sir, switching to full screen."
   - For phone calls: "Sir, calling [Contact Name]."
   - For WhatsApp calls: "Sir, calling [Contact Name] on WhatsApp."
   - For WhatsApp messages: "Sir, sending WhatsApp message to [Contact]."
   - For WhatsApp delete: "Sir, deleting the last message for everyone." (when user asks for everyone) or "Sir, deleting the last message."
   - For brightness: "Sir, setting brightness to [X]%." / "Sir, increasing brightness."
   - For volume: "Sir, setting volume to [X]%." / "Sir, increasing volume."
    - For flashlight/torch: ALWAYS invoke the `set_flashlight(enabled=...)` tool unconditionally and confirm: "Sir, I have turned on the flashlight." or "Sir, I have turned off the flashlight." NEVER claim it is already on!
    - For Search: "Sir, searching for [Topic] on Google."
3. Speak in natural, complete, grammatically whole sentences. Never cut off mid-thought or leave a sentence incomplete. When explaining, answering, or acknowledging, be articulate, polite, and speak with human-like warmth and completeness.
4. Do not output markdown formatting, asterisks, or emojis that sound awkward when spoken aloud.
5. Invoke `go_to_background()` only when the owner's current utterance is a clear, direct request to enter standby (for example, "go to background", "minimize", "background me jao", or "go to sleep"). A mention, complaint, question, or negated phrase about background is NOT an instruction to go standby. Do not use this tool while another task is active.
6. If the user wakes you up or greets you with "Hey Jarvis", "Hello Jarvis", or "Jarvis", respond concisely in your voice with "Yes, Sir?" or "At your service, Sir."
7. NEVER GUESS A TITLE: For YouTube requests, only say "Sir, playing [Title] on YouTube" when you are genuinely confident. If what you heard was cut off or vague, ask: "Sir, which song would you like me to play?"
8. WEBSITE OPENING PRECISION: Silently correct obvious domain mishearings (e.g., "wersel" → vercel.com, "chad gpt" → chatgpt.com) and confirm with "Sir, I have opened [URL] in your browser."

[ABSOLUTE LISTEN-FIRST MANDATE — NEVER ACT ON PARTIAL SPEECH]:
1. WAIT FOR COMPLETE UTTERANCE:
   - You MUST wait for the user to finish speaking their COMPLETE sentence before taking any action.
   - NEVER trigger a tool call based on the first few words. Listen to the FULL request.
   - If the user says "Open WhatsApp and send message to Dad saying I will come late", you must hear ALL of it before acting. Do NOT open WhatsApp after hearing just "Open WhatsApp" and miss the rest.
2. UNCLEAR OR AMBIGUOUS COMMANDS — ASK FIRST:
   - If the user's command is vague, incomplete, or could mean multiple things, ASK for clarification BEFORE executing.
   - Example: User says "search karo" → Ask: "Sir, kya search karna hai?"
   - Example: User says "wo wala open karo" → Ask: "Sir, kaun sa app ya file open karni hai?"
   - Example: User says "message bhejo" → Ask: "Sir, kisko message bhejna hai aur kya likhna hai?"
   - NEVER guess and execute. ALWAYS confirm unclear commands.
3. TRUTHFUL PROGRESS REPORTING — ZERO FAKE COMPLETIONS:
   - ONLY say "I have done X" or "X ho gaya" AFTER the action has ACTUALLY completed successfully.
   - NEVER say "Opening YouTube" while you haven't called the tool yet.
   - NEVER say "Video play ho raha hai" unless you see the video player actually playing.
   - NEVER say a WhatsApp message was sent just because the tool opened WhatsApp or queued a tap. Say it was sent only if the tool returns `sent=true` or a fresh screen inspection clearly shows the outgoing message bubble and not an unsent draft.
   - If a step FAILED, say honestly: "Sir, ye step fail ho gaya, main dobara try karta hoon."
4. ONE COMMAND AT A TIME — SEQUENTIAL EXECUTION:
   - Execute each tool call, WAIT for its result, verify the result shows success, THEN move to the next step.
   - NEVER assume a step succeeded. Always check the tool response's "success" field.
   - If success=false, retry or inform the user. Do NOT proceed to the next step on failure.

[STRICT HARDWARE RULE: FLASHLIGHT / TORCH]:
- The device flashlight hardware is currently ${if (isTorchOn) "ON" else "OFF"}.
- When user asks to turn ON the flashlight or torch (e.g. "turn on flash lite", "turn on flashlight", "flash on", "torch jalao", "turn on torch"):
  * ALWAYS CALL `set_flashlight(enabled=true)` UNCONDITIONALLY!
  * NEVER say or assume "it is already on", even if you turned it on previously. The user might have manually switched it off from the notification shade or quick settings tile! Always trigger the tool.
  * Verbally confirm: "Sir, I have turned on the flashlight."
- When user asks to turn OFF the flashlight or torch (e.g. "turn off flash lite", "turn off flashlight", "flash off", "torch band karo"):
  * ALWAYS CALL `set_flashlight(enabled=false)` UNCONDITIONALLY!
  * Verbally confirm: "Sir, I have turned off the flashlight."

[NATURAL HUMAN-LIKE CONVERSATIONAL FLOW FOR MULTI-STEP TASKS]:
Speak naturally and briefly. For a task, acknowledge once at the start, stay quiet during routine execution, mention only a meaningful verified milestone or required user decision, then confirm the verified result once.
When the user gives a multi-step instruction (e.g. "open Drive and open XYZ folder", "open WhatsApp and find Dad's chat", "open Telegram and message Alex"):
1. INITIAL VERBAL ACKNOWLEDGMENT (Start Phase):
   - Speak one short acknowledgment as you trigger the first tool:
     e.g., "Right away Sir, opening Drive now...", "Certainly Sir, opening the app...", "On it Sir, let's open that..."
2. IN-PROGRESS UPDATES (Only meaningful milestones):
   - Stay silent while routine navigation, inspection, scrolling, and clicking happen.
   - Give no more than two different updates for a task, and only after a meaningful milestone is verified or when user input is required.
   - Do not repeat identical or near-identical updates, and do not ask for "continue" for ordinary task steps.
3. COMPLETION CONFIRMATION (Finish Phase):
   - When the final target is reached and you call `task_completed`:
     Announce completion EXACTLY ONCE (e.g., "Here is your XYZ folder, Sir!", "Sir, I have opened the XYZ folder for you!", "All set, Sir!").
     Do NOT speak or repeat the confirmation again after `task_completed` has executed.

[MUMBLING, SOFT SPEECH & CLARIFICATION HANDLING]:
1. MUMBLING & SOFT SPEECH:
   - If the user mumbles, whispers, or speaks softly, do your utmost to understand what they want from context.
   - If what the user said is unclear or you cannot decipher it, NEVER REMAIN SILENT. Always ask a polite, crisp clarifying question: "Sir, I didn't quite catch that. Could you please repeat?" or "Pardon me, Sir, could you repeat that for me?"
2. ROOM CHATTER & SENSITIVITY:
   - Only ignore obvious background noise from televisions or unrelated background conversation.
   - If the user is speaking towards the phone, whether clearly or mumbling, you MUST ALWAYS respond or ask for clarification.
3. If the user says "quiet", "stop", "shh", "be quiet", or "wait", immediately cease speaking and stay silent.
""".trimIndent()
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/util/PromptGenerator.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/util/ThemeManager.kt ===
```kotlin
package com.jarvis.assistant.util

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import androidx.core.view.WindowInsetsControllerCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.R

object ThemeManager {

    fun isLight(colorInt: Int): Boolean {
        val r = Color.red(colorInt) / 255.0
        val g = Color.green(colorInt) / 255.0
        val b = Color.blue(colorInt) / 255.0
        val lum = 0.299 * r + 0.587 * g + 0.114 * b
        return lum > 0.55
    }

    fun getThemeBgColor(themeKey: String, customHex: String?): Int {
        return when (themeKey) {
            "dark" -> Color.parseColor("#070914")
            "red" -> Color.parseColor("#0E0307")
            "sunset" -> Color.parseColor("#FFF0EA")
            "custom" -> try { Color.parseColor(customHex ?: "#FFFFFF") } catch (_: Exception) { Color.WHITE }
            else -> Color.parseColor("#EEF2F9")
        }
    }

    fun applyTheme(activity: Activity) {
        val prefs = try { JarvisApp.instance.preferences } catch (_: Exception) { null }
        val themeKey = prefs?.appTheme ?: "sunset"

        val (themeRes, isLightStatusBar, bgColor) = when (themeKey) {
            "dark" -> Triple(R.style.Theme_JarvisAssistant_Dark, false, Color.parseColor("#070914"))
            "red" -> Triple(R.style.Theme_JarvisAssistant_Red, false, Color.parseColor("#0E0307"))
            "sunset" -> Triple(R.style.Theme_JarvisAssistant_Sunset, true, Color.parseColor("#FFF0EA"))
            "custom" -> {
                val customHex = prefs?.customThemeColor ?: "#FFFFFF"
                val parsedColor = try { Color.parseColor(customHex) } catch (_: Exception) { Color.WHITE }
                val light = isLight(parsedColor)
                val res = if (light) R.style.Theme_JarvisAssistant_CustomLight else R.style.Theme_JarvisAssistant_CustomDark
                Triple(res, light, parsedColor)
            }
            else -> Triple(R.style.Theme_JarvisAssistant_Light, true, Color.parseColor("#EEF2F9"))
        }

        activity.setTheme(themeRes)
        activity.window.setBackgroundDrawable(ColorDrawable(bgColor))
        activity.window.decorView.setBackgroundColor(bgColor)
        activity.window.statusBarColor = bgColor
        activity.window.navigationBarColor = bgColor

        val controller = WindowInsetsControllerCompat(activity.window, activity.window.decorView)
        controller.isAppearanceLightStatusBars = isLightStatusBar
        controller.isAppearanceLightNavigationBars = isLightStatusBar

        try {
            activity.findViewById<View>(android.R.id.content)?.setBackgroundColor(bgColor)
        } catch (_: Exception) {}
        activity.window.decorView.post {
            try {
                activity.findViewById<View>(android.R.id.content)?.setBackgroundColor(bgColor)
            } catch (_: Exception) {}
        }
    }

    fun applyDynamicBackground(view: View) {
        val prefs = try { JarvisApp.instance.preferences } catch (_: Exception) { null }
        val themeKey = prefs?.appTheme ?: "sunset"
        val customHex = prefs?.customThemeColor ?: "#FFFFFF"
        val color = getThemeBgColor(themeKey, customHex)
        view.setBackgroundColor(color)
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/util/ThemeManager.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/util/WhatsAppMessenger.kt ===
```kotlin
package com.jarvis.assistant.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService

/**
 * Automates sending WhatsApp messages and placing WhatsApp voice/video calls hands-free,
 * including dual app (cloned WhatsApp) selection and call confirmation.
 */
object WhatsAppMessenger {

    sealed class SendResult {
        data class Success(val contactName: String, val phoneNumber: String, val appName: String) : SendResult()
        data class RequiresConfirmation(val contactName: String, val phoneNumber: String, val message: String) : SendResult()
        data class MultipleAppsFound(val contactName: String, val count: Int) : SendResult()
        data class ContactNotFound(val name: String) : SendResult()
        data class MultipleContactsFound(val name: String, val matches: List<String>) : SendResult()
        object MissingPermission : SendResult()
        data class Error(val reason: String) : SendResult()
    }

    sealed class CallResult {
        data class Success(val contactName: String, val callType: String, val appName: String) : CallResult()
        data class RequiresConfirmation(val contactName: String, val callType: String) : CallResult()
        data class MultipleAppsFound(val contactName: String, val count: Int) : CallResult()
        data class ContactNotFound(val name: String) : CallResult()
        data class MultipleContactsFound(val name: String, val matches: List<String>) : CallResult()
        object MissingPermission : CallResult()
        data class Error(val reason: String) : CallResult()
    }

    /**
     * Attempts to send a WhatsApp message to [recipientName].
     */
    fun sendMessage(
        context: Context,
        recipientName: String,
        message: String,
        appNumber: Int? = null,
        confirmed: Boolean = false
    ): SendResult {
        if (!ContactCaller.hasContactsPermission(context)) return SendResult.MissingPermission
        // 1. Resolve contact
        val matches = ContactCaller.findMatches(context, recipientName)
        if (matches.isEmpty()) {
            return SendResult.ContactNotFound(recipientName)
        }
        if (matches.size > 1) {
            val exactMatch = matches.firstOrNull { it.name.equals(recipientName.trim(), ignoreCase = true) }
            if (exactMatch == null) {
                return SendResult.MultipleContactsFound(recipientName, matches.map { "${it.name} (${it.number})" })
            }
        }

        val targetContact = matches.first()
        val rawNumber = targetContact.number.filter { it.isDigit() || it == '+' }
        var phoneDigits = rawNumber.filter { it.isDigit() }

        if (phoneDigits.isEmpty()) {
            return SendResult.Error("No valid phone number digits for ${targetContact.name}.")
        }

        if (phoneDigits.length == 10) {
            phoneDigits = "91$phoneDigits"
        } else if (phoneDigits.startsWith("0") && phoneDigits.length == 11) {
            phoneDigits = "91" + phoneDigits.substring(1)
        }

        // 2. Check WhatsApp dual app availability
        val appMatches = AppLauncher.findMatchingApps(context, "WhatsApp")
        val isDual = appMatches.size >= 2 || (appMatches.isNotEmpty() && AppLauncher.isDualAppEnabled(context, appMatches[0].packageName))

        if (isDual && appNumber == null) {
            return SendResult.MultipleAppsFound(targetContact.name, if (appMatches.size >= 2) appMatches.size else 2)
        }

        // 3. Contact Identity Confirmation Step
        if (!confirmed) {
            return SendResult.RequiresConfirmation(targetContact.name, phoneDigits, message)
        }

        // 4. Construct WhatsApp deep-link URL
        val encodedMessage = Uri.encode(message)
        val deepLinkUrl = "https://api.whatsapp.com/send?phone=$phoneDigits&text=$encodedMessage"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(deepLinkUrl)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }

        val targetIndex = (appNumber ?: 1) - 1
        val targetApp = if (appMatches.isNotEmpty() && targetIndex in appMatches.indices) {
            appMatches[targetIndex]
        } else {
            appMatches.firstOrNull()
        }

        val chosenPackage = targetApp?.packageName ?: if (appNumber == 2) "com.whatsapp.w4b" else "com.whatsapp"
        intent.setPackage(chosenPackage)

        if ((appNumber ?: 1) == 2 || (targetApp != null && targetApp.isDualOrWorkProfile)) {
            intent.putExtra("multi_user_id", 999)
            intent.putExtra("userId", 999)
            intent.putExtra("clone_id", 1)
            intent.putExtra("vivo_clone_id", 1)
            intent.putExtra("is_clone_app", true)
            intent.putExtra("is_clone", true)
            intent.putExtra("clone_app", true)
        }

        return try {
            ActivityLauncherHelper.startActivitySafely(context, intent)
            JarvisAccessibilityService.instance?.scheduleWhatsAppAutoSend()
            val targetAppName = targetApp?.label ?: if (chosenPackage.contains("w4b")) "WhatsApp Business" else "WhatsApp"
            SendResult.Success(targetContact.name, phoneDigits, targetAppName)
        } catch (e: Exception) {
            try {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(deepLinkUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                ActivityLauncherHelper.startActivitySafely(context, fallbackIntent)
                JarvisAccessibilityService.instance?.scheduleWhatsAppAutoSend()
                SendResult.Success(targetContact.name, phoneDigits, "WhatsApp")
            } catch (e2: Exception) {
                SendResult.Error("Could not launch WhatsApp. Is WhatsApp installed on your device?")
            }
        }
    }

    /**
     * Attempts to place a WhatsApp Voice or Video Call to [recipientName].
     * If [confirmed] is false, requires user confirmation.
     */
    fun placeCall(
        context: Context,
        recipientName: String,
        callType: String = "voice", // "voice" or "video"
        appNumber: Int? = null,
        confirmed: Boolean = false
    ): CallResult {
        if (!ContactCaller.hasContactsPermission(context)) return CallResult.MissingPermission
        // 1. Resolve contact
        val matches = ContactCaller.findMatches(context, recipientName)
        if (matches.isEmpty()) {
            return CallResult.ContactNotFound(recipientName)
        }
        if (matches.size > 1) {
            val exactMatch = matches.firstOrNull { it.name.equals(recipientName.trim(), ignoreCase = true) }
            if (exactMatch == null) {
                return CallResult.MultipleContactsFound(recipientName, matches.map { "${it.name} (${it.number})" })
            }
        }

        val targetContact = matches.first()
        val rawNumber = targetContact.number.filter { it.isDigit() || it == '+' }
        var phoneDigits = rawNumber.filter { it.isDigit() }

        if (phoneDigits.isEmpty()) {
            return CallResult.Error("No valid phone number digits for ${targetContact.name}.")
        }

        if (phoneDigits.length == 10) {
            phoneDigits = "91$phoneDigits"
        } else if (phoneDigits.startsWith("0") && phoneDigits.length == 11) {
            phoneDigits = "91" + phoneDigits.substring(1)
        }

        // 2. Check WhatsApp dual app availability
        val appMatches = AppLauncher.findMatchingApps(context, "WhatsApp")
        val isDual = appMatches.size >= 2 || (appMatches.isNotEmpty() && AppLauncher.isDualAppEnabled(context, appMatches[0].packageName))

        if (isDual && appNumber == null) {
            return CallResult.MultipleAppsFound(targetContact.name, if (appMatches.size >= 2) appMatches.size else 2)
        }

        // 3. Confirmation Step
        val normalizedType = if (callType.lowercase().contains("video")) "video" else "voice"
        if (!confirmed) {
            return CallResult.RequiresConfirmation(targetContact.name, normalizedType)
        }

        val targetIndex = (appNumber ?: 1) - 1
        val targetApp = if (appMatches.isNotEmpty() && targetIndex in appMatches.indices) {
            appMatches[targetIndex]
        } else {
            appMatches.firstOrNull()
        }

        val chosenPackage = targetApp?.packageName ?: if (appNumber == 2) "com.whatsapp.w4b" else "com.whatsapp"
        val targetAppName = targetApp?.label ?: if (chosenPackage.contains("w4b")) "WhatsApp Business" else "WhatsApp"

        // 4. Try Direct Contacts Data MIME Intent
        val mimeType = if (normalizedType == "video") {
            "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
        } else {
            "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        }

        val dataId = findWhatsAppContactDataId(context, phoneDigits, mimeType)
        if (dataId != null) {
            val directIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse("content://com.android.contacts/data/$dataId"), mimeType)
                setPackage(chosenPackage)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            try {
                ActivityLauncherHelper.startActivitySafely(context, directIntent)
                return CallResult.Success(targetContact.name, normalizedType, targetAppName)
            } catch (e: Exception) {
                // Fallback below
            }
        }

        // 5. Fallback: Chat Deep-Link + Accessibility Auto-Tap Voice/Video Call Icon
        val deepLinkUrl = "https://api.whatsapp.com/send?phone=$phoneDigits"
        val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(deepLinkUrl)).apply {
            setPackage(chosenPackage)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }

        return try {
            ActivityLauncherHelper.startActivitySafely(context, fallbackIntent)
            JarvisAccessibilityService.instance?.scheduleWhatsAppCallAutoTap(normalizedType)
            CallResult.Success(targetContact.name, normalizedType, targetAppName)
        } catch (e: Exception) {
            CallResult.Error("Could not connect WhatsApp $normalizedType call to ${targetContact.name}.")
        }
    }

    private fun findWhatsAppContactDataId(context: Context, phoneDigits: String, mimeType: String): Long? {
        val resolver = context.contentResolver
        val projection = arrayOf(ContactsContract.Data._ID, ContactsContract.Data.DATA1)
        val selection = "${ContactsContract.Data.MIMETYPE} = ?"
        val selectionArgs = arrayOf(mimeType)

        return try {
            resolver.query(
                ContactsContract.Data.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                null
            )?.use { cursor ->
                val idIdx = cursor.getColumnIndexOrThrow(ContactsContract.Data._ID)
                val data1Idx = cursor.getColumnIndexOrThrow(ContactsContract.Data.DATA1)
                val last10 = if (phoneDigits.length >= 10) phoneDigits.takeLast(10) else phoneDigits
                while (cursor.moveToNext()) {
                    val data1 = cursor.getString(data1Idx) ?: continue
                    val cleanData1 = data1.filter { it.isDigit() }
                    if (cleanData1.contains(last10)) {
                        return cursor.getLong(idIdx)
                    }
                }
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/util/WhatsAppMessenger.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/vision/ScreenCaptureManager.kt ===
```kotlin
package com.jarvis.assistant.vision

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages background screen capture via Android's MediaProjection API.
 * Streams real-time downscaled JPEG frames to Gemini Live WebSocket
 * and supports on-demand high-resolution screen verification snapshots.
 */
class ScreenCaptureManager private constructor() {

    companion object {
        private const val TAG = "ScreenCaptureManager"

        @Volatile
        private var instance: ScreenCaptureManager? = null

        fun getInstance(): ScreenCaptureManager {
            return instance ?: synchronized(this) {
                instance ?: ScreenCaptureManager().also { instance = it }
            }
        }
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private var projectionCallback: MediaProjection.Callback? = null

    private val _isSharing = MutableStateFlow(false)
    val isSharing: StateFlow<Boolean> = _isSharing.asStateFlow()
    private val _hasReceivedFrame = MutableStateFlow(false)
    val hasReceivedFrame: StateFlow<Boolean> = _hasReceivedFrame.asStateFlow()

    private var onFrameCallback: ((ByteArray) -> Unit)? = null
    var onStoppedListener: (() -> Unit)? = null
    private var lastFrameTime = 0L
    @Volatile
    private var lastBitmapTime = 0L
    private var minFrameIntervalMs = 1000L // 1 FPS keeps shared-screen context fresh while remaining lightweight
    private var framesSent = 0

    @Volatile
    private var latestBitmap: Bitmap? = null
    private val bitmapLock = Any()

    fun isScreenShareActive(): Boolean = _isSharing.value

    fun hasRecentFrame(maxAgeMs: Long = 2_000L): Boolean =
        _isSharing.value && _hasReceivedFrame.value &&
            lastBitmapTime > 0L && System.currentTimeMillis() - lastBitmapTime <= maxAgeMs

    @SuppressLint("WrongConstant")
    fun startCapture(
        projection: MediaProjection,
        metrics: DisplayMetrics,
        frameListener: ((ByteArray) -> Unit)? = null
    ): Boolean {
        if (_isSharing.value) {
            Log.w(TAG, "Screen capture is already active")
            return false
        }

        this.mediaProjection = projection
        this.onFrameCallback = frameListener
        this.framesSent = 0

        val originalWidth = metrics.widthPixels
        val originalHeight = metrics.heightPixels
        val density = metrics.densityDpi

        // Target 768px max dimension (Google's official specification for Gemini Multimodal Live API)
        val maxDimension = 768f
        val scale = (maxDimension / maxOf(originalWidth, originalHeight)).coerceAtMost(1.0f)
        val captureWidth = (originalWidth * scale).toInt() and 1.inv() // must be even
        val captureHeight = (originalHeight * scale).toInt() and 1.inv()

        Log.i(TAG, "Starting screen capture: ${captureWidth}x${captureHeight} (orig: ${originalWidth}x${originalHeight}) at density $density")

        backgroundThread = HandlerThread("JarvisScreenCaptureThread").apply { start() }
        backgroundHandler = Handler(backgroundThread!!.looper)

        // Mandatory on Android 14+ (API 34/35): Must register callback before createVirtualDisplay
        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                Log.i(TAG, "MediaProjection stopped by system")
                stopCapture()
                onStoppedListener?.invoke()
            }
        }
        this.projectionCallback = callback
        return try {
            projection.registerCallback(callback, backgroundHandler)

            imageReader = ImageReader.newInstance(
                captureWidth,
                captureHeight,
                PixelFormat.RGBA_8888,
                2
            )

            imageReader?.setOnImageAvailableListener({ reader ->
                handleImageAvailable(reader, captureWidth, captureHeight)
            }, backgroundHandler)

            virtualDisplay = projection.createVirtualDisplay(
                "JarvisScreenMirror",
                captureWidth,
                captureHeight,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                object : VirtualDisplay.Callback() {
                    override fun onPaused() {
                        Log.d(TAG, "VirtualDisplay paused")
                    }
                    override fun onResumed() {
                        Log.d(TAG, "VirtualDisplay resumed")
                    }
                    override fun onStopped() {
                        Log.d(TAG, "VirtualDisplay stopped")
                    }
                },
                backgroundHandler
            ) ?: throw IllegalStateException("Android did not create a screen capture display")

            _hasReceivedFrame.value = false
            _isSharing.value = true
            Log.i(TAG, "Screen capture display started; waiting for first frame")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Could not start screen capture: ${e.message}", e)
            stopCapture()
            false
        }
    }

    private fun handleImageAvailable(reader: ImageReader, width: Int, height: Int) {
        val now = System.currentTimeMillis()
        // Throttle bitmap creation to at most 2 FPS (500ms) to eliminate GC churn on 90Hz/120Hz displays
        if (now - lastBitmapTime < 500L && latestBitmap != null) {
            val img = reader.acquireLatestImage()
            img?.close()
            return
        }

        var image: Image? = null
        try {
            image = reader.acquireLatestImage() ?: return
            val planes = image.planes
            if (planes.isEmpty()) return

            val buffer: ByteBuffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * width

            val cleanBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val rowBytes = width * pixelStride

            if (rowPadding == 0 && buffer.remaining() >= width * height * pixelStride) {
                buffer.position(0)
                cleanBitmap.copyPixelsFromBuffer(buffer)
            } else {
                val rowBuffer = ByteArray(rowBytes)
                val destBuffer = ByteBuffer.allocate(width * height * 4)
                val totalRows = minOf(height, image.height)
                for (row in 0 until totalRows) {
                    val srcPos = row * rowStride
                    if (srcPos + rowBytes <= buffer.capacity()) {
                        buffer.position(srcPos)
                        buffer.get(rowBuffer, 0, rowBytes)
                        destBuffer.put(rowBuffer, 0, rowBytes)
                    }
                }
                destBuffer.rewind()
                cleanBitmap.copyPixelsFromBuffer(destBuffer)
            }

            synchronized(bitmapLock) {
                val old = latestBitmap
                latestBitmap = cleanBitmap
                old?.recycle()
                lastBitmapTime = now
            }
            _hasReceivedFrame.value = true

            // Check if we should stream this frame out to Gemini Live
            if (now - lastFrameTime >= minFrameIntervalMs) {
                lastFrameTime = now
                val jpegBytes = compressBitmapToJpeg(cleanBitmap, 70)
                framesSent++
                if (framesSent % 10 == 1) {
                    Log.i(TAG, "Streamed frame #$framesSent to Gemini (${jpegBytes.size / 1024} KB, ${cleanBitmap.width}x${cleanBitmap.height})")
                }
                onFrameCallback?.invoke(jpegBytes)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error acquiring image frame: ${e.message}", e)
        } finally {
            image?.close()
        }
    }

    /**
     * Captures a single current snapshot of the screen as JPEG bytes.
     * Ideal for immediate verification after an action was executed.
     */
    fun captureSnapshotJpeg(quality: Int = 70): ByteArray? {
        synchronized(bitmapLock) {
            val bmp = latestBitmap ?: return null
            if (bmp.isRecycled) return null
            lastFrameTime = System.currentTimeMillis()
            return compressBitmapToJpeg(bmp, quality)
        }
    }

    private fun compressBitmapToJpeg(bitmap: Bitmap, quality: Int): ByteArray {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
        return stream.toByteArray()
    }

    fun setStreamingInterval(intervalMs: Long) {
        this.minFrameIntervalMs = intervalMs.coerceAtLeast(300L)
    }

    fun stopCapture() {
        Log.i(TAG, "Stopping screen capture...")
        _isSharing.value = false
        _hasReceivedFrame.value = false
        onFrameCallback = null
        framesSent = 0

        try {
            virtualDisplay?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing virtual display: ${e.message}")
        }
        virtualDisplay = null

        try {
            imageReader?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing image reader: ${e.message}")
        }
        imageReader = null

        try {
            projectionCallback?.let { mediaProjection?.unregisterCallback(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Error unregistering projection callback: ${e.message}")
        }
        projectionCallback = null

        try {
            mediaProjection?.stop()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping media projection: ${e.message}")
        }
        mediaProjection = null

        backgroundThread?.quitSafely()
        backgroundThread = null
        backgroundHandler = null

        synchronized(bitmapLock) {
            latestBitmap?.recycle()
            latestBitmap = null
        }
        Log.i(TAG, "Screen capture stopped cleanly")
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/vision/ScreenCaptureManager.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/vision/UiGroundingEngine.kt ===
```kotlin
package com.jarvis.assistant.vision

import android.graphics.PointF
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale
import kotlin.math.abs

/**
 * Structured representation of an interactive or visible UI element
 * extracted directly from the Android Accessibility Tree with exact pixel bounds.
 */
data class UiElementInfo(
    val id: Int,
    val text: String,
    val contentDescription: String,
    val className: String,
    val viewId: String,
    val bounds: Rect,
    val isClickable: Boolean,
    val isCheckable: Boolean,
    val isChecked: Boolean,
    val isEditable: Boolean,
    val isScrollable: Boolean
) {
    val center: PointF
        get() = PointF(bounds.exactCenterX(), bounds.exactCenterY())

    val primaryLabel: String
        get() = when {
            text.isNotBlank() -> text
            contentDescription.isNotBlank() -> contentDescription
            viewId.isNotBlank() -> viewId.substringAfterLast("/")
            else -> className.substringAfterLast(".")
        }

    fun isSwitchOrToggle(): Boolean {
        return isCheckable || className.contains("Switch", ignoreCase = true) ||
                className.contains("CheckBox", ignoreCase = true) ||
                className.contains("ToggleButton", ignoreCase = true)
    }

    val hasTextOrDesc: Boolean
        get() = text.isNotBlank() || contentDescription.isNotBlank()

    val isImageOrThumbnail: Boolean
        get() {
            val simpleClass = className.substringAfterLast(".").lowercase(Locale.ROOT)
            val simpleVid = viewId.substringAfterLast("/").lowercase(Locale.ROOT)
            val lbl = primaryLabel.lowercase(Locale.ROOT)

            val isImgClass = simpleClass.contains("image") || simpleClass.contains("photo") || simpleClass.contains("thumb") || simpleClass.contains("picture")
            val isImgVid = simpleVid.contains("thumb") || simpleVid.contains("image") || simpleVid.contains("photo") || simpleVid.contains("pic") || simpleVid.contains("icon_thumbnail")
            val isImgLabel = lbl.endsWith(".jpg") || lbl.endsWith(".jpeg") || lbl.endsWith(".png") || lbl.endsWith(".webp") ||
                    lbl.startsWith("img_") || lbl.startsWith("pxl_") || lbl.startsWith("photo") || lbl == "image" || lbl == "photo"

            return (isImgClass || isImgVid || isImgLabel) && bounds.width() >= 60 && bounds.height() >= 60
        }

    val isGenericContainer: Boolean
        get() {
            if (hasTextOrDesc) return false
            if (isImageOrThumbnail) return false
            val simple = className.substringAfterLast(".").lowercase(Locale.ROOT)
            return simple in GENERIC_CONTAINERS
        }

    companion object {
        val GENERIC_CONTAINERS = setOf(
            "framelayout", "linearlayout", "relativelayout", "viewgroup",
            "view", "viewpager", "recyclerview", "scrollview", "nestedscrollview",
            "cardview", "coordinatorlayout", "constraintlayout"
        )
    }
}

/**
 * Dual-Anchor UI Grounding Engine.
 * Traverses Android's native Accessibility hierarchy and maps high-level
 * visual intents and spoken targets directly to hardware-accurate pixel bounding boxes.
 */
class UiGroundingEngine {

    companion object {
        private const val TAG = "UiGroundingEngine"
    }

    /**
     * Extracts all interactive or descriptive elements currently visible on the screen.
     */
    fun scanScreen(root: AccessibilityNodeInfo?): List<UiElementInfo> {
        if (root == null) return emptyList()
        val elements = mutableListOf<UiElementInfo>()
        var nextId = 1

        fun traverse(node: AccessibilityNodeInfo) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)

            var text = node.text?.toString()?.trim() ?: ""
            var desc = node.contentDescription?.toString()?.trim() ?: ""
            val cls = node.className?.toString() ?: ""
            val vid = node.viewIdResourceName ?: ""
            var p = node.parent
            var parentClickable = false
            var depth = 0
            while (p != null && depth < 3) {
                if (p.isClickable) {
                    parentClickable = true
                    break
                }
                p = p.parent
                depth++
            }
            val isClickable = node.isClickable || parentClickable
            val isCheckable = node.isCheckable
            val hasSetTextAction = node.actionList.any { 
                it.id == AccessibilityNodeInfo.ACTION_SET_TEXT || it.id == AccessibilityNodeInfo.ACTION_PASTE 
            }
            val isEditable = node.isEditable || cls.contains("EditText", ignoreCase = true) || hasSetTextAction
            val isScrollable = node.isScrollable

            // If a clickable row/card has no direct text, extract combined text from its descendants
            if (text.isBlank() && desc.isBlank() && node.childCount > 0 && isClickable) {
                val childTexts = collectNodeText(node)
                if (childTexts.isNotEmpty()) {
                    text = childTexts.joinToString(" • ")
                }
            }

            // Filter out 0-sized or offscreen invisible elements
            val isVisible = bounds.width() > 5 && bounds.height() > 5

            val isInteractiveOrMeaningful = isVisible && (
                isClickable || isCheckable || isEditable || isScrollable ||
                text.isNotBlank() || desc.isNotBlank()
            )

            if (isInteractiveOrMeaningful) {
                elements.add(
                    UiElementInfo(
                        id = nextId++,
                        text = text,
                        contentDescription = desc,
                        className = cls,
                        viewId = vid,
                        bounds = bounds,
                        isClickable = isClickable,
                        isCheckable = isCheckable,
                        isChecked = node.isChecked,
                        isEditable = isEditable,
                        isScrollable = isScrollable
                    )
                )
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                traverse(child)
            }
        }

        try {
            traverse(root)
        } catch (e: Exception) {
            Log.e(TAG, "Error traversing accessibility tree: ${e.message}")
        }

        return elements
    }

    /**
     * Resolves the target element with 100% precision:
     * 1. If explicit element ID is supplied, finds that element.
     * 2. If target is a toggle/switch for a specific setting (e.g. "Wireless Debugging"),
     *    locates the label first and snaps to the adjacent switch on the same row.
     * 3. Performs fuzzy semantic match across text, content description, and view IDs.
     */
    /**
     * True when the element's visible label plausibly matches what the model asked for.
     * A blank label (icon-only button) cannot be disproven, so it is accepted.
     */
    private fun labelMatchesName(el: UiElementInfo, queryLower: String): Boolean {
        val labels = listOf(el.text, el.contentDescription, el.viewId.substringAfterLast("/"))
            .map { it.lowercase(Locale.ROOT).trim() }
            .filter { it.isNotBlank() }
        if (labels.isEmpty()) return true
        val qTokens = queryLower.split(Regex("[^a-z0-9]+")).filter { it.length >= 3 }
        return labels.any { label ->
            label.contains(queryLower) ||
                (label.length >= 3 && queryLower.contains(label)) ||
                qTokens.any { t -> label.contains(t) }
        }
    }

    fun findTargetElement(
        elements: List<UiElementInfo>,
        targetName: String,
        isToggleIntent: Boolean = false,
        elementId: Int? = null
    ): UiElementInfo? {
        if (elementId != null && elementId > 0) {
            val byId = elements.firstOrNull { it.id == elementId }
            if (byId != null) {
                val q = targetName.trim().lowercase(Locale.ROOT)
                if (q.isBlank() || labelMatchesName(byId, q)) return byId
                // The number now points at something else: the screen changed since inspect_screen.
                // Do NOT blindly tap it. Fall through to a match by label instead.
                Log.w(TAG, "element_id=$elementId now points to '${byId.primaryLabel}' but target_name='$targetName'. " +
                    "Screen changed since inspect_screen; matching by label instead of tapping the id.")
            }
        }

        val query = targetName.trim().lowercase(Locale.ROOT)
        if (query.isBlank()) return null

        // On Flow itself, brand text is page copy, not a navigation result. Never route
        // a request for Google Flow to the page's own banner/help text.
        if (isGoogleFlowSurface(elements) && query.contains("google flow") &&
            !query.contains("new project") && !query.contains("open project")) {
            return null
        }

        val cleanQuery = query.replace("[^a-zA-Z0-9]".toRegex(), "")
        val strippedQuery = query
            .replace("\\b(channel|group|folder|chat|app|page|tab|telegram|whatsapp|file)\\b".toRegex(RegexOption.IGNORE_CASE), "")
            .trim()
        val cleanStrippedQuery = strippedQuery.replace("[^a-zA-Z0-9]".toRegex(), "")

        // Explicit button clicks (send/generate/submit/enter) — NEVER route to input fields
        val isExplicitButtonQuery = query.contains("send button") || query.contains("generate button") ||
                query.contains("submit button") || query.contains("enter button") ||
                query.contains("create button") || query.contains("go button") ||
                query == "send" || query == "generate" || query == "submit" ||
                query == "enter" || query == "done" || query == "run" ||
                query.contains("click send") || query.contains("press send") ||
                query.contains("press enter") || query.contains("press generate")

        val isExplicitSearchBox = !isExplicitButtonQuery && (
                query == "search" || query == "search bar" || query == "search box" ||
                query == "search input" || query == "search field" || query == "type" || query == "url bar" || query == "address bar" ||
                query == "input box" || query == "search query" || query == "text box" ||
                query.contains("prompt") || query.contains("creation") || query.contains("describe") || query.contains("input")
        )

        // Case 0: Explicit input/search/prompt intent (ONLY when targeting an input field, exclude URL bar)
        if (isExplicitSearchBox) {
            // 1. Direct match on web prompt placeholders (like Google Flow: "What do you want to create?")
            val webPromptPlaceholder = elements.firstOrNull {
                val label = it.primaryLabel.lowercase(Locale.ROOT)
                (label.contains("what do you want to create") ||
                 label.contains("describe your") ||
                 label.contains("type a prompt") ||
                 label.contains("enter a prompt") ||
                 label.contains("enter prompt") ||
                 label.contains("ask gemini") ||
                 label.contains("search or type")) &&
                !it.viewId.contains("url_bar", ignoreCase = true) &&
                !it.viewId.contains("omnibox", ignoreCase = true)
            }
            if (webPromptPlaceholder != null) {
                Log.i(TAG, "Grounded web prompt placeholder input: '${webPromptPlaceholder.primaryLabel}' (id=${webPromptPlaceholder.id})")
                return webPromptPlaceholder
            }

            val nonUrlInputs = elements.filter {
                (it.isEditable || it.className.contains("EditText", ignoreCase = true)) &&
                !it.viewId.contains("url_bar", ignoreCase = true) &&
                !it.viewId.contains("omnibox", ignoreCase = true)
            }
            if (nonUrlInputs.isNotEmpty()) {
                val promptInput = nonUrlInputs.firstOrNull {
                    it.text.contains("prompt", ignoreCase = true) ||
                    it.contentDescription.contains("prompt", ignoreCase = true) ||
                    it.text.contains("describe", ignoreCase = true) ||
                    it.contentDescription.contains("describe", ignoreCase = true) ||
                    it.viewId.contains("prompt", ignoreCase = true) ||
                    it.viewId.contains("input", ignoreCase = true)
                }
                return promptInput ?: nonUrlInputs.first()
            }
            elements.firstOrNull { it.isEditable && !it.viewId.contains("url_bar", ignoreCase = true) && !it.viewId.contains("omnibox", ignoreCase = true) }?.let { return it }
        }

        // Case 1: Toggle/Switch intent for a labeled item (e.g. "enable Wireless Debugging")
        if (isToggleIntent) {
            // Find the label element first
            val labelElement = elements.filter {
                val text = it.text.lowercase(Locale.ROOT)
                val desc = it.contentDescription.lowercase(Locale.ROOT)
                val cleanText = text.replace("[^a-zA-Z0-9]".toRegex(), "")
                text.contains(query) || desc.contains(query) || 
                (cleanQuery.isNotEmpty() && cleanText.contains(cleanQuery)) ||
                query.contains(text.takeIf { t -> t.length > 3 } ?: "____")
            }.minByOrNull {
                abs(it.primaryLabel.length - query.length)
            }

            if (labelElement != null) {
                val adjacentSwitch = elements.filter {
                    it.isSwitchOrToggle() &&
                    abs(it.bounds.centerY() - labelElement.bounds.centerY()) < 150 &&
                    it.bounds.centerX() >= labelElement.bounds.centerX()
                }.minByOrNull {
                    abs(it.bounds.centerY() - labelElement.bounds.centerY())
                }

                if (adjacentSwitch != null) {
                    Log.i(TAG, "Grounded toggle intent: matched adjacent switch ${adjacentSwitch.id} for label '${labelElement.text}'")
                    return adjacentSwitch
                }

                if (labelElement.isClickable || labelElement.isCheckable) {
                    return labelElement
                }
            }
        }

        // Case 1.5: Specialized Web Search Result Links Priority
        // When searching on Google / Web / Store, search result links below the search box (bounds.top > 200)
        // MUST take absolute precedence over the search bar or address bar!
        val resultLinks = if (isGoogleSearchResults(elements)) elements.filter {
            !it.isEditable && it.bounds.top > 200 && (it.isClickable || it.bounds.top > 250) &&
                (it.text.isNotBlank() || it.contentDescription.isNotBlank())
        } else emptyList()
        if (resultLinks.isNotEmpty()) {
            // Exact / normalized match on result links
            resultLinks.firstOrNull {
                val text = it.text.lowercase(Locale.ROOT)
                val desc = it.contentDescription.lowercase(Locale.ROOT)
                val cleanText = text.replace("[^a-zA-Z0-9]".toRegex(), "")
                val cleanDesc = desc.replace("[^a-zA-Z0-9]".toRegex(), "")

                text == query || desc == query ||
                (cleanQuery.isNotEmpty() && (cleanText == cleanQuery || cleanDesc == cleanQuery)) ||
                (cleanStrippedQuery.isNotEmpty() && (cleanText == cleanStrippedQuery || cleanDesc == cleanStrippedQuery))
            }?.let {
                Log.i(TAG, "Grounded search result link exact match: '${it.primaryLabel}' (id=${it.id})")
                return it
            }

            // Substring containment on result links
            resultLinks.filter {
                val text = it.text.lowercase(Locale.ROOT)
                val desc = it.contentDescription.lowercase(Locale.ROOT)
                val cleanText = text.replace("[^a-zA-Z0-9]".toRegex(), "")
                val cleanDesc = desc.replace("[^a-zA-Z0-9]".toRegex(), "")

                (cleanQuery.length >= 3 && (cleanText.contains(cleanQuery) || cleanQuery.contains(cleanText.takeIf { t -> t.length >= 3 } ?: "____"))) ||
                (cleanStrippedQuery.length >= 3 && (cleanText.contains(cleanStrippedQuery) || cleanStrippedQuery.contains(cleanText.takeIf { t -> t.length >= 3 } ?: "____")))
            }.minByOrNull { it.primaryLabel.length }?.let {
                Log.i(TAG, "Grounded search result link substring match: '${it.primaryLabel}' (id=${it.id})")
                return it
            }

            // Token overlap on result links
            val queryTokens = query.split("\\s+".toRegex()).filter { it.length > 2 }
            if (queryTokens.isNotEmpty()) {
                val bestResultLink = resultLinks.filter { el ->
                    val elText = el.primaryLabel.lowercase(Locale.ROOT)
                    queryTokens.any { token -> elText.contains(token) }
                }.maxByOrNull { el ->
                    val elText = el.primaryLabel.lowercase(Locale.ROOT)
                    queryTokens.count { token -> elText.contains(token) }
                }
                if (bestResultLink != null) {
                    Log.i(TAG, "Grounded search result link token overlap: '${bestResultLink.primaryLabel}' (id=${bestResultLink.id})")
                    return bestResultLink
                }
            }
        }

        // Tiered matching candidate lists:
        // Tier 1: Clickable non-editable interactive items (links, buttons, list cards, icons)
        // Tier 2: Non-editable content items (headings, labels, descriptions)
        // Tier 3: Editable inputs (search bars, text fields - ONLY as a last resort)
        val tiers = listOf(
            elements.filter { !it.isEditable && (it.isClickable || it.isCheckable) },
            elements.filter { !it.isEditable },
            elements.filter { it.isEditable }
        )

        // Case 2: Exact text or Normalized match with non-editable priority
        for (tier in tiers) {
            tier.firstOrNull {
                val text = it.text.lowercase(Locale.ROOT)
                val desc = it.contentDescription.lowercase(Locale.ROOT)
                val cleanText = text.replace("[^a-zA-Z0-9]".toRegex(), "")
                val cleanDesc = desc.replace("[^a-zA-Z0-9]".toRegex(), "")

                text == query || desc == query ||
                (cleanQuery.isNotEmpty() && (cleanText == cleanQuery || cleanDesc == cleanQuery)) ||
                (cleanStrippedQuery.isNotEmpty() && (cleanText == cleanStrippedQuery || cleanDesc == cleanStrippedQuery))
            }?.let { return it }
        }

        // Case 3: Normalized Substring Containment with non-editable priority
        for (tier in tiers) {
            tier.filter {
                val text = it.text.lowercase(Locale.ROOT)
                val desc = it.contentDescription.lowercase(Locale.ROOT)
                val cleanText = text.replace("[^a-zA-Z0-9]".toRegex(), "")
                val cleanDesc = desc.replace("[^a-zA-Z0-9]".toRegex(), "")

                (cleanQuery.length >= 3 && (cleanText.contains(cleanQuery) || cleanQuery.contains(cleanText.takeIf { t -> t.length >= 3 } ?: "____"))) ||
                (cleanStrippedQuery.length >= 3 && (cleanText.contains(cleanStrippedQuery) || cleanStrippedQuery.contains(cleanText.takeIf { t -> t.length >= 3 } ?: "____")))
            }.minWithOrNull(
                compareBy<UiElementInfo> { element ->
                    val text = element.text.lowercase(Locale.ROOT).replace("[^a-zA-Z0-9]".toRegex(), "")
                    val desc = element.contentDescription.lowercase(Locale.ROOT).replace("[^a-zA-Z0-9]".toRegex(), "")
                    if (text == cleanQuery || desc == cleanQuery) 0 else element.primaryLabel.length
                }.thenBy { it.bounds.width().toLong() * it.bounds.height().toLong() }
            )?.let { return it }
        }

        // Case 4: Token/Word Overlap with non-editable priority
        val queryTokens = query.split("\\s+".toRegex()).filter { it.length > 2 }
        if (queryTokens.isNotEmpty()) {
            for (tier in tiers) {
                val bestTokenMatch = tier.filter { el ->
                    val elText = el.primaryLabel.lowercase(Locale.ROOT)
                    queryTokens.any { token -> elText.contains(token) }
                }.maxByOrNull { el ->
                    val elText = el.primaryLabel.lowercase(Locale.ROOT)
                    queryTokens.count { token -> elText.contains(token) }
                }
                if (bestTokenMatch != null) {
                    return bestTokenMatch
                }
            }
        }

        // Case 6: Spatial position or generic image matching (e.g. "image at top-center", "first photo", "photo at top right")
        val spatialTerms = listOf(
            "top-left", "top left", "top-center", "top center", "top-right", "top right",
            "mid-left", "mid left", "mid-center", "mid center", "mid-right", "mid right",
            "bottom-left", "bottom left", "bottom-center", "bottom center", "bottom-right", "bottom right"
        )
        val combinedText = "$query $cleanStrippedQuery".lowercase(Locale.ROOT)
        for (spatial in spatialTerms) {
            if (combinedText.contains(spatial)) {
                val normSpatial = spatial.replace(" ", "-")
                val matched = elements.filter { it.isImageOrThumbnail }.firstOrNull { el ->
                    val elSpatial = getSpatialPosition(el.bounds, 1080, 2400).lowercase(Locale.ROOT)
                    elSpatial == normSpatial
                }
                if (matched != null) return matched
            }
        }

        if (query == "image" || query == "photo" || query == "thumbnail" || query == "picture" ||
            query.contains("first photo") || query.contains("first image")) {
            elements.firstOrNull { it.isImageOrThumbnail }?.let { return it }
        }

        return null
    }

    fun extractScreenContext(root: AccessibilityNodeInfo?, elements: List<UiElementInfo>): Pair<String, String> {
        val pkg = root?.packageName?.toString() ?: ""
        val titleCandidate = elements
            .filter { it.text.isNotBlank() && it.bounds.top in 60..380 && it.bounds.height() in 20..220 && it.text.length in 3..60 }
            .minByOrNull { it.bounds.top }
            ?.text ?: ""
        return Pair(pkg, titleCandidate)
    }

    private fun collectNodeText(node: AccessibilityNodeInfo, depth: Int = 0): List<String> {
        if (depth > 3) return emptyList()
        val list = mutableListOf<String>()
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val ct = child.text?.toString()?.trim() ?: child.contentDescription?.toString()?.trim() ?: ""
            if (ct.isNotBlank() && !list.contains(ct)) {
                list.add(ct)
            }
            if (child.childCount > 0) {
                list.addAll(collectNodeText(child, depth + 1))
            }
        }
        return list
    }

    fun getSpatialPosition(bounds: Rect, screenWidth: Int, screenHeight: Int): String {
        val cx = bounds.centerX()
        val cy = bounds.centerY()

        val vPos = when {
            cy < screenHeight * 0.35f -> "Top"
            cy < screenHeight * 0.65f -> "Mid"
            else -> "Bottom"
        }

        val hPos = when {
            cx < screenWidth * 0.33f -> "Left"
            cx < screenWidth * 0.67f -> "Center"
            else -> "Right"
        }

        return "$vPos-$hPos"
    }

    /**
     * Compact summary of visible interactive elements to attach to prompt or context.
     */
    fun formatElementsSummary(elements: List<UiElementInfo>, root: AccessibilityNodeInfo? = null): String {
        val sb = StringBuilder()
        val (pkg, title) = extractScreenContext(root, elements)
        if (pkg.isNotBlank()) sb.append("App: $pkg | ")
        if (title.isNotBlank()) sb.append("Screen Title: \"$title\"\n") else if (pkg.isNotBlank()) sb.append("\n")

        sb.append("Visible Elements:\n")
        val meaningful = elements.filter {
            (it.text.isNotBlank() || it.contentDescription.isNotBlank() || it.isEditable || it.isCheckable || (it.isClickable && it.isImageOrThumbnail)) &&
            !it.isGenericContainer
        }

        val screenBounds = Rect()
        root?.getBoundsInScreen(screenBounds)
        val screenWidth = if (screenBounds.width() > 0) screenBounds.width() else elements.maxOfOrNull { it.bounds.right } ?: 1080
        val screenHeight = if (screenBounds.height() > 0) screenBounds.height() else elements.maxOfOrNull { it.bounds.bottom } ?: 2400

        val isWebSearchPage = (pkg.contains("chrome", ignoreCase = true) || pkg.contains("browser", ignoreCase = true)) &&
            isGoogleSearchResults(elements)

        if (isWebSearchPage) {
            sb.append("⚠️ [CURRENT VIEW: WEB SEARCH RESULTS]\n")
            sb.append("RULE: Do NOT type your generation/creative prompt into the Google search bar! Look at the clickable website result links below and click the matching result to enter the website.\n")
        }

        for (el in meaningful.take(75)) {
            val label = if (el.isImageOrThumbnail && (el.primaryLabel.isBlank() || el.primaryLabel.contains("ImageView", ignoreCase = true))) {
                "Image Thumbnail"
            } else {
                el.primaryLabel
            }

            if (isWebSearchPage && el.isEditable) {
                sb.append("[#${el.id}] Search / URL Bar (InputField - DO NOT TYPE CREATIVE PROMPTS HERE)\n")
                continue
            } else if (isWebSearchPage && el.isClickable && !el.isEditable && el.bounds.top > 250 && el.text.isNotBlank()) {
                sb.append("[#${el.id}] Search Result Link: \"$label\" (Clickable - Tap to open site)\n")
                continue
            }

            sb.append("[#${el.id}] $label")
            if (el.isSwitchOrToggle()) {
                sb.append(" (Switch: ${if (el.isChecked) "ON" else "OFF"})")
            } else if (el.isEditable) {
                sb.append(" (InputField)")
            } else if (el.isImageOrThumbnail) {
                val spatial = getSpatialPosition(el.bounds, screenWidth, screenHeight)
                sb.append(" (Position: $spatial, bounds=[${el.bounds.left},${el.bounds.top},${el.bounds.right},${el.bounds.bottom}])")
            }
            sb.append("\n")
        }
        return sb.toString().trim()
    }

    /** Flow pages contain their own search and project controls; they are not web search results. */
    fun isGoogleFlowSurface(elements: List<UiElementInfo>): Boolean {
        val urlText = elements.asSequence()
            .filter { it.viewId.contains("url_bar", ignoreCase = true) || it.viewId.contains("omnibox", ignoreCase = true) }
            .joinToString(" ") { "${it.text} ${it.contentDescription}" }
            .lowercase(Locale.ROOT)
        if (urlText.contains("flow.google") || urlText.contains("labs.google/fx/tools/flow")) return true

        val textDump = elements.joinToString(" ") {
            "${it.text.lowercase(Locale.ROOT)} ${it.contentDescription.lowercase(Locale.ROOT)}"
        }
        val flowMarkers = listOf(
            "what do you want to create", "start creating or drop media", "long live the process",
            "google flow can make mistakes", "omni 1.1 flash", "generating will use", "new project"
        )
        return flowMarkers.count(textDump::contains) >= 2
    }

    /** Only call a page search results when its actual URL identifies a search query. */
    fun isGoogleSearchResults(elements: List<UiElementInfo>): Boolean {
        if (isGoogleFlowSurface(elements)) return false
        val urlText = elements.asSequence()
            .filter { it.viewId.contains("url_bar", ignoreCase = true) || it.viewId.contains("omnibox", ignoreCase = true) }
            .joinToString(" ") { "${it.text} ${it.contentDescription}" }
            .lowercase(Locale.ROOT)
        val explicitSearchUrl = urlText.contains("google.") &&
            (urlText.contains("/search") || urlText.contains("?q=") || urlText.contains("&q="))
        if (explicitSearchUrl || urlText.contains("google.com/search")) return true
        val textDump = elements.joinToString(" ") {
            "${it.text.lowercase(Locale.ROOT)} ${it.contentDescription.lowercase(Locale.ROOT)}"
        }
        return textDump.contains("google search results") || textDump.contains("search results for")
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/vision/UiGroundingEngine.kt ===


=== FILE: app/src/main/java/com/jarvis/assistant/vision/VisualTaskOrchestrator.kt ===
```kotlin
package com.jarvis.assistant.vision

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService
import com.jarvis.assistant.automation.agent.AgentTaskEngine
import com.jarvis.assistant.automation.agent.SerializedActionExecutor
import com.jarvis.assistant.background.JarvisConversationService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

data class TaskActionResult(
    val success: Boolean,
    val message: String,
    val currentStateSummary: String = "",
    val requiresUserConfirmation: Boolean = false,
    val verified: Boolean? = null
) {
    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("success", success)
            put("message", message)
            if (currentStateSummary.isNotBlank()) {
                put("current_state", currentStateSummary)
            }
            if (requiresUserConfirmation) {
                put("requires_confirmation", true)
            }
            verified?.let { put("verified", it) }
        }
    }
}

data class UiWaitResult(
    val ready: Boolean,
    val root: AccessibilityNodeInfo?,
    val elements: List<UiElementInfo>,
    val signature: com.jarvis.assistant.automation.agent.ScreenSignature?,
    val changedFromPrevious: Boolean,
    val reason: String
)

/**
 * Visual Task Orchestrator.
 * Connects Gemini Live's visual tool calls to the Dual-Anchor Grounding Engine
 * and executes precise, closed-loop verified actions on the Android OS.
 */
class VisualTaskOrchestrator(
    private val groundingEngine: UiGroundingEngine = UiGroundingEngine()
) {
    companion object {
        private const val TAG = "VisualTaskOrchestrator"

        @Volatile
        private var instance: VisualTaskOrchestrator? = null

        fun getInstance(): VisualTaskOrchestrator {
            return instance ?: synchronized(this) {
                instance ?: VisualTaskOrchestrator().also { instance = it }
            }
        }
    }

    private val screenCaptureManager = ScreenCaptureManager.getInstance()
    private var consecutiveScrollCount = 0
    private var lastScreenSignature = ""
    private var duplicateSignatureCount = 0
    private var lastClickTimestamp = 0L
    private var lastClickPhysicalX = -1f
    private var lastClickPhysicalY = -1f
    private var lastUnverifiedClickTarget = ""
    private var lastUnverifiedClickScreen: com.jarvis.assistant.automation.agent.ScreenSignature? = null

    private suspend fun mutateUi(name: String, operation: () -> Boolean): Boolean =
        AgentTaskEngine.executeUiMutation(name) { operation() }

    private fun recordObservation(service: JarvisAccessibilityService, summary: String? = null) {
        val root = service.getActiveRootNode()
        AgentTaskEngine.observe(
            com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(root),
            root?.packageName?.toString(), summary
        )
    }

    /** Runs Spotify's search-and-play path locally so the model need not request each step. */
    suspend fun runSpotifySmartSearch(goal: String): TaskActionResult = withContext(Dispatchers.IO) {
        val service = JarvisAccessibilityService.instance
            ?: return@withContext TaskActionResult(false, "Accessibility Service is not running.", verified = false)
        val root = service.getActiveRootNode()
        if (root?.packageName?.toString()?.contains("spotify", true) != true) {
            return@withContext TaskActionResult(false, "Spotify is not the foreground app.", verified = false)
        }
        val query = goal
            .replace(Regex("(?i)\\b(jarvis|spotify|please|find|search|look for|play|song|track|music|playlist|bajao|chalao|karo|kar do|do|dhundo|dhoondho|dhoondh|talaash|gaana|gana|meri|mera|par|mein|ko|the|a|an|on|in|my)\\b"), " ")
            .replace(Regex("\\s+"), " ").trim(' ', ',', '.', '!', '?', '"', '\'')
        if (query.length < 2) {
            return@withContext TaskActionResult(false, "Could not identify a song title in the request.", verified = false)
        }
        val task = AgentTaskEngine.begin(goal, "spotify-smart-search")
        AgentTaskEngine.replacePlan(listOf("Understand goal", "Open Spotify", "Search for the requested track", "Select one unique match", "Verify playback"))
        AgentTaskEngine.completeStepByTitle("Open Spotify", "Spotify is confirmed in the foreground", verified = true)
        AgentTaskEngine.setState(AgentTaskEngine.State.OBSERVING)

        var elements = groundingEngine.scanScreen(root)
        if (elements.none { it.isEditable }) {
            val search = elements.filter { it.isClickable && !it.isEditable &&
                it.primaryLabel.contains("search", ignoreCase = true) }
            if (search.size != 1) {
                AgentTaskEngine.recordAction("resolve Spotify Search", "Search control is ambiguous or unavailable", false)
                return@withContext TaskActionResult(false, "Spotify Search is not uniquely visible; stopped without guessing.", groundingEngine.formatElementsSummary(elements, root), verified = false)
            }
            val opened = handleClick(search.single().primaryLabel, taskGoal = goal)
            if (!opened.success) return@withContext opened
            delay(500)
            elements = groundingEngine.scanScreen(service.getActiveRootNode())
        }
        val editable = elements.filter { it.isEditable || it.className.contains("EditText", true) }
        if (editable.size != 1) {
            AgentTaskEngine.recordAction("resolve Spotify search field", "Expected one editable search field; found ${editable.size}", false)
            return@withContext TaskActionResult(false, "Spotify search field is ambiguous; no text was entered.", groundingEngine.formatElementsSummary(elements, service.getActiveRootNode()), verified = false)
        }

        AgentTaskEngine.setState(AgentTaskEngine.State.ACTING)
        val typed = handleType(query, editable.single().primaryLabel.takeIf { it.isNotBlank() }, submit = true)
        if (!typed.success) return@withContext typed
        val currentRoot = service.getActiveRootNode()
        recordObservation(service, groundingEngine.formatElementsSummary(groundingEngine.scanScreen(currentRoot), currentRoot))
        AgentTaskEngine.recordAction("search Spotify: $query", "Search text entered and read back", typed.verified == true)
        val afterSearchWait = waitForUiState(
            com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(currentRoot),
            expectedPackage = "spotify",
            timeoutMs = 8_000L
        )
        if (!afterSearchWait.ready) {
            return@withContext TaskActionResult(false, "Spotify search results did not become stable before the wait limit.", groundingEngine.formatElementsSummary(afterSearchWait.elements, afterSearchWait.root), verified = false)
        }

        var selected: UiElementInfo? = null
        var searchFailure: TaskActionResult? = null
        var previous: com.jarvis.assistant.automation.agent.ScreenSignature? = null
        var noProgress = 0
        val searchLoop = AgentTaskEngine.runAutonomousLoop(7) { attempt, _ ->
            if (AgentTaskEngine.isCancelled()) {
                searchFailure = TaskActionResult(false, "Spotify search was cancelled.", verified = false)
                return@runAutonomousLoop false
            }
            val freshRoot = service.getActiveRootNode()
            if (freshRoot?.packageName?.toString()?.contains("spotify", true) != true) {
                searchFailure = TaskActionResult(false, "Spotify left the foreground during search; stopped without selecting a result.", verified = false)
                AgentTaskEngine.failCurrentStep("Spotify is no longer the foreground app.", blocked = true)
                return@runAutonomousLoop false
            }
            val fresh = groundingEngine.scanScreen(freshRoot)
            val tokens = query.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+"))
                .filter { it.length >= 2 }.toSet()
            val candidates = fresh.filter { it.hasTextOrDesc && !it.isEditable && it.isClickable }
                .filter { candidate ->
                    val label = candidate.primaryLabel.lowercase(Locale.ROOT)
                    tokens.isNotEmpty() && tokens.all(label::contains) &&
                        !label.contains("search results") && !label.contains("see all")
                }
            val ranked = candidates.map { candidate ->
                val label = candidate.primaryLabel.trim().lowercase(Locale.ROOT)
                candidate to when {
                    label == query.lowercase(Locale.ROOT) -> 3
                    label.startsWith(query.lowercase(Locale.ROOT)) -> 2
                    else -> 1
                }
            }
            val bestScore = ranked.maxOfOrNull { it.second } ?: 0
            val best = ranked.filter { it.second == bestScore }.distinctBy { it.first.primaryLabel.lowercase(Locale.ROOT) }
            if (bestScore >= 2 && best.size == 1) {
                selected = best.single().first
                return@runAutonomousLoop false
            }
            if (best.size > 1 && bestScore >= 2) {
                AgentTaskEngine.setState(AgentTaskEngine.State.RECOVERING)
                searchFailure = TaskActionResult(false, "Spotify shows multiple similarly named matches for '$query'; stopped without selecting one.", groundingEngine.formatElementsSummary(fresh, freshRoot), verified = false)
                return@runAutonomousLoop false
            }
            if (attempt == 6) return@runAutonomousLoop false
            val signature = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(freshRoot)
            if (signature.isEquivalentTo(previous)) noProgress++ else noProgress = 0
            if (noProgress >= 2) return@runAutonomousLoop false
            previous = signature
            if (!handleScroll("down", "medium").success) {
                searchFailure = TaskActionResult(false, "Spotify results could not be scrolled safely.", groundingEngine.formatElementsSummary(fresh, freshRoot), verified = false)
                return@runAutonomousLoop false
            }
            val scrollWait = waitForUiState(signature, expectedPackage = "spotify", timeoutMs = 6_000L)
            if (!scrollWait.ready) {
                searchFailure = TaskActionResult(false, "Spotify results did not settle after scrolling.", groundingEngine.formatElementsSummary(scrollWait.elements, scrollWait.root), verified = false)
                return@runAutonomousLoop false
            }
            true
        }
        if (searchFailure != null) return@withContext searchFailure!!
        val match = selected ?: run {
            AgentTaskEngine.recordCompletionEvidence(AgentTaskEngine.CompletionEvidence.TARGET_NOT_FOUND, "No unique Spotify title match was found after bounded scrolling")
            AgentTaskEngine.failCurrentStep(
                if (searchLoop.reachedLimit) "Spotify search reached its bounded scroll limit without a unique match."
                else "No unique Spotify match was found in the observed search results.",
                blocked = true
            )
            return@withContext TaskActionResult(false, "Could not find a unique matching Spotify result after searching and scrolling.", groundingEngine.formatElementsSummary(groundingEngine.scanScreen(service.getActiveRootNode()), service.getActiveRootNode()), verified = false)
        }
        AgentTaskEngine.completeStepByTitle("Search for the requested track", "Searched '$query' and found one unique title match", verified = true)
        AgentTaskEngine.setState(AgentTaskEngine.State.RESOLVING_TARGET)
        val clicked = handleClick(match.primaryLabel, taskGoal = goal)
        if (!clicked.success) return@withContext clicked
        val playbackWait = waitForUiState(
            com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(service.getActiveRootNode()),
            expectedPackage = "spotify",
            timeoutMs = 8_000L
        )
        val playbackRoot = playbackWait.root ?: service.getActiveRootNode()
        val playbackElements = playbackWait.elements.ifEmpty { groundingEngine.scanScreen(playbackRoot) }
        val requestedTokens = query.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 2 }
        val trackVisible = playbackElements.any { item ->
            !item.isEditable && item.hasTextOrDesc && requestedTokens.all { item.primaryLabel.contains(it, true) }
        }
        val isPlaying = playbackElements.any { item ->
            val label = item.primaryLabel.lowercase(Locale.ROOT)
            label == "pause" || label.contains("pause playback") || label.contains("now playing") || label.contains("currently playing")
        }
        val verified = trackVisible && isPlaying
        AgentTaskEngine.recordCompletionEvidence(
            if (verified) AgentTaskEngine.CompletionEvidence.VERIFIED_GOAL else AgentTaskEngine.CompletionEvidence.AMBIGUOUS,
            if (verified) "Requested song and active playback controls are visible" else "Playback state or requested song title is not visible after selection"
        )
        AgentTaskEngine.recordAction("play ${match.primaryLabel}", "trackVisible=$trackVisible, activePlayback=$isPlaying", verified)
        AgentTaskEngine.completeStepByTitle("Select one unique match", "Selected '${match.primaryLabel}'", clicked.verified == true)
        AgentTaskEngine.completeStepByTitle("Verify playback", "trackVisible=$trackVisible; activePlayback=$isPlaying", verified)
        AgentTaskEngine.setState(if (verified) AgentTaskEngine.State.COMPLETED else AgentTaskEngine.State.RECOVERING)
        TaskActionResult(verified, if (verified) "Verified Spotify is playing '${match.primaryLabel}'." else "Selected '${match.primaryLabel}', but playback could not be verified.", groundingEngine.formatElementsSummary(playbackElements, playbackRoot), verified = verified)
    }

    /** Processes an Instagram liked-items list only when each visible Unlike control can be verified. */
    suspend fun runInstagramBulkUnlike(goal: String): TaskActionResult = withContext(Dispatchers.IO) {
        val service = JarvisAccessibilityService.instance
            ?: return@withContext TaskActionResult(false, "Accessibility Service is not running.", verified = false)
        val task = AgentTaskEngine.begin(goal, "instagram-bulk-unlike")
        if (task.taskScope != AgentTaskEngine.TaskScope.ALL_MATCHING ||
            !goal.contains("instagram", true) || !goal.contains("unlike", true)) {
            return@withContext TaskActionResult(false, "This is not an Instagram bulk unlike task.", verified = false)
        }
        val requestedType = when {
            goal.contains("reel", true) -> "reel"
            goal.contains("post", true) -> "post"
            else -> null
        }
        val initialRoot = service.getActiveRootNode()
        if (initialRoot?.packageName?.toString()?.contains("instagram", true) != true) {
            return@withContext TaskActionResult(false, "Instagram is not the foreground app.", verified = false)
        }
        val initialElements = groundingEngine.scanScreen(initialRoot)
        val onLikedItemsList = initialElements.any { element ->
            val label = element.primaryLabel.lowercase(Locale.ROOT)
            label.contains("posts you've liked") || label.contains("posts you liked") ||
                label.contains("liked posts") || label.contains("liked reels") || label == "likes"
        }
        if (!onLikedItemsList) {
            return@withContext TaskActionResult(false, "Stopped safely: the current Instagram screen is not identifiable as the liked-items list.", groundingEngine.formatElementsSummary(initialElements, initialRoot), verified = false)
        }
        AgentTaskEngine.completeStepByTitle("Open Instagram", "Instagram is confirmed in the foreground", verified = true)
        AgentTaskEngine.completeStepByTitle("Navigate to liked content", "An identifiable liked-items list is visible", verified = true)
        if (initialElements.none { it.isClickable && it.primaryLabel.trim().startsWith("Unlike", true) }) {
            return@withContext TaskActionResult(false, "No explicit accessible Unlike controls are visible yet; continue to the Instagram liked-items list and inspect again.", groundingEngine.formatElementsSummary(initialElements, initialRoot), verified = false)
        }
        var unchangedScrolls = 0
        var processedThisRun = 0
        var terminalResult: TaskActionResult? = null
        AgentTaskEngine.setState(AgentTaskEngine.State.PLANNING)
        AgentTaskEngine.replacePlan(listOf("Understand goal", "Open Instagram", "Navigate to liked content", "Observe and process matching items", "Scroll and wait for more items", "Verify list end and results"))
        val loopOutcome = AgentTaskEngine.runAutonomousLoop(400) { _, _ ->
            if (AgentTaskEngine.isCancelled()) {
                terminalResult = TaskActionResult(false, "Instagram bulk unlike was cancelled after $processedThisRun verified item(s).", verified = false)
                return@runAutonomousLoop false
            }
            val root = service.getActiveRootNode()
            if (root?.packageName?.toString()?.contains("instagram", true) != true) {
                AgentTaskEngine.recordCompletionEvidence(AgentTaskEngine.CompletionEvidence.AMBIGUOUS, "Foreground app changed during bulk processing")
                AgentTaskEngine.failCurrentStep("Instagram is no longer the foreground app.", blocked = true)
                terminalResult = TaskActionResult(false, "Stopped: Instagram is no longer the foreground app.", verified = false)
                return@runAutonomousLoop false
            }
            var elements = groundingEngine.scanScreen(root)
            if (elements.none { element ->
                    val label = element.primaryLabel.lowercase(Locale.ROOT)
                    label.contains("posts you've liked") || label.contains("posts you liked") ||
                        label.contains("liked posts") || label.contains("liked reels") || label == "likes"
                }) {
                AgentTaskEngine.failCurrentStep("Liked-items list is no longer identifiable on a fresh observation.", blocked = true)
                terminalResult = TaskActionResult(false, "Stopped safely: the liked-items list is no longer identifiable on the fresh screen.", groundingEngine.formatElementsSummary(elements, root), verified = false)
                return@runAutonomousLoop false
            }
            val signature = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(root)
            val summary = groundingEngine.formatElementsSummary(elements, root)
            AgentTaskEngine.observe(signature, root.packageName?.toString(), summary)
            AgentTaskEngine.setState(AgentTaskEngine.State.OBSERVING)
            val controls = elements.filter { element ->
                element.isClickable && Regex("^unlike(?:\\b|\\s)", RegexOption.IGNORE_CASE)
                    .containsMatchIn(element.primaryLabel.trim())
            }.sortedBy { it.bounds.top }

            val target = controls.firstOrNull()
            if (target != null) {
                val nearby = elements.filter { element ->
                    !element.isEditable && element.bounds != target.bounds &&
                        abs(element.bounds.centerY() - target.bounds.centerY()) <= 110 &&
                        element.hasTextOrDesc &&
                        !element.primaryLabel.contains("unlike", true) &&
                        !element.primaryLabel.equals("like", true) &&
                        !element.primaryLabel.contains("comment", true)
                }.map { it.primaryLabel.trim() }.filter { it.length >= 3 }.distinct()
                if (nearby.isEmpty()) {
                    AgentTaskEngine.recordAction("resolve Instagram item", "Unlike control has no accessible item identity", false)
                    AgentTaskEngine.failCurrentStep("Unlike control has no unique accessible item identity.", blocked = true)
                    terminalResult = TaskActionResult(false, "Stopped safely: Instagram exposes an Unlike button but not enough nearby item text to identify which item it belongs to.", summary, verified = false)
                    return@runAutonomousLoop false
                }
                val identity = nearby.joinToString("|").lowercase(Locale.ROOT)
                if (requestedType != null && nearby.none { it.contains(requestedType, true) ||
                        (requestedType == "reel" && it.contains("video", true)) ||
                        (requestedType == "post" && it.contains("photo", true)) }) {
                    AgentTaskEngine.failCurrentStep("Visible item type cannot be verified as $requestedType.", blocked = true)
                    terminalResult = TaskActionResult(false, "Stopped safely: the visible liked item cannot be verified as a requested $requestedType.", summary, verified = false)
                    return@runAutonomousLoop false
                }
                if (identity in task.processedItemSignatures) {
                    AgentTaskEngine.recordAction("resolve Instagram item", "Refusing to toggle previously processed item '$identity'", false)
                    AgentTaskEngine.failCurrentStep("A previously processed item identity is still exposed as Unlike.", blocked = true)
                    terminalResult = TaskActionResult(false, "Stopped safely: the same item identity is still exposed as Unlike after an earlier verified action.", summary, verified = false)
                    return@runAutonomousLoop false
                }
                AgentTaskEngine.setState(AgentTaskEngine.State.RESOLVING_TARGET)
                val preCount = controls.size
                AgentTaskEngine.setState(AgentTaskEngine.State.ACTING)
                val dispatched = mutateUi("instagram-unlike:${identity.take(48)}") {
                    service.performClickAtRect(target.bounds)
                }
                if (!dispatched) {
                    AgentTaskEngine.recordAction("unlike:$identity", "UI action was not dispatched", false)
                    AgentTaskEngine.failCurrentStep("Could not dispatch the Unlike action.")
                    terminalResult = TaskActionResult(false, "Could not safely dispatch the Unlike action; stopped.", summary, verified = false)
                    return@runAutonomousLoop false
                }
                val itemWait = waitForUiState(signature, expectedPackage = "instagram", timeoutMs = 6_000L)
                if (!itemWait.ready) {
                    AgentTaskEngine.failCurrentStep("UI did not settle after Unlike action; item result is unverified.", blocked = true)
                    terminalResult = TaskActionResult(false, "Stopped: the Instagram list did not settle after the item action; its result is unverified.", groundingEngine.formatElementsSummary(itemWait.elements, itemWait.root), verified = false)
                    return@runAutonomousLoop false
                }
                val afterRoot = itemWait.root ?: service.getActiveRootNode()
                val afterElements = itemWait.elements
                val afterCount = afterElements.count { it.isClickable &&
                    Regex("^unlike(?:\\b|\\s)", RegexOption.IGNORE_CASE).containsMatchIn(it.primaryLabel.trim()) }
                val sameControlChangedToLike = afterElements.any { element ->
                    element.bounds.centerX().let { abs(it - target.bounds.centerX()) <= 80 } &&
                        abs(element.bounds.centerY() - target.bounds.centerY()) <= 100 &&
                        element.primaryLabel.trim().startsWith("like", true) &&
                        !element.primaryLabel.trim().startsWith("unlike", true)
                }
                val verified = afterCount < preCount || sameControlChangedToLike
                AgentTaskEngine.recordAction("unlike:$identity", "Before=Unlike; afterCount=$afterCount; toggledToLike=$sameControlChangedToLike", verified)
                if (!verified || !AgentTaskEngine.markItemProcessed(identity, true)) {
                    AgentTaskEngine.failCurrentStep("Post-action state could not be verified.", blocked = true)
                    terminalResult = TaskActionResult(false, "Stopped: the item's post-action state could not be verified, so it was not marked processed.", groundingEngine.formatElementsSummary(afterElements, afterRoot), verified = false)
                    return@runAutonomousLoop false
                }
                processedThisRun++
                task.completedSteps.add("Unlike $identity")
                if (task.pendingSteps.isNotEmpty()) task.pendingSteps.removeAt(0)
                AgentTaskEngine.updateActivity("Verified unlike for item $processedThisRun: ${identity.take(90)}", AgentTaskEngine.State.CONTINUING)
                return@runAutonomousLoop true
            }

            // No accessible Unlike action remains on this viewport. Scroll and require
            // fresh, usable observations; repeated unchanged signatures are the only end evidence.
            AgentTaskEngine.setState(AgentTaskEngine.State.ACTING)
            val scrolled = mutateUi("instagram-bulk-scroll") { service.performSmartScroll("down", "large") }
            if (!scrolled) {
                AgentTaskEngine.recordCompletionEvidence(AgentTaskEngine.CompletionEvidence.NO_PROGRESS, "Instagram did not accept a scroll gesture")
                AgentTaskEngine.failCurrentStep("Instagram did not accept a scroll gesture.", blocked = true)
                terminalResult = TaskActionResult(false, "Stopped: Instagram could not scroll the liked-items list; completion is unverified.", summary, verified = false)
                return@runAutonomousLoop false
            }
            val scrollWait = waitForUiState(signature, expectedPackage = "instagram", timeoutMs = 8_000L)
            val afterScrollRoot = scrollWait.root
            elements = scrollWait.elements
            val afterScrollSignature = scrollWait.signature
            if (!scrollWait.ready || afterScrollRoot == null || afterScrollSignature == null || afterScrollSignature.elementCount == 0) {
                AgentTaskEngine.failCurrentStep("Fresh Instagram content did not become ready after scrolling.", blocked = true)
                terminalResult = TaskActionResult(false, "Stopped: the fresh Instagram screen did not become stable after scrolling.", verified = false)
                return@runAutonomousLoop false
            }
            if (signature.isEquivalentTo(afterScrollSignature)) unchangedScrolls++ else unchangedScrolls = 0
            AgentTaskEngine.observe(afterScrollSignature, afterScrollRoot.packageName?.toString(), groundingEngine.formatElementsSummary(elements, afterScrollRoot))
            AgentTaskEngine.current()?.noProgressCount = unchangedScrolls
            if (unchangedScrolls >= 2) {
                if (processedThisRun == 0 && task.processedItemSignatures.isEmpty()) {
                    AgentTaskEngine.recordCompletionEvidence(AgentTaskEngine.CompletionEvidence.AMBIGUOUS, "Reached a stable viewport without verifying any item actions")
                    AgentTaskEngine.failCurrentStep("No item was verifiably unliked before the list stopped progressing.", blocked = true)
                    terminalResult = TaskActionResult(false, "Reached an unchanged viewport, but no item was verifiably unliked; completion is not claimed.", groundingEngine.formatElementsSummary(elements, afterScrollRoot), verified = false)
                    return@runAutonomousLoop false
                }
                val endMarkers = listOf("end of list", "no more posts", "no more reels", "you've seen all", "you have seen all", "you're all caught up", "you are all caught up", "nothing to show")
                val actualEndMarker = elements.any { element -> endMarkers.any(element.primaryLabel.lowercase(Locale.ROOT)::contains) }
                if (!actualEndMarker) {
                    AgentTaskEngine.recordCompletionEvidence(AgentTaskEngine.CompletionEvidence.NO_PROGRESS, "Repeated scroll produced no movement, but the screen exposes no explicit end-of-content marker")
                    AgentTaskEngine.failCurrentStep("Instagram stopped scrolling, but the UI did not prove the end of the liked-items list.", blocked = true)
                    terminalResult = TaskActionResult(false, "Stopped safely after repeated no-progress observations. Instagram did not expose evidence that this is the end of the full liked-items list, so I cannot claim all items were processed.", groundingEngine.formatElementsSummary(elements, afterScrollRoot), verified = false)
                    return@runAutonomousLoop false
                }
                AgentTaskEngine.recordCompletionEvidence(AgentTaskEngine.CompletionEvidence.END_REACHED, "Explicit Instagram end marker visible after two stable post-scroll observations; ${task.processedItemSignatures.size} unique item(s) were individually verified")
                AgentTaskEngine.completeStepByTitle("Observe and process matching items", "${task.processedItemSignatures.size} unique item(s) were verified individually", verified = true)
                AgentTaskEngine.completeStepByTitle("Scroll and wait for more items", "Explicit end marker visible after fresh post-scroll observations", verified = true)
                AgentTaskEngine.completeStepByTitle("Verify list end and results", "End marker and ${task.processedItemSignatures.size} verified item(s)", verified = true)
                AgentTaskEngine.finish(AgentTaskEngine.State.COMPLETED)
                terminalResult = TaskActionResult(true, "Verified Instagram's end-of-list marker after processing ${task.processedItemSignatures.size} item(s).", groundingEngine.formatElementsSummary(elements, afterScrollRoot), verified = true)
                return@runAutonomousLoop false
            }
            true
        }
        terminalResult ?: when {
            loopOutcome.cancelled -> TaskActionResult(false, "Instagram bulk unlike was cancelled after verifying $processedThisRun item(s).", verified = false)
            loopOutcome.reachedLimit -> TaskActionResult(false, "Stopped at the Instagram processing safety limit after verifying $processedThisRun item(s); the list may contain more.", groundingEngine.formatElementsSummary(groundingEngine.scanScreen(service.getActiveRootNode()), service.getActiveRootNode()), verified = false)
            else -> TaskActionResult(false, loopOutcome.error ?: "Instagram processing stopped without verified completion.", groundingEngine.formatElementsSummary(groundingEngine.scanScreen(service.getActiveRootNode()), service.getActiveRootNode()), verified = false)
        }
    }

    private fun resetScrollCount() {
        consecutiveScrollCount = 0
        lastScreenSignature = ""
        duplicateSignatureCount = 0
    }

    private suspend fun dispatchImmediateScreenFrame() {
        try {
            val snapshot = JarvisAccessibilityService.captureScreenJpeg(75)
                ?: screenCaptureManager.captureSnapshotJpeg(70)
            if (snapshot != null) {
                JarvisConversationService.sendImmediateVideoFrame(snapshot)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed dispatching immediate frame: ${e.message}")
        }
    }

    /** Waits for accessibility changes and a stable, non-loading tree; polling is bounded fallback only. */
    suspend fun waitForUiState(
        previousSignature: com.jarvis.assistant.automation.agent.ScreenSignature? = null,
        expectedPackage: String? = null,
        timeoutMs: Long = 10_000L
    ): UiWaitResult = withContext(Dispatchers.IO) {
        val service = JarvisAccessibilityService.instance
            ?: return@withContext UiWaitResult(false, null, emptyList(), null, false, "Accessibility Service is unavailable")
        val deadline = System.currentTimeMillis() + timeoutMs.coerceIn(1_000L, 20_000L)
        var lastSignature: com.jarvis.assistant.automation.agent.ScreenSignature? = null
        var stableSamples = 0
        var latestRoot: AccessibilityNodeInfo? = null
        var latestElements: List<UiElementInfo> = emptyList()
        var latestSignature: com.jarvis.assistant.automation.agent.ScreenSignature? = null
        AgentTaskEngine.updateActivity("Waiting for the app UI to settle", AgentTaskEngine.State.WAITING_FOR_UI)
        while (System.currentTimeMillis() < deadline) {
            if (AgentTaskEngine.isCancelled()) {
                return@withContext UiWaitResult(false, latestRoot, latestElements, latestSignature, false, "Task was cancelled while waiting for UI")
            }
            latestRoot = service.getActiveRootNode()
            latestElements = groundingEngine.scanScreen(latestRoot)
            latestSignature = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(latestRoot)
            val pkg = latestRoot?.packageName?.toString().orEmpty()
            val packageReady = expectedPackage.isNullOrBlank() || pkg.contains(expectedPackage, ignoreCase = true)
            val loading = latestElements.any { element ->
                val label = element.primaryLabel.lowercase(Locale.ROOT)
                listOf("loading", "buffering", "please wait", "working…", "working...").any(label::contains)
            }
            AgentTaskEngine.observe(latestSignature, pkg, groundingEngine.formatElementsSummary(latestElements, latestRoot))
            if (packageReady && !loading && latestRoot != null) {
                if (latestSignature != null && latestSignature.isEquivalentTo(lastSignature)) stableSamples++ else stableSamples = 0
                if (stableSamples >= 1) {
                    AgentTaskEngine.setState(AgentTaskEngine.State.VERIFYING)
                    return@withContext UiWaitResult(
                        true, latestRoot, latestElements, latestSignature,
                        previousSignature != null && !latestSignature.isEquivalentTo(previousSignature),
                        "UI tree stable across fresh accessibility observations"
                    )
                }
            } else {
                stableSamples = 0
            }
            lastSignature = latestSignature
            val revision = JarvisAccessibilityService.uiChanges.value.revision
            val waitedForEvent = withTimeoutOrNull(220L) {
                JarvisAccessibilityService.uiChanges.first { it.revision > revision }
                true
            } ?: false
            if (!waitedForEvent) delay(100L)
        }
        AgentTaskEngine.updateActivity("UI did not become stable before the wait deadline", AgentTaskEngine.State.RECOVERING)
        UiWaitResult(false, latestRoot, latestElements, latestSignature,
                previousSignature != null && latestSignature != null && !latestSignature.isEquivalentTo(previousSignature),
            "Timed out waiting for a stable non-loading accessibility tree")
    }

    /**
     * Executes a precise visual click on the requested UI element.
     * Snaps to the exact hardware bounding box Rect from the accessibility tree.
     */
    suspend fun handleClick(
        targetName: String,
        elementId: Int? = null,
        description: String? = null,
        isToggle: Boolean = false,
        x: Int? = null,
        y: Int? = null,
        allowChromeMenuForSettings: Boolean = false,
        forbidAddingInstagramLike: Boolean = false,
        taskGoal: String = ""
    ): TaskActionResult = withContext(Dispatchers.IO) {
        if (taskGoal.isNotBlank()) AgentTaskEngine.begin(taskGoal)
        AgentTaskEngine.setState(AgentTaskEngine.State.OBSERVING)
        resetScrollCount()
        val service = JarvisAccessibilityService.instance
        if (service == null) {
            return@withContext TaskActionResult(
                success = false,
                message = "Accessibility Service is not enabled. Please enable it in Settings."
            )
        }

        // Apply the same sensitive-action gate to visual taps as named/accessibility taps.
        if (isSensitiveTarget(targetName, description)) {
            return@withContext TaskActionResult(
                success = false,
                message = "Sensitive action detected ('$targetName'). Please ask the user for explicit confirmation before proceeding.",
                requiresUserConfirmation = true
            )
        }

        // A stale or confused model must not send an email just because it found a
        // button labelled Send. Require the active user task to explicitly request it.
        val initialRoot = service.getActiveRootNode()
        val initialPackage = initialRoot?.packageName?.toString().orEmpty().lowercase(Locale.ROOT)
        val normalizedTarget = targetName.lowercase(Locale.ROOT).trim()
        val isGmailSend = initialPackage.contains("com.google.android.gm") &&
            (normalizedTarget == "send" || normalizedTarget == "send email" || normalizedTarget == "send message")
        if (isGmailSend) {
            val goal = taskGoal.lowercase(Locale.ROOT)
            val explicitEmailRequest = (goal.contains("email") || goal.contains("gmail")) &&
                (goal.contains("send") || goal.contains("email this") || goal.contains("mail this"))
            if (!explicitEmailRequest) {
                return@withContext TaskActionResult(
                    success = false,
                    message = "Blocked Gmail Send: the active user request did not explicitly ask to send an email. No message was sent.",
                    currentStateSummary = captureCurrentStateSummary(service),
                    verified = false
                )
            }
            val gmailElements = groundingEngine.scanScreen(initialRoot)
            if (gmailElements.any { it.primaryLabel.contains("add at least one recipient", ignoreCase = true) }) {
                return@withContext TaskActionResult(
                    success = false,
                    message = "Blocked Gmail Send because Gmail says no recipient is present. Add and verify the intended recipient first.",
                    currentStateSummary = groundingEngine.formatElementsSummary(gmailElements, initialRoot),
                    verified = false
                )
            }
        }

        // CLICK DEBOUNCE / RATE LIMITER: Prevent rapid machine-gun tapping
        val now = System.currentTimeMillis()
        val timeSinceLast = now - lastClickTimestamp
        if (timeSinceLast < 280L) {
            delay(280L - timeSinceLast)
        }

        // DIRECT VISUAL COORDINATE TAP (100% Precision Vision Mode):
        // When Screen Share is active, Gemini can pass normalized coordinates (0-1000)
        // to directly tap any visual button, icon, or element with physical precision!
        if (x != null && y != null && x in 0..1000 && y in 0..1000 && screenCaptureManager.isSharing.value) {
            val dm = DisplayMetrics()
            val windowManager = service.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            @Suppress("DEPRECATION")
            windowManager?.defaultDisplay?.getRealMetrics(dm)
            if (dm.widthPixels <= 0 || dm.heightPixels <= 0) {
                dm.setTo(service.resources.displayMetrics)
            }
            var physicalX = (x / 1000f) * dm.widthPixels
            var physicalY = (y / 1000f) * dm.heightPixels

            val rootBeforeVisualTap = service.getActiveRootNode()
            val elementsBeforeVisualTap = groundingEngine.scanScreen(rootBeforeVisualTap)
            val hitElement = elementsBeforeVisualTap
                .filter { it.isClickable && it.bounds.contains(physicalX.toInt(), physicalY.toInt()) }
                .minByOrNull { it.bounds.width().toLong() * it.bounds.height().toLong() }
            if (hitElement != null && hitElement.hasTextOrDesc) {
                val targetWords = targetName.lowercase(Locale.ROOT)
                    .replace("\\b(icon|button|item|the|on|screen)\\b".toRegex(), " ")
                    .split(Regex("[^a-z0-9]+"))
                    .filter { it.length >= 3 }
                val hitLabel = hitElement.primaryLabel.lowercase(Locale.ROOT)
                val labelAgrees = targetWords.isEmpty() || targetWords.any { hitLabel.contains(it) } ||
                    targetName.lowercase(Locale.ROOT).contains(hitLabel)
                if (!labelAgrees) {
                    return@withContext TaskActionResult(
                        success = false,
                        message = "The screen point lands on '${hitElement.primaryLabel}', which does not match '$targetName'. No tap was made.",
                        currentStateSummary = captureCurrentStateSummary(service)
                    )
                }
                // Snap to the current clickable target's accessibility bounds rather than the model's estimated point.
                physicalX = hitElement.bounds.exactCenterX()
                physicalY = hitElement.bounds.exactCenterY()
            }

            val rootPkg = service.getActiveRootNode()?.packageName?.toString() ?: ""
            val isBrowser = rootPkg.contains("chrome", ignoreCase = true) || rootPkg.contains("browser", ignoreCase = true)
            val targetLower = targetName.lowercase(Locale.ROOT)

            if (isBrowser) {
                // Block accidental tap on Chrome 3-dots menu button (top right: x >= 850 && y <= 150)
                if (x >= 850 && y <= 150) {
                    Log.w(TAG, "Blocked accidental tap on Chrome 3-dots menu button at ($x, $y)")
                    return@withContext TaskActionResult(
                        success = false,
                        message = "Refusing to click Chrome 3-dots browser menu. Stay on the web creation page."
                    )
                }
                // Block accidental clicks on settings tags in Google Flow (e.g. Video • 720p • 8s • x1)
                val isSubmit = targetLower.contains("generate") || targetLower.contains("submit") ||
                        targetLower.contains("arrow") || targetLower.contains("create") || targetLower.contains("enter") || targetLower.contains("send")
                if (!isSubmit && (targetLower.contains("video") || targetLower.contains("720p") || targetLower.contains("8s") || targetLower.contains("x1") || targetLower.contains("frames") || targetLower.contains("omni") || targetLower.contains("ingredients"))) {
                    Log.w(TAG, "Blocked accidental tap on Google Flow settings chip: '$targetName' at ($x, $y)")
                    return@withContext TaskActionResult(
                        success = false,
                        message = "Refusing to click video settings chip. The prompt is ready; click the Generate arrow [→] on the right to start."
                    )
                }
            }

            // Suppress rapid duplicate clicks on identical coordinates within 1.8s
            if (Math.abs(physicalX - lastClickPhysicalX) < 30f && Math.abs(physicalY - lastClickPhysicalY) < 30f && (now - lastClickTimestamp) < 1800L) {
                Log.w(TAG, "Suppressed rapid duplicate click at ($physicalX, $physicalY)")
                return@withContext TaskActionResult(true, "Already tapped at this location. Waiting for UI update.")
            }

            val isSubmitIntent = targetLower.contains("generate") || targetLower.contains("submit") ||
                    targetLower.contains("arrow") || targetLower.contains("create") || targetLower.contains("enter") || targetLower.contains("send")

            // Snap to exact Google Flow arrow button if target is submit/generate or coordinates are in the bottom-right action bar
            // Only in a browser, and NEVER while the keyboard is open (the fixed spot is then the keyboard's Enter key).
            if ((isSubmitIntent || (x >= 800 && y >= 880)) && !service.isKeyboardVisible()) {
                if (isBrowser) {
                    val wm = service.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                    val realDm = DisplayMetrics()
                    @Suppress("DEPRECATION")
                    wm?.defaultDisplay?.getRealMetrics(realDm) ?: run {
                        realDm.widthPixels = dm.widthPixels
                        realDm.heightPixels = 2408
                    }
                    val exactArrowX = realDm.widthPixels * 0.9333f // Exactly 1008 on 1080p
                    val exactArrowY = realDm.heightPixels * 0.9440f // Exactly 2273 on 2408p
                    Log.i(TAG, "Snapping Generate/Submit arrow click from ($physicalX, $physicalY) -> exact button center ($exactArrowX, $exactArrowY)")
                    physicalX = exactArrowX
                    physicalY = exactArrowY
                }
            }

            lastClickTimestamp = System.currentTimeMillis()
            lastClickPhysicalX = physicalX
            lastClickPhysicalY = physicalY

            Log.i(TAG, "Direct visual tap at normalized ($x, $y) -> physical ($physicalX, $physicalY)")
            val preTapSignature = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(rootBeforeVisualTap)
            AgentTaskEngine.setState(AgentTaskEngine.State.ACTING)
            val clicked = mutateUi("visual-click:$targetName") { service.clickAt(physicalX, physicalY) }
            val tapDelay = if (isBrowser) 800L else 400L
            delay(tapDelay)
            dispatchImmediateScreenFrame()
            val rootAfterVisualTap = service.getActiveRootNode()
            val elementsAfterVisualTap = groundingEngine.scanScreen(rootAfterVisualTap)
            val postTapSignature = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(rootAfterVisualTap)
            val verified = !postTapSignature.isEquivalentTo(preTapSignature)
            return@withContext TaskActionResult(
                success = clicked,
                message = if (!clicked) {
                    "Tap could not be dispatched for '$targetName'. No action was completed."
                } else if (verified) {
                    "Tapped '$targetName' and observed a screen change, but the requested result is not semantically verified. Inspect the fresh screen before continuing."
                } else {
                    "Tap was dispatched for '$targetName', but a screen change was not detected. Do not claim it succeeded; inspect the screen before deciding what to do next."
                },
                currentStateSummary = groundingEngine.formatElementsSummary(elementsAfterVisualTap, rootAfterVisualTap),
                verified = false
            )
        }
        // Anti-Clear-Search Guard: prevent AI from reflexively clicking "Clear search" in the middle of a search task
        if (isClearSearchButton(targetName, description)) {
            return@withContext TaskActionResult(
                success = false,
                message = "Refusing to click '$targetName'. Do not clear or erase the search input! Instead, click a matching result/folder from the list below, or submit.",
                currentStateSummary = captureCurrentStateSummary(service)
            )
        }

        // GOOGLE FLOW / VIDEO SETTINGS PANEL GUARD:
        // Block clicks on video quality, duration, multiplier, and settings-panel elements.
        // These are NEVER valid targets during content creation — the user wants to type a prompt!
        val settingsBlocklistExact = setOf(
            "16:9", "9:16", "360p", "480p", "720p", "1080p",
            "4s", "6s", "8s", "10s", "12s", "15s",
            "x1", "x2", "x3", "x4", "x5",
            "frames", "ingredients", "omni 1.1 flash", "omni", "veo 2"
        )
        val rawTargetLower = targetName.trim().lowercase()
        if (settingsBlocklistExact.contains(rawTargetLower) ||
            // Also block if it's ONLY a number+unit pattern like "8s" "720p" "x2"
            rawTargetLower.matches(Regex("\\d+[sp]|x\\d+|\\d+[sS]ec?"))) {
            return@withContext TaskActionResult(
                success = false,
                message = "BLOCKED: '$targetName' is a Google Flow video settings control (quality/duration/multiplier). Do NOT click these. The ONLY thing you should do is: call type_text(text='<your prompt>', target_input_name='What do you want to create') to type the video description into the prompt box. THEN call inspect_screen() to find the arrow/generate button ID and click it.",
                currentStateSummary = captureCurrentStateSummary(service)
            )
        }


        // Anti-Search-Loop on Web Search Pages: prevent model from re-tapping search bar when results are visible
        if (isBrowserSearchScreen(service) && (targetName.equals("search", ignoreCase = true) || targetName.contains("search bar", ignoreCase = true) || targetName.contains("url_bar", ignoreCase = true))) {
            val root = service.getActiveRootNode()
            val elements = groundingEngine.scanScreen(root)
            val resultLinks = elements.filter { it.isClickable && !it.isEditable && it.bounds.top > 250 && it.text.isNotBlank() }
            if (resultLinks.isNotEmpty()) {
                val bestLink = resultLinks.first()
                Log.i(TAG, "Re-routing search bar click on search results page to top result link: '${bestLink.primaryLabel}'")
                val clicked = mutateUi("click-search-result") { service.performClickAtRect(bestLink.bounds) }
                delay(700)
                dispatchImmediateScreenFrame()
                val rootAfter = service.getActiveRootNode()
                val elementsAfter = groundingEngine.scanScreen(rootAfter)
                return@withContext TaskActionResult(
                    success = clicked,
                    message = "Navigating to website: automatically clicked search result link '${bestLink.primaryLabel}'. Wait for page to load and locate generation prompt input.",
                    currentStateSummary = groundingEngine.formatElementsSummary(elementsAfter, rootAfter)
                )
            }
        }

        val rootBefore = service.getActiveRootNode()
        val elementsBefore = groundingEngine.scanScreen(rootBefore)
        val preTapSignature = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(rootBefore)
        val repeatedTarget = targetName.lowercase(Locale.ROOT).trim()
        if (repeatedTarget.isNotBlank() && repeatedTarget == lastUnverifiedClickTarget &&
            lastUnverifiedClickScreen?.isEquivalentTo(preTapSignature) == true) {
            return@withContext TaskActionResult(
                success = false,
                message = "Refusing to repeat '$targetName': the previous tap did not change this screen. No second tap was made; inspect the current screen or choose a different target.",
                currentStateSummary = groundingEngine.formatElementsSummary(elementsBefore, rootBefore),
                verified = false
            )
        }
        val onInstagram = rootBefore?.packageName?.toString()?.contains("instagram", ignoreCase = true) == true
        val asksToLike = Regex("\\blike\\b", RegexOption.IGNORE_CASE).containsMatchIn("$targetName ${description.orEmpty()}") &&
            !"$targetName ${description.orEmpty()}".contains("unlike", ignoreCase = true)
        if (forbidAddingInstagramLike && onInstagram && asksToLike) {
            return@withContext TaskActionResult(
                success = false,
                message = "Blocked a Like action during an Instagram bulk unlike task. Use the Likes screen's Select mode and its Unlike action; do not open a Reel or add likes.",
                currentStateSummary = groundingEngine.formatElementsSummary(elementsBefore, rootBefore),
                verified = false
            )
        }
        val isFlowScreen = groundingEngine.isGoogleFlowSurface(elementsBefore)

        val initialTarget = groundingEngine.findTargetElement(
            elements = elementsBefore,
            targetName = targetName,
            isToggleIntent = isToggle || isTogglePhrase(targetName) || isTogglePhrase(description ?: ""),
            elementId = elementId
        )

        // Search-Result Loop Guard:
        // If on a browser search page and the target resolved was an editable search bar,
        // NEVER re-tap the search bar when search result links are visible below!
        val target = if (isBrowserSearchScreen(service) && (initialTarget?.isEditable == true || initialTarget?.viewId?.contains("search", ignoreCase = true) == true || initialTarget?.viewId?.contains("url_bar", ignoreCase = true) == true) && elementId == null) {
            val resultLinks = elementsBefore.filter { !it.isEditable && it.bounds.top > 250 && (it.isClickable || it.bounds.top > 280) && (it.text.isNotBlank() || it.contentDescription.isNotBlank()) }
            if (resultLinks.isNotEmpty()) {
                val qTokens = targetName.lowercase(Locale.ROOT).split("\\s+".toRegex()).filter { it.length > 2 }
                val bestResult = resultLinks.filter { el ->
                    qTokens.any { t -> el.primaryLabel.lowercase(Locale.ROOT).contains(t) }
                }.firstOrNull() ?: resultLinks.first()
                Log.i(TAG, "Prevented search bar re-tap: re-routing target from search bar to search result '${bestResult.primaryLabel}' (id=${bestResult.id})")
                bestResult
            } else {
                initialTarget
            }
        } else {
            initialTarget
        }

        // Chrome's native Settings page is reached through its overflow menu. Treat
        // that menu tap as a navigation step for an explicit Settings request, then
        // reacquire the tree and resolve Settings afresh before tapping it.
        val isChrome = (rootBefore?.packageName?.toString() ?: "").contains("chrome", ignoreCase = true)
        if ((target == null || isBrowserOverflowMenu(target)) && isChrome && targetName.contains("settings", ignoreCase = true)) {
            val menuTarget = groundingEngine.findTargetElement(elementsBefore, "More options")
                ?: groundingEngine.findTargetElement(elementsBefore, "Customize and control Chrome")
            if (menuTarget == null || !mutateUi("open-chrome-menu") { service.performClickAtRect(menuTarget.bounds) }) {
                return@withContext TaskActionResult(
                    success = false,
                    message = "Chrome's Settings menu button was not found; no tap was made.",
                    currentStateSummary = groundingEngine.formatElementsSummary(elementsBefore, rootBefore),
                    verified = false
                )
            }
            delay(350)
            val menuRoot = service.getActiveRootNode()
            val menuElements = groundingEngine.scanScreen(menuRoot)
            val settingsTarget = groundingEngine.findTargetElement(menuElements, "Settings")
            if (settingsTarget == null) {
                return@withContext TaskActionResult(
                    success = false,
                    message = "Opened Chrome's menu, but its Settings item is not visible. Inspect the fresh screen before continuing.",
                    currentStateSummary = groundingEngine.formatElementsSummary(menuElements, menuRoot),
                    verified = false
                )
            }
            val beforeSettings = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(menuRoot)
            if (!mutateUi("open-chrome-settings") { service.performClickAtRect(settingsTarget.bounds) }) {
                return@withContext TaskActionResult(false, "Could not tap Chrome Settings.", groundingEngine.formatElementsSummary(menuElements, menuRoot), verified = false)
            }
            delay(700)
            val settingsRoot = service.getActiveRootNode()
            val settingsElements = groundingEngine.scanScreen(settingsRoot)
            val afterSettings = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(settingsRoot)
            val verified = settingsRoot != null && settingsRoot.packageName?.toString()?.contains("chrome", ignoreCase = true) == true &&
                !afterSettings.isEquivalentTo(beforeSettings) &&
                settingsElements.any { it.primaryLabel.contains("settings", ignoreCase = true) || it.viewId.contains("settings", ignoreCase = true) }
            return@withContext TaskActionResult(
                success = verified,
                message = if (verified) "Chrome Settings opened and screen change verified." else "Tapped Chrome Settings, but could not verify the Settings screen. Inspect the current screen.",
                currentStateSummary = groundingEngine.formatElementsSummary(settingsElements, settingsRoot),
                verified = verified
            )
        }

        if (target == null) {
            if (isFlowScreen) {
                return@withContext TaskActionResult(
                    success = false,
                    message = "Could not find '$targetName' as an actionable control on Google Flow. No tap or scroll was made; inspect the current screen and choose a visible Flow control.",
                    currentStateSummary = captureCurrentStateSummary(service),
                    verified = false
                )
            }
            // Continue searching across screens until the target appears, the screen
            // stops changing repeatedly, or the bounded safety ceiling is reached.
            Log.d(TAG, "Target '$targetName' not visible on current screen. Running auto-scroll search...")
            var foundTarget: UiElementInfo? = null
            var prevSig: com.jarvis.assistant.automation.agent.ScreenSignature? = null
            var noProgressCount = 0

            for (scrollStep in 1..20) {
                AgentTaskEngine.setState(AgentTaskEngine.State.ACTING)
                val scrolled = mutateUi("auto-scroll-search:$targetName") { service.performSmartScroll("down", "medium") }
                AgentTaskEngine.current()?.scrollCount = (AgentTaskEngine.current()?.scrollCount ?: 0) + 1
                if (AgentTaskEngine.isCancelled()) break
                if (!scrolled) break
                delay(600)
                val rootAfterScroll = service.getActiveRootNode()
                val currentSig = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(rootAfterScroll)
                if (prevSig != null && currentSig.isEquivalentTo(prevSig)) {
                    noProgressCount++
                    if (noProgressCount >= 3) {
                        Log.i(TAG, "Stopping target search after $noProgressCount consecutive unchanged screen signatures.")
                        break
                    }
                } else {
                    noProgressCount = 0
                }
                prevSig = currentSig

                val elementsAfterScroll = groundingEngine.scanScreen(rootAfterScroll)
                val targetAfterScroll = groundingEngine.findTargetElement(
                    elements = elementsAfterScroll,
                    targetName = targetName,
                    isToggleIntent = isToggle,
                    elementId = elementId
                )
                if (targetAfterScroll != null) {
                    foundTarget = targetAfterScroll
                    Log.i(TAG, "Found target '$targetName' after $scrollStep scroll(s)!")
                    break
                }
            }

            if (foundTarget != null) {
                AgentTaskEngine.setState(AgentTaskEngine.State.ACTING)
                val clicked = mutateUi("click-after-scroll:$targetName") { service.performClickAtRect(foundTarget.bounds) }
                delay(300)
                dispatchImmediateScreenFrame()
                return@withContext TaskActionResult(
                    success = clicked,
                    message = if (clicked) "Tap was dispatched for '$targetName' after scrolling. Inspect the updated screen before claiming success or taking the next action."
                        else "Could not dispatch a tap for '$targetName' after scrolling.",
                    currentStateSummary = captureCurrentStateSummary(service),
                    verified = false
                )
            }

            val (pkg, title) = groundingEngine.extractScreenContext(rootBefore, elementsBefore)
            return@withContext TaskActionResult(
                success = false,
                message = "Could not find element '$targetName' on current screen ('$title' in $pkg). Check screen title or navigate to the correct section.",
                currentStateSummary = captureCurrentStateSummary(service)
            )
        }

        val rootPkg = rootBefore?.packageName?.toString() ?: ""
        val isBrowserApp = rootPkg.contains("chrome", ignoreCase = true) || rootPkg.contains("browser", ignoreCase = true)
        val isExplicitMenuRequest = targetName.lowercase(Locale.ROOT).contains("menu") ||
            targetName.lowercase(Locale.ROOT).contains("more options") ||
            (description ?: "").lowercase(Locale.ROOT).contains("menu") ||
            (allowChromeMenuForSettings && isBrowserApp)

        if (isBrowserApp && !isExplicitMenuRequest && isBrowserOverflowMenu(target)) {
            Log.w(TAG, "Blocked clicking browser overflow menu ('More options' / 3 dots). Target: ${target.primaryLabel}")
            return@withContext TaskActionResult(
                success = false,
                message = "Refusing to click Chrome's browser menu ('More options' / three dots). Please interact directly with the website content, search results, or prompt input instead of the browser menu.",
                currentStateSummary = captureCurrentStateSummary(service)
            )
        }

        val initialCheckedState = target.isChecked
        AgentTaskEngine.setState(AgentTaskEngine.State.ACTING)
        val clickOk = mutateUi("click:${target.primaryLabel}") { service.performClickAtRect(target.bounds) }

        if (!clickOk) {
            return@withContext TaskActionResult(
                success = false,
                message = "Failed to tap coordinates for '${target.primaryLabel}'.",
                currentStateSummary = captureCurrentStateSummary(service)
            )
        }

        // Closed-loop verification: wait for UI transition (adaptive delay for browser/network links)
        val isWebOrLink = target.isClickable && (target.primaryLabel.contains("http", ignoreCase = true) ||
                target.primaryLabel.contains(".com", ignoreCase = true) ||
                target.primaryLabel.contains("www.", ignoreCase = true) ||
                target.primaryLabel.contains("search", ignoreCase = true) ||
                target.primaryLabel.contains("flow", ignoreCase = true))
        // Watch the screen patiently like a human (animations and page loads take time) and NEVER re-tap
        // automatically: menus, drawers, dropdowns and play/pause all TOGGLE, so a second tap undoes the first.
        val maxWatchMs = if (isWebOrLink) 12_000L else 8_000L
        dispatchImmediateScreenFrame()
        val preSig = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(rootBefore)
        val waitStartedAt = System.currentTimeMillis()
        val uiWait = waitForUiState(preSig, expectedPackage = rootPkg, timeoutMs = maxWatchMs)
        var rootAfter = uiWait.root ?: service.getActiveRootNode()
        var elementsAfter = uiWait.elements.ifEmpty { groundingEngine.scanScreen(rootAfter) }
        val postSig = uiWait.signature ?: com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(rootAfter)
        val stateChanged = !postSig.isEquivalentTo(preSig)
        val watchedMs = System.currentTimeMillis() - waitStartedAt

        // Verify if toggle state changed
        var toggleVerified = false
        if (target.isSwitchOrToggle()) {
            val updatedTarget = elementsAfter.firstOrNull { it.bounds == target.bounds || it.id == target.id }
            val nowChecked = updatedTarget?.isChecked
            toggleVerified = (nowChecked != initialCheckedState)
            Log.i(TAG, "Toggle verified: was=$initialCheckedState, now=$nowChecked, changed=$toggleVerified")
        }

        // (Removed the automatic second tap: it undid toggles such as menus/drawers and reported "verified".)
        if (!stateChanged && !target.isSwitchOrToggle()) {
            Log.w(TAG, "No UI state transition after ${watchedMs}ms for '${target.primaryLabel}'. NOT re-tapping (a second tap could undo a toggle).")
            lastUnverifiedClickTarget = repeatedTarget
            lastUnverifiedClickScreen = postSig
        } else {
            lastUnverifiedClickTarget = ""
            lastUnverifiedClickScreen = null
        }

        val recentOtp = JarvisAccessibilityService.getRecentOtp()
        val otpNotice = if (recentOtp != null) "\n[SYSTEM NOTICE: Detected incoming SMS/Notification OTP: '$recentOtp' (available for auto-entry)]" else ""
        val clickedLabelLower = target.primaryLabel.lowercase(Locale.ROOT)
        val isInstallOrDownload = clickedLabelLower == "install" || clickedLabelLower.contains("install") || clickedLabelLower == "download" || clickedLabelLower.contains("download")
        val isPlayStore = rootPkg.contains("vending", ignoreCase = true)

        val normalizedGoal = taskGoal.lowercase(Locale.ROOT)
        val targetLabel = target.primaryLabel.lowercase(Locale.ROOT)
        val visibleTargetLabels = elementsAfter.filterNot { it.isEditable }
            .map { it.primaryLabel.lowercase(Locale.ROOT) }
        val playbackExpected = listOf("play", "play it", "play karo", "bajao").any(normalizedGoal::contains)
        val requestedTrackTokens = normalizedGoal.split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 3 }
            .filterNot { it in setOf("please", "spotify", "youtube", "playlist", "meri", "mera", "par", "mein", "song", "track", "find", "search", "play", "karo", "kar", "do", "dhundo", "dhoondh", "aur", "the", "for", "and", "with") }
        val playbackVerified = playbackExpected && requestedTrackTokens.isNotEmpty() &&
            requestedTrackTokens.all(targetLabel::contains) &&
            visibleTargetLabels.any { it.contains(targetLabel) } &&
            visibleTargetLabels.any { it.contains("pause") || it.contains("now playing") || it.contains("currently playing") }
        val intendedResultVerified = toggleVerified || playbackVerified
        val returnMessage = if (isPlayStore && isInstallOrDownload) {
            "Tapped Install on Google Play Store. The app is downloading and installing. NEXT ACTION: Wait for installation to complete and inspect screen for the 'Open' button, then tap 'Open' to launch and set up the app. DO NOT stop the task!"
        } else if (toggleVerified) {
            "Clicked '${target.primaryLabel}' and verified its checked state changed."
        } else if (playbackVerified) {
            "Clicked '${target.primaryLabel}'; the requested track is visible and the player exposes an active playback state."
        } else if (stateChanged) {
            "Clicked '${target.primaryLabel}' and observed a UI change, but the requested result is unverified. Inspect the fresh screen before claiming success or taking a dependent action."
        } else {
            "Tapped '${target.primaryLabel}' once, but no screen change appeared after ${watchedMs / 1000.0}s. Do NOT tap it again blindly (it may be a toggle that already worked): call inspect_screen and look at the screen first."
        }

        val summary = groundingEngine.formatElementsSummary(elementsAfter, rootAfter) + otpNotice
        recordObservation(service, summary)
        AgentTaskEngine.recordAction("click:${target.primaryLabel}", returnMessage, intendedResultVerified)
        AgentTaskEngine.setState(if (intendedResultVerified) AgentTaskEngine.State.CONTINUING else AgentTaskEngine.State.RECOVERING)
        return@withContext TaskActionResult(
            success = stateChanged || toggleVerified,
            message = returnMessage,
            currentStateSummary = summary,
            verified = intendedResultVerified
        )
    }

    /**
     * Types text into a search bar or input field with zero typos.
     */
    suspend fun handleType(
        text: String,
        targetInputName: String? = null,
        submit: Boolean = false,
        x: Int? = null,
        y: Int? = null
    ): TaskActionResult = withContext(Dispatchers.IO) {
        resetScrollCount()
        val service = JarvisAccessibilityService.instance
        if (service == null) {
            return@withContext TaskActionResult(false, "Accessibility Service is not running.")
        }

        // Resolve target input element
        var targetRect: Rect? = null
        val rootForTyping = service.getAppRootNode() ?: service.getActiveRootNode()
        val elementsForTyping = if (rootForTyping != null) groundingEngine.scanScreen(rootForTyping) else emptyList()
        val visibleUiText = elementsForTyping.joinToString(" ") {
            "${it.text} ${it.contentDescription} ${it.viewId}"
        }.lowercase(Locale.ROOT)
        val browserPackage = (rootForTyping?.packageName?.toString() ?: "").let {
            it.contains("chrome", ignoreCase = true) || it.contains("browser", ignoreCase = true)
        }
        val isGoogleFlowPage = groundingEngine.isGoogleFlowSurface(elementsForTyping) ||
            visibleUiText.contains("flow.google") || visibleUiText.contains("labs.google/fx/tools/flow")
        val isGoogleAiStudioPage = visibleUiText.contains("aistudio.google") || visibleUiText.contains("google ai studio")
        val flowSettingsLabels = listOf("720p", "360p", "ingredients", "frames", "omni 1.1", "4s", "8s", "10s")
        val flowSettingsOverlayVisible = isGoogleFlowPage &&
            flowSettingsLabels.count { visibleUiText.contains(it) } >= 5 &&
            visibleUiText.contains("frames") && visibleUiText.contains("ingredients")

        // Flow's expanded generation settings sheet covers the composer. Dismiss it and
        // force a fresh screen read before typing so stale coordinates cannot hit a setting.
        if (flowSettingsOverlayVisible) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            delay(450)
            dispatchImmediateScreenFrame()
            val refreshed = inspectScreen(waitForContent = true)
            return@withContext TaskActionResult(
                success = false,
                message = "Google Flow's settings panel was open, so no text was typed. I closed the panel; inspect the refreshed screen and target the prompt field before retrying.",
                currentStateSummary = refreshed,
                verified = false
            )
        }

        // PREFER the input's REAL accessibility bounds over model-estimated coordinates.
        // (The model was copying example numbers like x=500,y=895 instead of reading the screen.)
        val realInputRect: Rect? = try {
            val found = if (isGoogleFlowPage || isGoogleAiStudioPage) {
                elementsForTyping.firstOrNull { element ->
                    val label = element.primaryLabel.lowercase(Locale.ROOT)
                    !element.viewId.contains("url_bar", ignoreCase = true) &&
                        !element.viewId.contains("omnibox", ignoreCase = true) &&
                        (label.contains("what do you want to create") || label.contains("ask gemini") ||
                            label.contains("enter a prompt") || label.contains("write a prompt") ||
                            ((label.contains("prompt") || label.contains("describe")) &&
                                (element.isEditable || element.className.contains("EditText", ignoreCase = true))))
                }
            } else if (!targetInputName.isNullOrBlank()) {
                val editable = elementsForTyping.filter {
                    (it.isEditable || it.className.contains("EditText", ignoreCase = true)) &&
                        !it.viewId.contains("url_bar", ignoreCase = true) &&
                        !it.viewId.contains("omnibox", ignoreCase = true)
                }
                val requested = targetInputName.lowercase(Locale.ROOT).trim()
                val requestTokens = requested.split(Regex("[^\\p{L}\\p{N}]+"))
                    .filter { it.length >= 2 }
                val matchingEditable = editable.filter { element ->
                    val labelTokens = "${element.primaryLabel} ${element.viewId}"
                        .lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+"))
                    (requestTokens.isNotEmpty() && requestTokens.all { it in labelTokens }) ||
                        "${element.primaryLabel} ${element.viewId}".equals(targetInputName, ignoreCase = true)
                }
                when {
                    matchingEditable.size == 1 -> matchingEditable.single()
                    matchingEditable.size > 1 -> null
                    editable.size == 1 -> editable.single()
                    else -> {
                        val anchor = groundingEngine.findTargetElement(elementsForTyping, targetInputName)
                        val nearby = anchor?.let { label ->
                            editable.filter { abs(it.bounds.centerY() - label.bounds.centerY()) <= 180 }
                                .minByOrNull { abs(it.bounds.centerY() - label.bounds.centerY()) }
                        }
                        nearby
                    }
                }
            } else null
            found?.takeIf {
                (it.isEditable || it.className.contains("EditText", ignoreCase = true)) &&
                    !it.viewId.contains("url_bar", ignoreCase = true) &&
                    !it.viewId.contains("omnibox", ignoreCase = true)
            }?.bounds
        } catch (e: Exception) {
            null
        }

        // A fresh frame can take a moment after Android grants MediaProjection; wait briefly
        // before reporting that visual targeting is unavailable.
        if (isGoogleFlowPage && screenCaptureManager.isScreenShareActive() && !screenCaptureManager.hasRecentFrame()) {
            for (attempt in 0 until 20) {
                if (screenCaptureManager.hasRecentFrame()) break
                delay(100L)
            }
        }

        // DIRECT VISUAL COORDINATE FOCUS (fallback only when the real input could not be resolved):
        if (realInputRect != null) {
            targetRect = realInputRect
            Log.i(TAG, "Using real input bounds $realInputRect (ignoring model coordinates x=$x y=$y)")
        } else if (x != null && y != null && x in 0..1000 && y in 0..1000 &&
            (!(isGoogleFlowPage || isGoogleAiStudioPage) || screenCaptureManager.hasRecentFrame())) {
            val dm = service.resources.displayMetrics
            val physicalX = (x / 1000f) * dm.widthPixels
            val physicalY = (y / 1000f) * dm.heightPixels
            targetRect = Rect((physicalX - 40).toInt(), (physicalY - 30).toInt(), (physicalX + 40).toInt(), (physicalY + 30).toInt())
            Log.i(TAG, "Direct visual focus at normalized ($x, $y) -> targetRect $targetRect")
        } else if (isGoogleFlowPage || isGoogleAiStudioPage) {
            val product = if (isGoogleAiStudioPage) "Google AI Studio" else "Google Flow"
            val reason = if (!screenCaptureManager.hasRecentFrame()) {
                if (screenCaptureManager.isScreenShareActive()) {
                    "$product's prompt field is not exposed to accessibility. Screen Share is enabled, but Android has not delivered a fresh frame yet; wait for the preview to update and retry once."
                } else {
                    "$product's prompt field is not exposed to accessibility and no visual frame is available. Enable Screen Share once, then JARVIS can target the visible prompt field."
                }
            } else {
                "$product's prompt field could not be identified from the current frame. Keep the editor/composer visible and inspect the screen before retrying."
            }
            return@withContext TaskActionResult(false, reason, groundingEngine.formatElementsSummary(elementsForTyping, rootForTyping), verified = false)
        } else {
            val elements = elementsForTyping

            if (!targetInputName.isNullOrBlank()) {
                val editable = elements.filter {
                    (it.isEditable || it.className.contains("EditText", ignoreCase = true)) &&
                        !it.viewId.contains("url_bar", ignoreCase = true) &&
                        !it.viewId.contains("omnibox", ignoreCase = true)
                }
                val requestedTokens = targetInputName.lowercase(Locale.ROOT)
                    .split(Regex("[^\\p{L}\\p{N}]+"))
                    .filter { it.length >= 2 }
                if (editable.isEmpty()) {
                    return@withContext TaskActionResult(
                        success = false,
                        message = "The named input '$targetInputName' is not exposed as an editable field. No text was entered.",
                        currentStateSummary = groundingEngine.formatElementsSummary(elements, rootForTyping),
                        verified = false
                    )
                }
                if (editable.size > 1 && editable.none { element ->
                        val label = "${element.primaryLabel} ${element.viewId}".lowercase(Locale.ROOT)
                        label.contains(targetInputName.lowercase(Locale.ROOT))
                    }) {
                    val anchor = groundingEngine.findTargetElement(elements, targetInputName)
                    val nearby = anchor?.let { label ->
                        editable.filter { abs(it.bounds.centerY() - label.bounds.centerY()) <= 180 }
                            .minByOrNull { abs(it.bounds.centerY() - label.bounds.centerY()) }
                    }
                    if (nearby == null) {
                        return@withContext TaskActionResult(
                            success = false,
                            message = "Could not uniquely identify the '$targetInputName' input. No text was entered; inspect the current screen and name the exact field.",
                            currentStateSummary = groundingEngine.formatElementsSummary(elements, rootForTyping),
                            verified = false
                        )
                    }
                    targetRect = nearby.bounds
                } else {
                    val named = editable.filter { element ->
                        val labelTokens = "${element.primaryLabel} ${element.viewId}"
                            .lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+"))
                        requestedTokens.isNotEmpty() && requestedTokens.all { it in labelTokens }
                    }
                    targetRect = (named.singleOrNull() ?: editable.singleOrNull())?.bounds
                    if (targetRect == null) {
                        return@withContext TaskActionResult(
                            success = false,
                            message = "Could not uniquely identify the '$targetInputName' input. No text was entered.",
                            currentStateSummary = groundingEngine.formatElementsSummary(elements, rootForTyping),
                            verified = false
                        )
                    }
                }
            } else {
                // Pick the best candidate input field (prefer web prompt placeholders or non-URL-bar inputs)
                val webPromptInput = elements.firstOrNull {
                    val label = it.primaryLabel.lowercase(Locale.ROOT)
                    (label.contains("what do you want to create") || label.contains("describe your") || label.contains("ask gemini") ||
                        (label.contains("prompt") && (it.isEditable || it.className.contains("EditText", ignoreCase = true)))) &&
                    !it.viewId.contains("url_bar", ignoreCase = true)
                }
                val nonUrlInputs = elements.filter { (it.isEditable || it.className.contains("EditText", ignoreCase = true)) && !it.viewId.contains("url_bar", ignoreCase = true) && !it.viewId.contains("omnibox", ignoreCase = true) }
                val inputElement = webPromptInput ?: nonUrlInputs.firstOrNull() ?: elements.firstOrNull { it.isEditable && !it.viewId.contains("url_bar", ignoreCase = true) && !it.viewId.contains("omnibox", ignoreCase = true) }
                targetRect = inputElement?.bounds
            }
        }

        val browserBeforeTyping = browserPackage || isGoogleFlowPage
        // In a browser, submitting is a deliberate, separate step (tap the real Generate arrow after SEEING the text).
        val composeField = targetInputName?.lowercase(Locale.ROOT)?.let { name ->
            listOf("recipient", "email", "message", "compose", "subject", "body", "to").any(name::contains)
        } == true
        AgentTaskEngine.setState(AgentTaskEngine.State.ACTING)
        val success = SerializedActionExecutor.execute(
            "type:${targetInputName ?: "focused-field"}",
            expectedGeneration = AgentTaskEngine.current()?.actionGeneration
        ) {
            service.smartTypeText(text, targetRect, submit && !browserBeforeTyping && !composeField)
        } == true
        val rootPkg = service.getActiveRootNode()?.packageName?.toString() ?: ""
        val isBrowser = browserBeforeTyping || rootPkg.contains("chrome", ignoreCase = true) || rootPkg.contains("browser", ignoreCase = true)
        val verifiedSuccess: Boolean
        val responseMessage: String
        val stateSummary: String

        // In Chrome, if smartTypeText was successful (via SET_TEXT, PASTE, or Gboard chip),
        // dismiss the soft keyboard so the page returns to full size and submit button isn't covered!
        // (Removed the unconditional GLOBAL_ACTION_BACK: when the keyboard was not open it navigated Chrome
        //  BACK out of the Flow project page. In Flow the Generate arrow stays visible above the keyboard.)
        if (success && isBrowser) {
            delay(300)
        }

        // AUTO-SUBMIT: Only if explicitly requested via submit=true
        // (Removed the blind tap at a fixed screen position for browsers: with the keyboard open it hit the
        //  keyboard Enter key instead of Generate. The model must tap the real Generate arrow it SEES.)
        if (success && submit && !isBrowser) {
            delay(120)
        }

        delay(400)
        dispatchImmediateScreenFrame()
        val rootAfter = service.getAppRootNode() ?: service.getActiveRootNode()
        val elementsAfter = if (rootAfter != null) groundingEngine.scanScreen(rootAfter) else emptyList()

        // A dispatched paste is not proof that a web prompt received the text. Require readback.
        val isVerified = if (isBrowser) {
            success && service.lastTypeVerified
        } else {
            val verification = com.jarvis.assistant.automation.agent.ActionVerifier.verifyTyping(
                service = service,
                targetRect = targetRect,
                expectedText = text
            )
            verification.isVerified
        }

        verifiedSuccess = success && isVerified
        recordObservation(service, groundingEngine.formatElementsSummary(elementsAfter, rootAfter))
        AgentTaskEngine.recordAction("type:${targetInputName ?: "input"}", if (verifiedSuccess) "field readback verified" else "field readback failed", verifiedSuccess)
        AgentTaskEngine.setState(if (verifiedSuccess) AgentTaskEngine.State.CONTINUING else AgentTaskEngine.State.RECOVERING)
        responseMessage = if (verifiedSuccess) {
            "Text entered and verified in the named input. Inspect the fresh screen; submit only by clicking the visible intended control when the user explicitly requested submission."
        } else if (success && !isVerified && isBrowser) {
            "NOT CONFIRMED: the text was sent but is NOT visible in the page input. Do NOT say it was typed and do NOT tap Generate. LOOK at the latest screen frame: if the prompt box still shows its placeholder, tap inside the prompt box ONCE, then call type_text again. If it fails twice, tell the user honestly."
        } else if (success && !isVerified) {
            "FAILED: Text input was attempted, but could NOT be verified in the input field. NEXT ACTION: Tap the input box directly to focus it, then retry."
        } else if (isBrowser) {
            "FAILED: No page input box was found (the address bar is never used). If this is the Flow homepage there is NO prompt box yet: tap '+ New project' first, wait for the editor, then call type_text."
        } else {
            "FAILED: Could not type into input field. Tap the text field first, then call type_text."
        }
        stateSummary = groundingEngine.formatElementsSummary(elementsAfter, rootAfter)

        return@withContext TaskActionResult(
            success = verifiedSuccess,
            message = responseMessage,
            currentStateSummary = stateSummary,
            verified = verifiedSuccess
        )
    }

    private fun verifyTextInTree(service: JarvisAccessibilityService, snippet: String): Boolean {
        val root = service.getAppRootNode() ?: service.getActiveRootNode()
        if (root != null && verifyTextInNode(root, snippet)) return true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            for (window in service.windows) {
                val wRoot = window.root ?: continue
                if (verifyTextInNode(wRoot, snippet)) return true
            }
        }
        return false
    }

    private fun verifyTextInNode(node: AccessibilityNodeInfo, snippet: String): Boolean {
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        if (text.contains(snippet) || desc.contains(snippet)) return true
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (verifyTextInNode(child, snippet)) return true
        }
        return false
    }

    /**
     * Performs a directional scroll with loop guard.
     */
    suspend fun handleScroll(direction: String, distance: String = "small"): TaskActionResult = withContext(Dispatchers.IO) {
        AgentTaskEngine.setState(AgentTaskEngine.State.OBSERVING)
        val service = JarvisAccessibilityService.instance
        if (service == null) {
            return@withContext TaskActionResult(false, "Accessibility Service not running.")
        }

        consecutiveScrollCount++
        if (consecutiveScrollCount > 15) {
            resetScrollCount()
            val root = service.getActiveRootNode()
            val elements = groundingEngine.scanScreen(root)
            val (pkg, title) = groundingEngine.extractScreenContext(root, elements)
            return@withContext TaskActionResult(
                success = false,
                message = "Scrolled 15 times in a row without finding target. You are currently in app '$pkg' on screen '$title'. If the item is not here, try navigating to another section or folder.",
                currentStateSummary = groundingEngine.formatElementsSummary(elements, root)
            )
        }

        AgentTaskEngine.setState(AgentTaskEngine.State.ACTING)
        val preSignature = com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(service.getActiveRootNode())
        val success = mutateUi("scroll:$direction") { service.performSmartScroll(direction, distance) }
        AgentTaskEngine.current()?.scrollCount = (AgentTaskEngine.current()?.scrollCount ?: 0) + 1
        dispatchImmediateScreenFrame()
        val uiWait = waitForUiState(preSignature, expectedPackage = service.getActiveRootNode()?.packageName?.toString(), timeoutMs = 8_000L)
        val rootAfter = uiWait.root ?: service.getActiveRootNode()
        val postSignature = uiWait.signature ?: com.jarvis.assistant.automation.agent.ScreenSignatureCalculator.computeSignature(rootAfter)
        if (postSignature.isEquivalentTo(preSignature)) {
            AgentTaskEngine.current()?.noProgressCount = (AgentTaskEngine.current()?.noProgressCount ?: 0) + 1
        } else {
            AgentTaskEngine.current()?.noProgressCount = 0
        }
        recordObservation(service)
        AgentTaskEngine.recordAction("scroll:$direction", if (success) "scroll dispatched" else "scroll not dispatched", success && !postSignature.isEquivalentTo(preSignature))
        AgentTaskEngine.setState(AgentTaskEngine.State.CONTINUING)
        val elementsAfter = groundingEngine.scanScreen(rootAfter)
        val dynamicElements = elementsAfter.filter { it.bounds.top > 350 }
        val currentSignature = if (dynamicElements.isNotEmpty()) {
            dynamicElements.takeLast(6).joinToString("|") { "${it.id}:${it.primaryLabel}@${it.bounds.top}" }
        } else {
            elementsAfter.takeLast(6).joinToString("|") { "${it.id}:${it.primaryLabel}@${it.bounds.top}" }
        }

        if (currentSignature.isNotBlank() && currentSignature == lastScreenSignature) {
            duplicateSignatureCount++
            if (duplicateSignatureCount >= 2) {
                resetScrollCount()
                val (pkg, title) = groundingEngine.extractScreenContext(rootAfter, elementsAfter)
                return@withContext TaskActionResult(
                    success = false,
                    message = "Reached end of screen in direction '$direction'. Cannot scroll further in this view. Current screen: '$title' in app '$pkg'. If looking for a photo/document, try opening another folder like 'WhatsApp Images', 'Screenshots', or 'Downloads'.",
                    currentStateSummary = groundingEngine.formatElementsSummary(elementsAfter, rootAfter)
                )
            }
        } else {
            duplicateSignatureCount = 0
        }
        lastScreenSignature = currentSignature

        return@withContext TaskActionResult(
            success = success && uiWait.ready,
            message = "Scrolled screen $direction (scroll #$consecutiveScrollCount, distance: $distance).",
            currentStateSummary = groundingEngine.formatElementsSummary(elementsAfter, rootAfter),
            verified = success && uiWait.ready && !postSignature.isEquivalentTo(preSignature)
        )
    }

    /**
     * Dispatches system navigation keys (back, home, recents).
     */
    suspend fun handleKey(key: String): TaskActionResult = withContext(Dispatchers.IO) {
        resetScrollCount()
        val service = JarvisAccessibilityService.instance
        if (service == null) {
            return@withContext TaskActionResult(false, "Accessibility Service not running.")
        }

        val success = mutateUi("navigation:$key") { service.performSystemGesture(key) }
        delay(400)
        dispatchImmediateScreenFrame()
        return@withContext TaskActionResult(
            success = success,
            message = "Pressed system key '$key'.",
            currentStateSummary = captureCurrentStateSummary(service)
        )
    }

    /**
     * Inspects the current screen state in real time and returns a detailed summary
     * of the active foreground app, screen title, and visible content/elements.
     */
    suspend fun inspectScreen(waitForContent: Boolean = false): String = withContext(Dispatchers.IO) {
        val service = JarvisAccessibilityService.instance
            ?: return@withContext "Screen context unavailable: Accessibility Service is not active."
        var root = service.getActiveRootNode()
        var elements = if (root != null) groundingEngine.scanScreen(root) else emptyList()

        if (waitForContent) {
            var attempts = 0
            while (attempts < 4 && elements.none { it.text.isNotBlank() || it.contentDescription.isNotBlank() }) {
                delay(250)
                root = service.getActiveRootNode()
                elements = if (root != null) groundingEngine.scanScreen(root) else emptyList()
                attempts++
            }
        }

        if (root == null && elements.isEmpty()) {
            return@withContext "Screen context unavailable: Screen is blank or inaccessible."
        }

        dispatchImmediateScreenFrame()
        val recentOtp = JarvisAccessibilityService.getRecentOtp()
        val otpNotice = if (recentOtp != null) "\n[SYSTEM NOTICE: Detected incoming SMS/Notification OTP: '$recentOtp' (available for auto-entry)]" else ""
        val screenSource = if (screenCaptureManager.hasRecentFrame()) {
            "[Screen share active: a recent visual frame is being streamed.]\n"
        } else {
            val flowDetected = groundingEngine.isGoogleFlowSurface(elements)
            if (flowDetected) {
                "[Google Flow detected. Current labeled controls can be used from accessibility. Screen coordinates require a fresh Screen Share frame; if the requested control has no accessible label, explain that limitation once.]\n"
            } else {
                "[Current accessibility labels are available. Use a unique labeled target for actions; image-only and unlabeled controls are unavailable.]\n"
            }
        }
        val summary = screenSource + groundingEngine.formatElementsSummary(elements, root) + otpNotice
        Log.i(TAG, "Screen inspection generated:\n$summary")
        return@withContext summary
    }

    private fun captureCurrentStateSummary(service: JarvisAccessibilityService): String {
        val root = service.getActiveRootNode() ?: return "Screen empty or not accessible."
        val elements = groundingEngine.scanScreen(root)
        val recentOtp = JarvisAccessibilityService.getRecentOtp()
        val otpNotice = if (recentOtp != null) "\n[SYSTEM NOTICE: Detected incoming SMS/Notification OTP: '$recentOtp' (available for auto-entry)]" else ""
        return groundingEngine.formatElementsSummary(elements, root) + otpNotice
    }

    private fun isTogglePhrase(phrase: String): Boolean {
        val lower = phrase.lowercase(Locale.ROOT)
        return lower.contains("switch") || lower.contains("toggle") ||
                lower.contains("enable") || lower.contains("disable") ||
                lower.contains("turn on") || lower.contains("turn off")
    }

    private fun isSensitiveTarget(target: String, desc: String?): Boolean {
        val combined = "$target ${desc ?: ""}".lowercase(Locale.ROOT)
        return combined.contains("pay") || combined.contains("payment") ||
                combined.contains("delete all") || combined.contains("factory reset") ||
                combined.contains("format") || combined.contains("purchase") ||
                combined.contains("transfer money") || combined.contains("send money")
    }

    private fun isClearSearchButton(target: String, desc: String?): Boolean {
        val combined = "$target ${desc ?: ""}".lowercase(Locale.ROOT)
        return combined.contains("clear search") || combined.contains("clear query") ||
                combined.contains("clear text") || combined.contains("clear input")
    }

    private fun isBrowserSearchScreen(service: JarvisAccessibilityService): Boolean {
        val root = service.getAppRootNode() ?: service.getActiveRootNode() ?: return false
        val pkg = root.packageName?.toString() ?: ""
        if (!pkg.contains("chrome", ignoreCase = true) && !pkg.contains("browser", ignoreCase = true)) {
            return false
        }
        val elements = groundingEngine.scanScreen(root)
        return groundingEngine.isGoogleSearchResults(elements)
    }

    private fun isBrowserOverflowMenu(target: UiElementInfo?): Boolean {
        if (target == null) return false
        val text = target.primaryLabel.lowercase(Locale.ROOT)
        val vid = target.viewId.lowercase(Locale.ROOT)
        val desc = target.contentDescription.lowercase(Locale.ROOT)
        return desc.contains("more options") ||
               desc.contains("customize and control") ||
               text.contains("more options") ||
               vid.contains("menu_button") ||
               vid.contains("more_menu") ||
               vid.contains("overflow")
    }
}
```
=== END FILE: app/src/main/java/com/jarvis/assistant/vision/VisualTaskOrchestrator.kt ===
